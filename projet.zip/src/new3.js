/* ======================================================================
   v0.10 : atelier de tuning, icônes 3D, ouverture de paquet, pièces visibles, tout récupérer
   ====================================================================== */

/* ---- icônes 3D (SVG en couches empilées en profondeur, teintées par la rareté) ---- */
const ICO_SPRITE=`<svg id="icospr" width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<linearGradient id="gm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f1f5ff"/><stop offset=".42" stop-color="#9aa6c6"/><stop offset="1" stop-color="#3b4362"/></linearGradient>
<linearGradient id="gd" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#58628a"/><stop offset="1" stop-color="#171a2c"/></linearGradient>
<radialGradient id="gk" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#3a4262"/><stop offset="1" stop-color="#0b0d18"/></radialGradient></defs>
<symbol id="ic-moteur" viewBox="0 0 64 64"><rect x="8" y="28" width="42" height="24" rx="4" fill="url(#gm)"/><rect x="10" y="12" width="38" height="4" rx="2" fill="url(#gm)"/>
<g fill="url(#gd)" stroke="var(--rc)" stroke-width="1.8"><rect x="12" y="16" width="9" height="13" rx="2"/><rect x="25" y="16" width="9" height="13" rx="2"/><rect x="38" y="16" width="9" height="13" rx="2"/></g>
<circle cx="54" cy="40" r="7" fill="url(#gd)" stroke="var(--rc)" stroke-width="2"/><circle cx="54" cy="40" r="2.4" fill="var(--rc)"/><path d="M12 40h34" stroke="var(--rc)" stroke-width="2.4" stroke-linecap="round"/><rect x="12" y="45" width="30" height="3" rx="1.5" fill="#0b0d16" opacity=".45"/></symbol>
<symbol id="ic-turbo" viewBox="0 0 64 64"><path d="M44 22 L58 10 L63 21 L50 31Z" fill="url(#gm)"/><circle cx="30" cy="34" r="23" fill="url(#gm)"/><circle cx="30" cy="34" r="18" fill="url(#gk)" stroke="var(--rc)" stroke-width="2"/>
<g stroke="var(--rc)" stroke-width="3.2" stroke-linecap="round" fill="none"><path id="tb" d="M30 34 q9 -1 11 -12"/><path d="M30 34 q9 -1 11 -12" transform="rotate(60 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(120 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(180 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(240 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(300 30 34)"/></g><circle cx="30" cy="34" r="4" fill="url(#gm)"/></symbol>
<symbol id="ic-echap" viewBox="0 0 64 64"><path d="M4 46 H30 Q38 46 38 38 V34" fill="none" stroke="#56607f" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 44 H30 Q36 44 36 38 V34" fill="none" stroke="#b9c4e2" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M36 22 L56 12 L60 52 L36 44Z" fill="url(#gd)" stroke="var(--rc)" stroke-width="2.4" stroke-linejoin="round"/><ellipse cx="57" cy="32" rx="3.6" ry="14" fill="#06070e" stroke="var(--rc)" stroke-width="1.6"/><path d="M60 24 q4 8 0 16 q8 -8 0 -16z" fill="var(--rc)" opacity=".9"/></symbol>
<symbol id="ic-pneus" viewBox="0 0 64 64"><circle cx="32" cy="32" r="26" fill="#0b0d16" stroke="#3b4260" stroke-width="3"/><circle cx="32" cy="32" r="26" fill="none" stroke="#6a7396" stroke-width="3.4" stroke-dasharray="5 3.2"/>
<circle cx="32" cy="32" r="19" fill="none" stroke="var(--rc)" stroke-width="2.2"/><circle cx="32" cy="32" r="14" fill="url(#gm)"/><circle cx="32" cy="32" r="5" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.6"/><g fill="#0b0d16"><circle cx="32" cy="21" r="1.8"/><circle cx="42" cy="28" r="1.8"/><circle cx="38" cy="40" r="1.8"/><circle cx="26" cy="40" r="1.8"/><circle cx="22" cy="28" r="1.8"/></g></symbol>
<symbol id="ic-freins" viewBox="0 0 64 64"><circle cx="30" cy="34" r="24" fill="url(#gm)"/><circle cx="30" cy="34" r="10" fill="url(#gd)"/><circle cx="30" cy="34" r="3.5" fill="#0b0d16"/><g fill="#0b0d16"><circle cx="30" cy="19" r="2.2"/><circle cx="40.6" cy="23.4" r="2.2"/><circle cx="45" cy="34" r="2.2"/><circle cx="40.6" cy="44.6" r="2.2"/><circle cx="30" cy="49" r="2.2"/><circle cx="19.4" cy="44.6" r="2.2"/><circle cx="15" cy="34" r="2.2"/><circle cx="19.4" cy="23.4" r="2.2"/></g>
<path d="M42 9 a26 26 0 0 1 14 22 l-10 2 a16 16 0 0 0 -7 -13z" fill="var(--rc)" stroke="#06070e" stroke-width="1.2"/><rect x="47" y="14" width="6" height="3" rx="1.5" fill="#fff" opacity=".5" transform="rotate(35 50 15)"/></symbol>
<symbol id="ic-susp" viewBox="0 0 64 64"><rect x="28" y="6" width="8" height="52" rx="3" fill="url(#gm)"/><rect x="24" y="10" width="16" height="18" rx="4" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.8"/>
<path d="M17 28 L47 33 L17 38 L47 43 L17 48 L47 53" fill="none" stroke="#06070e" stroke-width="7" stroke-linejoin="round" stroke-linecap="round" opacity=".5"/><path d="M17 28 L47 33 L17 38 L47 43 L17 48 L47 53" fill="none" stroke="var(--rc)" stroke-width="4.4" stroke-linejoin="round" stroke-linecap="round"/>
<circle cx="32" cy="8" r="5.5" fill="url(#gm)" stroke="var(--rc)" stroke-width="1.8"/><circle cx="32" cy="57" r="5.5" fill="url(#gm)" stroke="var(--rc)" stroke-width="1.8"/></symbol>
<symbol id="ic-chassis" viewBox="0 0 64 64"><g fill="none" stroke="#06070e" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" opacity=".5"><path d="M10 56 V32 L22 12 H42 L54 32 V56 M10 32 H54 M10 56 L54 32 M54 56 L10 32"/></g>
<g fill="none" stroke="#aeb9d8" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10 56 V32 L22 12 H42 L54 32 V56 M10 32 H54 M22 12 L10 32 M42 12 L54 32 M10 56 L54 32 M54 56 L10 32"/></g>
<g fill="url(#gk)" stroke="var(--rc)" stroke-width="2.2"><circle cx="10" cy="32" r="4"/><circle cx="54" cy="32" r="4"/><circle cx="22" cy="12" r="4"/><circle cx="42" cy="12" r="4"/><circle cx="32" cy="32" r="4"/></g></symbol>
<symbol id="ic-aero" viewBox="0 0 64 64"><rect x="24" y="38" width="5" height="18" rx="2" fill="url(#gd)"/><rect x="36" y="38" width="5" height="18" rx="2" fill="url(#gd)"/><rect x="18" y="54" width="28" height="4" rx="2" fill="url(#gd)"/>
<path d="M10 33 H54 L58 38 H6Z" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.6" stroke-linejoin="round"/><path d="M8 22 H56 L61 31 H3Z" fill="url(#gm)" stroke="var(--rc)" stroke-width="1.8" stroke-linejoin="round"/>
<rect x="3" y="12" width="6" height="28" rx="2" fill="var(--rc)"/><rect x="55" y="12" width="6" height="28" rx="2" fill="var(--rc)"/><rect x="12" y="25" width="40" height="2.4" rx="1.2" fill="#fff" opacity=".6"/></symbol>
<symbol id="ic-nitro" viewBox="0 0 64 64"><rect x="26" y="10" width="12" height="12" rx="3" fill="url(#gd)"/><circle cx="32" cy="8" r="5.6" fill="var(--rc)" stroke="#06070e" stroke-width="1.4"/><path d="M38 8 q14 -2 16 12" fill="none" stroke="var(--rc)" stroke-width="3" stroke-linecap="round"/>
<rect x="18" y="20" width="28" height="40" rx="10" fill="url(#gm)"/><rect x="18" y="31" width="28" height="15" fill="var(--rc)"/><rect x="21" y="24" width="4" height="32" rx="2" fill="#fff" opacity=".35"/><path d="M35 32 L27 41 H32 L29 49 L38 39 H33Z" fill="#fff" stroke="#06070e" stroke-width="1" stroke-linejoin="round"/></symbol>
<symbol id="ic-jantes" viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="url(#gk)" stroke="var(--rc)" stroke-width="3"/><circle cx="32" cy="32" r="24" fill="none" stroke="#b9c4e2" stroke-width="1.6"/>
<g stroke="#06070e" stroke-width="9" stroke-linecap="round" opacity=".5"><path d="M32 32 V9"/><path d="M32 32 V9" transform="rotate(72 32 32)"/><path d="M32 32 V9" transform="rotate(144 32 32)"/><path d="M32 32 V9" transform="rotate(216 32 32)"/><path d="M32 32 V9" transform="rotate(288 32 32)"/></g>
<g stroke="#d7dff5" stroke-width="6" stroke-linecap="round"><path d="M32 32 V10"/><path d="M32 32 V10" transform="rotate(72 32 32)"/><path d="M32 32 V10" transform="rotate(144 32 32)"/><path d="M32 32 V10" transform="rotate(216 32 32)"/><path d="M32 32 V10" transform="rotate(288 32 32)"/></g>
<circle cx="32" cy="32" r="8" fill="url(#gm)" stroke="var(--rc)" stroke-width="2"/><circle cx="32" cy="32" r="2.6" fill="#0b0d16"/></symbol>
<symbol id="ic-peinture" viewBox="0 0 64 64"><g fill="var(--rc)" opacity=".85"><circle cx="9" cy="14" r="2.6"/><circle cx="15" cy="9" r="2"/><circle cx="6" cy="22" r="2"/><circle cx="14" cy="19" r="3.2"/><circle cx="20" cy="13" r="1.8"/><circle cx="10" cy="28" r="1.6"/><circle cx="19" cy="24" r="2.2"/></g>
<rect x="26" y="8" width="7" height="8" rx="2" fill="url(#gd)"/><rect x="25" y="14" width="22" height="12" rx="3" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.8"/><rect x="25" y="25" width="22" height="34" rx="6" fill="var(--rc)"/><rect x="25" y="25" width="22" height="34" rx="6" fill="url(#gd)" opacity=".28"/>
<rect x="29" y="28" width="4.5" height="28" rx="2.2" fill="#fff" opacity=".42"/><circle cx="38" cy="42" r="6" fill="#fff" opacity=".85"/><path d="M38 37 q4 5 0 10 q-4 -5 0 -10z" fill="var(--rc)"/></symbol>
</svg>`;
function ico(id,rc,sz,live){
  const u=`<svg viewBox="0 0 64 64"><use href="#ic-${id}"/></svg>`;
  return `<span class="i3${live?' live':''}" style="--rc:${rc};--s:${sz||48}px"><i class="fl"></i><span class="st"><b class="ly l3">${u}</b><b class="ly l2">${u}</b><b class="ly l1">${u}</b></span></span>`;
}
(function(){ if(!document.getElementById('icospr')) document.body.insertAdjacentHTML('afterbegin',ICO_SPRITE); })();

/* ---- ce que chaque module change visuellement ---- */
const VIS={mo1:'',tu1:'Entrée d’air sur le capot',tu2:'Double entrée d’air',tu3:'Compresseur sur le capot',ec1:'Sortie d’échappement',ec2:'Sorties d’échappement',ec3:'Sorties d’échappement',
  su1:'Caisse abaissée',su2:'Caisse légèrement abaissée',su3:'Caisse surélevée, garde au sol rallye',ja1:'Jantes forgées',ja2:'Grosses jantes',ja3:'Jantes XXL néon',
  ae1:'Lame avant',ae2:'Aileron arrière',ae3:'Bas de caisse larges',ch1:'Arceau et pare-buffle',ch2:'Capot carbone',ch3:'Ailes élargies',
  ni1:'Bouteille visible, flamme teintée',ni2:'Bouteille visible, flamme teintée',ni3:'Bouteille visible, flamme teintée',pe1:'Peinture nacrée aux couleurs de la rareté',pe2:'Teinte mate et néon sous la caisse',pe3:'Bandes de course'};
const visOf=m=>'';

/* ---- apparence : suspension, châssis, jantes plus grandes, néons ---- */
/* les modules ne changent plus l'apparence : seulement les statistiques */
carLook=function(c){ if(!c) return {}; if(c.lk) return c.lk; const L={}; if(c.sh) L.shiny=1; return L; };
rndLook=function(lv){ return {}; };
function addLook(g,D,look,wheels){
  if(!look) return;
  const j=look.jantes, s=look.susp, ch=look.chassis, pe=look.peinture, ni=look.nitro;
  const par=wheels[0]&&wheels[0].parent, glb=!!par&&par!==g, ps=glb?(par.scale.y||1):1;
  let ws=j?({ja1:1.05,ja2:1.17,ja3:1.3}[j.t]||1)+.012*j.r:1; if(s&&s.t==='su3') ws*=1.08;
  if(ws!==1) wheels.forEach(w=>{ w.scale.multiplyScalar(ws); w.position.y+=D.wr*(ws-1)/ps; });
  addLook0(g,D,look,wheels);
  const L=D.x1-D.x0, mx=(D.x0+D.x1)/2, dark=new THREE.MeshLambertMaterial({color:0x14151b}), neon=r=>new THREE.MeshBasicMaterial({color:new THREE.Color(RCOL[r])});
  const box=(w,h,d,mat,x,y,z)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat); m.position.set(x,y,z); g.add(m); return m;};
  if(ch){
    if(ch.t==='ch1'){ [1,-1].forEach(sd=>box(L*.34,.04,.04,ch.r>=3?neon(ch.r):dark,mx-.04*L,D.H+.05,sd*D.W*.3)); box(.04,.04,D.W*.6,dark,mx+.13*L,D.H+.05,0); box(.04,.04,D.W*.6,dark,mx-.21*L,D.H+.05,0);
      box(.06,.12,D.W*.84,ch.r>=2?neon(ch.r):dark,D.x1+.05,.34,0); [1,-1].forEach(sd=>box(.05,.22,.05,dark,D.x1+.04,.3,sd*D.W*.3)); }
    else if(ch.t==='ch2'){ box(L*.28,.014,D.W*.42,dark,D.x1-.18*L,D.hood+.014,0); if(ch.r>=2) [1,-1].forEach(sd=>box(L*.28,.016,.02,neon(ch.r),D.x1-.18*L,D.hood+.018,sd*D.W*.21)); box(.3,.014,D.W*.9,dark,D.x0+.1*L,D.deck+.012,0); }
    else wheels.forEach(w=>{ const sg=w.position.z>=0?1:-1, rr=D.wr*ws; box(rr*2.15,.08,.12,dark,w.position.x,rr*1.95+.02,sg*(D.W/2+.03)); if(ch.r>=2) box(rr*2.15,.02,.02,neon(ch.r),w.position.x,rr*1.95-.03,sg*(D.W/2+.09)); });
  }
  if(pe&&pe.t==='pe3'){ const mt=neon(pe.r), wm=new THREE.MeshBasicMaterial({color:0xf4f6ff}); [[D.x1-.2*L,D.hood+.016],[D.x0+.16*L,D.deck+.016]].forEach(q=>{ box(L*.3,.012,.1*D.W,wm,q[0],q[1],-.14*D.W); box(L*.3,.012,.1*D.W,mt,q[0],q[1],.0); box(L*.3,.012,.1*D.W,wm,q[0],q[1],.14*D.W); }); }
  if(ni){ const bm=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,.5,10),neon(ni.r)); bm.rotation.x=Math.PI/2; bm.position.set(D.x0+.2*L,D.deck+.09,.0); g.add(bm); box(.1,.04,.22,dark,D.x0+.2*L,D.deck+.03,0); }
  /* assiette : abaisse ou surélève la caisse, les roues restent au sol */
  let dy=0; if(s) dy={su1:-(.055+.012*s.r),su2:-(.03+.006*s.r),su3:.07+.014*s.r}[s.t]||0; if(glb) dy=Math.max(dy,-.09);
  if(dy){ g.children.slice().forEach(o=>{ if(wheels.includes(o)) return; if(o.geometry&&o.geometry.type==='PlaneGeometry'&&o.material&&o.material.blending===THREE.AdditiveBlending) return; o.position.y+=dy; });
    if(glb) wheels.forEach(w=>{ w.position.y-=dy/ps; }); }
  if(pe&&pe.t==='pe2'){ const ug=new THREE.Mesh(new THREE.PlaneGeometry(L*.96,D.W*1.2),new THREE.MeshBasicMaterial({color:new THREE.Color(RCOL[pe.r]),transparent:true,opacity:.55,blending:THREE.AdditiveBlending,depthWrite:false})); ug.rotation.x=-Math.PI/2; ug.position.set(mx,.045,0); g.add(ug); }
}

/* ---- modules : carte avec icône 3D ---- */
function modHTML(m,act){
  const sl=SLOTS.find(s=>s[0]===MODI[m.t][1]), fx=modFx(m), on=eqCar(m.u), rc=RAR[m.r].c, vs=visOf(m);
  return `<div class="mod mod3 ${m.sh?'shiny':''} ${m.un!=null?'uniq':''}" style="--rc:${rc}">
    <div class="m3h">${ico(sl[0],rc,50,m.r>=3)}<div class="m3t"><span class="rar">${RAR[m.r].n}${m.sh?' ✨':''}</span><div class="mod-name">${modName(m)}</div><span class="slotn">${sl[1]}${m.un!=null?`, unique n° ${String(m.sn).padStart(3,'0')}`:''}</span></div></div>
    ${vs?`<div class="vis">🔧 ${vs}</div>`:''}
    <div class="mod-fx">${Object.keys(fx).map(k=>`<span class="${fx[k]<0?'neg':''}">${fxText(k,fx[k])}</span>`).join('')}</div>
    ${m.un!=null?`<div class="mod-eq">${UNIQ[m.un].d}</div>`:''}${on?`<div class="mod-eq">Monté sur ${M[on.mid].nom}</div>`:''}${act||''}</div>`;
}
const tilesHTML=c=>`<div class="tiles">${SLOTS.map(sl=>{const mm=modOf((c.mods||{})[sl[0]]), rc=mm?RAR[mm.r].c:'#4a5280';
  return `<button class="tile ${mm?'on':''}" style="--rc:${rc}" data-a="modslot" data-id="${sl[0]}">${ico(sl[0],rc,46)}<b>${sl[1]}</b><small>${mm?modName(mm)+(mm.sh?' ✨':''):'Vide'}</small>${mm?`<i class="tr"></i>`:''}</button>`;}).join('')}</div>`;

/* ---- atelier de tuning ---- */
const dChip=(lab,a,b,unit,inv)=>{ const d=Math.round(b-a), good=inv?d<0:d>0; return `<span class="dc ${d===0?'':good?'up':'dn'}">${lab} <b>${fmt(Math.round(b))}${unit}</b>${d?` <i>${d>0?'+':'−'}${fmt(Math.abs(d))}</i>`:''}</span>`; };
function tuneCar(c,slot,pv){ const mods=Object.assign({},c.mods||{}); if(pv) mods[slot]=pv; return Object.assign({},c,{mods,lk:undefined}); }
function tvwHTML(c){
  const slot=sheet.slot, cur=c.mods&&c.mods[slot], pv=sheet.pv&&sheet.pv!==cur?sheet.pv:null, tc=tuneCar(c,slot,pv), s0=st(c), s1=st(tc), sl=SLOTS.find(x=>x[0]===slot);
  const rc=pv?RAR[modOf(pv).r].c:'#00e5ff';
  return `<div class="tvw ${sheet.flash?'flash':''}" style="--rc:${rc}"><div class="tvimg">${thArt(tc)}</div><div class="tscan"></div><div class="tcorner a"></div><div class="tcorner b"></div>
    <div class="tname"><b>${M[c.mid].nom}</b><span>${pv?'Essai : '+modName(modOf(pv)):'Équipement actuel'}</span></div>
    <div class="tdelta">${dChip('Puissance',s0.ch,s1.ch,' ch')}${dChip('Poids',s0.kg,s1.kg,' kg',1)}${dChip('Vmax',s0.vmax,s1.vmax,' km/h')}${dChip('Adhérence',s0.adh,s1.adh,'')}${dChip('Style',s0.sty,s1.sty,'')}</div></div>`;
}
function tbarHTML(c){
  const slot=sheet.slot, cur=c.mods&&c.mods[slot], pv=sheet.pv&&sheet.pv!==cur?modOf(sheet.pv):null, o=pv&&eqOther(pv.u,c);
  if(pv) return `<button class="btn ${o?'mag':'good'} grow2" data-a="tequip">${o?`Reprendre à ${M[o.mid].nom}`:'Monter'} : ${modName(pv)}</button><button class="btn alt" data-a="tprev" data-id="${pv.u}">Annuler</button>`;
  return `<button class="btn alt" data-a="car" data-id="${c.uid}">← Voiture</button><button class="btn good" data-a="eqbest" data-id="${c.uid}">⚡ Meilleures pièces</button>${cur?`<button class="btn danger" data-a="tunun">Retirer</button>`:''}`;
}
function tcardHTML(m,c){
  const cur=c.mods&&c.mods[sheet.slot], o=eqOther(m.u,c), rc=RAR[m.r].c, fx=modFx(m), keys=Object.keys(fx).slice(0,3), isCur=m.u===cur, sel=sheet.pv===m.u||(!sheet.pv&&isCur), vs=visOf(m);
  const cm=cur&&modOf(cur), d=cm?Math.round((modPow(m)/Math.max(.01,modPow(cm))-1)*100):null;
  return `<button class="tcard ${sel?'sel':''} ${isCur?'cur':''}" style="--rc:${rc}" data-a="tprev" data-id="${m.u}">${ico(MODI[m.t][1],rc,54,sel)}
    <span class="tc"><span class="tcn">${modName(m)}${m.sh?' ✨':''}</span><span class="tcr">${RAR[m.r].n}${m.un!=null?' · unique':''}</span>
      <span class="tcf">${keys.map(k=>`<i class="${fx[k]<0?'neg':''}">${fxText(k,fx[k])}</i>`).join('')}</span>${vs?`<span class="tcv">🔧 ${vs}</span>`:''}</span>
    <span class="tcs">${isCur?'<em class="on">Monté</em>':o?`<em class="oth">Sur ${M[o.mid].nom.split(' ')[0]}</em>`:d!=null?`<em class="${d>=0?'up':'dn'}">${d>=0?'▲ +':'▼ −'}${Math.abs(d)} %</em>`:''}</span></button>`;
}
function tuneSheets(X){
  const el=$('sheet');
  if(sheet.t==='modpick'){ sheet.t='tune'; sheet.pv=null; }
  if(sheet.t==='tune'){
    const c=car(sheet.uid); if(!c){closeSheet(); return true;} const slot=sheet.slot||SLOTS[0][0], cur=c.mods&&c.mods[slot];
    sheet.slot=slot;
    const list=S.mods.filter(m=>MODI[m.t][1]===slot).sort((a,b)=>(b.u===cur)-(a.u===cur)||(!!eqOther(a.u,c))-(!!eqOther(b.u,c))||b.r-a.r||modPow(b)-modPow(a));
    el.innerHTML=`${X}<h2>Atelier de tuning</h2><div id="tvw">${tvwHTML(c)}</div>
      <div class="tstrip">${SLOTS.map(sl=>{const mm=modOf((c.mods||{})[sl[0]]), rc=mm?RAR[mm.r].c:'#4a5280'; return `<button class="ts ${sl[0]===slot?'on':''} ${mm?'eq':''}" style="--rc:${rc}" data-a="tslot" data-id="${sl[0]}">${ico(sl[0],rc,36)}<small>${sl[1]}</small></button>`;}).join('')}</div>
      <div class="thead"><b>${SLOTS.find(s=>s[0]===slot)[1]}</b><span>${list.length} module${list.length>1?'s':''}</span></div>
      <div class="tlist">${list.length?list.slice(0,60).map(m=>tcardHTML(m,c)).join(''):`<div class="tempty">Aucun module de ce type. Ouvre des paquets pour en trouver.<button class="btn sm" data-a="tab" data-id="cartes">Aller aux paquets</button></div>`}</div>
      <div class="tbar" id="tbar">${tbarHTML(c)}</div>`;
    const on=el.querySelector('.ts.on'); if(on&&on.scrollIntoView) try{ on.scrollIntoView({block:'nearest',inline:'center'}); }catch(_){ }
    return true;
  }
  if(sheet.t==='open') return openStage(X);
  return false;
}
function tuneRefresh(){
  const c=car(sheet.uid), a=$('tvw'), b=$('tbar'); if(!c||!a||!b) return renderSheet();
  a.innerHTML=tvwHTML(c); b.innerHTML=tbarHTML(c);
  document.querySelectorAll('.tcard').forEach(e=>{ const u=+e.dataset.id, cur=c.mods&&c.mods[sheet.slot]; e.classList.toggle('sel',sheet.pv===u||(!sheet.pv&&u===cur)); });
}
Object.assign(ACT,{
  modslot(d){ openSheet({t:'tune',uid:sheet.uid,slot:d.id,pv:null}); },
  tslot(d){ sheet.slot=d.id; sheet.pv=null; sheet.flash=0; renderSheet(); },
  tprev(d){ const u=+d.id, c=car(sheet.uid); if(!c) return; sheet.pv=sheet.pv===u?null:u; sheet.flash=0; tuneRefresh(); const m=modOf(u); if(m&&sheet.pv) auTry(()=>auCard(Math.min(m.r,3),false,false)); },
  tequip(){ const c=car(sheet.uid), u=sheet.pv, m=modOf(u); if(!c||!m) return; if(eqOther(u,c)) return openSheet({t:'eqconf',uid:c.uid,slot:sheet.slot,u});
    equipMod(c,u,sheet.slot); sheet.pv=null; sheet.flash=1; bump('eqN'); save(); render(); renderSheet(); setTimeout(()=>{ if(sheet&&sheet.t==='tune') sheet.flash=0; },900); auTry(()=>auCard(m.r,m.sh,m.un!=null)); toast(`${modName(m)} montée`); },
  tunun(){ const c=car(sheet.uid); if(!c||!c.mods) return; delete c.mods[sheet.slot]; sheet.pv=null; save(); render(); renderSheet(); toast('Module retiré'); }
});

/* ---- ouverture d'un paquet : scène de révélation ---- */
const rcOf=m=>RAR[m.r].c;
function bigCard(m,anim){
  const sl=SLOTS.find(s=>s[0]===MODI[m.t][1]), fx=modFx(m), rc=rcOf(m), vs=visOf(m);
  return `<div class="bigc ${anim?'in':''} ${m.sh?'sh':''} ${m.un!=null?'un':''}" style="--rc:${rc}"><div class="foil"></div>
    <div class="bt"><span>${sl[1]}</span><span class="rar">${RAR[m.r].n}${m.sh?' ✨':''}</span></div>${ico(sl[0],rc,92,1)}
    <div class="bn">${modName(m)}</div>${m.un!=null?`<div class="bu">UNIQUE n° ${String(m.sn).padStart(3,'0')}</div>`:''}
    ${vs?`<div class="bv">🔧 ${vs}</div>`:''}<div class="bfx">${Object.keys(fx).slice(0,3).map(k=>`<span class="${fx[k]<0?'neg':''}">${fxText(k,fx[k])}</span>`).join('')}</div><div class="bq">Qualité ${Math.round(m.q*100)} %</div></div>`;
}
const backCard=(pk)=>{ const th=PKT[pk.id]||PKT.p1; return `<div class="bigc back in" style="--c1:${th.c1};--c2:${th.c2};--c3:${th.c3}"><div class="foil"></div><div class="bq0">R&amp;G</div><div class="bm">?</div><div class="bq1">${th.tag}</div></div>`; };
const burstHTML=m=>{ let s=''; const n=10+m.r*4; for(let k=0;k<n;k++){ const a=k/n*360+rint(-8,8), d=rint(90,190); s+=`<i style="--a:${a}deg;--d:${d}px;--w:${rint(4,9)}px"></i>`; } return `<div class="burst" style="--rc:${rcOf(m)}">${s}</div>`; };
function openStage(X){
  const n=sheet.cards.length, i=sheet.i, done=i>=n, pk=PACKS.find(p=>p.id===sheet.pk)||PACKS[0], el=$('sheet');
  const ms=sheet.cards.map(modOf).filter(Boolean);
  if(done){
    const best=ms.slice().sort((a,b)=>b.r-a.r||modPow(b)-modPow(a)), b0=best[0];
    el.innerHTML=`${X}<h2>${pk.nom}</h2><div class="orec" style="--rc:${b0?rcOf(b0):'#00e5ff'}"><div class="ohd">Résultat</div><p class="note" style="margin:0 0 10px">Meilleur tirage : <b style="color:${b0?rcOf(b0):'inherit'}">${b0?modName(b0):''}</b>${b0?` (${RAR[b0.r].n}${b0.sh?', brillant':''}${b0.un!=null?', unique':''})`:''}. Tout est dans ton inventaire.</p>
      <div class="rgrid">${best.map((m,k)=>{const sl=MODI[m.t][1]; return `<div class="rmini ${k===0?'top':''} ${m.sh?'sh':''}" style="--rc:${rcOf(m)};animation-delay:${k*70}ms">${ico(sl,rcOf(m),k===0?64:46,k===0)}<b>${modName(m)}</b><small>${RAR[m.r].n}${m.sh?' ✨':''}</small></div>`;}).join('')}</div></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="close">Fermer</button><button class="btn" data-a="pack" data-id="${pk.id}" data-k="cr" ${S.cr<pk.cr?'disabled':''}>Encore un, ${cr(pk.cr)}</button></div>
      <button class="btn good wide" style="margin-top:8px" data-a="eqcaropen">⚡ Équiper les meilleures pièces sur une voiture</button>`;
    return true;
  }
  const cur=i>0?modOf(sheet.cards[i-1]):null, anim=!!sheet.anim, rc=cur?rcOf(cur):'#00e5ff';
  const deck=Math.min(3,n-i-(cur?0:1));
  el.innerHTML=`${X}<h2>${pk.nom}</h2><div class="ocount"><b>${i}</b> / ${n}</div>
    <div class="ostage ${cur&&cur.r>=4&&anim?'shake':''}" data-a="reveal" style="--rc:${rc}"><div class="rays ${cur&&cur.r>=3?'on':''}"></div>
      ${Array.from({length:deck}).map((_,k)=>`<div class="dk" style="--k:${k+1}"></div>`).join('')}
      ${cur?bigCard(cur,anim):backCard(pk)}${anim&&cur&&cur.r>=2?burstHTML(cur):''}${anim&&cur&&cur.r>=3?`<div class="oflash"></div>`:''}
      <div class="ohint">${i===0?'Touche la carte pour révéler le premier module':n-i===1?'Touche pour le dernier module':'Touche pour le module suivant'}</div></div>
    <div class="otray">${sheet.cards.slice(0,Math.max(0,i-1)).map(modOf).filter(Boolean).map(m=>`<span class="mt" style="--rc:${rcOf(m)}">${ico(MODI[m.t][1],rcOf(m),32)}</span>`).join('')}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px"><button class="btn" data-a="reveal">${i===0?'Révéler':'Suivant'}</button><button class="btn alt" data-a="revealall">Tout révéler</button></div>`;
  return true;
}
Object.assign(ACT,{
  reveal(){ if(!sheet||sheet.t!=='open'||sheet.i>=sheet.cards.length) return; const m=modOf(sheet.cards[sheet.i]); sheet.i++; auCard(m.r,m.sh,m.un!=null); sheet.anim=1; renderSheet(); sheet.anim=0; if(sheet.i>=sheet.cards.length) $('sheet').scrollTop=0; },
  revealall(){ if(!sheet||sheet.t!=='open') return; let best=null; while(sheet.i<sheet.cards.length){const m=modOf(sheet.cards[sheet.i++]); if(!best||m.r>best.r) best=m;} if(best) auCard(best.r,best.sh,best.un!=null); sheet.anim=0; renderSheet(); }
});

/* ---- missions : tout récupérer ---- */
function claimList(){
  questsEnsure(); const L=[];
  if(S.daily!==dayKey()) L.push(['daily']);
  [['dq',DQ],['wq',WQ]].forEach(([k,T])=>S[k].ids.forEach(id=>{ const q=T.find(x=>x.id===id); if(q&&!S[k].cl[id]&&qProg(S[k],q)>=q.n) L.push([k,id]); }));
  MISSIONS.forEach(m=>{ if(!S.claimed[m.id]){ const p=m.p(S); if(p[0]>=p[1]) L.push(['m',m.id]); } });
  return L;
}
function claimTotal(L){
  const g={cr:0,tok:0,nitro:0,xp:0}, add=x=>{g.cr+=x.cr||0; g.tok+=x.tok||0; g.nitro+=x.nitro||0; g.xp+=x.xp||0;};
  L.forEach(([k,id])=>{ if(k==='daily') add(dailyReward()); else if(k==='m') add(MISSIONS.find(m=>m.id===id).g); else add(qRew((k==='dq'?DQ:WQ).find(x=>x.id===id))); });
  return g;
}
const claimBar=()=>{ const L=claimList(); if(!L.length) return `<div class="claimall off">Aucune récompense à récupérer pour l’instant.</div>`; const g=claimTotal(L);
  return `<button class="btn good wide claimall" data-a="claimall"><b>🎁 Tout récupérer</b><span>${L.length} récompense${L.length>1?'s':''} : ${gText(g)}</span></button>`; };
ACT.claimall=function(){
  const L=claimList(); if(!L.length) return toast('Rien à récupérer');
  const g=claimTotal(L);
  L.forEach(([k,id])=>{
    if(k==='daily'){ const y=new Date(Date.now()-864e5), yk=y.getFullYear()+'-'+(y.getMonth()+1)+'-'+y.getDate(); S.streak=S.daily===yk?(S.streak||0)+1:1; S.daily=dayKey(); }
    else if(k==='m') S.claimed[id]=1;
    else S[k].cl[id]=1;
  });
  giveG(g); toast('Tout récupéré : '+[g.cr?fmt(g.cr)+' cr':'',g.nitro?g.nitro+' nitro':'',g.xp?g.xp+' XP':'',g.tok?g.tok+' jeton'+(g.tok>1?'s':''):''].filter(Boolean).join(', ')); save(); render();
};
