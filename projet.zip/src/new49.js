/* ---- v1.2b : boutons de course. DRIFT remplace le gros NITRO, GAZ agrandi, NITRO réduit ---- */
function pad49(h){
  try{
    if(!RC||(RC.kind!=='spa'&&RC.kind!=='race')||(RC.kind==='race'&&RC.mn&&RC.mn.d==='drag')) return h;
    const spa=RC.kind==='spa', auto=!!RC.auto, a=h.indexOf(spa?'<div class="padS">':'<div class="pad3">'), b=h.indexOf('<div id="over"');
    if(a<0||b<0||b<a) return h;
    let steer=''; if(spa){ const s=h.indexOf('<div id="steerZone"',a), e=h.indexOf('<button id="pBrk"',a); if(s<0||e<0) return h; steer=h.slice(s,e); }
    const pad=`<div class="${spa?'padS':'pad3'} pad49 ${spa?'':'p3'}">${steer}
      <div class="nbk"><button id="pNit" class="pedal nit">Nitro<small>×${S.nitro}</small></button><button id="pBrk" class="pedal brk" ${auto?'disabled':''}><span>${auto?'Auto':'Frein'}</span></button></div>
      <button id="pHnd" class="pedal hnd big" ${auto?'disabled':''}><span>Drift</span><small>frein à main</small></button>
      <button id="pGas" class="pedal gas big" ${auto?'disabled':''}><i id="gasPed"></i><span>${auto?'Auto':'Gaz'}<small>${auto?'':'glisse vers le bas pour doser'}</small></span></button>
    </div>
    `;
    h=h.slice(0,a)+pad+h.slice(b);
    if(!spa&&h.indexOf('id="hDrift"')<0) h=h.replace('<div class="hud-lights"','<div class="hud-drift" id="hDrift"></div><div class="hud-lights"');
    return h;
  }catch(e){ try{console.warn('pad49',e);}catch(_){} return h; }
}
{ const _vr=vRace; vRace=function(){ return pad49(_vr.apply(this,arguments)); }; }
{ const _br=bindRace; bindRace=function(){ _br.apply(this,arguments);
  try{ if(RC&&RC.kind==='race'){ const hd=$('pHnd'); if(hd&&!hd._b49){ hd._b49=1;
    hd.addEventListener('pointerdown',e=>{e.preventDefault(); try{hd.setPointerCapture(e.pointerId);}catch(_){} RC.inp.hand=true; hd.classList.add('on');});
    const hu=()=>{RC.inp.hand=false; hd.classList.remove('on');}; hd.addEventListener('pointerup',hu); hd.addEventListener('pointercancel',hu); hd.addEventListener('contextmenu',e=>e.preventDefault()); } } }catch(e){} }; }
