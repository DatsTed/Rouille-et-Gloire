import re
s=open('main_v09.js',encoding='utf-8').read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a); assert n==cnt,(n,cnt,a[:70]); s=s.replace(a,b)
rep("function addLook(g,D,look,wheels){\n  if(!look) return;","function addLook0(g,D,look,wheels){\n  if(!look) return;")
rep("function eqSheets(X){\n  const el=$('sheet');","function eqSheets(X){\n  const el=$('sheet');\n  if(tuneSheets(X)) return true;")
# grille de tuiles dans la fiche voiture
i=s.index('<div class="slots">${SLOTS.map(sl=>{const mm=modOf((c.mods||{})[sl[0]]);')
j=s.index("</div></div>\n",i)
s=s[:i]+"${tilesHTML(c)}"+s[j+len("</div>"):]
rep("""restant${left>1?'s':''}</p></div>\n  <div class="row ${can?'':'locked'}">""","""restant${left>1?'s':''}</p></div>\n  ${claimBar()}\n  <div class="row ${can?'':'locked'}">""")
n3=open('new3.js',encoding='utf-8').read()
rep("setInterval(updPod,4000);",n3+"\nsetInterval(updPod,4000);")
s=s.replace("démo v0.9","démo v0.10")
open('main_v010.js','w',encoding='utf-8').write(s); print('ok',len(s))
