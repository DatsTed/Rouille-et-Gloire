src=open('orig.html',encoding='utf-8').read()
i=src.rfind('<script>'); e=src.find('</script>',i)
js=open('main.js',encoding='utf-8').read()
head=src[:i]
css=open('extra.css',encoding='utf-8').read()+open('extra3.css',encoding='utf-8').read()+open('extra4.css',encoding='utf-8').read()+open('extra5.css',encoding='utf-8').read()
import re
css=re.sub(r'/\*.*?\*/','',css,flags=re.S); css=re.sub(r'\n\s*','',css)
k=head.find('</style>'); assert k>0
head=head[:k]+css+head[k:]
out=head+open('/home/claude/w/models_new.html',encoding='utf-8').read()+'<script>'+js+src[e:]
open('/home/claude/w/out.html','w',encoding='utf-8').write(out); print(round(len(out)/1e6,2),'Mo')
