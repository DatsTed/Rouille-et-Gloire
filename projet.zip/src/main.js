
/* =====================================================================
   ROUILLE & GLOIRE — démo v0.14
   1) DONNÉES : tout le contenu du jeu (voitures, pièces, épreuves,
      circuits, bâtiments, missions). On ajoute du contenu ici.
   2) MOTEUR : calculs, sauvegarde, écrans.
   3) COURSE : physique, pilote automatique, affichage.
   ===================================================================== */

/* ---------- 1) DONNÉES ---------- */
const SAVE_VERSION = 3;
const KEY = 'rouille_gloire_save';

const TIERS = [null,
  {n:'Populaire', c:'#7E8A94'},
  {n:'Standard',  c:'#2F9460'},
  {n:'Sport',     c:'#2B7BD6'},
  {n:'Prestige',  c:'#8B55D9'},
  {n:'Supercar',  c:'#E09A12'},
  {n:'Hypercar',  c:'#E0354B'}
];
const TR = {FWD:'traction', RWD:'propulsion', AWD:'4 roues motrices'};

/* Marques et modèles inventés. adh/fre/man/fia/sty sont notés sur 100. */
const CARS = [
  {id:'piccola', nom:'Veloz Piccola',   an:1992, cat:'Citadine',   shape:'hatch',  tr:'FWD', t:1, ch:55,   nm:88,   kg:780,  vmax:150, adh:38, fre:35, man:50, fia:60, sty:20, val:800,    col:'#C8503C'},
  {id:'kombi',   nom:'Brenner Kombi',   an:1988, cat:'Break',      shape:'wagon',  tr:'RWD', t:1, ch:115,  nm:185,  kg:1350, vmax:175, adh:40, fre:40, man:38, fia:80, sty:25, val:1500,   col:'#7C8B5A'},
  {id:'steppe',  nom:'Marova Steppe',   an:1985, cat:'4x4',        shape:'suv',    tr:'AWD', t:1, ch:75,   nm:130,  kg:1150, vmax:135, adh:55, fre:30, man:40, fia:65, sty:30, val:1800,   col:'#B89A5E'},
  {id:'riva',    nom:'Kaido Riva SR',   an:2004, cat:'Compacte',   shape:'hatch',  tr:'FWD', t:2, ch:125,  nm:150,  kg:1050, vmax:195, adh:52, fre:50, man:62, fia:85, sty:35, val:4000,   col:'#3E7FB8'},
  {id:'hauler',  nom:'Dalton Hauler V8',an:1998, cat:'Pick-up',    shape:'pickup', tr:'RWD', t:2, ch:210,  nm:420,  kg:1900, vmax:170, adh:42, fre:38, man:30, fia:75, sty:40, val:5000,   col:'#8A2F2A'},
  {id:'patrouille',nom:'Brenner Patrouille',an:2016,cat:'Utilitaire',shape:'van',tr:'FWD',t:2,ch:180,nm:400,kg:1950,vmax:185,adh:48,fre:45,man:35,fia:80,sty:50,val:9000,col:'#E6ECF2',glb:'patrouille'},
  {id:'velo',  nom:'Vélo d’estafette 1940',an:1940,cat:'Vélo',shape:'bike',tr:'RWD',t:1,ch:1,nm:40,kg:95,vmax:42,adh:28,fre:22,man:82,fia:92,sty:68,val:600,col:'#4d5a3c',glb:'velo',noAI:true},
  {id:'subi',  nom:'Kaido Tento 360',  an:1968, cat:'Classique', shape:'hatch', tr:'RWD', t:1, ch:25,  nm:34,  kg:410,  vmax:110, adh:32, fre:26, man:58, fia:55, sty:62, val:2600,   col:'#e8dfc8',glb:'subi'},
  {id:'audi',  nom:'Ostwald Executive',an:2014, cat:'Berline',   shape:'sedan', tr:'AWD', t:3, ch:245, nm:580, kg:1790, vmax:250, adh:66, fre:62, man:58, fia:78, sty:58, val:16000,  col:'#20242b',glb:'audi'},
  {id:'merco', nom:'Sternberg Elegance',an:2012,cat:'Berline',   shape:'sedan', tr:'RWD', t:3, ch:306, nm:370, kg:1735, vmax:250, adh:62, fre:60, man:55, fia:80, sty:72, val:21000,  col:'#c9ccd2',glb:'merco'},
  {id:'touge',   nom:'Kaido Touge S',   an:1996, cat:'Drift',      shape:'coupe',  tr:'RWD', t:3, ch:130,  nm:150,  kg:950,  vmax:200, adh:55, fre:52, man:78, fia:78, sty:55, val:9000,   col:'#E8E4DA'},
  {id:'fury',    nom:'Stallion Fury',   an:2012, cat:'Muscle car', shape:'coupe',  tr:'RWD', t:3, ch:420,  nm:530,  kg:1650, vmax:250, adh:55, fre:55, man:48, fia:70, sty:65, val:18000,  col:'#D9741C'},
  {id:'rx4',     nom:'Nordik RX4',      an:2009, cat:'Rallye',     shape:'sedan',  tr:'AWD', t:4, ch:300,  nm:410,  kg:1300, vmax:230, adh:78, fre:68, man:75, fia:72, sty:60, val:28000,  col:'#2456A6'},
  {id:'gts',     nom:'Brenner GT-S',    an:2018, cat:'Sportive',   shape:'coupe',  tr:'RWD', t:4, ch:430,  nm:550,  kg:1550, vmax:280, adh:76, fre:75, man:78, fia:74, sty:68, val:45000,  col:'#4B5560'},
  {id:'volta',   nom:'Volta E-GT',      an:2023, cat:'Électrique', shape:'sedan',  tr:'AWD', t:4, ch:600,  nm:850,  kg:2100, vmax:250, adh:74, fre:70, man:62, fia:88, sty:66, val:60000,  col:'#3FA7A0'},
  {id:'majestic',nom:'Albion Majestic', an:2021, cat:'Luxe',       shape:'sedan',  tr:'AWD', t:5, ch:550,  nm:900,  kg:2300, vmax:300, adh:65, fre:66, man:50, fia:80, sty:95, val:120000, col:'#2B3A2E'},
  {id:'rossa',   nom:'Corsa Rossa V8',  an:2020, cat:'Supercar',   shape:'super',  tr:'RWD', t:5, ch:670,  nm:760,  kg:1450, vmax:330, adh:88, fre:88, man:88, fia:62, sty:92, val:220000, col:'#C8202B'},
  {id:'aurion',  nom:'Aurion W16',      an:2024, cat:'Hypercar',   shape:'super',  tr:'AWD', t:6, ch:1500, nm:1600, kg:1995, vmax:420, adh:90, fre:90, man:78, fia:60, sty:98, val:900000, col:'#1F2A44'}
];

/* Paliers d'amélioration : niveau 0 à 4 */
const PALIERS = ['Stock','Street','Sport','Course','Élite'];
const PARTS = [
  {id:'moteur', nom:'Moteur',      ic:'⚙️', effet:'+8 % de puissance et de couple', apply:(s,l)=>{s.ch*=1+.08*l; s.nm*=1+.08*l; s.vmax*=1+.02*l;}},
  {id:'pneus',  nom:'Pneus',       ic:'⭕', effet:'+5 d’adhérence',                 apply:(s,l)=>{s.adh+=5*l;}},
  {id:'freins', nom:'Freins',      ic:'🛑', effet:'+5 de freinage',                 apply:(s,l)=>{s.fre+=5*l;}},
  {id:'susp',   nom:'Suspension',  ic:'🔩', effet:'+5 de maniabilité',              apply:(s,l)=>{s.man+=5*l;}},
  {id:'poids',  nom:'Allègement',  ic:'🪶', effet:'−4 % de poids',                  apply:(s,l)=>{s.kg*=1-.04*l;}},
  {id:'fiab',   nom:'Fiabilisation',ic:'🧰', effet:'+5 de fiabilité',               apply:(s,l)=>{s.fia+=5*l;}},
  {id:'carro',  nom:'Carrosserie', ic:'🎨', effet:'+5 de style',                    apply:(s,l)=>{s.sty+=5*l;}}
];

/* Disciplines : w = poids de chaque note, tr = bonus selon la transmission */
const DISC = {
  drag:     {nom:'Drag',                 ic:'🏁', w:{acc:.6,vit:.15,adh:.15,fia:.1},          tr:{AWD:1.05,RWD:1,FWD:.95},  aide:'L’accélération décide. Les 4 roues motrices aident au départ.'},
  circuit:  {nom:'Circuit',              ic:'🛣️', w:{adh:.3,man:.25,fre:.2,acc:.15,vit:.1},   tr:{},                         aide:'Sur le circuit de Spa tu pilotes vraiment : direction, gaz, frein, nitro. Herbe, gravier et sable te ralentissent, les murs abîment ta voiture.'},
  rallye:   {nom:'Rallye',               ic:'🌲', w:{man:.3,adh:.2,acc:.2,fia:.2,fre:.1},     tr:{AWD:1.15,FWD:1.03,RWD:.93},aide:'Maniabilité et fiabilité. Avantage aux 4 roues motrices.'},
  drift:    {nom:'Drift',                ic:'💨', w:{man:.4,pui:.35,fre:.15,adh:.1},          tr:{RWD:1.2,AWD:.9,FWD:.65},   aide:'Sur le circuit, maintiens « Drift » (frein à main) en tournant : plus tu glisses longtemps, plus le multiplicateur monte. Le meilleur score gagne. La propulsion est reine.'},
  endurance:{nom:'Endurance',            ic:'⏱️', w:{fia:.45,vit:.2,fre:.2,adh:.15},          tr:{},                         aide:'La fiabilité d’abord, puis la vitesse de pointe.'},
  elegance: {nom:'Concours d’élégance',  ic:'🏆', w:{sty:.65,etat:.35}, tr:{}, calme:true,                                   aide:'Pas de course : un jury note le style et l’état de la voiture.'}
};
const METEO = {
  sec:   {nom:'sur le sec',       ic:'☀️'},
  pluie: {nom:'sous la pluie',    ic:'🌧️', f:s=>(.78+s.adh/400)*(s.tr==='AWD'?1.05:1)},
  neige: {nom:'sur la neige',     ic:'❄️', f:s=>(.6+s.adh/300)*({AWD:1.15,FWD:1,RWD:.88}[s.tr])}
};

/* Épreuves : opp = adversaires (catégories min/max, palier des pièces, état min/max) */
const EVENTS = [
  {id:'e1', nom:'Spa : La Source et Eau Rouge',lvl:1, gain:700,   xp:30,  opp:{t:[1,1],up:0,etat:[30,55]},  manches:[{d:'circuit',m:'sec',sp:'s1'}]},
  {id:'e2', nom:'Run du parking',          lvl:1,  gain:800,   xp:35,  opp:{t:[1,1],up:0,etat:[28,48]},  manches:[{d:'drag',m:'sec'}]},
  {id:'e3', nom:'Chemin de ferme',         lvl:2,  gain:900,   xp:40,  opp:{t:[1,1],up:0,etat:[40,65]},  manches:[{d:'rallye',m:'pluie'}]},
  {id:'e4', nom:'Nuit pluvieuse',          lvl:3,  gain:1800,   xp:70,  opp:{t:[1,2],up:0,etat:[50,80]},  manches:[{d:'circuit',m:'pluie',sp:'s5'},{d:'drag',m:'pluie'}]},
  {id:'e5', nom:'Rassemblement du dimanche',lvl:4, gain:2200,   xp:90,  opp:{t:[1,2],up:1,etat:[60,90]},  manches:[{d:'elegance',m:'sec'},{d:'drift',m:'sec'}]},
  {id:'e6', nom:'Coupe régionale',         lvl:5,  gain:4000,  xp:150, opp:{t:[2,3],up:1,etat:[70,100]}, manches:[{d:'circuit',m:'sec',sp:'s3'},{d:'rallye',m:'sec'},{d:'drag',m:'sec'}]},
  {id:'e7', nom:'Spéciale des cimes',      lvl:7,  gain:8000,  xp:260, opp:{t:[3,4],up:2,etat:[80,100]}, manches:[{d:'rallye',m:'neige'},{d:'circuit',m:'pluie',sp:'s2'},{d:'endurance',m:'sec'}]},
  {id:'e8', nom:'Trophée Prestige',        lvl:9,  gain:18000, xp:420, opp:{t:[4,5],up:2,etat:[90,100]}, manches:[{d:'elegance',m:'sec'},{d:'circuit',m:'sec',sp:'s4'},{d:'drag',m:'sec'}]},
  {id:'e9', nom:'Grand Prix des Légendes', lvl:12, gain:50000, xp:700, opp:{t:[5,6],up:3,etat:[100,100]},manches:[{d:'drift',m:'sec'},{d:'endurance',m:'pluie'},{d:'circuit',m:'sec',sp:'tour'}]}
];

/* Bâtiments : cout[n] = prix pour passer au niveau n+1 */
const BATS = [
  {id:'atelier',   nom:'Atelier',            ic:'🔧', max:5, cout:[0,1500,6000,25000,90000],
   effet:l=>`Pièces jusqu’au palier ${PALIERS[Math.min(4,l)]}, réparations −${(l-1)*10} %`},
  {id:'casse',     nom:'Casse automobile',   ic:'🏚️', max:5, cout:[0,2500,10000,40000,150000],
   effet:l=>{const r=CASSE_T[l-1];return `Épaves de ${TIERS[r[0]].n} à ${TIERS[r[1]].n}`}},
  {id:'bureau',    nom:'Bureau des contrats',ic:'📋', max:5, cout:[1000,4000,15000,60000,200000],
   effet:l=>l?`Gains des épreuves +${l*10} %`:'Augmente les gains des épreuves'},
  {id:'concession',nom:'Concession',         ic:'🏢', max:5, cout:[2000,8000,30000,100000,400000],
   effet:l=>l?`Voitures neuves jusqu’à ${TIERS[l+1].n}`:'Vend des voitures neuves, en parfait état'}
];
const CASSE_T = [[1,2],[1,3],[2,4],[3,5],[3,6]];

/* Missions : p renvoie [progression, objectif], g = récompense */
const MISSIONS = [
  {id:'m1', t:'Remets une voiture à 100 % d’état',     p:s=>[s.stats.repFull,1],  g:{cr:300}},
  {id:'m2', t:'Gagne ta première épreuve',             p:s=>[s.stats.wins,1],     g:{cr:300,nitro:1}},
  {id:'m3', t:'Installe une amélioration',             p:s=>[s.stats.ups,1],      g:{cr:400}},
  {id:'m4', t:'Possède 2 voitures',                    p:s=>[s.cars.length,2],    g:{cr:500}},
  {id:'m5', t:'Gagne 5 épreuves',                      p:s=>[s.stats.wins,5],     g:{cr:1000,nitro:2}},
  {id:'m6', t:'Améliore un bâtiment',                  p:s=>[s.stats.bats,1],     g:{cr:800}},
  {id:'m7', t:'Gagne une épreuve à 3 manches',         p:s=>[s.stats.wins3,1],    g:{cr:2500}},
  {id:'m8', t:'Possède une voiture Sport ou mieux',    p:s=>[s.cars.some(c=>M[c.mid].t>=3)?1:0,1], g:{cr:3000,nitro:3}},
  {id:'m9', t:'Atteins le niveau 10',                  p:s=>[s.lvl,10],           g:{cr:15000}},
  {id:'m10',t:'Possède une Hypercar',                  p:s=>[s.cars.some(c=>M[c.mid].t>=6)?1:0,1], g:{cr:100000}},
  {id:'m13',t:'Ouvre un paquet de cartes',             p:s=>[s.stats.packs||0,1],  g:{tok:2}},
  {id:'m14',t:'Monte 3 modules sur une même voiture',  p:s=>[s.stats.eq||0,3],     g:{cr:1500,tok:2}},
  {id:'m15',t:'Obtiens un module Épique ou mieux',     p:s=>[(s.stats.best||0)>=3?1:0,1], g:{tok:5}},
  {id:'m16',t:'Monte sur le podium d’une course à 6',  p:s=>[s.stats.pods||0,1],   g:{cr:2000,tok:2}},
  {id:'m11',t:'Expose une voiture sur un podium',      p:s=>[s.pod.slots.some(u=>u)?1:0,1], g:{cr:600}},
  {id:'m12',t:'Amène tes podiums au niveau 3',         p:s=>[s.pod.tier,3],       g:{cr:5000,nitro:2}}
];

/* Circuits : ['S', longueur en m] = ligne droite, ['C', longueur, vitesse de base en km/h] = virage */
const TRACKS = {
  drag:     [['S',900]],
  circuit:  [['S',240],['C',80,70],['S',200],['C',60,55],['S',180],['C',100,88],['S',150]],
  rallye:   [['S',120],['C',60,52],['S',100],['C',50,45],['S',90],['C',70,60],['S',110],['C',50,45],['S',100]],
  drift:    [['S',100],['C',90,55],['S',60],['C',90,50],['S',60],['C',110,60],['S',80]],
  endurance:[['S',420],['C',80,85],['S',460],['C',90,80],['S',420]]
};
/* Spa-Francorchamps : secteurs de course (abscisses en mètres le long de la piste) */
const SPA_STAGES = [{"id": "s1", "nom": "La Source, Eau Rouge, Raidillon", "a": 0, "b": 1300}, {"id": "s2", "nom": "Kemmel et Les Combes", "a": 1300, "b": 2650}, {"id": "s3", "nom": "Malmedy, Rivage, Pouhon", "a": 2650, "b": 4300}, {"id": "s4", "nom": "Pouhon, Fagnes, Campus", "a": 4300, "b": 5200}, {"id": "s5", "nom": "Stavelot, Blanchimont, Bus Stop", "a": 5200, "b": 7051.4}, {"id": "tour", "nom": "Tour complet de Spa-Francorchamps", "a": 0, "b": 7051.4}];
const NITRO_PRIX = 150;
const NITRO_DUREE = 2.5;

/* Showroom : podiums. POD_LVL = niveau du joueur requis pour chaque emplacement */
const POD_MAX = 8;
const POD_LVL = [1,1,3,5,7,9,12,15];
const POD_TIER = [null,
  {n:'Standard',      cost:0,      lvl:1},
  {n:'Néon',          cost:3000,   lvl:3},
  {n:'Plateau tournant',cost:12000,lvl:6},
  {n:'Projecteur',    cost:50000,  lvl:10},
  {n:'Or',            cost:200000, lvl:15}
];
const TABS = [['garage','🚗','Garage'],['hub','🗺️','Monde'],['epreuves','🏁','Épreuves'],['cartes','🃏','Cartes'],['marche','🛒','Marché'],['base','🏗️','Base'],['missions','📜','Missions']];

/* ---------- 2) MOTEUR ---------- */
const M = Object.fromEntries(CARS.map(c=>[c.id,c]));
const $ = id=>document.getElementById(id);
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
const rnd = (a,b)=>a+Math.random()*(b-a);
const rint = (a,b)=>Math.floor(rnd(a,b+1));
const fmt = n=>Math.round(n).toLocaleString('fr-FR');
const fmtT = t=>t.toFixed(2).replace('.',',')+'&nbsp;s';
const cr = n=>`${fmt(n)}&nbsp;cr`;
const need = l=>Math.round(130*Math.pow(l,1.7));

let S, view='garage', R=null, RC=null, RS=null, sheet=null, resetArm=false;

function fresh(){
  return {v:SAVE_VERSION, ts:0, cr:1500, tok:3, scrap:0, mods:[], muid:1, pity:[0,0,0,0,0,0,0], alb:{}, daily:'', streak:0, nitro:2, xp:0, lvl:1, nuid:2, gift1:1,
    cars:[{uid:1,mid:'epave',etat:22,xp:0,lvl:1,up:{},inv:0}],
    bat:{atelier:1,casse:1,bureau:0,concession:0,banc:0,entrepot:0,simu:0},
    stats:{wins:0,races:0,repFull:0,ups:0,bats:0,wins3:0,packs:0,pods:0,best:0,eq:0,shiny:0},
    claimed:{}, first:{}, offres:[], age:0, intro:false,
    pod:{tier:1,slots:[null,null,null,null,null,null,null,null],last:Date.now()},
    audio:Object.assign({},AUDEF)};
}
function migrate(s){
  const gifted=!!(s&&s.gift1), f=fresh();
  s=Object.assign(f,s); s.bat=Object.assign(fresh().bat,s.bat); s.stats=Object.assign(fresh().stats,s.stats);
  s.cars=(s.cars||[]).filter(c=>M[c.mid]); s.offres=(s.offres||[]).filter(o=>M[o.mid]);
  if(!s.cars.length) s.cars=fresh().cars;
  if(!gifted&&!s.cars.some(c=>c.mid==='patrouille')){s.cars.push({uid:Math.max(s.nuid||1,...s.cars.map(c=>c.uid+1)),mid:'patrouille',etat:85,xp:0,lvl:1,up:{},inv:0,mods:{},sh:Math.random()<.03?1:0}); s.nuid=Math.max(s.nuid||1,...s.cars.map(c=>c.uid+1));}
  s.gift1=1;
  const pd=s.pod||{}, seen={};
  s.pod={tier:clamp(pd.tier||1,1,5),last:pd.last||Date.now(),
    slots:Array.from({length:POD_MAX},(_,i)=>{const u=pd.slots&&pd.slots[i]; if(u&&!seen[u]&&s.cars.some(c=>c.uid===u)){seen[u]=1; return u;} return null;})};
  { const a=s.audio||{}; if(a.sfx!=null&&a.eng==null){ a.master=.9; delete a.sfx; } s.audio=Object.assign({},AUDEF,a); }
  if(!Array.isArray(s.mods)) s.mods=[]; s.muid=Math.max(s.muid||1,1+s.mods.reduce((t,m)=>Math.max(t,m.u||0),0));
  s.mods=s.mods.filter(m=>m&&MODI[m.t]&&RAR[m.r]); if(!Array.isArray(s.pity)||s.pity.length!==7) s.pity=[0,0,0,0,0,0,0];
  s.alb=s.alb||{}; s.tok=s.tok||0; s.scrap=s.scrap||0; s.daily=s.daily||''; s.streak=s.streak||0;
  if(!s.gift3){ s.gift3=1; if((s.v||0)<3) s.tok+=3; }
  s.cars.forEach(c=>{ c.mods=c.mods||{}; for(const k in c.mods) if(!s.mods.some(m=>m.u===c.mods[k])) delete c.mods[k]; });
  s.v=SAVE_VERSION; return s;
}
function load(){
  try{const raw=localStorage.getItem(KEY); if(raw) return migrate(JSON.parse(raw));}catch(e){}
  return fresh();
}
function localSave(){try{localStorage.setItem(KEY,JSON.stringify(S));}catch(e){}}
function save(){S.ts=Date.now(); localSave(); cloudQueue();}

/* Sauvegarde en ligne (propre à chaque joueur), si disponible */
let cloudDoc=null, cloudT=null, cloudBusy=false, cloudDirty=false;
async function cloudInit(){
  try{
    if(!window.claude||!window.claude.use) return;
    const [db,user]=await Promise.all([window.claude.use('db'),window.claude.use('user')]);
    if(!db||!user) return;
    const id=await user.id(); if(!id) return;
    const doc=db.collection('data/users/'+id).doc('save');
    const snap=await doc.get();
    cloudDoc=doc;
    if(snap.exists){
      const d=snap.data(); const cs=d&&d.json?JSON.parse(d.json):null;
      if(cs&&(cs.ts||0)>(S.ts||0)&&view!=='race'){S=migrate(cs); localSave(); R=null; if(view==='prep'||view==='result')view='garage'; closeSheet(); render(); toast('Sauvegarde en ligne chargée');}
      else if(S.ts) cloudQueue();
    } else if(S.ts) cloudQueue();
  }catch(e){}
}
function cloudQueue(){if(!cloudDoc)return; clearTimeout(cloudT); cloudT=setTimeout(cloudPush,2500);}
async function cloudPush(){
  if(cloudBusy){cloudDirty=true;return;}
  cloudBusy=true;
  try{await cloudDoc.set({json:JSON.stringify(S),ts:S.ts});}catch(e){}
  cloudBusy=false;
  if(cloudDirty){cloudDirty=false;cloudQueue();}
}

/* --- calculs --- */
function st(c){
  const s=Object.assign({},M[c.mid]);
  PARTS.forEach(p=>{const l=(c.up&&c.up[p.id])||0; if(l)p.apply(s,l);});
  applyMods(s,c); if(S.bat.banc&&c.uid>0){s.ch*=1+.02*S.bat.banc; s.nm*=1+.02*S.bat.banc;}
  ['adh','fre','man','fia','sty'].forEach(k=>s[k]=clamp(s[k],0,125));
  s.pw=s.ch/s.kg*1000;
  let t=2+900/s.pw; if(s.tr==='AWD')t*=.93; if(s.tr==='FWD')t*=1.03;
  s.t100=Math.max(1.9,t);
  s.acc=clamp(100-(s.t100-2.5)*6.5,2,100);
  s.vit=clamp((s.vmax-100)/3.2,2,100);
  s.pui=clamp(Math.sqrt(s.ch)*2.7,2,100);
  return s;
}
/* Indice : estimation rapide du niveau d'une voiture dans une discipline */
function indice(c,mn){
  const s=st(c), d=DISC[mn.d], me=METEO[mn.m]; let v=0;
  for(const k in d.w) v+=d.w[k]*(k==='etat'?c.etat:s[k]);
  v*=(d.tr[s.tr])||1;
  if(me.f&&!d.calme) v*=me.f(s);
  if(!d.calme) v*=.55+.45*c.etat/100;
  return v*(1+.015*(c.lvl-1));
}
const car = uid=>S.cars.find(c=>c.uid==uid);
const repUnit = c=>Math.max(1,(1-.07*pk('rep'))*ECO.rep*.013*Math.pow(M[c.mid].val,.8)*(1-.1*(S.bat.atelier-1)));
const repCost = c=>Math.ceil((100-c.etat)*repUnit(c));
const upCost = (c,l)=>Math.round((1-.05*pk('upg'))*ECO.up*.33*Math.pow(M[c.mid].val,.8)*Math.pow(l+1,1.6)/10)*10;
const prixCasse = (mid,etat)=>Math.round(M[mid].val*(.25+.5*etat/100)/10)*10;
const prixVente = c=>Math.round((prixCasse(c.mid,c.etat)*.6+(c.inv||0)*.3)/10)*10;
const etatMot = e=>e<40?'Épave':e<75?'Fatiguée':e<100?'En état':'Impeccable';

function addXP(n){
  S.xp+=n; let up=false;
  while(S.xp>=need(S.lvl)){S.xp-=need(S.lvl); S.lvl++; S.cr+=200*S.lvl; S.tok+=1; up=true;}
  if(up){toast(`Niveau ${S.lvl} atteint, prime de ${fmt(200*S.lvl)} cr et 1 jeton`); setTimeout(auLevelUp,1900);}
}
function addCarXP(c,n){
  if(!c) return;
  c.xp+=n; while(c.lvl<20&&c.xp>=60*c.lvl){c.xp-=60*c.lvl; c.lvl++;}
}
function newOffres(){
  const r=CASSE_T[S.bat.casse-1], pool=CARS.filter(m=>m.t>=r[0]&&m.t<=r[1]);
  S.offres=[0,1,2].map(()=>{const m=pool[rint(0,pool.length-1)], etat=rint(12,45); return {mid:m.id,etat,prix:prixCasse(m.id,etat)};});
  S.age=0;
}
/* adversaires : plusieurs pilotes par manche, avec un style de conduite */
const PILOTS=['Vega','Koltz','Marlow','Sato','Brandt','Okoye','Lindqvist','Ferro','Achterberg','Dumas','Kovac','Ibarra','Nakai','Petrov','Quill','Rossi'];
const STYLES=[{n:'propre',sk:0,room:1},{n:'agressif',sk:.01,room:.6},{n:'prudent',sk:-.02,room:1.5},{n:'kamikaze',sk:.02,room:.4}];
const nOppFor=mn=>DISC[mn.d].calme?2:(mn.d==='circuit'?5:2);
function makeOpps(ev){
  const pool=CARS.filter(m=>m.t>=ev.opp.t[0]&&m.t<=ev.opp.t[1]&&!m.noAI), i=evDi(ev), exT=Math.max(0,S.lvl-ev.lvl), hiT=Math.min(6,ev.opp.t[1]+(exT>=4?1:0)+(exT>=9?1:0)), pool2=CARS.filter(m=>m.t>=ev.opp.t[0]&&m.t<=hiT&&!m.noAI).length?CARS.filter(m=>m.t>=ev.opp.t[0]&&m.t<=hiT&&!m.noAI):pool;
  return ev.manches.map(mn=>{
    const names=PILOTS.slice().sort(()=>Math.random()-.5);
    return Array.from({length:nOppFor(mn)},(_,k)=>{
      const ex=Math.max(0,S.lvl-ev.lvl), m=pool2[rint(0,pool2.length-1)], up={}; PARTS.forEach(p=>up[p.id]=Math.min(4,ev.opp.up+Math.floor(ex/3)));
      return {uid:-1-k,mid:m.id,etat:rint(ev.opp.etat[0],ev.opp.etat[1]),xp:0,lvl:1+i+ex,up,pil:names[k],sty:rint(0,STYLES.length-1)};
    });
  });
}
/* paiement selon la place */
const payFor=(rank,n)=>n<=2?[1,.35][rank-1]:n===3?[1,.6,.3][rank-1]:([1,.7,.5,.35,.25,.15][rank-1]||.15);
const ordF=r=>r===1?'1er':r+'e';
function mkRow(mn,c,a,ot,ex){
  ot.sort((x,y)=>x.t-y.t); const n=ot.length+1, rank=a==null?n:1+ot.filter(o=>o.t<a).length;
  return Object.assign({d:mn.d,a,b:ot[0].t,bn:ot[0].nom,rank,n,pay:payFor(rank,n),won:rank===1,uid:c.uid},ex);
}
function showOver(row,pad){
  const n=R.ev.manches.length, last=RC.i>=n-1, ov=$('over'); if(!ov||view!=='race') return;
  const v=row.rank===1?'Manche gagnée':row.rank<=3&&row.n>=4?'Podium, '+ordF(row.rank)+' place':ordF(row.rank)+' place sur '+row.n;
  ov.hidden=false;
  ov.innerHTML=`<div class="verdict ${row.rank===1?'v':row.pay>=.5?'p':'d'}" style="font-size:30px;margin:0 0 10px">${v}</div>${rowHTML(row)}
    <p class="note">${row.a==null?'Tu n’as pas franchi la ligne à temps.':row.jury?(row.rank===1?`Tu l’emportes avec ${fmt(row.a-row.b)} pts d’avance.`:`Le vainqueur te devance de ${fmt(row.b-row.a)} pts.`):row.rank===1?`Tu l’emportes avec ${fmtT(row.b-row.a)} d’avance.`:`Le vainqueur te devance de ${fmtT(row.a-row.b)}.`}${row.pen?` Pénalités : +${row.pen} s.`:''} Cette place rapporte ${Math.round(row.pay*100)} % de la prime.</p>
    <button class="btn wide" data-a="nextm">${last?'Voir le résultat':'Manche suivante'}</button>`;
  const p=document.querySelector(pad), q=$('bQuit'), rs=$('bResp'), au=$('bAud'); [p,q,rs,au].forEach(e=>{if(e) e.style.display='none';});
  const rw=document.querySelector('.race'); if(rw) rw.classList.add('fin'); ov.scrollIntoView&&ov.scrollIntoView({block:'nearest'});
}
/* --- dessin des cartes --- */
const SHAPES = {
  hatch: ['M10 58 L12 36 L30 18 L110 18 L134 38 L180 44 Q190 46 190 52 L190 58 Z','M32 22 L107 22 L127 37 L24 37 Z'],
  sedan: ['M8 58 L10 40 L40 38 L60 18 L115 18 L140 38 L185 44 Q194 46 194 52 L194 58 Z','M63 22 L113 22 L132 37 L50 37 Z'],
  wagon: ['M8 58 L10 24 Q11 18 18 18 L118 18 L142 38 L186 44 Q194 46 194 52 L194 58 Z','M16 22 L116 22 L135 37 L16 37 Z'],
  suv:   ['M8 58 L8 20 Q9 12 20 12 L120 12 L142 34 L186 38 Q194 40 194 46 L194 58 Z','M14 17 L118 17 L136 33 L14 33 Z'],
  van:   ['M6 58 L6 12 Q6 8 12 8 L132 8 L156 34 L188 40 Q194 42 194 48 L194 58 Z','M118 12 L134 12 L150 32 L118 32 Z'],
  bike:  ['M40 58 L78 26 L128 26 L152 58 M78 26 L100 58 L128 26 M70 20 L86 20 M124 16 L134 26','M0 0'],
  pickup:['M6 58 L6 36 L84 36 L84 14 L128 14 L148 36 L188 40 Q194 42 194 48 L194 58 Z','M90 18 L126 18 L142 35 L90 35 Z'],
  coupe: ['M8 58 L10 44 L34 38 L70 22 L112 22 L142 40 L186 46 Q194 48 194 53 L194 58 Z','M72 26 L110 26 L134 40 L48 40 Z'],
  super: ['M6 58 L8 44 L30 36 L80 26 L110 26 L150 44 L190 50 Q196 51 196 55 L196 58 Z','M84 29 L108 29 L134 41 L70 41 Z']
};
function carSVG(m,etat){
  const [b,w]=SHAPES[m.shape], rust=etat<40;
  return `<svg viewBox="0 0 200 74" class="car${rust?' rust':''}" aria-hidden="true"><ellipse cx="100" cy="70" rx="92" ry="4" fill="var(--t,var(--accent))" opacity=".35"/><path d="${b}" fill="${m.col}" stroke="var(--t,var(--accent))" stroke-width="1.5"/><path d="${w}" fill="var(--glass)"/>${rust?'<g fill="#7A4A2A"><circle cx="34" cy="50" r="5"/><circle cx="104" cy="52" r="4"/><circle cx="168" cy="52" r="3"/><circle cx="122" cy="47" r="2.5"/></g>':''}<g fill="#07080F"><circle cx="48" cy="58" r="13"/><circle cx="152" cy="58" r="13"/></g><g fill="none" stroke="var(--t,var(--accent))" stroke-width="2"><circle cx="48" cy="58" r="6.5"/><circle cx="152" cy="58" r="6.5"/></g></svg>`;
}
function cardHTML(c,o={}){
  const m=M[c.mid], s=st(c), t=TIERS[m.t];
  return `<${o.tag||'button'} class="card ${c.sh?'shiny ':''}${o.cls||''}" style="--t:${t.c}" ${o.attr||''}>
    <div class="card-top"><span class="tier">${t.n}${c.sh?' ✨':''}</span><span>Niv. ${c.lvl}</span></div>
    <div class="card-art">${thArt(c)}</div>
    <div class="card-name">${m.nom}</div>
    <div class="card-sub">${m.cat}, ${TR[m.tr]}</div>
    <div class="etat"><i style="width:${c.etat}%" class="${c.etat<40?'low':c.etat<75?'mid':''}"></i></div>
    <div class="card-foot"><span>${fmt(s.ch)} ch</span><span>${fmt(s.kg)} kg</span><span>${c.etat}&nbsp;%</span></div>
  </${o.tag||'button'}>`;
}

/* --- écrans --- */
function render(){
  const racing=view==='race'&&RC&&(RC.kind==='race'||RC.kind==='spa'||RC.kind==='show');
  document.body.classList.toggle('racing',!!racing);
  $('top').innerHTML=`<button class="lv" data-a="pilot" title="Carte pilote">${S.lvl}${pilDot()?'<i class="pdot"></i>':''}</button><span class="who xpb" data-a="pilot"><span class="xpbar"><i style="width:${clamp(S.xp/need(S.lvl)*100,0,100)}%"></i></span><b>${fmt(S.xp)} / ${fmt(need(S.lvl))} XP</b></span><span class="money">${fmt(S.cr)} cr<small>⚡ ${S.nitro}</small><small class="tk">🎟 ${S.tok}</small></span><button class="mutebtn" data-a="mute" aria-label="Son">${S.audio&&S.audio.mute?'🔇':'🔊'}</button><div class="xp"><i style="width:${clamp(S.xp/need(S.lvl)*100,0,100)}%"></i></div>`;
  const claimable=MISSIONS.some(m=>!S.claimed[m.id]&&m.p(S)[0]>=m.p(S)[1])||questReady()||bdgReady()>0;
  const cur=(view==='prep'||view==='result'||view==='race')?'epreuves':view;
  $('nav').innerHTML=TABS.filter(t=>typeof tabOk!=='function'||tabOk(t[0])).map(([id,ic,n])=>`<button data-a="tab" data-id="${id}" ${cur===id?'aria-current="page"':''}><b>${ic}</b>${n}${id==='missions'&&claimable?'<i class="dot"></i>':''}</button>`).join('');
  $('view').innerHTML=({hub:vHub,garage:vGarage,epreuves:vEpreuves,cartes:vCartes,prep:vPrep,race:vRace,result:vResult,marche:vMarche,base:vBase,missions:vMissions,atelier:vAtelier,equipe:vEquipe})[view]();
  if(view!==lastView){lastView=view; const vv=$('view'); vv.classList.remove('enter'); void vv.offsetWidth; if(!racing) vv.classList.add('enter');}
  renderSheet(); hubMode();
  if(view==='cartes') bindPacks();
  if(racing) bindRace(); else if(view==='garage') bindGarage(); else if(view==='hub') bindHub(); else glStop();
  auView(view);
}
function vGarage(){
  const t=S.pod.tier, nx=POD_TIER[t+1], open=POD_LVL.filter(l=>S.lvl>=l).length;
  const shown=S.pod.slots.filter((u,i)=>u&&S.lvl>=POD_LVL[i]).length;
  const nextSlot=POD_LVL.find(l=>l>S.lvl);
  const has3d=glEnsure(), view3d=has3d?`<div class="gl" id="gslot"><div class="hint">Glisse pour tourner, touche un podium pour y placer une voiture</div></div>`:`<p class="note">La 3D n’est pas disponible sur cet appareil. Tu peux quand même gérer tes podiums depuis la liste ci-dessous.</p>`;
  const listPods=has3d?'':POD_LVL.map((l,i)=>{const u=S.pod.slots[i], c=u&&car(u); return `<button class="row ${S.lvl<l?'locked':''}" data-a="slot3" data-id="${i}"><span class="ico">🏛️</span><span class="grow"><span class="ttl">Podium ${i+1}</span><br><span class="sub">${S.lvl<l?'Niveau '+l+' requis':c?M[c.mid].nom:'Libre'}</span></span></button>`;}).join('');
  return `<div class="head"><h2>Garage</h2><p>${S.cars.length} voiture${S.cars.length>1?'s':''}</p></div>${view3d}${listPods}
  <div class="row" style="margin-top:10px"><span class="ico">🏛️</span><span class="grow"><span class="ttl">Showroom <span class="plate">${POD_TIER[t].n}</span></span><br>
    <span class="sub">${open} podium${open>1?'s':''} ouvert${open>1?'s':''}, ${shown} occupé${shown>1?'s':''}. Rapporte ${podRate().toFixed(1).replace('.',',')} cr par minute${nextSlot?`. Prochain podium au niveau ${nextSlot}`:''}.</span></span>
    <button class="btn sm" id="pCollect" data-a="collect">Récolter<br>${cr(Math.floor(podPending()))}</button></div>
  ${nx?`<div class="row"><span class="ico">⬆️</span><span class="grow"><span class="ttl">Podiums : ${nx.n}</span><br><span class="sub">${S.lvl<nx.lvl?'Niveau '+nx.lvl+' requis. ':''}Plus de revenus et un plateau plus spectaculaire.</span></span>
    <button class="btn sm" data-a="podup" ${S.lvl<nx.lvl||S.cr<nx.cost?'disabled':''}>Améliorer<br>${cr(nx.cost)}</button></div>`:''}
  <div class="sec"><h3>Collection</h3><div class="grid" style="margin-top:10px">${S.cars.map(c=>cardHTML(c,{attr:`data-a="car" data-id="${c.uid}"`})).join('')}</div>
  <p class="note">Touche une voiture pour la gérer et monter ses modules. Appui long : vue 3D.</p></div>`;
}
function vEpreuves(){
  return `<div class="head"><h2>Épreuves</h2><p>Une voiture par manche</p></div>`+EVENTS.filter(e=>!e.ill).map(ev=>{
    const lock=S.lvl<ev.lvl, few=S.cars.length<ev.manches.length;
    const sub=lock?`Débloquée au niveau ${ev.lvl}`:few?`Il te faut ${ev.manches.length} voitures`:ev.manches.map(m=>DISC[m.d].nom).join(', ');
    return `<button class="row ${lock?'locked':''}" data-a="ev" data-id="${ev.id}" ${lock||few?'disabled':''}>
      <span class="ico">${lock?'🔒':DISC[ev.manches[0].d].ic}</span>
      <span class="grow"><span class="ttl">${ev.nom}</span><br><span class="sub">${sub}</span></span>
      <span class="gain">${cr(ev.gain)}${S.first[ev.id]?'':'<br><span class="sub">×2 la 1<sup>re</sup> fois</span>'}</span></button>`;
  }).join('');
}
function vPrep(){
  const ev=R.ev, ready=R.pick.every(x=>x);
  return `<div class="head"><h2>${ev.nom}</h2><button class="btn alt sm" data-a="tab" data-id="epreuves">Retour</button></div>
  <p class="note">Place la bonne voiture sur chaque manche. La prime dépend de ta place : 1er 100 %, 2e 70 %, 3e 50 %.</p><button class="btn wide" style="margin-bottom:12px" data-a="autopick">⚡ Choisir automatiquement les meilleures voitures</button>`+
  ev.manches.map((mn,i)=>{
    const d=DISC[mn.d], me=METEO[mn.m], os=R.opps[i].slice().sort((a,b)=>indice(b,mn)-indice(a,mn)), c=R.pick[i]?car(R.pick[i]):null, stg=mn.sp&&SPA_STAGES.find(s=>s.id===mn.sp);
    return `<div class="manche"><h3>${d.ic} Manche ${i+1} : ${d.nom}${d.calme?'':' '+me.nom+' '+me.ic}<span>${d.aide}${stg?` <b>Spa-Francorchamps : ${stg.nom}, ${((stg.b-stg.a)/1000).toFixed(1).replace('.',',')} km.</b>`:''}</span></h3>
    <div class="duel">
      <div><div class="lab"><span>Ta voiture</span>${c?`<b>${fmt(indice(c,mn))}</b>`:''}</div>
        ${c?cardHTML(c,{cls:'cmini',attr:`data-a="slot" data-id="${i}"`}):`<button class="card empty" data-a="slot" data-id="${i}">Choisir une voiture</button>`}${c&&c.etat<100?`<button class="btn sm wide" style="margin-top:6px" data-a="prep_rep" data-id="${c.uid}" ${S.cr<Math.ceil(repUnit(c))?'disabled':''}>🔧 Réparer, ${fmt(Math.min(repCost(c),Math.max(S.cr,Math.ceil(repUnit(c)))))} cr</button>`:''}</div>
      <div><div class="lab"><span>${os.length} adversaire${os.length>1?'s':''}</span></div>
        <div class="opl">${os.map(o=>`<div><b>${fmt(indice(o,mn))}</b> ${o.pil} <span>${M[o.mid].nom}, ${STYLES[o.sty].n}</span></div>`).join('')}</div></div>
    </div></div>`;
  }).join('')+
  `<div style="display:grid;gap:8px"><button class="btn wide" data-a="go" data-id="manual" ${ready?'':'disabled'}>Prendre le volant</button>
   <button class="btn alt wide" data-a="go" data-id="auto" ${ready?'':'disabled'}>Pilote automatique</button></div>
   ${glEnsure()?'':'<p class="note">La 3D n’est pas disponible sur cet appareil : la course sera simulée automatiquement.</p>'}
   <p class="note">Au volant, tu règles le <b>gaz</b>, le <b>frein</b> et la <b>nitro</b> (⚡ ${S.nitro} en stock). Sur le circuit de Spa tu braques toi-même. Clavier : Z ou ↑ gaz, Q/D ou flèches direction, S ou ↓ frein, Espace frein à main, N nitro, R remise en piste.</p>`;
}
function rowHTML(x){
  const A=x.jury?fmt(x.a)+' pts':(x.a==null?'Abandon':fmtT(x.a)), B=x.jury?fmt(x.b)+' pts':fmtT(x.b);
  return `<div class="res">
    <div class="side ${x.rank===1?'win':''}"><div class="n">${ordF(x.rank)} <small>sur ${x.n}</small></div><div class="who">${x.an}, ${A}</div>${x.ap?'<div class="tag">Panne</div>':''}${x.slides?`<div class="tag">${x.slides} sortie${x.slides>1?'s':''} large${x.slides>1?'s':''}</div>`:''}${x.hits?`<div class="tag">${x.hits} choc${x.hits>1?'s':''}</div>`:''}${x.pen?`<div class="tag">+${x.pen} s de pénalité</div>`:''}${x.nit?`<div class="tag" style="color:var(--accent)">Nitro ×${x.nit}</div>`:''}</div>
    <div class="mid">${DISC[x.d].ic}<br>${DISC[x.d].nom}</div>
    <div class="side r"><div class="who">${x.rank===1?'2e':'Vainqueur'}</div><div class="n" style="font-size:15px">${x.bn}</div><div class="who">${B}</div></div></div>`;
}
function vRace(){
  if(RC.kind==='spa') return vSpa(); if(RC.kind==='show') return vShow();
  const ev=R.ev, n=ev.manches.length, last=RC.i>=n-1;
  const next=`<button class="btn wide" data-a="nextm">${last?'Voir le résultat':'Manche suivante'}</button>`;
  if(RC.kind==='row'){
    const x=RC.row;
    return `<div class="race"><div class="head"><h2>${DISC[x.d].ic} Manche ${RC.i+1} sur ${n}</h2></div>
      <p class="note">${x.jury?'Le jury compare le style et l’état des deux voitures.':'Course simulée automatiquement : la 3D n’est pas disponible sur cet appareil.'}</p>
      ${x.jury?`<div class="duel" style="margin-bottom:12px"><div>${cardHTML(car(x.uid),{cls:'cmini',tag:'div'})}</div><div>${cardHTML(R.opps[RC.i].slice().sort((a,b)=>indice(b,R.ev.manches[RC.i])-indice(a,R.ev.manches[RC.i]))[0],{cls:'cmini',tag:'div'})}</div></div>`:''}
      ${rowHTML(x)}<div class="verdict ${x.won?'v':'d'}" style="font-size:30px;margin-bottom:12px">${x.won?'Manche gagnée':'Manche perdue'}</div>${next}</div>`;
  }
  const auto=RC.auto;
  return `<div class="race"><div class="rwrap"><div class="rs" id="rslot"></div>
    <div class="hud"><div class="hud-top"><span>Manche ${RC.i+1}/${n}, ${DISC[RC.mn.d].nom} ${METEO[RC.mn.m].ic}</span><span id="hTime">0,00 s</span></div>
      <div class="hud-gap" id="hGap"></div><div class="hud-pos" id="hPos"></div>
      <div class="hud-lights" id="hLights"><i></i><i></i><i></i></div>
      <div class="hud-msg" id="hMsg"></div>
      <div class="hud-bot"><div class="spd"><b id="hSpd">0</b><small>km/h</small>${hudGear()}</div>
        <div class="gauges"><div class="g"><span>Nitro</span><div class="bar2 n"><i id="nitFill"></i></div></div></div></div></div>${FXL}</div>
    <div class="pad3">
      ${RC.mn.d==='drag'?shiftPad(auto):`<button id="pBrk" class="pedal brk" ${auto?'disabled':''}><span>${auto?'Auto':'Frein'}</span><small>${auto?'le pilote gère':'maintiens'}</small></button>`}
      <button id="pNit" class="pedal nit">Nitro<small>×${S.nitro}</small></button>
      <button id="pGas" class="pedal gas" ${auto?'disabled':''}><i id="gasPed"></i><span>${auto?'Auto':'Gaz'}<small>${auto?'le pilote gère':'glisse vers le bas pour doser'}</small></span></button>
    </div>
    <div id="over" hidden></div>
    <div style="display:flex;gap:8px"><button class="btn alt sm" id="bAud" data-a="audio">⚙ Son</button><button class="btn danger sm" id="bQuit" data-a="quit">Abandonner l’épreuve</button></div><canvas id="rmap" class="rmap"></canvas></div>`;
}
function vResult(){
  const r=R.result;
  return `<div class="resv"><div class="head"><h2>${R.ev.nom}</h2></div>`+r.rows.map(rowHTML).join('')+
  `<div class="verdict ${r.win?'v':r.pod?'p':'d'}">${r.win?'Victoire':r.pod?'Podium':'Défaite'}</div>
   <p><b class="num" style="font-size:20px;color:var(--yel)">+${fmt(r.gain)} cr</b>, +${r.xp} XP${r.tok?`, +${r.tok} 🎟`:''}${r.first?' (prime de première victoire)':''}</p>
   <p class="note">${r.win?'Tes voitures se sont usées pendant l’épreuve. Pense à l’atelier.':'Répare, améliore, équipe des modules, ou choisis une voiture mieux adaptée à la discipline.'}</p>
   <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button class="btn alt" data-a="tab" data-id="garage">Garage</button><button class="btn" data-a="ev" data-id="${R.ev.id}">Rejouer</button></div></div>`;
}
function vBase(){
  return `<div class="head"><h2>Base</h2><p>Tes bâtiments</p></div>`+BATS.map(b=>{
    const l=S.bat[b.id], maxed=l>=b.max, c=maxed?0:b.cout[l];
    return `<div class="row"><span class="ico">${b.ic}</span>
      <span class="grow"><span class="ttl">${b.nom} <span class="plate">${l?'Niv. '+l:'À construire'}</span></span><br>
      <span class="sub">${b.effet(l)}${maxed||!l?'':'<br>Ensuite : '+b.effet(l+1)}</span></span>
      ${maxed?'<span class="sub">Max</span>':`<button class="btn sm" data-a="bat" data-id="${b.id}" ${S.cr<c?'disabled':''}>${l?'Améliorer':'Construire'}<br>${cr(c)}</button>`}</div>`;
  }).join('')+
  `<div class="sec"><h3>Réglages</h3><p class="note">Volume de la musique, des moteurs, des sirènes, des chocs et des menus, avec des préréglages.</p><button class="btn alt" data-a="audio">🔊 Réglages audio</button> <button class="btn alt" data-a="tuto">📖 Revoir le tuto</button> <button class="btn alt" data-a="cine">🎬 Revoir l’intro</button> <button class="btn alt" data-a="patch">📰 Nouveautés</button></div>
   
   <div class="sec"><h3>Crédits</h3>
    <p class="note">Circuit « Circuit de Spa-Francorchamps 2022 layout » par Dave Love (Sketchfab), licence CC BY 4.0.</p>
    <p class="note">« Mercedes E Class W212 » par Peter_D (Sketchfab), licence CC BY 4.0.</p>
    <p class="note">« POLICE CAR - Belgian VW Transporter » par Mickael Boitte (Sketchfab), licence CC BY-NC 4.0 : usage non commercial.</p>
    <p class="note">« Subaru 360 (1968) » par geyges, « Audi A6 C7 Limousine » par KOElkast1007, « Old German bicycle WW2 » par TwilightFox (Sketchfab), licence Sketchfab Standard.</p></div>
   <div class="sec"><h3>Partie</h3><p class="note">La progression est enregistrée automatiquement.</p>
   <button class="btn danger sm" data-a="reset">${resetArm?'Confirmer : tout effacer':'Recommencer à zéro'}</button></div>`;
}
/* --- fiches --- */
function openSheet(s){sheet=s; document.body.classList.add('open'); renderSheet(); $('sheet').scrollTop=0;}
function closeSheet(){ const wr=sheet&&sheet.t==='ranch'; sheet=null; if(wr) ranchLeft(); document.body.classList.remove('open'); if(RC) RC.paused=false;}
function renderSheet(){
  if(!sheet) return;
  const X='<button class="x" data-a="close" aria-label="Fermer">×</button>';
  if(sheetExtra(X)) return;
  if(sheet.t==='intro'){
    $('sheet').innerHTML=`${X}<h2>High &amp; Rouillé</h2>
      <p>Tu démarres avec 1 500 cr, 3 jetons de paquet, deux bouteilles de nitro et une épave rouillée de 1962. À toi d’en faire une légende.</p>
      <p><b>1.</b> Répare ton épave dans le garage.<br><b>2.</b> Pilote-la en course : tu gères le gaz, le frein et la nitro.<br><b>3.</b> Expose tes voitures sur les podiums du showroom, ils rapportent des crédits.</p>
      <p class="note">Chaque discipline récompense des qualités différentes : aucune voiture n’est la meilleure partout.</p>
      <button class="btn wide" data-a="close">Ouvrir le garage</button>`;
    return;
  }
  if(sheet.t==='slot'){
    const i=sheet.i, lvl=POD_LVL[i];
    if(S.lvl<lvl){$('sheet').innerHTML=`${X}<h2>Podium ${i+1}</h2><p>Ce podium s’ouvre au niveau ${lvl}. Tu es niveau ${S.lvl}.</p><button class="btn wide" data-a="close">Fermer</button>`; return;}
    const cu=S.pod.slots[i], cc=cu&&car(cu);
    $('sheet').innerHTML=`${X}<h2>Podium ${i+1}</h2><p class="note">Une voiture exposée rapporte des crédits chaque minute. Plus elle est rare et en bon état, plus elle rapporte.</p>`+
      (cc?`<button class="btn danger wide" style="margin-bottom:10px" data-a="podclear">Retirer ${M[cc.mid].nom}</button>`:'')+
      S.cars.filter(c=>c.uid!==cu).map(c=>{const at=S.pod.slots.indexOf(c.uid); return `<button class="row" data-a="podset" data-id="${c.uid}">
        <span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span>
        <span class="grow"><span class="ttl">${M[c.mid].nom}</span><br><span class="sub">${TIERS[M[c.mid].t].n}, état ${c.etat}&nbsp;%${at>=0?', déjà sur le podium '+(at+1):''}</span></span></button>`;}).join('');
    return;
  }
  if(sheet.t==='pick'){
    const i=sheet.i, mn=R.ev.manches[i], o=indice(R.opps[i],mn);
    const list=S.cars.filter(c=>!R.pick.some((u,j)=>u===c.uid&&j!==i)).sort((a,b)=>indice(b,mn)-indice(a,mn));
    $('sheet').innerHTML=`${X}<h2>${DISC[mn.d].nom}</h2><p class="note">${DISC[mn.d].aide} Indice adverse : <b>${fmt(o)}</b></p>`+
      (list.length?list.map(c=>{const v=indice(c,mn);return `<button class="row" data-a="pick" data-id="${c.uid}">
        <span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span>
        <span class="grow"><span class="ttl">${M[c.mid].nom}</span><br><span class="sub">${TR[M[c.mid].tr]}, état ${c.etat}&nbsp;%</span></span>
        <span class="gain" style="color:${v>=o?'var(--good)':'var(--bad)'}">${fmt(v)}</span></button>`}).join('')
      :'<p>Toutes tes voitures sont déjà placées sur une autre manche.</p>');
    return;
  }
  if(sheet.t==='car'){
    const c=car(sheet.uid); if(!c){closeSheet();return;}
    const m=M[c.mid], s=st(c), t=TIERS[m.t], rc=repCost(c), maxUp=Math.min(4,S.bat.atelier);
    const bar=(n,v)=>`<div class="bar"><span>${n}</span><span class="tr"><i style="width:${Math.min(100,v)}%"></i></span><span class="num">${fmt(v)}</span></div>`;
    $('sheet').innerHTML=`${X}
      <span class="plate" style="background:${t.c};color:#fff">${t.n}</span>
      <h2 style="margin-top:6px">${m.nom}</h2>
      <p class="note" style="margin:2px 0 0">${m.cat} de ${m.an}, ${TR[m.tr]}. Niveau ${c.lvl}${c.lvl<20?` (${c.xp} / ${60*c.lvl} XP)`:' (max)'}</p>
      <div class="thhero" style="--t:${t.c}">${thArt(c)}<button data-a="view3d">Voir en 3D ⟳</button></div>
      <div class="row" style="margin-top:8px"><span class="grow"><span class="ttl">${etatMot(c.etat)}, ${c.etat}&nbsp;%</span>
        <div class="etat"><i style="width:${c.etat}%" class="${c.etat<40?'low':c.etat<75?'mid':''}"></i></div>
        <span class="sub">Un mauvais état réduit les performances et augmente le risque de panne.</span></span>
        ${c.etat<100?`<button class="btn sm" data-a="repair" ${S.cr<Math.ceil(repUnit(c))?'disabled':''}>Réparer<br>${cr(Math.min(rc,Math.max(S.cr,Math.ceil(repUnit(c)))))}</button>`:''}</div>
      <div class="statgrid">
        <div><b>${fmt(s.ch)} ch</b><span>Puissance</span></div><div><b>${fmt(s.nm)} Nm</b><span>Couple</span></div><div><b>${fmt(s.kg)} kg</b><span>Poids</span></div>
        <div><b>${s.t100.toFixed(1).replace('.',',')} s</b><span>0 à 100 km/h</span></div><div><b>${fmt(s.vmax)} km/h</b><span>Vitesse max</span></div><div><b>${fmt(s.pw)} ch/t</b><span>Poids/puissance</span></div>
      </div>
      ${bar('Adhérence',s.adh)}${bar('Freinage',s.fre)}${bar('Maniabilité',s.man)}${bar('Fiabilité',s.fia)}${bar('Style',s.sty)}
      <div class="sec" style="margin-top:16px"><h3>Aptitudes</h3><p class="note">Indice par discipline, sur le sec, dans l’état actuel.</p>
        <div class="chips">${Object.keys(DISC).map(k=>`<span class="chip">${DISC[k].ic} ${DISC[k].nom}<b>${fmt(indice(c,{d:k,m:'sec'}))}</b></span>`).join('')}</div></div>
      
      <div class="sec" style="margin-top:16px"><h3>Modules</h3><p class="note">Les cartes de modules s’obtiennent dans Marché › Cartes. Elles changent les stats et l’apparence.</p><div class="eqbar"><button class="btn good sm" data-a="eqbest">⚡ Équiper les meilleures</button><button class="btn alt sm" data-a="eqnone" ${Object.keys(c.mods||{}).length?'':'disabled'}>Tout retirer</button></div>
        ${tilesHTML(c)}</div>
      <div class="sec" style="margin-top:18px"><h3>Améliorations</h3><p class="note">Ton atelier (niv. ${S.bat.atelier}) monte les pièces jusqu’au palier ${PALIERS[maxUp]}.</p>
      ${PARTS.map(p=>{const l=c.up[p.id]||0, maxed=l>=4, blocked=l>=maxUp, k=upCost(c,l);
        return `<div class="row"><span class="ico">${p.ic}</span><span class="grow"><span class="ttl">${p.nom} <span class="plate">${PALIERS[l]}</span></span><br><span class="sub">${p.effet} par palier</span></span>
        ${maxed?'<span class="sub">Max</span>':blocked?'<span class="sub">Atelier trop petit</span>':`<button class="btn sm" data-a="up" data-id="${p.id}" ${S.cr<k?'disabled':''}>${PALIERS[l+1]}<br>${cr(k)}</button>`}</div>`}).join('')}</div>
      <div class="sec" style="margin-top:14px"><button class="btn danger wide" data-a="sell" ${S.cars.length<2?'disabled':''}>${sheet.arm?'Confirmer la vente':'Vendre'} pour ${cr(prixVente(c))}</button>
      ${S.cars.length<2?'<p class="note">Impossible de vendre ta dernière voiture.</p>':''}</div>`;
  }
}

let toastT;
function toast(msg){const t=$('toast'); t.textContent=msg; t.classList.add('on'); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.remove('on'),2400);}

/* ---------- 3) COURSE EN 3D ---------- */
const hash = (i,s)=>{const x=Math.sin(i*127.1+s*311.7)*43758.5453; return x-Math.floor(x);};

/* Circuit : segments droits (S) et virages (C). Les virages tournent à gauche ou à droite. */
function trackFor(ev,mn){
  const idx=evDi(ev), k=1+idx*.12, h0=hash(idx,4)>.5?1:-1; let x=0, ci=0;
  const segs=TRACKS[mn.d].map(([t,len,base])=>{
    const L=t==='S'?len*(mn.d==='drag'?Math.min(k,1.35):k):len, s={t,a:x,b:x+L,base};
    if(t==='C'){s.dir=h0*(ci++%2?-1:1); s.ang=clamp(L*.0155,.8,1.55);}
    x+=L; return s;
  });
  return {segs,L:x};
}
/* Transforme une carte en voiture de course : chaque stat devient un paramètre physique */
function mkRacer(c,mn,drv){
  const s=st(c), d=DISC[mn.d], me=METEO[mn.m];
  const ef=.55+.45*c.etat/100, lv=1+.015*(c.lvl-1), wet=me.f?Math.min(1.05,me.f(s)*(1+(s.sp.wet||0))):1, trb=d.tr[s.tr]||1;
  const base=mn.d==='drift'?s.man*.6+s.pui*.4:s.adh*.6+s.man*.4;
  const grip=base*wet*(mn.d==='rallye'?.9:1)*(mn.d==='drag'?1:trb)*sk(c,'grip',.012);
  const pP=(c.uid>0?1-.1*pk('rel'):1)*(100-s.fia)/500*(1.5-c.etat/100)*(mn.d==='endurance'?2.5:1);
  return {c, m:M[c.mid], nom:M[c.mid].nom,
    A:(2+s.acc*.09)*ef*lv*(mn.d==='drag'?trb:1)*sk(c,'acc',.015),
    VM:s.vmax/3.6*(.8+.2*ef),
    B:(6+s.fre*.12)*Math.sqrt(wet)*sk(c,'brk',.02),
    TR:(3.5+s.adh*.07)*wet*({AWD:1.25,RWD:1,FWD:.9}[s.tr]),
    cm:b=>b/3.6*(.55+grip/90), gc:.55+grip/90, nP:1+(s.sp.nitP||0)+(c.uid>0?.04*pk('nit'):0), nD:1+(s.sp.nitD||0)+(c.uid>0?.08*pk('nit'):0), dR:1/(1+Math.max(0,s.sp.dmg||0)), oB:1+(s.sp.off||0), xB:s.sp.xp||0,
    slideK:.6+s.man/400,
    panneAt:null, pP, skill:drv.skill, err:drv.err, react:drv.react,
    x:0,v:0,a:0,si:0,cur:null,go:false,fin:null,nitroT:0,boostT:0,panneT:0,slide:false,slides:0,nit:0,panned:false,msg:null,perfect:null,aiSeg:null,aiTarget:0,drift:0,pen:null,braking:false,drag:mn.d==='drag',gear:1,rpmF:0,shiftT:0,gBoost:0,autoG:true,shAt:clamp(.78+drv.skill*.2,.9,.985),gp:0};
}
/* inp = {thr: 0 à 1, brake: bool} */
function step(r,inp,dt,tk,clock){
  if(r.fin!=null){r.v=Math.max(0,r.v-9*dt); r.x+=r.v*dt; r.a=-9; r.braking=true; return;}
  if(!r.go){r.a=0; return;}
  let seg=tk.segs[r.si];
  while(r.x>=seg.b&&r.si<tk.segs.length-1) seg=tk.segs[++r.si];
  if(seg!==r.cur){
    if(r.cur&&r.cur.t==='C'&&r.perfect===r.cur) r.boostT=1.2;
    r.cur=seg;
    if(seg.t==='C'){
      const cm=r.cm(seg.base);
      if(r.v>cm*1.05){r.slide=true; r.slideTo=cm*r.slideK; r.slides++; r.msg='slide';}
      else if(r.v>=cm*.9){r.perfect=seg; r.msg='perfect';}
    } else r.slide=false;
  }
  const nit=r.nitroT>0; if(nit) r.nitroT-=dt; if(r.boostT>0) r.boostT-=dt;
  const vm=r.VM*(nit?1.18:1), thr=inp.brake?0:clamp(inp.thr,0,1);
  let drive=r.A*(nit?1.6*(r.nP||1):1)*(r.boostT>0?1.25:1)*(1-r.v/vm)*gearK(r,dt);
  if(drive>0) drive*=thr;
  let a=drive-(1-thr)*1.8;
  a=Math.min(a,r.TR*(nit?1.15:1));
  if(r.panneAt!=null&&r.x>=r.panneAt){r.panneAt=null; r.panneT=2; r.panned=true; r.msg='panne';}
  if(r.panneT>0){r.panneT-=dt; a=-1.5;}
  if(inp.brake) a=Math.min(a,-r.B);
  if(seg.t==='C'){
    const cm=r.cm(seg.base);
    if(r.slide){a=-16; if(r.v<=r.slideTo) r.slide=false;}
    else if(r.v>cm) a=Math.min(a,-6);
    else if(r.v+a*dt>cm) a=(cm-r.v)/dt;
  }
  r.braking=!!inp.brake||r.slide;
  r.a=a; r.v=Math.max(0,r.v+a*dt); r.x+=r.v*dt;
  if(r.x>=tk.L) r.fin=clock-(r.x-tk.L)/Math.max(r.v,1);
}
function nextCorner(r,tk){for(let i=r.si;i<tk.segs.length;i++){const s=tk.segs[i]; if(s.t==='C'&&s.a>r.x) return s;} return null;}
function ai(r,tk){
  const nc=nextCorner(r,tk); if(!nc) return {brake:false};
  if(nc!==r.aiSeg){r.aiSeg=nc; r.aiTarget=r.cm(nc.base)*(Math.random()<r.err?rnd(1.07,1.16):rnd(r.skill,1));}
  const d=(r.v*r.v-r.aiTarget*r.aiTarget)/(2*r.B);
  return {brake:r.v>r.aiTarget&&nc.a-r.x<=d+r.v*.04};
}
const aiIn=(r,tk)=>{const b=ai(r,tk).brake; return {thr:b?0:1,brake:b};};
function armPanne(r,tk){if(Math.random()<r.pP) r.panneAt=tk.L*rnd(.25,.8);}

/* --- logique de manche --- */
function leaveRace(){
  glStop(); if(RS&&RS.scene) disposeScene(RS.scene); RS=null; RC=null; auRaceStop();
}
function startManche(i){
  glStop(); if(RS&&RS.scene) disposeScene(RS.scene); RS=null;
  const ev=R.ev, mn=ev.manches[i], c=car(R.pick[i]), opps=R.opps[i], idx=evDi(ev);
  if(DISC[mn.d].calme){
    const a=indice(c,mn)*rnd(.94,1.06), ot=opps.map(o=>({nom:o.pil+' ('+M[o.mid].nom+')',t:-indice(o,mn)*rnd(.94,1.06),o}));
    const row=mkRow(mn,c,-a,ot,{jury:true,an:M[c.mid].nom}); row.a=a; row.b=-row.b;
    R.rows.push(row); return startShow(i,row,c,ot);
  }
  if((mn.d==='circuit'||mn.d==='drift')&&TRK.ready&&glEnsure()) return startSpa(i);
  const tk=trackFor(ev,mn), has3d=glEnsure();
  const P=mkRacer(c,mn,{skill:.86,err:.07,react:rnd(.3,.5)});
  const Os=opps.map(o=>{const r=mkRacer(o,mn,{skill:clamp(.8+idx*.016+S.lvl*.003+STYLES[o.sty].sk+rnd(-.015,.015),.78,.975),err:Math.max(.025,.14-idx*.012-S.lvl*.003),react:rnd(.25,.55)}); r.pil=o.pil; return r;});
  const all=[P].concat(Os), L=all.length===2?[-2.2,2.2]:all.length===3?[0,-3.5,3.5]:all.map((_,k)=>-4.4+8.8*k/(all.length-1));
  all.forEach((r,k)=>{r.lane=L[k]; armPanne(r,tk);});
  RC={kind:'race',i,mn,tk,auto:R.auto||!has3d,clock:-3.4,inp:{t:0,k:0,b:false,kb:false},flash:null,endAt:null,done:false,P,Os,O:Os[0]};
  if(!has3d){
    while(!RC.done&&RC.clock<260) tick(1/60);
    RC={kind:'row',i,row:R.rows[R.rows.length-1]}; view='race'; render(); document.querySelector('main').scrollTop=0; return;
  }
  P.autoG=!!RC.auto; RS=buildRace(ev,mn,tk,P,Os);
  auRaceStart({pm:P.m,oms:Os.map(o=>o.m),rain:mn.m==='pluie',siren:P.m.glb==='patrouille',drag:mn.d==='drag'});
  view='race'; render(); document.querySelector('main').scrollTop=0;
}
function flash(txt,col,dur){if(txt==='Départ parfait') auTry(auDing); if(RC) RC.flash={txt,col,until:RC.clock+(dur||1.1)};}
const inThr=()=>Math.max(RC.inp.t,RC.inp.k);
function fireNitro(){
  if(!RC||(RC.kind!=='race'&&RC.kind!=='spa')||RC.done) return;
  const P=RC.P; if(!P.go||P.fin!=null||P.nitroT>0) return;
  if(S.nitro<1){flash('Plus de nitro','#FF4D6D'); return;}
  S.nitro--; bump('nitroN'); fxFlash('nit'); P.nit++; P.nitroT=NITRO_DUREE*((P.r||P).nD||1); flash('Nitro','#00E5FF',.9); auNitro();
  try{navigator.vibrate&&navigator.vibrate(40);}catch(e){}
  const b=$('pNit'); if(b){const sm=b.querySelector('small'); if(sm) sm.textContent='×'+S.nitro;}
}
function tick(dt){
  const P=RC.P, Os=RC.Os, tk=RC.tk; RC.clock+=dt; const t=RC.clock;
  if(t<0){
    if(!RC.auto&&inThr()>.05&&P.pen==null){P.pen=.8; flash('Faux départ, −0,8 s','#FF4D6D',1.6);}
    return;
  }
  Os.forEach(o=>{if(!o.go&&t>=o.react) o.go=true;});
  const ipt={thr:inThr(),brake:RC.inp.b||RC.inp.kb};
  if(!P.go){
    if(RC.auto){if(t>=P.react) P.go=true;}
    else if(ipt.thr>.05&&t>=(P.pen||0)){P.go=true; if(!P.pen) flash(t<.25?'Départ parfait':'Parti','#3CFF9E',.9);}
  }
  step(P,RC.auto?aiIn(P,tk):ipt,dt,tk,t); Os.forEach(o=>step(o,aiIn(o,tk),dt,tk,t));
  RC.O=Os.reduce((a,b)=>Math.abs(b.x-P.x)<Math.abs(a.x-P.x)?b:a); RC.pos=1+Os.filter(o=>o.x>P.x).length;
  if(P.msg){
    if(P.msg==='slide'){flash('Trop vite','#FF4D6D',1.3); try{navigator.vibrate&&navigator.vibrate([60,40,60]);}catch(e){}}
    if(P.msg==='perfect') flash('Virage parfait','#3CFF9E',.9);
    if(P.msg==='panne') flash('Panne moteur','#FCEE0A',1.8);
    P.msg=null;
  }
  dragMsg(P);
  if(P.fin!=null&&RC.endAt==null) RC.endAt=t+1.3;
  if(P.fin==null&&Os.every(o=>o.fin!=null)&&t>Math.max.apply(null,Os.map(o=>o.fin))+12){P.dnf=true; RC.endAt=t;}
  if(t>240&&RC.endAt==null){P.dnf=true; RC.endAt=t;}
  if(RC.endAt!=null&&t>=RC.endAt&&!RC.done) endManche();
}
function endManche(){
  const P=RC.P, tk=RC.tk, c=P.c; RC.done=true;
  const a=P.dnf?null:P.fin+(P.pen||0)*0, ot=RC.Os.map(o=>({nom:o.pil+' ('+o.nom+')',t:o.fin!=null?o.fin:RC.clock+(tk.L-o.x)/Math.max(o.v,5)}));
  c.etat=Math.max(5,c.etat-Math.round((rint(2,5)+P.slides+(P.panned?8:0))*wearK()));
  const row=mkRow(RC.mn,c,a,ot,{ap:P.panned,nit:P.nit,slides:P.slides,an:P.nom,xpB:P.xB||0});
  R.rows.push(row); auFinish(row.rank===1); showOver(row,'.pad3');
}
function finalize(forfeit){
  leaveRace();
  const ev=R.ev, n=ev.manches.length, rows=R.rows;
  const pay=forfeit?Math.min(.1,rows.reduce((t,x)=>t+x.pay,0)/n):rows.reduce((t,x)=>t+x.pay,0)/n;
  const win=!forfeit&&pay>=.85, pod=!forfeit&&pay>=.5, first=win&&!S.first[ev.id];
  const gain=Math.round(ev.gain*ECO.gain*(1+.04*pk('gain'))*(1+.1*S.bat.bureau)*Math.max(.1,pay)*(first?2:1)*karmaPrize(ev)), xp=Math.round(ev.xp*.9*(1+.06*pk('xp'))*(.3+.7*pay)*(S.xpb>0?1.5:1)*(1+.1*(S.bat.simu||0))*(1+rows.reduce((t,x)=>t+(x.xpB||0),0)/Math.max(1,rows.length)));
  const tok=(first?3:win?1:0)+(win&&Math.random()<.06*pk('tok')?1:0);
  S.cr+=gain; S.tok+=tok; S.stats.races++; bump('earned',gain); if(S.xpb>0) S.xpb--; if(S.ins>0) S.ins--; rows.forEach(x=>{if(x.won) bump('w_'+x.d);});
  if(win){S.stats.wins++; S.first[ev.id]=1; if(n>=3) S.stats.wins3++;}
  if(pod&&rows.some(x=>x.n>=6&&x.rank<=3)) S.stats.pods++;
  rows.forEach(x=>addCarXP(car(x.uid),Math.round(ev.xp*(.25+.25*pay))));
  addXP(xp);
  S.age++; if(S.age>=3) newOffres();
  R.result={rows,win,pod,gain,xp,first,tok}; illResolve(ev,pay,win,pod);
  view='result'; save(); render(); document.querySelector('main').scrollTop=0;
}
/* ---------- moteur 3D (Three.js) ---------- */
const GL={r:null,raf:0,last:0,tick:null,scene:null,cam:null,slot:null,w:0,h:0,mode:null,bound:false};
function glEnsure(){
  if(GL.r) return true; if(!window.THREE) return false;
  try{
    GL.r=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
    GL.r.setPixelRatio(window.__lq?1:Math.min(window.devicePixelRatio||1,1.75)); GL.r.setClearColor(0x080612);
    bindGarageInput(GL.r.domElement); bindViewerInput(GL.r.domElement); return true;
  }catch(e){GL.r=null; return false;}
}
function glAttach(id){
  const s=$(id); if(!s||!GL.r) return; const c=GL.r.domElement;
  c.style.cssText='display:block;width:100%;height:100%';
  if(c.parentNode!==s) s.insertBefore(c,s.firstChild); GL.slot=s; GL.w=0; glSize();
}
function glSize(){
  const s=GL.slot; if(!s||!GL.r) return; const w=s.clientWidth, h=s.clientHeight;
  if(w&&h&&(w!==GL.w||h!==GL.h)){GL.w=w; GL.h=h; GL.r.setSize(w,h,false); if(GL.cam){GL.cam.aspect=w/h; GL.cam.updateProjectionMatrix();}}
}
function glRun(scene,cam,tick,mode){
  glStop(); GL.scene=scene; GL.cam=cam; GL.tick=tick; GL.mode=mode; GL.last=0;
  GL.r.domElement.style.touchAction=(mode==='race'||mode==='viewer')?'none':'pan-y';
  if(GL.w&&GL.h){cam.aspect=GL.w/GL.h; cam.updateProjectionMatrix();}
  GL.raf=requestAnimationFrame(glFrame);
}
function glStop(){if(GL.raf){cancelAnimationFrame(GL.raf); GL.raf=0;} GL.tick=null; GL.mode=null; GL.post=null;}
function glFrame(ts){
  if(!GL.tick){GL.raf=0; return;}
  const dt=GL.last?Math.min(.05,(ts-GL.last)/1000):0; GL.last=ts;
  glSize(); GL.tick(dt,ts/1000); GL.r.render(GL.scene,GL.cam); if(GL.post) GL.post(); GL.raf=requestAnimationFrame(glFrame);
}
function disposeScene(sc){
  sc.traverse(o=>{
    if(o.geometry) o.geometry.dispose();
    if(o.material) (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m.map) m.map.dispose(); m.dispose();});
  });
}
function ctex(w,h,draw,rep){
  const c=document.createElement('canvas'); c.width=w; c.height=h; draw(c.getContext('2d'),w,h);
  const t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; if(rep) t.repeat.set(rep[0],rep[1]); return t;
}
function labelSprite(txt,col,scale){
  const t=ctex(256,64,(x,W,H)=>{x.fillStyle='rgba(6,4,20,.82)'; x.fillRect(0,0,W,H); x.strokeStyle=col; x.lineWidth=3; x.strokeRect(2,2,W-4,H-4); x.fillStyle=col; x.font='700 28px "Chakra Petch",Arial,sans-serif'; x.textAlign='center'; x.textBaseline='middle'; x.fillText(txt,W/2,H/2+2);});
  t.wrapS=t.wrapT=THREE.ClampToEdgeWrapping;
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,fog:false})); s.scale.set(scale,scale/4,1); return s;
}

/* Voitures 3D : chaque modèle est construit en formes simples, on remplacera par tes fichiers 3D */
const CAR3D={hatch:{L:4,W:1.8,h:.6,cl:2.1,ch:.55,cx:-.2},sedan:{L:4.7,W:1.85,h:.58,cl:2.4,ch:.5,cx:-.2},wagon:{L:4.6,W:1.8,h:.62,cl:3,ch:.58,cx:-.35},
  suv:{L:4.4,W:1.9,h:.85,cl:2.7,ch:.62,cx:-.25},van:{L:4.7,W:1.9,h:1.25,cl:2.6,ch:.7,cx:.3},bike:{L:1.8,W:.5,h:.5,cl:.4,ch:.3,cx:0},pickup:{L:5.1,W:1.95,h:.8,cl:1.5,ch:.62,cx:.6},coupe:{L:4.5,W:1.85,h:.52,cl:1.9,ch:.46,cx:-.2},super:{L:4.5,W:2,h:.46,cl:1.8,ch:.4,cx:-.1}};
function buildCar(m,accent,look){
  if(m.glb&&MODELS[m.glb]) return buildGlb(m,accent,look);
  const d=CAR3D[m.shape], g=new THREE.Group(), R0=.34, by=R0*.9+d.h/2, wheels=[], tail=[];
  const col=paintOf(look)||new THREE.Color(m.col), ac=new THREE.Color(accent);
  const mb=new THREE.MeshLambertMaterial({color:col}), ma=new THREE.MeshBasicMaterial({color:ac});
  const body=new THREE.Mesh(new THREE.BoxGeometry(d.L,d.h,d.W),mb); body.position.y=by; g.add(body);
  const cab=new THREE.Mesh(new THREE.BoxGeometry(d.cl,d.ch,d.W*.84),new THREE.MeshLambertMaterial({color:0x16324a,emissive:0x0a2030})); cab.position.set(d.cx,by+d.h/2+d.ch/2,0); g.add(cab);
  [1,-1].forEach(sd=>{const s=new THREE.Mesh(new THREE.BoxGeometry(d.L*.92,.05,.04),ma); s.position.set(0,by-.02,sd*(d.W/2+.01)); g.add(s);});
  if(m.shape==='super'||m.shape==='coupe'){
    const w=new THREE.Mesh(new THREE.BoxGeometry(.55,.06,d.W*.92),mb); w.position.set(-d.L/2+.25,by+d.h/2+.38,0); g.add(w);
    [1,-1].forEach(sd=>{const p=new THREE.Mesh(new THREE.BoxGeometry(.08,.36,.06),mb); p.position.set(-d.L/2+.25,by+d.h/2+.18,sd*d.W*.3); g.add(p);});
  }
  const glow=new THREE.Mesh(new THREE.PlaneGeometry(d.L*1.2,d.W*1.5),new THREE.MeshBasicMaterial({color:ac,transparent:true,opacity:.5,blending:THREE.AdditiveBlending,depthWrite:false}));
  /* halo sous la voiture supprimé */
  const wg=new THREE.CylinderGeometry(R0,R0,.28,18), rg=new THREE.CylinderGeometry(R0*.55,R0*.55,.3,12), sg=new THREE.BoxGeometry(R0*1.5,R0*.18,.32), wm=new THREE.MeshLambertMaterial({color:0x08090f});
  [[1,1],[1,-1],[-1,1],[-1,-1]].forEach(([fx,fz])=>{
    const p=new THREE.Group(); p.position.set(fx*d.L*.31,R0,fz*(d.W/2-.05));
    const w=new THREE.Mesh(wg,wm); w.rotation.x=Math.PI/2; const r=new THREE.Mesh(rg,ma); r.rotation.x=Math.PI/2; const sp=new THREE.Mesh(sg,ma);
    p.add(w); p.add(r); p.add(sp); g.add(p); wheels.push(p);
  });
  const hm=new THREE.MeshBasicMaterial({color:0xeaffff});
  [1,-1].forEach(sd=>{
    const h=new THREE.Mesh(new THREE.BoxGeometry(.05,.14,.4),hm); h.position.set(d.L/2+.01,by+.04,sd*d.W*.32); g.add(h);
    const tm=new THREE.MeshBasicMaterial({color:0x6a0f1c}); tail.push(tm);
    const t=new THREE.Mesh(new THREE.BoxGeometry(.05,.14,.5),tm); t.position.set(-d.L/2-.01,by+.04,sd*d.W*.32); g.add(t);
  });
  const flame=new THREE.Group();
  [1,-1].forEach(sd=>{const f=new THREE.Mesh(new THREE.ConeGeometry(.28,2.4,8),new THREE.MeshBasicMaterial({color:0x7df3ff,transparent:true,opacity:.85,blending:THREE.AdditiveBlending,depthWrite:false})); f.rotation.z=Math.PI/2; f.position.set(-d.L/2-1.2,by-.05,sd*d.W*.28); flame.add(f);});
  flame.visible=false; g.add(flame);
  addLook(g,{x0:-d.L/2,x1:d.L/2,W:d.W,deck:by+d.h/2,hood:by+d.h/2,H:by+d.h/2+d.ch,wr:R0,ww:.15},look,wheels); tintFlame(flame,look);
  return {shine:look&&look.shiny?[mb]:[],g,wheels,tail,flame,L:d.L,H:by+d.h/2+d.ch,wr:.34,brake:on=>tail.forEach(t=>t.color.setHex(on?0xff2244:0x6a0f1c))};
}


/* Modèles 3D fournis (format compact : géométrie binaire + textures réduites) */
const MODELS={}, MODEL_IDS=['patrouille','subi','audi','merco','velo'];
let modelsP=null, modelsBusy=false;
function b64buf(id){const t=document.getElementById(id).textContent.trim(), bin=atob(t), u=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u.buffer;}
const loadImg=src=>new Promise((res,rej)=>{const im=new Image(); im.onload=()=>res(im); im.onerror=rej; im.src=src;});
async function loadModel(id){
  const meta=JSON.parse(document.getElementById('mdl-'+id).textContent), buf=b64buf('bin-'+id), FL=['audi'].includes(id);
  if(FL){ const a=-meta.x1, b=-meta.x0; meta.x0=a; meta.x1=b; if(meta.cx) meta.cx=-meta.cx; if(meta.sirens) meta.sirens=meta.sirens.map(q=>[-q[0],q[1],-q[2]]); if(meta.wheels) meta.wheels=meta.wheels.map(w=>[-w[0],w[1],-w[2],w[3]]); }
  const flF=a=>{ if(!FL) return a; const o=a.slice(); for(let i=0;i<o.length;i+=3){ o[i]=-o[i]; o[i+2]=-o[i+2]; } return o; };
  const flN=a=>{ if(!FL) return a; const o=a.slice(); for(let i=0;i<o.length;i+=4){ o[i]=o[i]===-128?127:-o[i]; o[i+2]=o[i+2]===-128?127:-o[i+2]; } return o; };
  const tex=await Promise.all(meta.images.map(async src=>{const t=new THREE.Texture(await loadImg(src)); t.flipY=false; t.wrapS=t.wrapT=THREE.RepeatWrapping; t.anisotropy=4; t.needsUpdate=true; return t;}));
  const root=new THREE.Group(); let tailMat=null, tailE=[.45,.45,.45];
  meta.parts.forEach(p=>{
    const g=new THREE.BufferGeometry(); let mat; const m=p.mat;
    if(meta.v===2){
      g.setAttribute('position',new THREE.BufferAttribute(flF(new Float32Array(buf,p.p,p.nv*3)),3));
      g.setAttribute('normal',new THREE.InterleavedBufferAttribute(new THREE.InterleavedBuffer(flN(new Int8Array(buf,p.n,p.nv*4)),4),3,0,true));
      g.setIndex(new THREE.BufferAttribute(new Uint16Array(buf,p.i,p.ni),1));
      if(p.u!=null){ g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(buf,p.u,p.nv*2),2)); mat=new THREE.MeshLambertMaterial({map:tex[m.map],side:THREE.DoubleSide}); }
      else{
        const cb=new Uint8Array(buf,p.c,p.nv*4);
        if(m.paint) mat=new THREE.MeshLambertMaterial({color:new THREE.Color(cb[0]/255,cb[1]/255,cb[2]/255),side:THREE.DoubleSide});
        else if(m.tr) mat=new THREE.MeshLambertMaterial({color:new THREE.Color(m.col[0],m.col[1],m.col[2]),transparent:true,opacity:m.a,side:THREE.DoubleSide,depthWrite:false});
        else{ g.setAttribute('color',new THREE.InterleavedBufferAttribute(new THREE.InterleavedBuffer(cb,4),3,0,true)); mat=new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide});
          if(m.e){mat.emissive=new THREE.Color(m.e[0],m.e[1],m.e[2]); if(m.tail){tailMat=mat; tailE=m.e;}} }
      }
    } else {
      const o=p.o;
      g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(buf,o[0],p.nv*3),3));
      g.setAttribute('normal',new THREE.BufferAttribute(new Int8Array(buf,o[1],p.nv*3),3,true));
      g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(buf,o[2],p.nv*2),2));
      g.setIndex(new THREE.BufferAttribute(p.i32?new Uint32Array(buf,o[3],p.ni):new Uint16Array(buf,o[3],p.ni),1));
      mat=new THREE.MeshLambertMaterial({color:new THREE.Color(m.c[0],m.c[1],m.c[2]),map:m.map>=0?tex[m.map]:null,transparent:!!m.tr,opacity:m.a,side:THREE.DoubleSide,depthWrite:!m.tr});
      if(m.em>=0){mat.emissive=new THREE.Color(.45,.45,.45); mat.emissiveMap=tex[m.em]; tailMat=mat;}
    }
    const mesh=new THREE.Mesh(g,mat); if((m&&m.paint)||p.name==='carosserieLOW.1') mesh.userData.paint=1;
    if(p.wheel){const pv=new THREE.Group(); pv.name='wheel'; pv.position.set(FL?-p.wheel[0]:p.wheel[0],p.wheel[1],FL?-p.wheel[2]:p.wheel[2]); pv.add(mesh); root.add(pv);} else root.add(mesh);
  });
  MODELS[id]={root,len:meta.len,cx:meta.cx||0,h:meta.h,w:meta.w,sirens:meta.sirens||[],tailMat,tailE,meta};
}
function ensureModels(){
  if(modelsP) return modelsP;
  if(!window.THREE||!glEnsure()) return (modelsP=Promise.resolve());
  modelsBusy=true;
  modelsP=Promise.all(MODEL_IDS.filter(id=>document.getElementById('mdl-'+id)).map(id=>loadModel(id).catch(e=>{try{console.warn('modèle',id,e);}catch(_){}}))).then(()=>{modelsBusy=false; GG.sig=null; if(view==='garage') render(); thPump();});
  return modelsP;
}
function buildGlb(m,accent,look){
  const M0=MODELS[m.glb], me=M0.meta, g=new THREE.Group(), body=M0.root.clone(true), ac=new THREE.Color(accent), L=M0.len, shine=[], pc=paintOf(look);
  g.add(body);
  const wheels=body.children.filter(c=>c.name==='wheel');
  if(pc||(look&&look.shiny)) body.traverse(o=>{ if(o.userData.paint){o.material=o.material.clone(); if(pc) o.material.color.copy(pc); if(look.shiny) shine.push(o.material);} });
  const D=me.v===2?{x0:me.x0,x1:me.x1,W:Math.min(me.w,2),deck:me.deck,hood:me.hood,H:me.h,wr:me.wr,ww:.14}:{x0:-L/2,x1:L/2,W:1.9,deck:M0.h,hood:1.15,H:M0.h,wr:.375,ww:.13};
  const glow=new THREE.Mesh(new THREE.PlaneGeometry(L*1.2,D.W+.5),new THREE.MeshBasicMaterial({color:ac,transparent:true,opacity:.5,blending:THREE.AdditiveBlending,depthWrite:false}));
  /* halo sous la voiture supprimé */
  const sir=M0.sirens.map(q=>{const mt=new THREE.MeshBasicMaterial({color:0x07102a}); const s=new THREE.Mesh(new THREE.BoxGeometry(.25,.1,.5),mt); s.position.set(q[0],q[1],q[2]); g.add(s); return mt;});
  const flame=new THREE.Group();
  [1,-1].forEach(sd=>{const f=new THREE.Mesh(new THREE.ConeGeometry(.28,2.4,8),new THREE.MeshBasicMaterial({color:0x7df3ff,transparent:true,opacity:.85,blending:THREE.AdditiveBlending,depthWrite:false})); f.rotation.z=Math.PI/2; f.position.set(D.x0-1.2,Math.min(.6,D.H*.4),sd*Math.min(.55,D.W*.28)); flame.add(f);});
  flame.visible=false; g.add(flame);
  addLook(g,D,look,wheels); tintFlame(flame,look);
  const tm=M0.tailMat, e=M0.tailE;
  return {g,wheels,tail:[],flame,L,H:M0.h,wr:D.wr,sirens:sir.length?sir:null,shine,brake:on=>{if(tm) tm.emissive.setRGB(e[0]*(on?3:1),e[1],e[2]);}};
}
function pulseSirens(c,t){if(!c||!c.sirens) return; const ph=Math.floor(t*5)%2; c.sirens[0].color.setHex(ph?0x2f6bff:0x07102a); c.sirens[1].color.setHex(ph?0x07102a:0x2f6bff);}

/* --- piste --- */
function buildPath(tk){
  const STEP=2, PRE=80, POST=220, n=Math.ceil((tk.L+PRE+POST)/STEP)+1, px=[], pz=[], th=[]; let x=0, z=0, h=0;
  for(let i=0;i<n;i++){
    const s=-PRE+i*STEP; px.push(x); pz.push(z); th.push(h);
    const sg=tk.segs.find(q=>s>=q.a&&s<q.b);
    if(sg&&sg.t==='C') h+=sg.dir*sg.ang/((sg.b-sg.a)/STEP);
    x+=Math.cos(h)*STEP; z+=Math.sin(h)*STEP;
  }
  return {px,pz,th,STEP,PRE,POST,n};
}
function pathAt(Pa,s,lane){
  const f=clamp((s+Pa.PRE)/Pa.STEP,0,Pa.n-1.001), i=Math.floor(f), u=f-i;
  const th=Pa.th[i]+(Pa.th[i+1]-Pa.th[i])*u, x=Pa.px[i]+(Pa.px[i+1]-Pa.px[i])*u, z=Pa.pz[i]+(Pa.pz[i+1]-Pa.pz[i])*u;
  return {x:x+Math.sin(th)*lane, z:z-Math.cos(th)*lane, th};
}
function ribbon(Pa,off0,off1,y,i0,i1,vs){
  const pos=[], uv=[], idx=[]; let k=0;
  for(let i=i0;i<=i1;i++){
    const th=Pa.th[i], nx=Math.sin(th), nz=-Math.cos(th), x=Pa.px[i], z=Pa.pz[i], s=-Pa.PRE+i*Pa.STEP;
    pos.push(x+nx*off0,y,z+nz*off0,x+nx*off1,y,z+nz*off1); uv.push(0,s/vs,1,s/vs);
    if(i<i1) idx.push(k,k+1,k+2,k+1,k+3,k+2); k+=2;
  }
  const g=new THREE.BufferGeometry(); g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3)); g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2)); g.setIndex(idx); return g;
}
function gantry(sc,Pa,s,txt,col){
  const a=pathAt(Pa,s,0), g=new THREE.Group(); g.position.set(a.x,0,a.z); g.rotation.y=-a.th;
  const mc=new THREE.MeshBasicMaterial({color:new THREE.Color(col)});
  [1,-1].forEach(sd=>{const p=new THREE.Mesh(new THREE.BoxGeometry(.3,7,.3),mc); p.position.set(0,3.5,sd*6.9); g.add(p);});
  const b=new THREE.Mesh(new THREE.BoxGeometry(.3,.3,14),mc); b.position.set(0,7,0); g.add(b);
  const l=labelSprite(txt,col,6); l.position.set(0,8.6,0); g.add(l); sc.add(g);
}

function buildRace(ev,mn,tk,Pm,Oms){
  const sc=new THREE.Scene(), me=mn.m, fogCol=me==='neige'?0x3d3470:me==='pluie'?0x150c33:0x140a2e;
  sc.background=new THREE.Color(fogCol);
  sc.fog=new THREE.Fog(fogCol,me==='sec'?90:55,me==='sec'?720:me==='pluie'?420:360);
  sc.add(new THREE.HemisphereLight(0x9fb0ff,0x2a0a4a,1.05));
  const dl=new THREE.DirectionalLight(0xff9af0,.85); dl.position.set(-40,60,30); sc.add(dl);
  const Pa=buildPath(tk), n=Pa.n;

  /* route, bords néon, virages, lignes */
  const roadTex=ctex(128,256,(x,W,H)=>{x.fillStyle='#0c0d1f'; x.fillRect(0,0,W,H);
    for(let i=0;i<500;i++){x.fillStyle='rgba(120,130,200,'+(Math.random()*.07)+')'; x.fillRect(Math.random()*W,Math.random()*H,2,2);}
    x.fillStyle='rgba(232,235,255,.75)'; x.fillRect(W/2-2,0,4,H*.5);});
  sc.add(new THREE.Mesh(ribbon(Pa,5.6,-5.6,0,0,n-1,16),new THREE.MeshBasicMaterial({map:roadTex,side:THREE.DoubleSide})));
  sc.add(new THREE.Mesh(ribbon(Pa,6.1,5.6,.04,0,n-1,16),new THREE.MeshBasicMaterial({color:0x00e5ff,side:THREE.DoubleSide})));
  sc.add(new THREE.Mesh(ribbon(Pa,-5.6,-6.1,.04,0,n-1,16),new THREE.MeshBasicMaterial({color:0xff2bd6,side:THREE.DoubleSide})));
  const chev=ctex(128,128,(x,W,H)=>{x.clearRect(0,0,W,H); x.strokeStyle='rgba(255,43,214,.75)'; x.lineWidth=9; x.lineCap='round'; x.beginPath(); x.moveTo(W*.22,H*.8); x.lineTo(W*.5,H*.42); x.lineTo(W*.78,H*.8); x.stroke();});
  const chevM=new THREE.MeshBasicMaterial({map:chev,transparent:true,depthWrite:false,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  tk.segs.forEach(sg=>{
    if(sg.t!=='C') return;
    const i0=Math.max(0,Math.floor((sg.a+Pa.PRE)/Pa.STEP)), i1=Math.min(n-1,Math.ceil((sg.b+Pa.PRE)/Pa.STEP));
    sc.add(new THREE.Mesh(ribbon(Pa,5.4,-5.4,.03,i0,i1,9),chevM));
    gantry(sc,Pa,sg.a,'VIRAGE '+Math.round(Pm.cm(sg.base)*3.6),'#FF2BD6');
  });
  const chk=ctex(128,32,(x,W,H)=>{for(let r=0;r<2;r++) for(let c=0;c<8;c++){x.fillStyle=(r+c)%2?'#E8EBFF':'#0b0b18'; x.fillRect(c*16,r*16,16,16);}});
  const ifin=Math.round((tk.L+Pa.PRE)/Pa.STEP);
  sc.add(new THREE.Mesh(ribbon(Pa,5.6,-5.6,.05,ifin,ifin+2,4),new THREE.MeshBasicMaterial({map:chk,side:THREE.DoubleSide})));
  const ist=Math.round(Pa.PRE/Pa.STEP);
  sc.add(new THREE.Mesh(ribbon(Pa,5.6,-5.6,.05,ist,ist+1,2),new THREE.MeshBasicMaterial({color:0xe8ebff,side:THREE.DoubleSide})));
  gantry(sc,Pa,tk.L,'ARRIVÉE','#FCEE0A');

  /* sol quadrillé */
  const gridT=ctex(128,128,(x,W,H)=>{x.fillStyle='#07061a'; x.fillRect(0,0,W,H); x.strokeStyle='rgba(0,229,255,.45)'; x.lineWidth=2; x.strokeRect(0,0,W,H);},[300,300]);
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(9000,9000),new THREE.MeshBasicMaterial({map:gridT}));
  ground.rotation.x=-Math.PI/2; ground.position.y=-.12; sc.add(ground);

  /* ciel et soleil */
  const sg=new THREE.SphereGeometry(1400,16,12), cols=[], pp=sg.attributes.position, c1=new THREE.Color(0x03020b), c2=new THREE.Color(0x7a1a7a);
  for(let i=0;i<pp.count;i++){const t=clamp(1-Math.abs(pp.getY(i))/1400*1.6,0,1), c=c1.clone().lerp(c2,t*t); cols.push(c.r,c.g,c.b);}
  sg.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));
  const sky=new THREE.Mesh(sg,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide,fog:false,depthWrite:false})); sky.renderOrder=-2; sc.add(sky);
  const sunT=ctex(128,128,(x,W,H)=>{const g=x.createLinearGradient(0,0,0,H); g.addColorStop(0,'#FCEE0A'); g.addColorStop(1,'#FF2BD6'); x.fillStyle=g; x.beginPath(); x.arc(W/2,H/2,W/2-2,0,7); x.fill(); x.globalCompositeOperation='destination-out'; for(let k=0;k<6;k++) x.fillRect(0,H*.5+k*H*.09,W,k*1.6+1);});
  sunT.wrapS=sunT.wrapT=THREE.ClampToEdgeWrapping;
  const sun=new THREE.Mesh(new THREE.PlaneGeometry(420,420),new THREE.MeshBasicMaterial({map:sunT,transparent:true,fog:false,depthWrite:false})); sun.renderOrder=-1; sc.add(sun);

  /* ville : immeubles et enseignes, sans empiéter sur la route */
  const winT=[ '#00E5FF','#FF2BD6','#FCEE0A' ].map(cc=>ctex(64,128,(x,W,H)=>{x.fillStyle='#0a0a1e'; x.fillRect(0,0,W,H); for(let r=0;r<22;r++) for(let c=0;c<6;c++) if(Math.random()<.32){x.fillStyle=cc; x.globalAlpha=.35+Math.random()*.5; x.fillRect(5+c*9,4+r*5.5,5,3);} x.globalAlpha=1;}));
  const bl=[[],[],[]], cap=[[],[]]; const rr=Math.random;
  for(let s=-Pa.PRE;s<tk.L+Pa.POST;s+=13) for(const sd of [1,-1]){
    const w=8+rr()*14, d=8+rr()*14, h=18+rr()*100, off=sd*(w/2+14+rr()*30), p=pathAt(Pa,s+rr()*6,off); let ok=true;
    for(let i=0;i<n;i+=2){const dx=Pa.px[i]-p.x, dz=Pa.pz[i]-p.z; if(dx*dx+dz*dz<(Math.max(w,d)*.75+11)**2){ok=false; break;}}
    if(ok){const k=Math.floor(rr()*3); bl[k].push([p.x,p.z,w,h,d,p.th]); if(rr()<.7) cap[rr()<.5?0:1].push([p.x,p.z,w,h,d,p.th]);}
  }
  const dm=new THREE.Object3D(), ub=new THREE.BoxGeometry(1,1,1); ub.translate(0,.5,0);
  bl.forEach((arr,k)=>{ if(!arr.length) return; const im=new THREE.InstancedMesh(ub,new THREE.MeshBasicMaterial({map:winT[k]}),arr.length);
    arr.forEach((a,i)=>{dm.position.set(a[0],0,a[1]); dm.rotation.set(0,-a[5],0); dm.scale.set(a[2],a[3],a[4]); dm.updateMatrix(); im.setMatrixAt(i,dm.matrix);}); sc.add(im);});
  cap.forEach((arr,k)=>{ if(!arr.length) return; const im=new THREE.InstancedMesh(ub,new THREE.MeshBasicMaterial({color:k?0xff2bd6:0x00e5ff}),arr.length);
    arr.forEach((a,i)=>{dm.position.set(a[0],a[3],a[1]); dm.rotation.set(0,-a[5],0); dm.scale.set(a[2]+.4,.5,a[4]+.4); dm.updateMatrix(); im.setMatrixAt(i,dm.matrix);}); sc.add(im);});

  /* lampadaires */
  const lamps=[]; for(let s=0;s<tk.L+120;s+=24) for(const sd of [1,-1]) lamps.push(pathAt(Pa,s,sd*7.2));
  const poles=new THREE.InstancedMesh(new THREE.BoxGeometry(.18,6,.18),new THREE.MeshBasicMaterial({color:0x2b2f60}),lamps.length);
  const heads=new THREE.InstancedMesh(new THREE.BoxGeometry(.9,.25,.5),new THREE.MeshBasicMaterial({color:0x7df3ff}),lamps.length);
  lamps.forEach((p,i)=>{dm.rotation.set(0,-p.th,0); dm.scale.set(1,1,1); dm.position.set(p.x,3,p.z); dm.updateMatrix(); poles.setMatrixAt(i,dm.matrix); dm.position.set(p.x,6.1,p.z); dm.updateMatrix(); heads.setMatrixAt(i,dm.matrix);});
  sc.add(poles); sc.add(heads);

  let strobe=null;
  if(mn.d==='drag'){ strobe=new THREE.MeshBasicMaterial({color:0x00e5ff}); const pts=[]; for(let s=0;s<tk.L+60;s+=14) for(const sd of [1,-1]) pts.push(pathAt(Pa,s,sd*6.7));
    const sm=new THREE.InstancedMesh(new THREE.BoxGeometry(.5,1.4,.5),strobe,pts.length); pts.forEach((p,i)=>{dm.rotation.set(0,-p.th,0); dm.scale.set(1,1,1); dm.position.set(p.x,.7,p.z); dm.updateMatrix(); sm.setMatrixAt(i,dm.matrix);}); sc.add(sm); }
  /* voitures */
  const pc=buildCar(Pm.m,'#00E5FF',carLook(Pm.c)), ocs=Oms.map(r=>buildCar(r.m,'#FF2BD6',carLook(r.c))), oc=ocs[0]; sc.add(pc.g); ocs.forEach(q=>sc.add(q.g));
  const cam=new THREE.PerspectiveCamera(62,1.6,.3,1600);
  return {scene:sc,cam,path:Pa,pc,oc,ocs,sky,sun,ground,strobe,fov:62,weather:mkWeather(me,sc)};
}
function mkWeather(kind,sc){
  if(kind==='sec') return null;
  const rain=kind==='pluie', n=rain?420:300, off=new Float32Array(n*3), pos=new Float32Array(n*(rain?6:3));
  for(let i=0;i<n;i++){off[i*3]=Math.random()*80-20; off[i*3+1]=Math.random()*24-2; off[i*3+2]=(Math.random()-.5)*40;}
  const g=new THREE.BufferGeometry(); g.setAttribute('position',new THREE.BufferAttribute(pos,3));
  const obj=rain?new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0x9fdcff,transparent:true,opacity:.45,fog:false})):new THREE.Points(g,new THREE.PointsMaterial({color:0xffffff,size:.3,transparent:true,opacity:.85,fog:false}));
  obj.frustumCulled=false; sc.add(obj); return {obj,off,pos,n,rain};
}
function updWeather(W,cx,cy,cz,fx,fz,dt,v){
  const rx=-fz, rz=fx, o=W.off, p=W.pos, fall=W.rain?28:2.4;
  for(let i=0;i<W.n;i++){
    let f=o[i*3]-v*dt, u=o[i*3+1]-fall*dt; const r=o[i*3+2];
    if(u<-3) u+=26; if(f<-20) f+=80; if(f>60) f-=80; o[i*3]=f; o[i*3+1]=u;
    const x=cx+fx*f+rx*r, y=cy+u-1.5, z=cz+fz*f+rz*r;
    if(W.rain){const k=i*6; p[k]=x; p[k+1]=y; p[k+2]=z; p[k+3]=x+fx*v*.012; p[k+4]=y+.6; p[k+5]=z+fz*v*.012;}
    else {p[i*3]=x; p[i*3+1]=y; p[i*3+2]=z;}
  }
  W.obj.geometry.attributes.position.needsUpdate=true;
}

/* --- boucle d'une course --- */
function raceFrame(dt,time){
  if(!RC||RC.kind!=='race'||!RS) return;
  let left=dt; while(left>1e-6&&!RC.done&&!RC.paused){const h=Math.min(left,1/120); tick(h); left-=h;}
  drawRace(dt,time); hudRace(); auOldFrame(dt);
}
function drawRace(dt,time){
  const P=RC.P, O=RC.O, tk=RC.tk, Pa=RS.path, cam=RS.cam, t=RC.clock;
  const place=(r,cr3,lane)=>{
    const s=clamp(r.x,-Pa.PRE+4,tk.L+Pa.POST-6), p=pathAt(Pa,s,lane), cur=r.cur&&r.cur.t==='C'?r.cur:null;
    r.drift+=((r.slide&&cur?cur.dir*.32:0)-r.drift)*Math.min(1,dt*7);
    cr3.g.position.set(p.x,0,p.z); cr3.g.rotation.y=-p.th-r.drift; cr3.g.rotation.z=clamp(-r.a*.0035,-.04,.05);
    cr3.wheels.forEach(w=>{w.rotation.z-=r.v*dt/(cr3.wr||.34);});
    cr3.flame.visible=r.nitroT>0; if(r.nitroT>0){const f=.8+Math.random()*.6; cr3.flame.scale.set(f,1,f);}
    cr3.brake(r.braking);
  };
  place(P,RS.pc,P.lane); RC.Os.forEach((o,k)=>place(o,RS.ocs[k],o.lane)); [RS.pc].concat(RS.ocs).forEach(q=>{pulseSirens(q,time); shineTick(q,time);});
  const nit=P.nitroT>0, camS=Math.max(-Pa.PRE+3,P.x-9-P.v*.045), cp=pathAt(Pa,camS,P.lane*.65), lk=pathAt(Pa,P.x+20,P.lane*.55);
  cam.position.set(cp.x,Math.max(3.1,1.7+(RS.pc.H||1.4)*.75)+P.v*.006+(nit?(Math.random()-.5)*.07:0),cp.z); cam.lookAt(lk.x,1.2,lk.z); if(orbitOn()) orbitRace(cam,P,Pa,dt);
  const tf=62+Math.min(P.v,95)*.13+(nit?12:0); RS.fov+=(tf-RS.fov)*Math.min(1,dt*4);
  if(Math.abs(cam.fov-RS.fov)>.05){cam.fov=RS.fov; cam.updateProjectionMatrix();}
  RS.sky.position.copy(cam.position);
  const sa=hash(EVENTS.indexOf(R.ev),9)*6.28; RS.sun.position.set(cam.position.x+Math.cos(sa)*1150,150,cam.position.z+Math.sin(sa)*1150); RS.sun.lookAt(cam.position);
  RS.ground.position.x=Math.round(cam.position.x/30)*30; RS.ground.position.z=Math.round(cam.position.z/30)*30;
  if(RS.strobe) RS.strobe.color.setHSL((time*1.6)%1,1,.35+.3*Math.abs(Math.sin(P.x*.05+time*6)));
  if(RS.weather) updWeather(RS.weather,cam.position.x,cam.position.y,cam.position.z,Math.cos(cp.th),Math.sin(cp.th),dt,P.v);
}
function sT(id,v){const e=$(id); if(e&&e._v!==v){e._v=v; e.textContent=v;}}
function hudRace(){
  const P=RC.P, O=RC.O, tk=RC.tk, t=RC.clock;
  sT('hSpd',String(Math.round(P.v*3.6))); sT('hPos',(RC.pos||1)+' / '+(RC.Os.length+1));
  sT('hTime',(Math.max(0,P.fin!=null?P.fin:t)).toFixed(2).replace('.',',')+' s');
  const gap=O.x-P.x; sT('hGap',P.go?(gap>0?`${O.pil} devant, ${Math.round(gap)} m`:`${O.pil} derrière, ${Math.round(-gap)} m`):'');
  const L=$('hLights'); if(L){
    L.style.display=(t>1.4||(P.go&&t>.6))?'none':'flex';
    const n=t<0?clamp(Math.floor(t+3.4),0,3):3; auLights(n,t>=0); [...L.children].forEach((e,k)=>{const c=t>=0?'g':(k<n?'r':''); if(e._c!==c){e._c=c; e.className=c;}});
  }
  const nc=nextCorner(P,tk), inC=P.cur&&P.cur.t==='C'; let msg='', col='#E8EBFF', cue=false, hot=false;
  if(P.go&&P.fin==null&&nc){
    const cm=P.cm(nc.base), dist=nc.a-P.x, needD=Math.max(0,(P.v*P.v-cm*cm)/(2*P.B));
    cue=P.v>cm&&dist<=needD+P.v*.35;
    if(cue&&Math.floor(t*8)%2===0){msg='FREINE'; col='#FCEE0A';}
    else if(!cue&&dist<260){msg=`Virage dans ${Math.round(dist)} m, max ${Math.round(cm*3.6)} km/h`; col='#FF8BEA';}
    hot=cue;
  }
  if(P.cur&&inC&&P.v>P.cm(P.cur.base)*1.04) hot=true;
  if(RC.flash&&t<RC.flash.until){msg=RC.flash.txt; col=RC.flash.col;}
  else if(t>=0&&!P.go&&!RC.auto&&P.pen==null){msg='Écrase le gaz'; col='#3CFF9E';}
  else if(P.fin!=null){msg='Arrivée'; col='#FCEE0A';}
  const m=$('hMsg'); if(m){if(m._v!==msg){m._v=msg; m.textContent=msg;} if(m._c!==col){m._c=col; m.style.color=col;} m.style.fontSize=msg==='FREINE'?'34px':'24px';}
  const sp=$('hSpd'); if(sp){sp.classList.toggle('hot',hot);}
  const th=RC.auto?(P.go&&!P.braking?1:0):(RC.inp.b||RC.inp.kb?0:inThr());
  const gf=$('gasFill'); if(gf) gf.style.width=Math.round(th*100)+'%';
  const gp=$('gasPed'); if(gp) gp.style.height=Math.round(th*100)+'%';
  const nf=$('nitFill'); if(nf) nf.style.width=Math.round(clamp(P.nitroT/NITRO_DUREE,0,1)*100)+'%'; fxUpdate(P,RC);
  const bn=$('pNit'); if(bn) bn.classList.toggle('on',P.nitroT>0); hudGearUpd(P); rmapDraw();
}
function bindRace(){
  if(RC&&RC.kind==='spa') return bindSpa(); if(RC&&RC.kind==='show') return bindShow();
  if(!GL.r||!RS) return; glAttach('rslot'); rmapInit();
  const bg=$('pGas'), bb=$('pBrk')||document.createElement('div'), bn=$('pNit'); let y0=0, gdown=false;
  bg.addEventListener('pointerdown',e=>{e.preventDefault(); try{bg.setPointerCapture(e.pointerId);}catch(_){} gdown=true; y0=e.clientY; RC.inp.t=1;});
  bg.addEventListener('pointermove',e=>{if(!gdown) return; RC.inp.t=clamp(1-Math.max(0,e.clientY-y0)/110,.25,1);});
  const gup=()=>{gdown=false; RC.inp.t=0;}; bg.addEventListener('pointerup',gup); bg.addEventListener('pointercancel',gup);
  bb.addEventListener('pointerdown',e=>{e.preventDefault(); try{bb.setPointerCapture(e.pointerId);}catch(_){} RC.inp.b=true; bb.classList.add('on');});
  const bup=()=>{RC.inp.b=false; bb.classList.remove('on');}; bb.addEventListener('pointerup',bup); bb.addEventListener('pointercancel',bup);
  bn.addEventListener('pointerdown',e=>{e.preventDefault(); fireNitro();});
  [bg,bb,bn].forEach(b=>b.addEventListener('contextmenu',e=>e.preventDefault())); bindShift();
  glRun(RS.scene,RS.cam,raceFrame,'race');
}

/* ---------- GARAGE 3D ---------- */
const GG={cars:[],sig:null,scene:null,cam:null,ang:.6,idle:0,hit:[],turn:[],ray:null,down:null};
function garageSig(){return S.pod.tier+'|'+S.lvl+'|'+S.pod.slots.map(u=>{const c=u&&car(u);return c?c.mid+':'+lookKey(c):'-';}).join(',');}
function garageSync(){
  if(!glEnsure()) return false;
  const sig=garageSig();
  if(GG.sig!==sig||!GG.scene){if(GG.scene) disposeScene(GG.scene); buildGarage(); GG.sig=sig;}
  return true;
}
function buildGarage(){
  const sc=new THREE.Scene(), tier=S.pod.tier; sc.background=new THREE.Color(0x07050f); sc.fog=new THREE.Fog(0x07050f,34,95);
  sc.add(new THREE.HemisphereLight(0xa9b8ff,0x2a0a4a,1.1)); const dl=new THREE.DirectionalLight(0xffa0f0,.8); dl.position.set(-12,24,10); sc.add(dl);
  const pa=new THREE.PointLight(0x00e5ff,1.1,45); pa.position.set(0,10,0); sc.add(pa);
  const gridT=ctex(128,128,(x,W,H)=>{x.fillStyle='#0a0a20'; x.fillRect(0,0,W,H); x.strokeStyle='rgba(0,229,255,.4)'; x.lineWidth=2; x.strokeRect(0,0,W,H);},[18,18]);
  const floor=new THREE.Mesh(new THREE.CircleGeometry(30,64),new THREE.MeshBasicMaterial({map:gridT})); floor.rotation.x=-Math.PI/2; sc.add(floor);
  [[10.4,10.6,0x00e5ff],[19.8,20,0xff2bd6]].forEach(([a,b,c])=>{const r=new THREE.Mesh(new THREE.RingGeometry(a,b,64),new THREE.MeshBasicMaterial({color:c,side:THREE.DoubleSide})); r.rotation.x=-Math.PI/2; r.position.y=.02; sc.add(r);});
  const wallT=ctex(256,64,(x,W,H)=>{x.fillStyle='#0b0a22'; x.fillRect(0,0,W,H); x.fillStyle='rgba(0,229,255,.8)'; x.fillRect(0,H*.45,W,3); x.fillStyle='rgba(255,43,214,.8)'; x.fillRect(0,H*.7,W,3); x.fillStyle='rgba(60,70,160,.5)'; for(let i=0;i<8;i++) x.fillRect(i*32,0,2,H);},[6,1]);
  const wall=new THREE.Mesh(new THREE.CylinderGeometry(30,30,18,48,1,true),new THREE.MeshBasicMaterial({map:wallT,side:THREE.BackSide})); wall.position.y=9; sc.add(wall);
  for(let i=0;i<12;i++){const a=i/12*6.283, b=new THREE.Mesh(new THREE.BoxGeometry(5,.2,.5),new THREE.MeshBasicMaterial({color:0xcff9ff})); b.position.set(Math.cos(a)*14,15,Math.sin(a)*14); b.rotation.y=-a+1.5708; sc.add(b);}
  GG.hit=[]; GG.turn=[]; GG.cars=[];
  const gold=tier>=5, c1=gold?0xfcee0a:0x00e5ff, uc=new THREE.Color(0x14163a);
  for(let i=0;i<POD_MAX;i++){
    const a=-Math.PI/2+i*Math.PI*2/POD_MAX, unl=S.lvl>=POD_LVL[i], pg=new THREE.Group(); pg.position.set(Math.cos(a)*10,0,Math.sin(a)*10); sc.add(pg);
    const base=new THREE.Mesh(new THREE.CylinderGeometry(3,3.2,.5,32),new THREE.MeshLambertMaterial({color:unl?uc:0x0b0b18})); base.position.y=.25; pg.add(base);
    const ring=new THREE.Mesh(new THREE.TorusGeometry(3.05,.07,8,48),new THREE.MeshBasicMaterial({color:unl?c1:0x333355})); ring.rotation.x=Math.PI/2; ring.position.y=.5; pg.add(ring);
    if(unl&&tier>=2){const r2=new THREE.Mesh(new THREE.TorusGeometry(2.45,.05,8,48),new THREE.MeshBasicMaterial({color:0xff2bd6})); r2.rotation.x=Math.PI/2; r2.position.y=.52; pg.add(r2);}
    if(unl&&tier>=4){const sp=new THREE.Mesh(new THREE.ConeGeometry(2.8,11,24,1,true),new THREE.MeshBasicMaterial({color:c1,transparent:true,opacity:.1,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide})); sp.position.y=6; pg.add(sp);}
    const hit=new THREE.Mesh(new THREE.CylinderGeometry(3.3,3.3,5,12),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false})); hit.position.y=2.5; hit.userData.slot=i; pg.add(hit); GG.hit.push(hit);
    const cr=unl&&S.pod.slots[i]?car(S.pod.slots[i]):null;
    if(!unl){const l=labelSprite('Niveau '+POD_LVL[i],'#8E94C0',4.4); l.position.y=2.4; pg.add(l);}
    else if(!cr){const l=labelSprite('Podium libre','#00E5FF',4.4); l.position.y=2.2; pg.add(l);}
    else{
      const m=M[cr.mid], pv=new THREE.Group(); pv.position.y=.58; pv.rotation.y=-(a+Math.PI/2)+.45; pg.add(pv);
      const cc=buildCar(m,TIERS[m.t].c,carLook(cr)); cc.g.scale.setScalar(1.12); pv.add(cc.g); GG.cars.push(cc); if(tier>=3) GG.turn.push(pv);
      if(tier>=2){const l=labelSprite(m.nom,TIERS[m.t].c,5.2); l.position.y=4.2; pg.add(l);}
    }
  }
  GG.scene=sc; GG.cam=new THREE.PerspectiveCamera(48,1.6,.5,200); GG.ray=new THREE.Raycaster();
}
function garageFrame(dt,time){
  GG.idle+=dt; GG.cars.forEach(c=>{pulseSirens(c,time); shineTick(c,time);}); if(GG.idle>2.5) GG.ang+=dt*.12;
  GG.turn.forEach(p=>{p.rotation.y+=dt*.5;});
  GG.cam.position.set(Math.cos(GG.ang)*25,8.8,Math.sin(GG.ang)*25); GG.cam.lookAt(0,1.4,0);
}
function bindGarage(){
  if(!$('gslot')||!garageSync()) return;
  glAttach('gslot'); glRun(GG.scene,GG.cam,garageFrame,'garage');
}
function bindGarageInput(c){
  c.addEventListener('pointerdown',e=>{if(GL.mode!=='garage') return; GG.down={x:e.clientX,y:e.clientY,ang:GG.ang,moved:false}; GG.idle=0; try{c.setPointerCapture(e.pointerId);}catch(_){}});
  c.addEventListener('pointermove',e=>{const d=GG.down; if(!d||GL.mode!=='garage') return; const dx=e.clientX-d.x; if(Math.abs(dx)>14) d.moved=true; GG.ang=d.ang-dx*.008; GG.idle=0;});
  c.addEventListener('pointerup',e=>{const d=GG.down; GG.down=null; if(!d||d.moved||GL.mode!=='garage') return; garagePick(e,c);});
  c.addEventListener('pointercancel',()=>{GG.down=null;});
}
function garagePick(e,c){
  const r=c.getBoundingClientRect(); GG.ray.setFromCamera({x:(e.clientX-r.left)/r.width*2-1,y:-((e.clientY-r.top)/r.height*2-1)},GG.cam);
  const h=GG.ray.intersectObjects(GG.hit,false); if(h.length) openSheet({t:'slot',i:h[0].object.userData.slot});
}
/* revenus du showroom */
const podRate=()=>(1+.06*pk('pod'))*S.pod.slots.reduce((t,u,i)=>{const c=u&&S.lvl>=POD_LVL[i]?car(u):null; return t+(c?M[c.mid].t*S.pod.tier*3*(.5+.5*c.etat/100)*(1+(st(c).sp.inc||0))*(c.sh?1.5:1):0);},0);
const podPending=()=>Math.min(480,(Date.now()-S.pod.last)/60000)*podRate();
function updPod(){const b=$('pCollect'); if(b&&view==='garage') b.innerHTML=`Récolter<br>${cr(Math.floor(podPending()))}`;}

/* ---------- CIRCUIT DE SPA : données, physique, surfaces, collisions, pilote ---------- */
const TRK={ready:false};
function b64bufT(txt){const bin=atob(txt.trim()), u=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u.buffer;}
async function loadTrack(opts){
  opts=opts||{};
  const meta=opts.meta||JSON.parse(document.getElementById('trk-json').textContent);
  const buf=opts.buf||b64bufT(document.getElementById('trk-bin').textContent), P=meta.phys, N=meta.N;
  const F=o=>new Float32Array(buf,o,N);
  Object.assign(TRK,{meta,buf,N,DS:meta.DS,L:meta.L,cx:F(P.cx),cz:F(P.cz),cy:F(P.cy),th:F(P.th),kap:F(P.kap),limL:F(P.limL),limR:F(P.limR),pl:F(P.pl),pr:F(P.pr),wallL:F(P.wallL),wallR:F(P.wallR),nseg:P.nseg,segs:new Float32Array(buf,P.segs,P.nseg*4),styp:new Uint8Array(buf,P.styp,P.nseg),
    hrel:new Int16Array(buf,P.hrel,N*meta.nh),nh:meta.nh,dh0:meta.dh0,dhs:meta.dhs,X0:meta.X0,Z0:meta.Z0,GW:meta.GW,GH:meta.GH});
  if(opts.gridBytes) TRK.grid=opts.gridBytes;
  else{
    const im=await loadImg(meta.grid), cv=document.createElement('canvas'); cv.width=im.width; cv.height=im.height;
    const cx2=cv.getContext('2d',{willReadFrequently:true}); cx2.drawImage(im,0,0); const d=cx2.getImageData(0,0,cv.width,cv.height).data, g=new Uint8Array(cv.width*cv.height);
    for(let i=0;i<g.length;i++) g[i]=d[i*4]; TRK.grid=g;
  }
  buildSegGrid(); TRK.ready=true; return TRK;
}
const wrapA=a=>{a=(a+Math.PI)%(2*Math.PI); return (a<0?a+2*Math.PI:a)-Math.PI;};
const wrapS=s=>{const L=TRK.L; s%=L; return s<0?s+L:s;};
const dS=(a,b)=>{const L=TRK.L; let d=(a-b)%L; if(d>L/2) d-=L; if(d<-L/2) d+=L; return d;};   /* écart signé le plus court sur la boucle */

/* repère de la piste interpolé à l'abscisse s */
function frameAt(s){
  const N=TRK.N, f=wrapS(s)/TRK.DS, i=Math.floor(f)%N, j=(i+1)%N, u=f-Math.floor(f);
  const th=Math.atan2(Math.sin(TRK.th[i])*(1-u)+Math.sin(TRK.th[j])*u,Math.cos(TRK.th[i])*(1-u)+Math.cos(TRK.th[j])*u);
  return {i,x:TRK.cx[i]+(TRK.cx[j]-TRK.cx[i])*u,z:TRK.cz[i]+(TRK.cz[j]-TRK.cz[i])*u,y:TRK.cy[i]+(TRK.cy[j]-TRK.cy[i])*u,th,
    nx:Math.sin(th),nz:-Math.cos(th),limL:TRK.limL[i]+(TRK.limL[j]-TRK.limL[i])*u,limR:TRK.limR[i]+(TRK.limR[j]-TRK.limR[i])*u,wL:TRK.wallL[i]+(TRK.wallL[j]-TRK.wallL[i])*u,wR:TRK.wallR[i]+(TRK.wallR[j]-TRK.wallR[i])*u,kap:TRK.kap[i]};
}
/* projection d'un point sur la ligne centrale : s (abscisse), d (écart latéral, + = gauche) */
function project(x,z,hint){
  const N=TRK.N, cx=TRK.cx, cz=TRK.cz; let bi=0, bd=1e18;
  if(hint==null||hint<0){for(let i=0;i<N;i+=2){const dx=x-cx[i],dz=z-cz[i],q=dx*dx+dz*dz; if(q<bd){bd=q;bi=i;}} for(let k=-2;k<=2;k++){const i=(bi+k+N)%N,dx=x-cx[i],dz=z-cz[i],q=dx*dx+dz*dz; if(q<bd){bd=q;bi=i;}}}
  else{for(let k=-30;k<=30;k++){const i=(hint+k+N)%N,dx=x-cx[i],dz=z-cz[i],q=dx*dx+dz*dz; if(q<bd){bd=q;bi=i;}}}
  const th=TRK.th[bi], tx=Math.cos(th), tz=Math.sin(th);
  let ds=(x-cx[bi])*tx+(z-cz[bi])*tz; ds=Math.max(-TRK.DS,Math.min(TRK.DS,ds));
  const s=bi*TRK.DS+ds, fr=frameAt(s), d=(x-fr.x)*fr.nx+(z-fr.z)*fr.nz;
  return {i:bi,s:wrapS(s),d,fr,dist:Math.sqrt(bd)};
}
/* hauteur du sol à (s,d) */
function groundY(s,d){
  const N=TRK.N, f=wrapS(s)/TRK.DS, i=Math.floor(f)%N, j=(i+1)%N, u=f-Math.floor(f), nh=TRK.nh;
  let k=(Math.max(TRK.dh0,Math.min(-TRK.dh0,d))-TRK.dh0)/TRK.dhs; const k0=Math.max(0,Math.min(nh-2,Math.floor(k))), t=k-k0, H=TRK.hrel;
  const a=H[i*nh+k0]*(1-t)+H[i*nh+k0+1]*t, b=H[j*nh+k0]*(1-t)+H[j*nh+k0+1]*t;
  return TRK.cy[i]+(TRK.cy[j]-TRK.cy[i])*u+(a+(b-a)*u)/100;
}
function surfAt(x,z){
  const gx=Math.floor(x-TRK.X0), gz=Math.floor(z-TRK.Z0);
  if(gx<0||gz<0||gx>=TRK.GW||gz>=TRK.GH) return 0;
  return TRK.grid[gz*TRK.GW+gx];
}
/* propriétés de chaque surface : adhérence, résistance, traction, freinage */
const SURF=[
 {n:'Hors piste',mu:.40,r0:2.0,rv:.20,tr:.50,br:.50},{n:'Hors piste',mu:.55,r0:.8,rv:.10,tr:.60,br:.60},
 {n:'Herbe',mu:.60,r0:.6,rv:.08,tr:.70,br:.60},{n:'Terre',mu:.65,r0:.5,rv:.06,tr:.75,br:.65},
 {n:'Sable',mu:.38,r0:2.2,rv:.22,tr:.45,br:.50},{n:'Gravier',mu:.50,r0:1.0,rv:.12,tr:.50,br:.55},
 {n:'Route',mu:.92,r0:.2,rv:.015,tr:.95,br:.95},{n:'Asphalte',mu:1,r0:.15,rv:.012,tr:1,br:1},{n:'Vibreur',mu:.93,r0:.2,rv:.014,tr:.97,br:.95}];
const SURF_COL=['#FF4D6D','#FF4D6D','#3CFF9E','#C08A4A','#FCEE0A','#B8B4D0','#E8EBFF','#E8EBFF','#FF2BD6'];

/* voiture sur la piste */
function mkSpaCar(r,m,s0,lane,etat){
  const fr=frameAt(s0), len=(typeof MODELS!=='undefined'&&MODELS[m.glb]&&MODELS[m.glb].len)||((typeof CAR3D!=='undefined'&&CAR3D[m.shape])||{L:4.5}).L;
  const mw=typeof MODELS!=='undefined'&&MODELS[m.glb]&&MODELS[m.glb].meta&&MODELS[m.glb].meta.v===2?Math.min(1.95,MODELS[m.glb].w):1.9;
  const c={r,m,len,wid:mw,x:fr.x+fr.nx*lane,z:fr.z+fr.nz*lane,y:fr.y,psi:fr.th,vx:0,vz:0,yaw:0,steer:0,s:wrapS(s0),d:lane,i:fr.i,prog:dS(s0,s0),surf:7,
    pitch:0,roll:0,etat:etat==null?100:etat,nitroT:0,boostT:0,hits:0,dmg:0,hitFlash:0,offT:0,onPave:true,fin:null,go:false,pen:0,wrongT:0,stuckT:0,rumble:0,slipAng:0,v:0,lastHit:0};
  c.prog=0; return c;
}
function carStep(c,inp,dt){
  const r=c.r, S0=SURF[c.surf]||SURF[7], S=S0;
  let fx=Math.cos(c.psi), fz=Math.sin(c.psi), lx=Math.sin(c.psi), lz=-Math.cos(c.psi);
  let vf=c.vx*fx+c.vz*fz, vl=c.vx*lx+c.vz*lz; const spd=Math.abs(vf);
  /* direction : braquage max décroissant avec la vitesse */
  const tr=r.m.tr, aS=11.0*S.mu*r.gc*(.55+.45*c.etat/100)*(c.surf<6?(r.oB||1):1); let dmax=Math.min(.62,1.35*aS*(c.len*.6)/(spd*spd+25)); if(tr==='FWD'&&inp.thr>.7) dmax*=.92;
  c.steer+=(inp.steer*dmax-c.steer)*Math.min(1,dt*9);
  let yaw=(vf>=0?1:-1)*spd/(c.len*.6)*Math.tan(c.steer);
  const slip=Math.atan2(vl,Math.max(spd,3)); c.slipAng=slip;
  yaw*=1-Math.max(0,Math.min(.6,(Math.abs(slip)-.35)/.7));
  if(inp.hand&&spd>6) yaw*=1.25;
  c.psi=wrapA(c.psi+yaw*dt); c.yaw=yaw;
  fx=Math.cos(c.psi); fz=Math.sin(c.psi); lx=Math.sin(c.psi); lz=-Math.cos(c.psi);
  vf=c.vx*fx+c.vz*fz; vl=c.vx*lx+c.vz*lz;
  /* longitudinal */
  const nit=c.nitroT>0, vm=r.VM*(nit?1.18:1), thr=Math.max(0,Math.min(1,inp.thr)); let a=0;
  if(c.nitroT>0) c.nitroT-=dt; if(c.boostT>0) c.boostT-=dt;
  if(!c.go||c.pen>0) { if(c.pen>0) c.pen-=dt; }
  if(c.go&&c.pen<=0){
    let drive=r.A*(nit?1.6*(r.nP||1):1)*(c.boostT>0?1.25:1)*(1-Math.max(vf,0)/vm); if(drive>0) drive*=thr;
    a+=Math.min(drive,r.TR*(nit?1.15:1)*S.tr)-(1-thr)*(vf>0?1.8:0);
  }
  if(inp.brake){ if(vf>.5) a-=r.B*S.br; else a-=Math.min(5,Math.max(0,8+vf)); }
  a-=Math.sign(vf)*Math.min(S.r0+S.rv*spd,spd/dt*.9);
  vf+=a*dt;
  if(vf<-9) vf=-9;
  /* adhérence latérale (cercle de friction simplifié) */
  let aMax=aS*(inp.hand?.5:1);
  if(tr==='RWD'&&thr>.7&&S.mu<.8) aMax*=.88;
  aMax*=1-.3*Math.min(1,Math.abs(a)/(r.B+1)); aMax=Math.max(aMax,1.5);
  const dv=aMax*dt, ovl=vl; vl=Math.abs(vl)<=dv?0:vl-Math.sign(vl)*dv;
  vf-=Math.sign(vf)*Math.min(Math.abs(vf),Math.abs(ovl)*dt*.35);       /* la glisse use de la vitesse */
  c.vx=vf*fx+vl*lx; c.vz=vf*fz+vl*lz; c.v=Math.hypot(c.vx,c.vz);
  c.x+=c.vx*dt; c.z+=c.vz*dt;
}
/* ---- vraies barrières : grille spatiale et collision rectangle / segment ---- */
function buildSegGrid(){
  const S=TRK.segs, n=TRK.nseg, C=10; let x0=1e9,z0=1e9,x1=-1e9,z1=-1e9;
  for(let i=0;i<n;i++){x0=Math.min(x0,S[4*i],S[4*i+2]); x1=Math.max(x1,S[4*i],S[4*i+2]); z0=Math.min(z0,S[4*i+1],S[4*i+3]); z1=Math.max(z1,S[4*i+1],S[4*i+3]);}
  x0-=2; z0-=2; const W=Math.ceil((x1-x0)/C)+2, H=Math.ceil((z1-z0)/C)+2, cnt=new Int32Array(W*H+1), cells=[];
  const span=i=>{const ax=Math.min(S[4*i],S[4*i+2])-.5, bx=Math.max(S[4*i],S[4*i+2])+.5, az=Math.min(S[4*i+1],S[4*i+3])-.5, bz=Math.max(S[4*i+1],S[4*i+3])+.5; return [Math.floor((ax-x0)/C),Math.floor((bx-x0)/C),Math.floor((az-z0)/C),Math.floor((bz-z0)/C)];};
  for(let i=0;i<n;i++){const [a,b,c,d]=span(i); for(let gz=c;gz<=d;gz++) for(let gx=a;gx<=b;gx++) cnt[gz*W+gx+1]++;}
  for(let k=0;k<W*H;k++) cnt[k+1]+=cnt[k];
  const idx=new Int32Array(cnt[W*H]), fill=cnt.slice(0,W*H);
  for(let i=0;i<n;i++){const [a,b,c,d]=span(i); for(let gz=c;gz<=d;gz++) for(let gx=a;gx<=b;gx++) idx[fill[gz*W+gx]++]=i;}
  TRK.sg={x0,z0,C,W,H,start:cnt,idx,stamp:new Int32Array(n),tick:0};
}
function segsNear(x,z,r,cb){
  const g=TRK.sg; if(!g) return; g.tick++;
  const a=Math.max(0,Math.floor((x-r-g.x0)/g.C)), b=Math.min(g.W-1,Math.floor((x+r-g.x0)/g.C)), c=Math.max(0,Math.floor((z-r-g.z0)/g.C)), d=Math.min(g.H-1,Math.floor((z+r-g.z0)/g.C));
  for(let gz=c;gz<=d;gz++) for(let gx=a;gx<=b;gx++){const k=gz*g.W+gx; for(let q=g.start[k];q<g.start[k+1];q++){const i=g.idx[q]; if(g.stamp[i]===g.tick) continue; g.stamp[i]=g.tick; cb(i);}}
}
const WALL_T=.18;
/* rectangle de la voiture contre un segment : vecteur minimal de sortie (axes : avant, côté, normale du segment) */
function segMTV(c,i){
  const S=TRK.segs, ax=S[4*i], az=S[4*i+1], bx=S[4*i+2], bz=S[4*i+3], cs=Math.cos(c.psi), sn=Math.sin(c.psi);
  const ua=(ax-c.x)*cs+(az-c.z)*sn, va=(ax-c.x)*sn-(az-c.z)*cs, ub=(bx-c.x)*cs+(bz-c.z)*sn, vb=(bx-c.x)*sn-(bz-c.z)*cs;
  const hl=c.len/2+WALL_T, hw=c.wid/2+WALL_T;
  const ou=Math.min(hl,Math.max(ua,ub))-Math.max(-hl,Math.min(ua,ub)); if(ou<=0) return null;
  const ov=Math.min(hw,Math.max(va,vb))-Math.max(-hw,Math.min(va,vb)); if(ov<=0) return null;
  const su=ub-ua, sv=vb-va, sl=Math.hypot(su,sv); if(sl<1e-6) return null;
  const nu=-sv/sl, nv=su/sl, dist=ua*nu+va*nv, r=Math.abs(nu)*hl+Math.abs(nv)*hw, on=r-Math.abs(dist); if(on<=0) return null;
  let pen=ou, du=(ua+ub>0?-1:1), dv=0;                     /* pousser la voiture à l'opposé du segment */
  if(ov<pen){pen=ov; du=0; dv=(va+vb>0?-1:1);}
  if(on<pen){pen=on; du=(dist>0?-nu:nu); dv=(dist>0?-nv:nv);}
  /* point de contact : point du segment le plus proche du centre de la voiture */
  const tt=Math.max(0,Math.min(1,-(ua*su+va*sv)/(sl*sl))), cu=ua+su*tt;
  return {pen,nx:du*cs+dv*sn,nz:du*sn-dv*cs,cu};
}
function wallCollide(c){
  const cs=Math.cos(c.psi), sn=Math.sin(c.psi); let any=false;
  for(let it=0;it<3;it++){
    let best=null;
    segsNear(c.x,c.z,c.len/2+1.5,i=>{const m=segMTV(c,i); if(m&&(!best||m.pen>best.pen)) best=m;});
    if(!best) break; any=true;
    c.x+=best.nx*(best.pen+.01); c.z+=best.nz*(best.pen+.01);
    const vn=c.vx*best.nx+c.vz*best.nz;
    if(vn<0){
      const e=Math.min(.25,Math.max(0,(-vn-1)/10)), imp=-(1+e)*vn; c.vx+=imp*best.nx; c.vz+=imp*best.nz;
      const tx=-best.nz, tz=best.nx, vt=c.vx*tx+c.vz*tz, fr=Math.min(Math.abs(vt),.2*imp); c.vx-=Math.sign(vt)*fr*tx; c.vz-=Math.sign(vt)*fr*tz;
      const nl=best.nx*Math.sin(c.psi)-best.nz*Math.cos(c.psi);
      if(imp>4) c.psi=wrapA(c.psi-Math.max(-.25,Math.min(.25,.012*imp*(best.cu/(c.len/2))*nl)));
      if(imp>2.5&&c.lastHit<=0){c.hits++; c.lastHit=.6; c.dmg+=imp*.035*(c.r.dR||1);}
      c.hitFlash=Math.max(c.hitFlash,Math.min(1,imp/14));
      auHit(imp,c);
    }
  }
  return any;
}
/* hauteur, inclinaison, surface, limite lointaine invisible */
function carWorld(c,dt){
  wallCollide(c);
  const hl=c.len/2, hw=c.wid/2, fx=Math.cos(c.psi), fz=Math.sin(c.psi), lx=Math.sin(c.psi), lz=-Math.cos(c.psi);
  const old=c.s, cen=project(c.x,c.z,c.i); c.i=cen.i; c.s=cen.s; c.d=cen.d;
  let worst=null, wp=0; const hts=[0,0,0,0]; let k=0, offCnt=0;
  for(const sx of [1,-1]) for(const sy of [1,-1]){
    const px=c.x+fx*hl*sx+lx*hw*sy, pz=c.z+fz*hl*sx+lz*hw*sy, pr=project(px,pz,c.i);
    hts[k++]=groundY(pr.s,pr.d);
    let pen=0, side=0;
    if(pr.d>pr.fr.limL-.25){pen=pr.d-(pr.fr.limL-.25); side=1;} else if(pr.d<-(pr.fr.limR-.25)){pen=-pr.d-(pr.fr.limR-.25); side=-1;}
    if(pen>wp){wp=pen; worst={pr,side,sx,sy};}
    const sf=SURF[surfAt(px,pz)]; if(sf&&sf.mu<.7) offCnt++;
  }
  c.onPave=offCnt<2;
  if(worst){
    const n=worst.pr.fr, ox=worst.side*n.nx, oz=worst.side*n.nz; c.x-=ox*wp; c.z-=oz*wp;
    const vn=c.vx*ox+c.vz*oz; if(vn>0){c.vx-=1.25*vn*ox; c.vz-=1.25*vn*oz; c.hitFlash=Math.max(c.hitFlash,Math.min(1,vn/14));}
  }
  if(c.lastHit>0) c.lastHit-=dt; if(c.hitFlash>0) c.hitFlash=Math.max(0,c.hitFlash-dt*3);
  c.surf=surfAt(c.x,c.z); const sfc=c.surf;
  const hF=(hts[0]+hts[1])/2, hR=(hts[2]+hts[3])/2, hLf=(hts[0]+hts[2])/2, hRt=(hts[1]+hts[3])/2, ty=(hts[0]+hts[1]+hts[2]+hts[3])/4;
  c.y+=(ty-c.y)*Math.min(1,dt*18);
  c.pitch+=(Math.atan2(hF-hR,c.len)-c.pitch)*Math.min(1,dt*10); c.roll+=(Math.atan2(hLf-hRt,c.wid)-c.roll)*Math.min(1,dt*10);
  c.rumble=(sfc===8)?1:(c.onPave?0:.5);
  c.prog+=dS(c.s,old);
}
/* repère de ré-apparition sur la piste */
function respawn(c){
  const fr=frameAt(c.s); c.x=fr.x; c.z=fr.z; c.psi=fr.th; c.vx=c.vz=0; c.steer=0; c.yaw=0; c.surf=7; c.pen=1.2; c.stuckT=0; c.wrongT=0; c.nitroT=0;
}
/* pilote : profil de vitesse le long de la piste, puis suivi de trajectoire */
function aiProfile(r,skill){
  const N=TRK.N, kap=TRK.kap, v=new Float32Array(N), aLat=11.0*r.gc*(.55+.45*(r.c?r.c.etat:100)/100)*skill*.93;
  for(let i=0;i<N;i++){let k=0; for(let j=-2;j<=2;j++) k=Math.max(k,Math.abs(kap[(i+j+N)%N])); v[i]=Math.min(r.VM*.97,Math.sqrt(aLat/Math.max(k,1e-4)));}
  const B=r.B*.72;
  for(let pass=0;pass<2;pass++) for(let i=N*2-1;i>=0;i--){const a=i%N, b=(i+1)%N; v[a]=Math.min(v[a],Math.sqrt(v[b]*v[b]+2*B*TRK.DS));}
  return v;
}
/* lancer de rayon contre les vraies barrières : distance du premier obstacle (ou max) */
function rayHit(x,z,ang,max){
  const dx=Math.cos(ang), dz=Math.sin(ang), S=TRK.segs; let best=max;
  segsNear(x+dx*max/2,z+dz*max/2,max/2+1,i=>{
    const ax=S[4*i],az=S[4*i+1],ex=S[4*i+2]-ax,ez=S[4*i+3]-az, den=dx*ez-dz*ex; if(Math.abs(den)<1e-9) return;
    const t=((ax-x)*ez-(az-z)*ex)/den, u=((ax-x)*dz-(az-z)*dx)/den; if(t>0&&t<best&&u>=0&&u<=1) best=t;
  });
  return best;
}
function aiControl(c,prof,lane,skill){
  const sp=c.v, look=7+.45*sp, fr=frameAt(c.s+look), N=TRK.N, i0=c.i, nw=Math.ceil((look+12)/TRK.DS)+1;
  /* couloir libre sur toute la zone à venir (murs réels) */
  let mwL=1e9, mwR=1e9; for(let k=0;k<=nw;k++){const j=(i0+k)%N; mwL=Math.min(mwL,TRK.wallL[j]); mwR=Math.min(mwR,TRK.wallR[j]);}
  const lo=-(mwR-2.5), hi=mwL-2.5; lane=hi<lo?(hi+lo)/2:Math.max(lo,Math.min(hi,lane));
  const tx=fr.x+fr.nx*lane, tz=fr.z+fr.nz*lane;
  let steer=Math.max(-1,Math.min(1,wrapA(Math.atan2(tz-c.z,tx-c.x)-c.psi)*2.2));
  /* moustaches : on s'écarte des barrières devant */
  const R=10+.9*sp, fx=c.x+Math.cos(c.psi)*c.len/2, fz=c.z+Math.sin(c.psi)*c.len/2;
  const tl=rayHit(fx,fz,c.psi-.32,R), tc=rayHit(fx,fz,c.psi,R), tr=rayHit(fx,fz,c.psi+.32,R);
  if(tl<R||tr<R){ steer+=Math.max(-.8,Math.min(.8,(1-tl/R)*1.2-(1-tr/R)*1.2)); steer=Math.max(-1,Math.min(1,steer)); }
  let vt=1e9; const nn=Math.ceil(sp*1.3/TRK.DS)+1;
  for(let k=0;k<=nn;k++) vt=Math.min(vt,prof[(i0+k)%N]);
  vt*=skill; let thr=1, brake=false;
  if(sp>vt+1.5){brake=true; thr=0;} else thr=Math.max(0,Math.min(1,(vt-sp)/4+.6));
  if(tc<Math.min(R,sp*.9+4)&&sp>8){thr=Math.min(thr,.3); if(tc<sp*.5+2){brake=true; thr=0;}}
  if(!c.onPave) thr=Math.min(thr,.6);
  return {steer,thr,brake,hand:false};
}

/* ---------- CIRCUIT DE SPA : scène 3D, course, affichage ---------- */
let trackP=null, trackBusy=false;
function ensureTrack(){
  if(trackP) return trackP;
  if(!window.THREE||!glEnsure()||!document.getElementById('trk-json')) return (trackP=Promise.resolve());
  trackBusy=true;
  trackP=loadTrack().catch(e=>{try{console.warn('circuit',e);}catch(_){}}).then(()=>{trackBusy=false;});
  return trackP;
}
const SPA_VIS=520;
function spaMats(){
  const po=(m,f)=>{m.polygonOffset=true; m.polygonOffsetFactor=f; m.polygonOffsetUnits=f; return m;};
  const L=c=>new THREE.MeshLambertMaterial({color:c,side:THREE.DoubleSide});
  const kt=new THREE.DataTexture(new Uint8Array([255,43,94,255,236,238,255,255]),2,1,THREE.RGBAFormat);
  kt.magFilter=kt.minFilter=THREE.NearestFilter; kt.wrapS=kt.wrapT=THREE.RepeatWrapping; kt.needsUpdate=true;
  return {terrain:po(L(0x0b2c27),5),grass:po(L(0x0f4b3a),4),dirt:po(L(0x4d3826),3.5),ext:po(L(0x181a35),2.5),gravel:po(L(0x8d89a6),3),sand:po(L(0xf0c85c),3),
    asph:po(L(0x2c3162),2),kerb:po(new THREE.MeshLambertMaterial({map:kt,side:THREE.DoubleSide}),1),lines:po(new THREE.MeshBasicMaterial({color:0xe6f7ff,side:THREE.DoubleSide}),-1),
    wall_solid:new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide}),
    wall_energy:new THREE.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.3,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}),
    bldg:L(0x3a4078)};
}
function spaGantry(sc,s,txt,col){
  const fr=frameAt(s), g=new THREE.Group(), mc=new THREE.MeshBasicMaterial({color:new THREE.Color(col)}), w=Math.min(fr.limL,fr.limR,9)+.9;
  g.position.set(fr.x,fr.y,fr.z); g.rotation.y=-fr.th;
  [1,-1].forEach(sd=>{const p=new THREE.Mesh(new THREE.BoxGeometry(.4,8,.4),mc); p.position.set(0,4,sd*w); g.add(p);});
  const b=new THREE.Mesh(new THREE.BoxGeometry(.4,.5,w*2),mc); b.position.set(0,8,0); g.add(b);
  const l=labelSprite(txt,col,9); l.position.set(0,10.2,0); g.add(l); sc.add(g);
}
function spaStrip(sc,s,tex,len,y){
  const fr=frameAt(s), w=Math.min(fr.limL,12)+Math.min(fr.limR,12), off=(Math.min(fr.limL,12)-Math.min(fr.limR,12))/2;
  const m=new THREE.Mesh(new THREE.PlaneGeometry(len,w),new THREE.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3}));
  m.rotation.x=-Math.PI/2; const g=new THREE.Group(); g.add(m); m.position.z=-off; g.position.set(fr.x,fr.y+.08,fr.z); g.rotation.y=-fr.th; sc.add(g);
}
function buildSpa(stage,mn,Pr,Ors,slots){
  const T=TRK, buf=T.buf, meta=T.meta, sc=new THREE.Scene(), me=mn.m;
  const fogCol=me==='pluie'?0x150c33:0x160b33; sc.background=new THREE.Color(fogCol);
  sc.fog=new THREE.Fog(fogCol,me==='sec'?130:70,me==='sec'?SPA_VIS:me==='pluie'?360:360);
  sc.add(new THREE.HemisphereLight(0xa5b4ff,0x2a0a4a,1.15)); const dl=new THREE.DirectionalLight(0xffa6f0,.9); dl.position.set(-60,90,40); sc.add(dl);
  const M=spaMats(), tiles={};
  const tileOf=(t)=>{const k=t[0]+','+t[1]; if(!tiles[k]){const g=new THREE.Group(); g.userData={cx:meta.TX0+(t[0]+.5)*meta.tile,cz:meta.TZ0+(t[1]+.5)*meta.tile}; tiles[k]=g; sc.add(g);} return tiles[k];};
  meta.parts.forEach(p=>{
    const g=new THREE.BufferGeometry(), o=p.o;
    g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(buf,o.p,p.nv*3),3));
    g.setIndex(new THREE.BufferAttribute(p.i32?new Uint32Array(buf,o.i,p.ni):new Uint16Array(buf,o.i,p.ni),1));
    if(o.c) g.setAttribute('color',new THREE.BufferAttribute(new Uint8Array(buf,o.c,p.nv*3),3,true));
    if(o.u) g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(buf,o.u,p.nv*2),2));
    if(p.g!=='lines'&&p.g!=='wall_energy') g.computeVertexNormals();
    g.computeBoundingSphere();
    const mesh=new THREE.Mesh(g,M[p.g]); tileOf(p.t).add(mesh);
  });
  const tg=new THREE.ConeGeometry(2.3,1,5); tg.translate(0,.5,0); const tm=new THREE.MeshLambertMaterial({color:0x0d4a39}), dm=new THREE.Object3D();
  (meta.trees||[]).forEach(tp=>{
    const arr=new Float32Array(buf,tp.o,tp.n*4), im=new THREE.InstancedMesh(tg,tm,tp.n);
    for(let k=0;k<tp.n;k++){const h=arr[k*4+3]; dm.position.set(arr[k*4],arr[k*4+1],arr[k*4+2]); dm.scale.set(h*.3,h,h*.3); dm.updateMatrix(); im.setMatrixAt(k,dm.matrix);}
    im.frustumCulled=false; im.userData.tree=true; tileOf(tp.t).add(im);
  });
  /* repères : ligne de départ, grille, arrivée */
  const sA=stage.a, sB=stage.b>=T.L-1?T.L:stage.b;
  const chk=ctex(128,32,(x,W,H)=>{for(let r=0;r<2;r++) for(let c=0;c<8;c++){x.fillStyle=(r+c)%2?'#E8EBFF':'#0b0b18'; x.fillRect(c*16,r*16,16,16);}});
  chk.wrapS=chk.wrapT=THREE.ClampToEdgeWrapping;
  const stT=ctex(16,16,(x,W,H)=>{x.fillStyle='#3CFF9E'; x.fillRect(0,0,W,H);}); stT.wrapS=stT.wrapT=THREE.ClampToEdgeWrapping;
  const box=ctex(64,128,(x,W,H)=>{x.clearRect(0,0,W,H); x.strokeStyle='#E8EBFF'; x.lineWidth=5; x.strokeRect(5,5,W-10,H-10);}); box.wrapS=box.wrapT=THREE.ClampToEdgeWrapping;
  spaStrip(sc,sA,stT,.9,0); spaGantry(sc,sA,'DÉPART','#3CFF9E');
  const fin=wrapS(sB); spaStrip(sc,fin,chk,3.2,0); spaGantry(sc,fin,'ARRIVÉE','#FCEE0A');
  (slots||[]).forEach(sl=>{const s0=sA-sl.off, ln=sl.lane, fr=frameAt(s0), m=new THREE.Mesh(new THREE.PlaneGeometry(5.2,2.4),new THREE.MeshBasicMaterial({map:box,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3}));
    m.rotation.x=-Math.PI/2; const g=new THREE.Group(); g.add(m); g.position.set(fr.x+fr.nx*ln,fr.y+.08,fr.z+fr.nz*ln); g.rotation.y=-fr.th; sc.add(g);});
  /* ciel */
  const sg=new THREE.SphereGeometry(1400,16,12), cols=[], pp=sg.attributes.position, c1=new THREE.Color(0x03020b), c2=new THREE.Color(0x7a1a7a);
  for(let i=0;i<pp.count;i++){const t=Math.max(0,Math.min(1,1-Math.abs(pp.getY(i))/1400*1.6)), c=c1.clone().lerp(c2,t*t); cols.push(c.r,c.g,c.b);}
  sg.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));
  const sky=new THREE.Mesh(sg,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide,fog:false,depthWrite:false})); sky.renderOrder=-2; sc.add(sky);
  const sunT=ctex(128,128,(x,W,H)=>{const g=x.createLinearGradient(0,0,0,H); g.addColorStop(0,'#FCEE0A'); g.addColorStop(1,'#FF2BD6'); x.fillStyle=g; x.beginPath(); x.arc(W/2,H/2,W/2-2,0,7); x.fill(); x.globalCompositeOperation='destination-out'; for(let k=0;k<6;k++) x.fillRect(0,H*.5+k*H*.09,W,k*1.6+1);});
  sunT.wrapS=sunT.wrapT=THREE.ClampToEdgeWrapping;
  const sun=new THREE.Mesh(new THREE.PlaneGeometry(420,420),new THREE.MeshBasicMaterial({map:sunT,transparent:true,fog:false,depthWrite:false})); sun.renderOrder=-1; sc.add(sun);
  const pc=buildCar(Pr.m,'#00E5FF',carLook(Pr.c)), ocs=Ors.map(r=>buildCar(r.m,'#FF2BD6',carLook(r.c))), oc=ocs[0]; [pc].concat(ocs).forEach(q=>{sc.add(q.g); q.g.rotation.order='YZX';});
  const cam=new THREE.PerspectiveCamera(62,1.6,.3,1700);
  /* mini-carte */
  const mc=document.createElement('canvas'); mc.width=96; mc.height=150; const mx=mc.getContext('2d');
  let x0=1e9,x1=-1e9,z0=1e9,z1=-1e9; for(let i=0;i<T.N;i++){x0=Math.min(x0,T.cx[i]);x1=Math.max(x1,T.cx[i]);z0=Math.min(z0,T.cz[i]);z1=Math.max(z1,T.cz[i]);}
  const sc2=Math.min((96-12)/(x1-x0),(150-12)/(z1-z0)), mp=(x,z)=>[6+(x-x0)*sc2,144-(z-z0)*sc2];
  mx.lineWidth=2.4; mx.lineJoin='round'; mx.strokeStyle='#3a3f6e'; mx.beginPath(); for(let i=0;i<=T.N;i++){const p=mp(T.cx[i%T.N],T.cz[i%T.N]); i?mx.lineTo(p[0],p[1]):mx.moveTo(p[0],p[1]);} mx.stroke();
  mx.strokeStyle='#00E5FF'; mx.lineWidth=3; mx.beginPath(); const i0=Math.floor(sA/T.DS), i1=Math.ceil(sB/T.DS); for(let i=i0;i<=i1;i++){const p=mp(T.cx[i%T.N],T.cz[i%T.N]); i===i0?mx.moveTo(p[0],p[1]):mx.lineTo(p[0],p[1]);} mx.stroke();
  return {scene:sc,cam,tiles,pc,oc,ocs,sky,sun,fov:62,weather:mkWeather(me,sc),vis:SPA_VIS,mini:mc,miniP:mp,camPos:null,shake:0,fps:.016,slow:0};
}
/* ---- démarrage d'une manche sur le circuit ---- */
function startSpa(i){
  const ev=R.ev, mn=ev.manches[i], c=car(R.pick[i]), opps=R.opps[i], idx=evDi(ev);
  const stage=(SPA_STAGES.find(s=>s.id===mn.sp))||SPA_STAGES[0], len=stage.b-stage.a, n=opps.length+1, pslot=Math.min(n-1,3);
  const slots=Array.from({length:n},(_,k)=>({off:8+k*8,lane:k%2?2.6:-2.6}));
  const mk=(r,card,slot)=>{const q=mkSpaCar(r,r.m,stage.a-slot.off,slot.lane,card.etat); q.prog=-slot.off; q.timePen=0; q.mass=Math.max(80,st(card).kg); q.laneT=slot.lane; return q;};
  const Pr=mkRacer(c,mn,{skill:.9,err:0,react:rnd(.3,.5)}), P=mk(Pr,c,slots[pslot]); P.card=c; P.nit=0;
  const Os=opps.map((o,k)=>{
    const stl=STYLES[o.sty||0], sk=clamp(.84+idx*.012+S.lvl*.0025+stl.sk+rnd(-.015,.015),.8,.985), r=mkRacer(o,mn,{skill:sk,err:0,react:rnd(.25,.6)});
    const q=mk(r,o,slots[k<pslot?k:k+1]); q.skill=sk; q.prof=aiProfile(r,sk); q.sty=stl; q.pil=o.pil; q.pref=rnd(-1.6,1.6); return q;
  });
  RC={kind:'spa',i,mn,stage,len,auto:R.auto,clock:-3.4,inp:{t:0,k:0,b:false,kb:false,st:0,sk:0,hand:false},flash:null,endAt:null,done:false,P,Os,all:[P].concat(Os),O:Os[0],pos:pslot+1,profP:aiProfile(Pr,.9)};
  P.dr={pts:0,chain:0,t:0,grace:0,mult:1,best:0,n:0,live:false}; if(mn.d==='drift') RC.dlim=70;
  RS=buildSpa(stage,mn,Pr,Os.map(o=>o.r),slots);
  auRaceStart({pm:Pr.m,oms:Os.map(o=>o.r.m),rain:mn.m==='pluie',siren:Pr.m.glb==='patrouille'});
  view='race'; render(); document.querySelector('main').scrollTop=0;
}
function respawnPlayer(){
  if(!RC||RC.kind!=='spa'||RC.done||RC.clock<0) return;
  const P=RC.P; if(P.fin!=null) return; respawn(P); P.timePen+=5; flash('Remise en piste, +5 s','#FCEE0A',1.6); ui('respawn');
}
/* ---- boucle de simulation ---- */
const inSteer=()=>{const i=RC.inp; return Math.max(-1,Math.min(1,i.st+i.sk));};
function carPair(A,B){
  const dx0=A.x-B.x, dz0=A.z-B.z; if(dx0*dx0+dz0*dz0>49) return;
  const wA=B.mass/(A.mass+B.mass), wB=1-wA, ra=Math.min(1.5,A.len/2-.5), rb=Math.min(1.5,B.len/2-.5), rr=Math.min(.95,A.wid/2)+Math.min(.95,B.wid/2);
  for(const a of [ra,0,-ra]) for(const b of [rb,0,-rb]){
    const ax=A.x+Math.cos(A.psi)*a, az=A.z+Math.sin(A.psi)*a, bx=B.x+Math.cos(B.psi)*b, bz=B.z+Math.sin(B.psi)*b;
    let dx=ax-bx, dz=az-bz, d=Math.hypot(dx,dz); if(d<rr&&d>1e-4){
      dx/=d; dz/=d; const ov=rr-d; A.x+=dx*ov*wA; A.z+=dz*ov*wA; B.x-=dx*ov*wB; B.z-=dz*ov*wB;
      const vr=(A.vx-B.vx)*dx+(A.vz-B.vz)*dz;
      if(vr<0){const j=-1.25*vr/(1/A.mass+1/B.mass); A.vx+=j/A.mass*dx; A.vz+=j/A.mass*dz; B.vx-=j/B.mass*dx; B.vz-=j/B.mass*dz;
        if(-vr>4) for(const c of [A,B]) if(c===RC.P){c.hitFlash=Math.max(c.hitFlash,Math.min(1,-vr/12)); c.dmg+=-vr*.015*(c.r.dR||1); auHit(-vr,c,true);}}
    }
  }
}
function tickSpa(h){
  const P=RC.P, Os=RC.Os, all=RC.all; RC.clock+=h; const t=RC.clock;
  if(t<0){
    if(!RC.auto&&inThr()>.05&&P.penSet==null){P.penSet=1; P.pen=.8; flash('Faux départ, moteur coupé 0,8 s','#FF4D6D',1.6);}
    return;
  }
  if(!P.go){
    if(RC.auto){if(t>=P.r.react) P.go=true;}
    else{P.go=true; if(inThr()>.05&&!P.penSet) flash(t<.3?'Départ parfait':'Parti','#3CFF9E',.9);}
  }
  let inp;
  if(RC.auto&&P.fin==null){ const l0=P.laneT*Math.max(0,1-Math.max(0,P.prog)/200), trf=aiPass(P,all,l0,1); inp=aiControl(P,RC.profP,trf.lane,.9); if(trf.cap<1){inp.thr=Math.min(inp.thr,trf.cap); if(trf.brake) inp.brake=true;} }
  else inp={steer:inSteer(),thr:inThr(),brake:RC.inp.b||RC.inp.kb,hand:RC.inp.hand};
  if(P.fin!=null) inp={steer:0,thr:.3,brake:false,hand:false};
  carStep(P,inp,h); carWorld(P,h); P.thrNow=inp.thr; P.braking=!!inp.brake; driftTick(P,h);
  for(const o of Os){
    if(!o.go&&t>=o.r.react) o.go=true;
    let lane=o.laneT+(o.pref-o.laneT)*clamp(o.prog/150,0,1); const trf=aiPass(o,all,lane,o.sty.room); lane=trf.lane;
    const rb=1+clamp((P.prog-o.prog)/2500,-.03,.03);
    const oi=aiControl(o,o.prof,lane,(o.fin!=null?.6:o.skill)*rb);
    if(trf.cap<1){oi.thr=Math.min(oi.thr,trf.cap); if(trf.brake) oi.brake=true;}
    carStep(o,oi,h); carWorld(o,h); o.thrNow=oi.thr; o.braking=!!oi.brake;
    o.stuckT=(o.go&&o.v<1.2)?o.stuckT+h:0; if(o.stuckT>3.5){respawn(o); o.stuckT=0;}
  }
  for(let a=0;a<all.length;a++) for(let b=a+1;b<all.length;b++) carPair(all[a],all[b]);
  /* sens interdit, voiture bloquée */
  const fr=frameAt(P.s), al=P.vx*Math.cos(fr.th)+P.vz*Math.sin(fr.th);
  P.wrongT=(al<-4)?P.wrongT+h:0; P.stuckT=(P.v<1.2&&P.fin==null)?P.stuckT+h:0;
  for(const c of all) if(c.fin==null&&c.prog>=RC.len) c.fin=t-(c.prog-RC.len)/Math.max(c.v,1);
  RC.pos=1+Os.filter(o=>o.prog>P.prog).length;
  RC.O=Os.reduce((a,b)=>Math.abs(b.prog-P.prog)<Math.abs(a.prog-P.prog)?b:a);
  if(RC.dlim&&P.fin==null&&t>=RC.dlim) P.fin=t;
  if(P.fin!=null&&RC.endAt==null) RC.endAt=t+2.2;
  if(P.fin==null&&Os.every(o=>o.fin!=null)&&t>Math.max.apply(null,Os.map(o=>o.fin))*1.25+15){P.dnf=true; RC.endAt=t;}
  if(t>600&&RC.endAt==null){P.dnf=true; RC.endAt=t;}
  if(P.msgHit==null&&P.hitFlash>.6){P.msgHit=1; flash('Choc !','#FF4D6D',.8);} if(P.hitFlash<.1) P.msgHit=null;
  if(RC.endAt!=null&&t>=RC.endAt&&!RC.done) endSpa();
}
function endSpa(){
  const P=RC.P, c=P.card; RC.done=true;
  const a=P.dnf?null:P.fin+P.timePen, ot=RC.Os.map(o=>({nom:o.pil+' ('+o.r.nom+')',t:o.fin!=null?o.fin+o.timePen:RC.clock+(RC.len-o.prog)/Math.max(o.v,8)}));
  c.etat=Math.max(5,c.etat-Math.round((rint(1,3)+Math.round(P.dmg*10))*wearK()));
  const row=RC.mn.d==='drift'?driftRow(P,c):mkRow(RC.mn,c,a,ot,{nit:P.nit,hits:P.hits,pen:P.timePen,an:P.r.nom,xpB:P.r.xB||0});
  R.rows.push(row); auFinish(row.rank===1); showOver(row,'.padS');
}
function spaFrame(dt,time){
  if(!RC||RC.kind!=='spa'||!RS) return;
  let left=dt; while(left>1e-6&&!RC.done&&!RC.paused){const h=Math.min(left,1/120); tickSpa(h); left-=h;}
  /* qualité adaptative */
  RS.fps+=(dt-RS.fps)*.05; if(RS.fps>.036){RS.slow+=dt; if(RS.slow>2.5&&RS.vis>300){RS.vis-=60; RS.slow=0;}} else RS.slow=0;
  drawSpa(dt,time); hudSpa(); auSpaFrame(dt);
}
function placeCar(c,cr3,dt,time){
  pulseSirens(cr3,time||0); shineTick(cr3,time||0);
  cr3.g.position.set(c.x,c.y+(c.rumble?(Math.random()-.5)*.03*c.rumble*Math.min(1,c.v/30):0),c.z);
  cr3.g.rotation.y=-c.psi; cr3.g.rotation.z=c.pitch; cr3.g.rotation.x=c.roll;
  cr3.wheels.forEach(w=>{w.rotation.z-=c.v*dt/(cr3.wr||.34);});
  cr3.flame.visible=c.nitroT>0; if(c.nitroT>0){const f=.8+Math.random()*.6; cr3.flame.scale.set(f,1,f);}
  cr3.brake(!!c.braking);
}
function drawSpa(dt,time){
  const P=RC.P,O=RC.O,cam=RS.cam; placeCar(P,RS.pc,dt,time); RC.Os.forEach((o,k)=>placeCar(o,RS.ocs[k],dt,time));
  /* caméra poursuite : entre le cap et la direction de déplacement */
  const vang=P.v>6?Math.atan2(P.vz,P.vx):P.psi, ang=P.psi+wrapA(vang-P.psi)*.4, dist=8.6+Math.min(P.v,90)*.025, fx=Math.cos(ang), fz=Math.sin(ang);
  const H=(RS.pc.H||1.4), camH=Math.max(3.1,1.7+H*.75);
  const tx=P.x-fx*dist, tz=P.z-fz*dist, pr=project(tx,tz,P.i), gy=groundY(pr.s,pr.d);
  let ty=Math.max(P.y+camH,gy+2.0);
  if(!RS.camPos) RS.camPos={x:tx,y:ty,z:tz}; const k=1-Math.exp(-dt*7);
  RS.camPos.x+=(tx-RS.camPos.x)*k; RS.camPos.y+=(ty-RS.camPos.y)*k; RS.camPos.z+=(tz-RS.camPos.z)*k;
  const sh=Math.max(P.hitFlash*.5,P.nitroT>0?.07:0,P.rumble*Math.min(1,P.v/40)*.05);
  cam.position.set(RS.camPos.x+(Math.random()-.5)*sh,RS.camPos.y+(Math.random()-.5)*sh,RS.camPos.z+(Math.random()-.5)*sh);
  cam.lookAt(P.x+fx*12,P.y+1.3,P.z+fz*12); if(orbitOn()) orbitSpa(cam,P,ang,dt);
  const tf=62+Math.min(P.v,95)*.13+(P.nitroT>0?12:0); RS.fov+=(tf-RS.fov)*Math.min(1,dt*4);
  if(Math.abs(cam.fov-RS.fov)>.05){cam.fov=RS.fov; cam.updateProjectionMatrix();}
  RS.sky.position.copy(cam.position);
  const sa=hash(EVENTS.indexOf(R.ev),9)*6.28; RS.sun.position.set(cam.position.x+Math.cos(sa)*1150,150,cam.position.z+Math.sin(sa)*1150); RS.sun.lookAt(cam.position);
  /* visibilité par tuile */
  RS.tick=(RS.tick||0)+1;
  if(RS.tick%6===1){for(const key in RS.tiles){const g=RS.tiles[key], d=Math.hypot(g.userData.cx-P.x,g.userData.cz-P.z); g.visible=d<RS.vis+190; g.children.forEach(m=>{if(m.userData&&m.userData.tree) m.visible=RS.vis>=340&&d<RS.vis*.8;});}}
  if(RS.weather) updWeather(RS.weather,cam.position.x,cam.position.y,cam.position.z,fx,fz,dt,P.v);
}
function hudSpa(){
  const P=RC.P, O=RC.O, t=RC.clock, S=SURF[P.surf]||SURF[7];
  sT('hSpd',String(Math.round(P.v*3.6))); sT('hPos',(RC.pos||1)+' / '+(RC.Os.length+1));
  sT('hTime',(Math.max(0,P.fin!=null?P.fin+P.timePen:t+P.timePen)).toFixed(2).replace('.',',')+' s');
  const gap=O.prog-P.prog; sT('hGap',P.go||RC.auto?(gap>.5?`${O.pil} devant, ${Math.round(gap)} m`:`${O.pil} derrière, ${Math.round(Math.max(0,-gap))} m`):'');
  const L=$('hLights'); if(L){
    L.style.display=(t>1.4||(P.go&&t>.6))?'none':'flex';
    const n=t<0?clamp(Math.floor(t+3.4),0,3):3; auLights(n,t>=0); [...L.children].forEach((e,k)=>{const c=t>=0?'g':(k<n?'r':''); if(e._c!==c){e._c=c; e.className=c;}});
  }
  let msg='', col='#E8EBFF';
  if(RC.flash&&t<RC.flash.until){msg=RC.flash.txt; col=RC.flash.col;}
  else if(P.wrongT>1.2){msg='SENS INTERDIT'; col='#FF4D6D';}
  else if(P.stuckT>4&&P.go){msg='Bloqué ? Touche « Remettre en piste »'; col='#FCEE0A';}
  else if(t>=0&&!P.go&&!RC.auto&&P.penSet==null){msg='Écrase le gaz'; col='#3CFF9E';}
  else if(P.fin!=null){msg='Arrivée'; col='#FCEE0A';}
  const m=$('hMsg'); if(m){if(m._v!==msg){m._v=msg; m.textContent=msg;} if(m._c!==col){m._c=col; m.style.color=col;}}
  const chip=$('hSurf'); if(chip){const nm=(P.surf===7||P.surf===6)?'':S.n; if(chip._v!==nm){chip._v=nm; chip.textContent=nm; chip.style.color=SURF_COL[P.surf]||'#fff'; chip.style.display=nm?'block':'none';}}
  hudDrift(P); const sp=$('hSpd'); if(sp) sp.classList.toggle('hot',!P.onPave&&P.v>8);
  const th=RC.auto?(P.go?1:0):(RC.inp.b||RC.inp.kb?0:inThr());
  const gf=$('gasFill'); if(gf) gf.style.width=Math.round(th*100)+'%';
  const gp=$('gasPed'); if(gp) gp.style.height=Math.round(th*100)+'%';
  const nf=$('nitFill'); if(nf) nf.style.width=Math.round(clamp(P.nitroT/NITRO_DUREE,0,1)*100)+'%'; fxUpdate(P,RC);
  const hp=$('hProg'); if(hp) hp.style.width=Math.round(clamp(P.prog/RC.len,0,1)*100)+'%';
  const bn=$('pNit'); if(bn) bn.classList.toggle('on',P.nitroT>0);
  const kn=$('steerKnob'); if(kn){const v=Math.round(P.steer/ .6*50)/50; const x=Math.round(clamp(inSteer(),-1,1)*45); if(kn._x!==x){kn._x=x; kn.style.transform=`rotate(${(x*2.6).toFixed(0)}deg)`;}}
  RS.mt=(RS.mt||0)+1; const mc=$('mini'); if(mc&&RS.mt%3===0){const g=mc.getContext('2d'); g.clearRect(0,0,96,150); g.drawImage(RS.mini,0,0);
    const dot=(c,col)=>{const p=RS.miniP(c.x,c.z); g.fillStyle=col; g.beginPath(); g.arc(p[0],p[1],3.2,0,7); g.fill();}; RC.Os.forEach(o=>dot(o,'#FF2BD6')); dot(P,'#00E5FF');}
}
function bindSpa(){
  if(!GL.r||!RS) return; glAttach('rslot');
  const bg=$('pGas'), bb=$('pBrk'), bn=$('pNit'), zn=$('steerZone'), hd=$('pHnd'); let y0=0, gdown=false; if(hd){ hd.addEventListener('pointerdown',e=>{e.preventDefault(); try{hd.setPointerCapture(e.pointerId);}catch(_){} RC.inp.hand=true; hd.classList.add('on');}); const hu=()=>{RC.inp.hand=false; hd.classList.remove('on');}; hd.addEventListener('pointerup',hu); hd.addEventListener('pointercancel',hu); hd.addEventListener('contextmenu',e=>e.preventDefault()); }
  const mini=$('mini'); if(mini){mini.width=96; mini.height=150;}
  bg.addEventListener('pointerdown',e=>{e.preventDefault(); try{bg.setPointerCapture(e.pointerId);}catch(_){} gdown=true; y0=e.clientY; RC.inp.t=1;});
  bg.addEventListener('pointermove',e=>{if(!gdown) return; RC.inp.t=clamp(1-Math.max(0,e.clientY-y0)/110,.25,1);});
  const gup=()=>{gdown=false; RC.inp.t=0;}; bg.addEventListener('pointerup',gup); bg.addEventListener('pointercancel',gup);
  bb.addEventListener('pointerdown',e=>{e.preventDefault(); try{bb.setPointerCapture(e.pointerId);}catch(_){} RC.inp.b=true; bb.classList.add('on');});
  const bup=()=>{RC.inp.b=false; bb.classList.remove('on');}; bb.addEventListener('pointerup',bup); bb.addEventListener('pointercancel',bup);
  bn.addEventListener('pointerdown',e=>{e.preventDefault(); fireNitro();});
  /* direction : la position du doigt dans la zone fixe l'angle du volant */
  const setSt=e=>{const r=zn.getBoundingClientRect(); RC.inp.st=clamp(((e.clientX-r.left)/r.width*2-1)*1.15,-1,1);};
  zn.addEventListener('pointerdown',e=>{e.preventDefault(); zn.classList.remove('rel'); try{zn.setPointerCapture(e.pointerId);}catch(_){} setSt(e);});
  zn.addEventListener('pointermove',e=>{if(e.buttons||e.pressure>0) setSt(e);});
  const zup=()=>{RC.inp.st=0; zn.classList.add('rel');}; zn.addEventListener('pointerup',zup); zn.addEventListener('pointercancel',zup);
  [bg,bb,bn,zn].forEach(b=>b.addEventListener('contextmenu',e=>e.preventDefault()));
  glRun(RS.scene,RS.cam,spaFrame,'race');
}
function vSpa(){
  const ev=R.ev, n=ev.manches.length, auto=RC.auto;
  return `<div class="race"><div class="rwrap"><div class="rs" id="rslot"></div>
    <div class="hud"><div class="hud-top"><span>Manche ${RC.i+1}/${n}, ${RC.stage.nom}</span><span id="hTime">0,00 s</span></div>
      <div class="prog2"><i id="hProg"></i></div>
      <div class="hud-gap" id="hGap"></div><div class="hud-pos" id="hPos"></div>
      <canvas id="mini" class="mini" width="96" height="150"></canvas>
      <div class="hud-lights" id="hLights"><i></i><i></i><i></i></div>
      <div class="hud-msg" id="hMsg"></div>
      <div class="hud-drift" id="hDrift"></div><div class="hud-surf" id="hSurf"></div>
      <div class="hud-bot"><div class="spd"><b id="hSpd">0</b><small>km/h</small>${hudGear()}</div>
        <div class="gauges"><div class="g"><span>Nitro</span><div class="bar2 n"><i id="nitFill"></i></div></div></div></div></div>${FXL}</div>
    <div class="padS">
      <div id="steerZone" class="steer ${auto?'off':''}"><div id="steerKnob" class="wheel">${WHEEL}</div><div class="lab">${auto?'Pilote auto':'Volant'}</div></div>
      <button id="pBrk" class="pedal brk" ${auto?'disabled':''}><span>${auto?'Auto':'Frein'}</span></button>
      <button id="pNit" class="pedal nit">Nitro<small>×${S.nitro}</small></button>
      <div class="gasstack"><button id="pGas" class="pedal gas" ${auto?'disabled':''}><i id="gasPed"></i><span>${auto?'Auto':'Gaz'}</span></button><button id="pHnd" class="pedal hnd" ${auto?'disabled':''}><span>Drift</span><small>frein à main</small></button></div>
    </div>
    <div id="over" hidden></div>
    <div style="display:flex;gap:8px"><button class="btn alt sm" id="bAud" data-a="audio">⚙ Son</button><button class="btn alt sm" id="bResp" data-a="respawn">Remettre en piste (+5 s)</button><button class="btn danger sm" id="bQuit" data-a="quit">Abandonner</button></div></div>`;
}

/* ======================================================================
   AUDIO : tout est synthétisé avec la Web Audio API (aucun fichier son)
   - bruits de voiture (moteur par type, turbo, pneus, vent, chocs, sirène)
   - musique adaptative sur une grille fixe (174 BPM) : ambiance, dubstep,
     drum and bass, version intense, et « drop » hardcore pendant la nitro
   - ambiances de menu et sons d'interface
   ====================================================================== */
const AU={ctx:null,ok:false,muted:false,vm:.7,vs:.85,view:null,log:null,seq:{timer:null,next:0,step:0,mood:'menu',level:0,cur:0,dropFrom:null,dropTo:null,heldBars:0},raceLevel:0,eng:null,loops:null,lastResult:null};
let BPM=174, STEP=60/BPM/4, BAR=STEP*16;
const LOG=(n,t,x)=>{if(AU.log) AU.log.push({n,t,x});};
const auTry=f=>{try{return f();}catch(e){return undefined;}};

/* ---------- construction du graphe ---------- */
function auUnlock(){
  if(AU.ctx){ if(AU.ctx.state==='suspended') auTry(()=>AU.ctx.resume()); return; }
  const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
  try{AU.ctx=new AC({latencyHint:'interactive'});}catch(e){try{AU.ctx=new AC();}catch(_){return;}}
  try{auBuild(); AU.ok=true;}catch(e){AU.ok=false; try{console.warn('audio',e);}catch(_){}; return;}
  auTry(()=>AU.ctx.resume()); auApplyVol(); auView(view,true);
}
function mkCurve(kind,k){
  const n=2048, c=new Float32Array(n);
  for(let i=0;i<n;i++){const x=i*2/n-1; c[i]=kind==='tanh'?Math.tanh(k*x):(1+k)*x/(1+k*Math.abs(x));}
  return c;
}
function auBuild(){
  const c=AU.ctx;
  AU.master=c.createGain(); AU.limit=c.createDynamicsCompressor();
  AU.limit.threshold.value=-9; AU.limit.knee.value=8; AU.limit.ratio.value=14; AU.limit.attack.value=.004; AU.limit.release.value=.22;
  AU.master.connect(AU.limit); AU.limit.connect(c.destination);
  AU.sfx=c.createGain(); AU.sfx.connect(AU.master);
  AU.b={}; ['eng','opp','siren','amb','hit','ui','jing'].forEach(k=>{AU.b[k]=c.createGain(); AU.b[k].connect(AU.sfx);});
  AU.engBus=c.createGain(); AU.engBus.gain.value=.9; AU.engBus.connect(AU.sfx);
  AU.mus=c.createGain(); AU.mFilt=c.createBiquadFilter(); AU.mFilt.type='lowpass'; AU.mFilt.frequency.value=1800; AU.mFilt.Q.value=.5;
  AU.mus.connect(AU.mFilt); AU.mFilt.connect(AU.master);
  AU.padBus=c.createGain(); AU.padBus.connect(AU.mus);                    /* nappes : pompage à chaque grosse caisse */
  /* réverbération : bruit décroissant */
  const sr=c.sampleRate, len=Math.floor(sr*1.7), ib=c.createBuffer(2,len,sr);
  for(let ch=0;ch<2;ch++){const d=ib.getChannelData(ch); for(let i=0;i<len;i++) d[i]=(Math.random()*2-1)*Math.pow(1-i/len,2.4);}
  AU.rev=c.createConvolver(); AU.rev.buffer=ib; AU.revIn=c.createGain(); AU.revIn.gain.value=.5; AU.revIn.connect(AU.rev); AU.rev.connect(AU.mus);
  /* bruits */
  const nl=sr*2, nb=c.createBuffer(1,nl,sr), nd=nb.getChannelData(0); for(let i=0;i<nl;i++) nd[i]=Math.random()*2-1; AU.noise=nb;
  const pb=c.createBuffer(1,sr*3,sr), pd=pb.getChannelData(0); let b0=0,b1=0,b2=0; for(let i=0;i<pd.length;i++){const w=Math.random()*2-1; b0=.99765*b0+w*.099046; b1=.963*b1+w*.2965164; b2=.57*b2+w*1.0526913; pd[i]=(b0+b1+b2+w*.1848)*.22;} AU.pink=pb;
  AU.cSoft=mkCurve('soft',4); AU.cHard=mkCurve('tanh',9); AU.cMid=mkCurve('tanh',3);
}
function auApplyVol(){
  if(!AU.ok) return; const t=AU.ctx.currentTime, v=AU.v||AUDEF;
  AU.master.gain.setTargetAtTime(AU.muted?.0001:Math.max(.0001,v.master),t,.05);
  AU.mus.gain.setTargetAtTime(Math.max(.0001,v.music*.42),t,.05);
  AU.sfx.gain.setTargetAtTime(.9,t,.05);
  for(const k in AU.b) AU.b[k].gain.setTargetAtTime(Math.max(.0001,v[k]),t,.05);
}
function auSet(s){ if(!s) return; AU.muted=!!s.mute; AU.v=Object.assign({},AUDEF,s); auApplyVol(); }
document.addEventListener('visibilitychange',()=>{ if(!AU.ctx) return; auTry(()=>document.hidden?AU.ctx.suspend():AU.ctx.resume()); });

/* ---------- briques sonores ---------- */
function nsrc(buf,loop){const s=AU.ctx.createBufferSource(); s.buffer=buf||AU.noise; s.loop=!!loop; return s;}
function envGain(t,peak,atk,dec,min){const g=AU.ctx.createGain(); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(Math.max(.0002,peak),t+atk); g.gain.exponentialRampToValueAtTime(min||.0002,t+atk+dec); return g;}
function osc(type,f,t,dur,dest,peak,atk,rel,detune){
  const c=AU.ctx, o=c.createOscillator(); o.type=type; o.frequency.setValueAtTime(Math.max(1,f),t); if(detune) o.detune.value=detune;
  const g=c.createGain(); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(Math.max(.0002,peak),t+(atk||.005));
  g.gain.setValueAtTime(Math.max(.0002,peak),t+Math.max((atk||.005)+.001,dur)); g.gain.exponentialRampToValueAtTime(.0002,t+Math.max((atk||.005)+.002,dur)+(rel||.08));
  o.connect(g); g.connect(dest); o.start(t); o.stop(t+Math.max(dur,.01)+(rel||.08)+.05); return {o,g};
}
function burst(t,dur,f,q,type,vol,dest,pink){
  const c=AU.ctx, s=nsrc(pink?AU.pink:AU.noise,true), fl=c.createBiquadFilter(); fl.type=type; fl.frequency.setValueAtTime(f,t); fl.Q.value=q;
  const g=envGain(t,vol,.002,dur); s.connect(fl); fl.connect(g); g.connect(dest); s.start(t); s.stop(t+dur+.06); return {s,fl,g};
}
function sendRev(node,amt){const g=AU.ctx.createGain(); g.gain.value=amt; node.connect(g); g.connect(AU.revIn);}

/* batterie */
function kick(t,vol,o){
  o=o||{}; const c=AU.ctx, os=c.createOscillator(), g=c.createGain(), p0=o.p0||165, p1=o.p1||44, dc=o.dec||.3; LOG('kick',t,o.hard?'hard':'');
  os.type='sine'; os.frequency.setValueAtTime(p0,t); os.frequency.exponentialRampToValueAtTime(p1,t+.11);
  g.gain.setValueAtTime(vol,t); g.gain.exponentialRampToValueAtTime(.001,t+dc);
  if(o.hard){const ws=c.createWaveShaper(); ws.curve=AU.cHard; const lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=1100; os.connect(ws); ws.connect(lp); lp.connect(g);} else os.connect(g);
  g.connect(o.dest||AU.mus); os.start(t); os.stop(t+dc+.05);
  if(!o.noClick) burst(t,.012,3500,.7,'highpass',vol*.35,o.dest||AU.mus);
  if(!o.noDuck){AU.padBus.gain.cancelScheduledValues(t); AU.padBus.gain.setValueAtTime(.25,t); AU.padBus.gain.linearRampToValueAtTime(1,t+.16);}
}
function snare(t,vol,o){
  o=o||{}; LOG('snare',t,o.hard?'hard':''); const d=o.dest||AU.mus;
  burst(t,o.long?.28:.19,o.hard?2400:1900,.9,'bandpass',vol,d);
  osc('triangle',o.hard?220:185,t,.02,d,vol*.45,.002,.09);
  if(o.hard){const ws=AU.ctx.createWaveShaper(); ws.curve=AU.cMid; const g=envGain(t,vol*.5,.002,.12); const s=nsrc(AU.noise,true); s.connect(ws); ws.connect(g); g.connect(d); s.start(t); s.stop(t+.2);}
}
function hat(t,vol,open){LOG(open?'ohat':'hat',t); burst(t,open?.2:.045,open?8000:9000,.6,'highpass',vol,AU.mus);}
function clap(t,vol){LOG('clap',t); for(let k=0;k<3;k++) burst(t+k*.012,.07,1500,1.2,'bandpass',vol*(k===2?1:.6),AU.mus);}
function crash(t,vol){LOG('crash',t); burst(t,1.3,5200,.5,'highpass',vol,AU.mus);}
function clank(t,vol){LOG('clank',t); [523,787,1181,1760].forEach((f,i)=>osc('square',f*(1+i*.01),t,.03,AU.mus,vol*.12,.001,.18+.05*i)); burst(t,.05,3000,2,'bandpass',vol*.5,AU.mus);}

/* basses, nappes, leads */
function sub(t,dur,f,vol){LOG('sub',t,f); osc('sine',f,t,dur,AU.mus,vol,.01,.08);}
function wobble(t,dur,f,vol,rate,depth){
  LOG('wobble',t,f); const c=AU.ctx, d=Math.max(.05,dur), lp=c.createBiquadFilter(); lp.type='lowpass'; lp.Q.value=9; lp.frequency.setValueAtTime(380,t);
  const lfo=c.createOscillator(), lg=c.createGain(); lfo.type='sine'; lfo.frequency.setValueAtTime(rate,t); lg.gain.value=depth||650; lfo.connect(lg); lg.connect(lp.frequency);
  const g=c.createGain(); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(vol,t+.01); g.gain.setValueAtTime(vol,t+d); g.gain.exponentialRampToValueAtTime(.0002,t+d+.06);
  [-9,9].forEach(det=>{const o=c.createOscillator(); o.type='sawtooth'; o.frequency.setValueAtTime(f,t); o.detune.value=det; o.connect(lp); o.start(t); o.stop(t+d+.1);});
  const sq=c.createOscillator(); sq.type='square'; sq.frequency.setValueAtTime(f/2,t); const sg=c.createGain(); sg.gain.value=.5; sq.connect(sg); sg.connect(lp); sq.start(t); sq.stop(t+d+.1);
  lp.connect(g); g.connect(AU.mus); lfo.start(t); lfo.stop(t+d+.1);
}
function reese(t,dur,f,vol){
  LOG('reese',t,f); const c=AU.ctx, d=Math.max(.05,dur), lp=c.createBiquadFilter(); lp.type='lowpass'; lp.Q.value=3; lp.frequency.setValueAtTime(420,t); lp.frequency.linearRampToValueAtTime(900,t+d*.5); lp.frequency.linearRampToValueAtTime(420,t+d);
  const ws=c.createWaveShaper(); ws.curve=AU.cSoft; const g=c.createGain(); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(vol,t+.01); g.gain.setValueAtTime(vol,t+d); g.gain.exponentialRampToValueAtTime(.0002,t+d+.05);
  [-14,14].forEach(det=>{const o=c.createOscillator(); o.type='sawtooth'; o.frequency.setValueAtTime(f,t); o.detune.value=det; o.connect(ws); o.start(t); o.stop(t+d+.08);});
  ws.connect(lp); lp.connect(g); g.connect(AU.mus);
}
function hardBass(t,dur,f,vol){
  LOG('hardbass',t,f); const c=AU.ctx, d=Math.max(.05,dur), ws=c.createWaveShaper(); ws.curve=AU.cHard; const lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=1500; lp.Q.value=2;
  const g=c.createGain(); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(vol,t+.005); g.gain.setValueAtTime(vol,t+d); g.gain.exponentialRampToValueAtTime(.0002,t+d+.04);
  ['sawtooth','square'].forEach((ty,i)=>{const o=c.createOscillator(); o.type=ty; o.frequency.setValueAtTime(f*1.5,t); o.frequency.exponentialRampToValueAtTime(f,t+.06); o.detune.value=i?7:-7; o.connect(ws); o.start(t); o.stop(t+d+.07);});
  ws.connect(lp); lp.connect(g); g.connect(AU.mus);
}
function screech(t,dur,f,vol){
  LOG('screech',t,f); const c=AU.ctx, d=Math.max(.05,dur), bp=c.createBiquadFilter(); bp.type='bandpass'; bp.Q.value=6; bp.frequency.setValueAtTime(2200,t); bp.frequency.linearRampToValueAtTime(3600,t+d);
  const ws=c.createWaveShaper(); ws.curve=AU.cHard; const g=c.createGain(); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(vol,t+.004); g.gain.setValueAtTime(vol,t+d*.8); g.gain.exponentialRampToValueAtTime(.0002,t+d+.04);
  [0,19].forEach(det=>{const o=c.createOscillator(); o.type='sawtooth'; o.frequency.setValueAtTime(f*1.3,t); o.frequency.exponentialRampToValueAtTime(f,t+d); o.detune.value=det; o.connect(ws); o.start(t); o.stop(t+d+.07);});
  ws.connect(bp); bp.connect(g); g.connect(AU.mus); sendRev(g,.25);
}
function pad(t,dur,freqs,vol){
  LOG('pad',t,freqs[0]); const c=AU.ctx, lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.setValueAtTime(500,t); lp.frequency.linearRampToValueAtTime(1500,t+dur*.6); lp.Q.value=.8;
  const g=c.createGain(); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(vol,t+Math.min(1.2,dur*.4)); g.gain.setValueAtTime(vol,t+dur); g.gain.exponentialRampToValueAtTime(.0002,t+dur+1.1);
  freqs.forEach(f=>[-8,8].forEach(det=>{const o=c.createOscillator(); o.type='sawtooth'; o.frequency.setValueAtTime(f,t); o.detune.value=det; o.connect(lp); o.start(t); o.stop(t+dur+1.2);}));
  lp.connect(g); g.connect(AU.padBus); sendRev(g,.5);
}
function pluck(t,f,vol,wave,len){
  LOG('pluck',t,f); const c=AU.ctx, o=c.createOscillator(), g=envGain(t,vol,.004,len||.32), lp=c.createBiquadFilter(); o.type=wave||'triangle'; o.frequency.setValueAtTime(f,t);
  lp.type='lowpass'; lp.frequency.setValueAtTime(3200,t); lp.frequency.exponentialRampToValueAtTime(700,t+(len||.32)); o.connect(lp); lp.connect(g); g.connect(AU.mus); sendRev(g,.35); o.start(t); o.stop(t+(len||.32)+.08);
}
function stab(t,f,vol,dur){
  LOG('stab',t,f); const c=AU.ctx, d=dur||.2, lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.setValueAtTime(4200,t); lp.frequency.exponentialRampToValueAtTime(900,t+d); lp.Q.value=2;
  const g=envGain(t,vol,.003,d); [-12,0,12].forEach(det=>{const o=c.createOscillator(); o.type='sawtooth'; o.frequency.setValueAtTime(f,t); o.detune.value=det; o.connect(lp); o.start(t); o.stop(t+d+.06);}); lp.connect(g); g.connect(AU.mus); sendRev(g,.3);
}
function riser(t0,t1){
  LOG('riser',t0,t1-t0); const c=AU.ctx, d=Math.max(.1,t1-t0), bp=c.createBiquadFilter(); bp.type='bandpass'; bp.Q.value=2.5; bp.frequency.setValueAtTime(300,t0); bp.frequency.exponentialRampToValueAtTime(9000,t0+d);
  const g=c.createGain(); g.gain.setValueAtTime(.02,t0); g.gain.exponentialRampToValueAtTime(.7,t0+d); g.gain.linearRampToValueAtTime(.0002,t0+d+.03);
  const s=nsrc(AU.noise,true); s.connect(bp); bp.connect(g); g.connect(AU.mus); s.start(t0); s.stop(t0+d+.06);
  const o=c.createOscillator(), og=c.createGain(); o.type='sawtooth'; o.frequency.setValueAtTime(180,t0); o.frequency.exponentialRampToValueAtTime(1800,t0+d); og.gain.setValueAtTime(.0002,t0); og.gain.exponentialRampToValueAtTime(.18,t0+d); og.gain.linearRampToValueAtTime(.0002,t0+d+.03);
  o.connect(og); og.connect(AU.mus); o.start(t0); o.stop(t0+d+.06);
  const n=Math.max(4,Math.round(d/.05)); for(let k=0;k<n;k++){const tt=t0+d*(1-Math.pow(1-k/n,1.6)); if(tt<t1-.01) snare(tt,.18+.35*k/n,{});}
}
function impact(t,vol){ LOG('impact',t); sub(t,.7,38,vol); osc('sine',90,t,.2,AU.mus,vol*.6,.001,.4); crash(t,vol*.7); burst(t,.5,200,.8,'lowpass',vol*.6,AU.mus); }

/* ---------- morceau : accords, ambiances, motifs ---------- */
const CHORDS=[
 {sub:55,   bass:110,    pad:[220,261.63,329.63],   arp:[220,261.63,329.63,440,523.25,659.25]},
 {sub:43.65,bass:87.31,  pad:[174.61,220,261.63],   arp:[174.61,220,261.63,349.23,440,523.25]},
 {sub:65.41,bass:130.81, pad:[196,261.63,329.63],   arp:[196,261.63,329.63,392,523.25,659.25]},
 {sub:49,   bass:98,     pad:[196,246.94,293.66],   arp:[196,246.94,293.66,392,493.88,587.33]}];
const MOODS={
 menu:    {arp:[0,3,6,8,11,14],oct:1,wave:'triangle',av:.12,pv:.1,filt:1500,hat:false,pulse:true},
 garage:  {arp:[0,4,8,12],oct:1,wave:'sine',av:.16,pv:.12,filt:1200,hat:false,pulse:true},
 prep:    {arp:[0,2,4,6,8,10,12,14],oct:1,wave:'triangle',av:.08,pv:.09,filt:1900,hat:true,pulse:true},
 market:  {arp:[0,2,3,5,7,8,10,11,13,15],oct:2,wave:'triangle',av:.07,pv:.07,filt:2800,hat:true,pulse:false},
 base:    {arp:[0,6,12],oct:1,wave:'sawtooth',av:.07,pv:.12,filt:1000,hat:false,pulse:true,perc:true},
 missions:{arp:[0,5,10],oct:2,wave:'sine',av:.17,pv:.09,filt:2200,hat:false,pulse:false},
 tense:   {arp:[],oct:1,wave:'sine',av:0,pv:.14,filt:2600,hat:false,pulse:false,beat:true},
 race:    {arp:[],oct:1,wave:'sine',av:0,pv:.09,filt:19000,hat:false,pulse:false},
 stinger: {arp:[],oct:1,wave:'sine',av:0,pv:.05,filt:2000,hat:false,pulse:false},
 drag:    {arp:[],oct:1,wave:'sine',av:0,pv:.09,filt:19000,hat:false,pulse:false}};
function auMood(m){
  if(!AU.ok||AU.seq.mood===m) return; AU.seq.mood=m; const M=MOODS[m]||MOODS.menu;
  AU.mFilt.frequency.setTargetAtTime(M.filt,AU.ctx.currentTime,.25);
  seqStart();
}
function seqStart(){
  const q=AU.seq; if(q.timer||!AU.ok) return; q.next=AU.ctx.currentTime+.12; q.step=0; q.timer=setInterval(seqTick,25);
}
function seqStop(){const q=AU.seq; if(q.timer){clearInterval(q.timer); q.timer=null;}}
function seqTick(){
  if(!AU.ok||!AU.ctx) return; const q=AU.seq, c=AU.ctx;
  if(q.next<c.currentTime-.3) q.next=c.currentTime+.05;                     /* rattrapage si l'onglet a dormi */
  while(q.next<c.currentTime+.18){ auTry(()=>schedStep(q.step,q.next)); q.next+=(q.mood==='drag'?dragSD():STEP); q.step++; }
}
function pickLevel(){
  const q=AU.seq; if(q.mood!=='race'&&q.mood!=='drag') return 0;
  q.heldBars++; let tgt=AU.raceLevel;
  if(tgt<q.cur&&q.heldBars<2) tgt=q.cur;                                     /* on ne redescend pas avant 2 mesures */
  if(tgt!==q.cur){q.cur=tgt; q.heldBars=0;} return q.cur;
}
function schedStep(step,t){
  const q=AU.seq, s=step%16, bar=Math.floor(step/16), ch=CHORDS[Math.floor(bar/2)%4], M=MOODS[q.mood]||MOODS.menu;
  if(s===0){ q.level=pickLevel(); LOG('bar',t,q.level); }
  if(q.dropFrom!=null&&step>=q.dropTo){q.dropFrom=null; q.dropTo=null;}
  if(q.dropFrom!=null&&step>=q.dropFrom){ dropStep(step-q.dropFrom,s,t,ch); return; }
  if(q.mood==='drag'){ dragSched(s,bar,t,ch); return; }
  if(q.mood==='fete'){ feteSched(s,bar,t,ch); return; }
  const L=q.mood==='race'?q.level:0;
  if(s===0&&bar%2===0&&M.pv>0) pad(t,BAR*2,ch.pad,M.pv*(L>0?.7:1));
  if(L===0){
    M.arp.forEach((st,i)=>{ if(st===s) pluck(t,ch.arp[(Math.floor(bar/1)*3+i)%6]*M.oct*(q.mood==='garage'?.5:1),M.av,M.wave,q.mood==='garage'?.7:.32); });
    if(M.pulse&&s===0) sub(t,BAR*.55,ch.sub,.35);
    if(M.hat&&s%4===2) hat(t,.045,false);
    if(M.perc&&s===8&&bar%2===1) clank(t,.6);
    if(M.beat){ if(s===0||s===3) kick(t,.45,{p0:90,p1:38,dec:.22,noClick:true}); if(s===0&&bar%4===0) sub(t,BAR*4,ch.sub,.4); }
    return;
  }
  if(L===1){                                                                   /* dubstep : demi-temps */
    if(s===0||s===10) kick(t,.9);
    if(s===8){snare(t,.75,{long:true}); clap(t,.3);}
    if(s===4||s===12) hat(t,.1,false); if(s===14) hat(t,.1,true);
    if(s===0){wobble(t,STEP*8,ch.bass,.34,2.9,700); sub(t,STEP*14,ch.sub,.42);}
    if(s===10) wobble(t,STEP*4,ch.bass*1.5,.26,5.8,500);
    return;
  }
  /* drum and bass : niveaux 2 et 3 */
  if(s===0||s===10) kick(t,.92); if(L===3&&s===7) kick(t,.5);
  if(s===4||s===12) snare(t,.7); if(s===7||s===15) snare(t,.16);
  if(s%2===0) hat(t,L===3?.11:.085,false); if(s===6||s===14) hat(t,.1,true); if(L===3&&s%2===1) hat(t,.05,false);
  const rb=[[0,3],[3,3],[6,2],[10,3],[13,2]]; rb.forEach(([st,len],i)=>{ if(st===s) reese(t,STEP*len,i===1||i===4?ch.bass*1.5:ch.bass,L===3?.34:.3); });
  if(s===0) sub(t,STEP*16,ch.sub,.4);
  if(L===3){
    [2,5,8,11,14].forEach((st,i)=>{ if(st===s) stab(t,ch.arp[(i+bar)%6]*2,.12,STEP*2); });
    if(bar%4===3&&s>=12) snare(t,.3+.18*(s-12),{});
    if(s===0&&bar%4===0) crash(t,.3);
  }
}
/* drop hardcore : se déclenche sur le temps, dure toute la nitro */
function dropStep(rel,s,t,ch){
  if(rel===0) impact(t,.9);
  if(s%4===0) kick(t,1.0,{hard:true,p0:260,p1:48,dec:.36,dest:AU.mus});
  if(s===14||s===15) kick(t,.8,{hard:true,p0:220,p1:50,dec:.15,noDuck:false});
  if(s%4===2) hardBass(t,STEP*2.6,ch.bass,.42);
  if(s===3||s===7||s===11||s===15) screech(t,STEP*2.2,ch.arp[(s+rel)%6]*2,.16);
  if(s===4||s===12){snare(t,.7,{hard:true,long:true}); clap(t,.35);}
  if(s%4===2) hat(t,.14,true); else hat(t,.09,false);
  if(s===0&&rel===0) sub(t,STEP*10,ch.sub,.5);
}
/* nitro : montée tendue, puis drop sur le temps suivant */
function auNitro(){
  if(!AU.ok) return; const q=AU.seq, c=AU.ctx, t0=c.currentTime;
  auSfxNitro(t0);
  if(!q.timer) seqStart();
  /* premier pas de grille qui est un temps (s%4==0), pas encore planifié, et au moins 120 ms plus tard */
  let st=q.step, tt=q.next; while(!(st%4===0&&tt>=t0+.12)){st++; tt+=STEP;}
  q.dropFrom=st; q.dropTo=st+32; LOG('nitro',t0,{dropAt:tt});
  riser(Math.max(t0,tt-Math.min(.46,tt-t0)),tt);
}
/* niveau de la musique d'après la vitesse relative de la voiture */
function auSetSpeed(frac){
  const cur=AU.raceLevel; let L=cur; AU.speedFrac=frac;
  const dg=AU.race&&AU.race.drag, up=dg?[.08,.28,.5]:[.1,.4,.7], dn=dg?[.05,.22,.42]:[.06,.33,.6];
  if(cur<1&&frac>=up[0]) L=1; if(cur<2&&frac>=up[1]) L=2; if(cur<3&&frac>=up[2]) L=3;
  if(cur>=3&&frac<dn[2]) L=2; if(L>=2&&frac<dn[1]) L=1; if(L>=1&&frac<dn[0]) L=0;
  AU.raceLevel=L;
}

/* ---------- sons d'interface ---------- */
function ui(kind,arg){
  if(!AU.ok) return; const c=AU.ctx, t=c.currentTime+.005, d=AU.b.ui; LOG('ui',t,kind);
  const bl=(f,dur,vol,type,t0)=>osc(type||'square',f,t0||t,dur,d,vol,.002,.04);
  switch(kind){
   case 'click': bl(1500,.015,.07); bl(900,.02,.05,'sine',t+.012); break;
   case 'close': bl(900,.02,.06); bl(600,.03,.05,'sine',t+.02); break;
   case 'open':  bl(700,.02,.06); bl(1100,.03,.06,'sine',t+.02); break;
   case 'tab': {const f={garage:[220,330,440],epreuves:[440,440,880],marche:[1319,1760,2093],base:[110,165,82],missions:[660,880,990]}[arg]||[500,700,900]; f.forEach((x,i)=>bl(x,.05,.08,arg==='base'?'sawtooth':'triangle',t+i*.045)); if(arg==='garage') burst(t,.18,300,1,'lowpass',.2,d); if(arg==='base') burst(t+.06,.06,1800,2,'bandpass',.15,d); break;}
   case 'buy': burst(t,.03,4000,1,'highpass',.2,d); [1319,1760,2349].forEach((f,i)=>osc('sine',f,t+i*.05,.04,d,.12,.002,.5)); break;
   case 'coins': for(let i=0;i<7;i++){const f=2000+Math.random()*1800; osc('sine',f,t+i*.055,.03,d,.09,.001,.18);} break;
   case 'up': [330,415,523,659,880].forEach((f,i)=>osc('sawtooth',f,t+i*.06,.05,d,.08,.002,.12)); burst(t,.3,800,1,'bandpass',.12,d); break;
   case 'error': bl(165,.1,.14); bl(150,.14,.14,'square',t+.14); break;
   case 'repair': for(let i=0;i<5;i++) burst(t+i*.045,.025,2500,3,'bandpass',.2,d); osc('triangle',1245,t+.26,.05,d,.1,.002,.3); break;
   case 'claim': [784,988,1175,1568].forEach((f,i)=>osc('triangle',f,t+i*.07,.06,d,.12,.002,.4)); break;
   case 'go': osc('sawtooth',90,t,.25,d,.18,.01,.3); burst(t,.35,500,1,'lowpass',.18,d); break;
   case 'beep': osc('sine',440,t,.14,d,.22,.003,.04); break;
   case 'green': osc('sine',880,t,.45,d,.26,.003,.1); osc('sine',1320,t,.45,d,.1,.003,.1); break;
   case 'false': osc('sawtooth',130,t,.6,d,.2,.003,.1); break;
   case 'respawn': burst(t,.5,400,1,'bandpass',.2,d); osc('sine',300,t,.3,d,.1,.01,.2); break;
   case 'toggle': bl(1000,.03,.07,'sine'); bl(1400,.03,.07,'sine',t+.04); break;
  }
}
function auLevelUp(){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.02, d=AU.b.jing; LOG('levelup',t);
  [523,659,784,1047,1319,1568].forEach((f,i)=>{osc('sawtooth',f,t+i*.08,.12,d,.1,.004,.5); osc('sine',f*2,t+i*.08,.08,d,.07,.004,.6);}); burst(t+.1,.8,5000,.6,'highpass',.16,d,true);
}
function auStinger(win){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.05; LOG('stinger',t,win); AU.stg=AU.stg||AU.ctx.createGain(); AU.stg.gain.value=.9; AU.stg.connect(AU.b.jing); const d=AU.stg;
  if(win){ [523,659,784,1047].forEach((f,i)=>{osc('sawtooth',f,t+i*.12,.1,d,.1,.004,.45); osc('square',f/2,t+i*.12,.1,d,.04,.004,.4);});
    [523,659,784,1047].forEach(f=>osc('sawtooth',f,t+.55,1.2,d,.08,.02,1)); burst(t+.5,1.4,6000,.5,'highpass',.14,d,true); osc('sine',65,t,.6,d,.3,.01,.5); }
  else { [440,415,392,349,329].forEach((f,i)=>{osc('triangle',f,t+i*.3,.3,d,.14,.01,.5); osc('sawtooth',f*.5,t+i*.3,.3,d,.05,.01,.5,12);}); osc('sine',55,t,2,d,.3,.05,1); burst(t,1.4,400,.8,'lowpass',.12,d,true); }
}
/* clic global : le son dépend de l'action et de ce qu'elle a changé */
function auAction(a,d,pre){
  if(!AU.ok) return;
  try{
    const cr0=pre.cr, cr1=S.cr;
    if(a==='tab'){ui('tab',d.id); return;}
    if(a==='repair'){ui(cr1<cr0?'repair':'error'); return;}
    if(a==='up'||a==='bat'||a==='podup'){ui(cr1<cr0?'up':'error'); return;}
    if(a==='buy'||a==='buynew'||a==='buynitro'){ui(cr1<cr0?'buy':'error'); return;}
    if(a==='sell'){ui(cr1>cr0?'coins':'click'); return;}
    if(a==='collect'||a==='claim'){ui(cr1>cr0?(a==='claim'?'claim':'coins'):'error'); return;}
    if(a==='go'){ui('go'); return;}
    if(a==='close'){ui('close'); return;}
    if(['car','slot','slot3','ev','modslot','rates','craftopen','cartab'].includes(a)){ui('open'); return;}
    if(a==='mute'||a==='vol'){ui('toggle'); return;}
    if(['respawn','nextm','quit','audio','preset','autest','mute2','reveal','revealall','pack','fuse','craft','vclose','view3d','vol'].includes(a)) return;
    if(a==='recycle'||a==='recycleall'||a==='daily'||a==='devkit'){ui('coins'); return;}
    if(a==='modeq'){ui('up'); return;}
    ui('click');
  }catch(e){}
}

/* ---------- bruits de voiture ---------- */
const ENG_OF={velo:'velo',subi:'twin',audi:'v6',merco:'v6',patrouille:'diesel',piccola:'i4',kombi:'diesel',steppe:'i4',riva:'i4t',hauler:'v8big',touge:'i6',fury:'v8',rx4:'rally',gts:'v6',volta:'ev',majestic:'v8smooth',rossa:'v8flat',aurion:'w16'};
const ENGS={
 diesel:  {fpr:2,idle:820, red:4300,cut:520, drive:2.6,mix:[1,.75,.3], turbo:.8,rough:.22,pop:0,vol:.95,gears:[.13,.24,.38,.55,.76,1]},
 i4:      {fpr:2,idle:950, red:6800,cut:760, drive:2.4,mix:[1,.6,.3],  turbo:0, rough:.1, pop:0,vol:.8, gears:[.15,.28,.42,.6,.8,1]},
 i4t:     {fpr:2,idle:900, red:7000,cut:850, drive:3,  mix:[1,.6,.35], turbo:.6,rough:.08,pop:1,vol:.85,gears:[.15,.28,.42,.6,.8,1]},
 v6:      {fpr:3,idle:900, red:7600,cut:950, drive:3,  mix:[1,.6,.4],  turbo:.3,rough:.07,pop:1,vol:.9, gears:[.14,.26,.39,.54,.72,1]},
 i6:      {fpr:3,idle:850, red:7800,cut:900, drive:3,  mix:[1,.55,.4], turbo:0, rough:.05,pop:1,vol:.9, gears:[.15,.27,.4,.55,.74,1]},
 v8:      {fpr:4,idle:700, red:6500,cut:720, drive:3.4,mix:[1,.85,.2], turbo:0, rough:.32,pop:1,vol:1,  gears:[.16,.3,.45,.62,.82,1]},
 v8big:   {fpr:4,idle:620, red:5400,cut:560, drive:3,  mix:[1,.9,.15], turbo:0, rough:.38,pop:0,vol:1,  gears:[.14,.26,.4,.58,.78,1]},
 v8smooth:{fpr:4,idle:650, red:6200,cut:640, drive:1.8,mix:[1,.5,.15], turbo:0, rough:.12,pop:0,vol:.85,gears:[.13,.25,.38,.52,.7,1]},
 v8flat:  {fpr:4,idle:1000,red:8800,cut:1500,drive:3.8,mix:[1,.45,.55],turbo:0, rough:.05,pop:1,vol:1,  gears:[.17,.3,.44,.6,.8,1]},
 w16:     {fpr:6,idle:800, red:7200,cut:1300,drive:3,  mix:[1,.6,.45], turbo:1, rough:.06,pop:1,vol:1,  gears:[.15,.27,.4,.55,.74,1]},
 rally:   {fpr:2,idle:1000,red:7400,cut:900, drive:3,  mix:[1,.6,.4],  turbo:1, rough:.08,pop:1,vol:.9, gears:[.17,.3,.45,.62,.82,1]},
 twin:    {fpr:2,idle:1100,red:6500,cut:900, drive:3.6,mix:[1,.3,.65],turbo:0, rough:.3, pop:0,vol:.8, gears:[.24,.45,.7,1]},
 velo:    {electric:true,idle:0,red:1,vol:.12,gears:[1]},
 ev:      {electric:true,idle:0,red:1,vol:.8,gears:[1]}};
const engType=m=>ENG_OF[m&&m.id]||'i4';
/* régime moteur : rapports simulés, passages de vitesse avec petite chute de régime */
function engRpm(E,st,v,vTop,thr,dt){
  const g=E.gears, n=g.length, rpmAt=k=>v/(vTop*g[k-1]+1e-6)*E.red; let k=st.gear||1, guard=0;
  while(k<n&&rpmAt(k)>E.red*.94&&guard++<8){k++; st.shift=.2; st.shifted=true;}
  while(k>1&&rpmAt(k)<E.red*.42&&guard++<16){k--; st.shift=.14;}
  st.gear=k; let rpm=Math.max(E.idle,rpmAt(k));
  if(v<1.5) rpm=E.idle+thr*(E.red*.55-E.idle);
  if(st.shift>0){st.shift-=dt; rpm*=.82;}
  return Math.min(E.red*1.02,rpm);
}
function mkEng(type,bus){
  bus=bus||AU.b.eng;
  const E=ENGS[type]||ENGS.i4, c=AU.ctx, out=c.createGain(); out.gain.value=.0001;
  let pan=null; if(c.createStereoPanner){pan=c.createStereoPanner(); out.connect(pan); pan.connect(bus);} else out.connect(bus);
  const o={bus,E,out,pan,st:{gear:1,shift:0,thrPrev:0},nodes:[],type};
  const add=n=>{o.nodes.push(n); return n;};
  if(E.electric){
    o.a=add(c.createOscillator()); o.a.type='sine'; o.b=add(c.createOscillator()); o.b.type='triangle'; o.c=add(c.createOscillator()); o.c.type='sine';
    o.ga=c.createGain(); o.gb=c.createGain(); o.gc=c.createGain(); o.ga.gain.value=.5; o.gb.gain.value=.2; o.gc.gain.value=.12;
    o.lp=c.createBiquadFilter(); o.lp.type='lowpass'; o.lp.frequency.value=4200;
    o.a.connect(o.ga); o.b.connect(o.gb); o.c.connect(o.gc); o.ga.connect(o.lp); o.gb.connect(o.lp); o.gc.connect(o.lp); o.lp.connect(out);
    o.a.start(); o.b.start(); o.c.start();
  } else {
    o.a=add(c.createOscillator()); o.a.type='sawtooth'; o.b=add(c.createOscillator()); o.b.type='square'; o.c=add(c.createOscillator()); o.c.type='sawtooth';
    o.ga=c.createGain(); o.gb=c.createGain(); o.gc=c.createGain(); o.ga.gain.value=E.mix[0]*.5; o.gb.gain.value=E.mix[1]*.4; o.gc.gain.value=E.mix[2]*.3;
    const sum=c.createGain(), ws=c.createWaveShaper(); sum.gain.value=.5; ws.curve=mkCurve('tanh',E.drive); o.lp=c.createBiquadFilter(); o.lp.type='lowpass'; o.lp.Q.value=1.2; o.lp.frequency.value=E.cut;
    o.vca=c.createGain(); o.vca.gain.value=.4;
    o.lfo=add(c.createOscillator()); o.lfo.type='sine'; o.lfg=c.createGain(); o.lfg.gain.value=E.rough*.4; o.lfo.connect(o.lfg); o.lfg.connect(o.vca.gain);
    o.a.connect(o.ga); o.b.connect(o.gb); o.c.connect(o.gc); o.ga.connect(sum); o.gb.connect(sum); o.gc.connect(sum); sum.connect(ws); ws.connect(o.lp); o.lp.connect(o.vca); o.vca.connect(out);
    o.ns=add(nsrc(AU.pink,true)); o.nbp=c.createBiquadFilter(); o.nbp.type='bandpass'; o.nbp.Q.value=.8; o.nbp.frequency.value=900; o.ng=c.createGain(); o.ng.gain.value=0; o.ns.connect(o.nbp); o.nbp.connect(o.ng); o.ng.connect(out);
    if(E.turbo){o.tur=add(c.createOscillator()); o.tur.type='sine'; o.tg=c.createGain(); o.tg.gain.value=0; o.tur.connect(o.tg); o.tg.connect(out); o.tur.start();}
    o.a.start(); o.b.start(); o.c.start(); o.lfo.start(); o.ns.start();
  }
  return o;
}
function engUpdate(o,p,dt){
  const E=o.E, c=AU.ctx, t=c.currentTime, tc=.045, thr=p.thr;
  if(E.electric){
    const fe=140+p.v*13*(p.nit?1.06:1), fr=clamp(p.v/Math.max(10,p.vTop),0,1);
    o.a.frequency.setTargetAtTime(fe,t,tc); o.b.frequency.setTargetAtTime(fe*2.01,t,tc); o.c.frequency.setTargetAtTime(fe*3.02,t,tc);
    o.lp.frequency.setTargetAtTime(1500+fr*5000,t,tc); o.out.gain.setTargetAtTime(Math.max(.0001,p.vol*E.vol*(.12+.5*Math.max(thr,fr*.5))),t,.06);
    if(o.pan) o.pan.pan.setTargetAtTime(p.pan,t,.08); return;
  }
  const rpm=engRpm(E,o.st,p.v,p.vTop*(p.nit?1.04:1),thr,dt)*(p.nit?1.05:1), f=rpm/60*E.fpr, rf=clamp((rpm-E.idle)/(E.red-E.idle),0,1);
  o.a.frequency.setTargetAtTime(f,t,tc); o.b.frequency.setTargetAtTime(f*.5,t,tc); o.c.frequency.setTargetAtTime(f*2,t,tc); o.lfo.frequency.setTargetAtTime(Math.min(90,rpm/60),t,tc);
  o.lp.frequency.setTargetAtTime(E.cut*(1+(p.nit?.4:0))+rf*2800*(.25+.75*thr),t,tc);
  o.vca.gain.setTargetAtTime(.3+.55*thr+.15*rf,t,.05);
  o.ng.gain.setTargetAtTime(.01+.12*thr*rf,t,.06); o.nbp.frequency.setTargetAtTime(700+rf*1600,t,.06);
  const boost=E.turbo?clamp(thr*(rf*1.2),0,1):0;
  if(o.tg){o.tg.gain.setTargetAtTime(boost*.05*E.turbo,t,.08); o.tur.frequency.setTargetAtTime(1800+boost*3800,t,.08);}
  /* levée de pied : soupape de turbo / pétarade */
  if(o.st.thrPrev>.7&&thr<.25){
    if(E.turbo&&o.st.boostPrev>.35){burst(t,.3,2600,1.2,'highpass',.16*p.vol,o.bus); LOG('blowoff',t);}
    if(E.pop&&rf>.45) for(let k=0;k<3;k++) burst(t+.05+k*(.05+Math.random()*.05),.06,500,1,'lowpass',.18*p.vol,o.bus);
  }
  if(o.st.shifted){o.st.shifted=false; if(E.pop&&thr>.5) burst(t,.05,1800,1.5,'bandpass',.12*p.vol,o.bus);}
  o.st.thrPrev=thr; o.st.boostPrev=boost;
  o.out.gain.setTargetAtTime(Math.max(.0001,p.vol*E.vol*(o.st.shift>0?.6:1)*(p.nit?1.25:1)),t,.05);
  if(o.pan) o.pan.pan.setTargetAtTime(p.pan,t,.08);
  o.rpm=rpm;
}
function engStop(o){ if(!o) return; auTry(()=>{[o.a,o.b,o.c,o.lfo,o.ns,o.tur].forEach(n=>{if(n) auTry(()=>n.stop());}); o.out.disconnect();}); }

/* ambiance de piste : pneus, vent, dérapage, vibreurs, pluie, sirène */
function mkLoops(opts){
  const c=AU.ctx, bus=c.createGain(); bus.gain.value=1; bus.connect(AU.b.amb); const L={bus,nodes:[]};
  const loop=(buf,type,f,q)=>{const s=nsrc(buf,true), fl=c.createBiquadFilter(), g=c.createGain(); fl.type=type; fl.frequency.value=f; fl.Q.value=q; g.gain.value=0; s.connect(fl); fl.connect(g); g.connect(bus); s.start(); L.nodes.push(s); return {s,fl,g};};
  L.tire=loop(AU.noise,'bandpass',900,.7); L.wind=loop(AU.pink,'lowpass',900,.5); L.skid=loop(AU.noise,'bandpass',1800,5); L.rain=loop(AU.pink,'highpass',2500,.4);
  L.rum=(()=>{const o=c.createOscillator(), lp=c.createBiquadFilter(), g=c.createGain(); o.type='square'; o.frequency.value=20; lp.type='lowpass'; lp.frequency.value=170; g.gain.value=0; o.connect(lp); lp.connect(g); g.connect(bus); o.start(); L.nodes.push(o); return {o,g};})();
  if(opts&&opts.rain) L.rain.g.gain.setTargetAtTime(.07,c.currentTime,.5);
  if(opts&&opts.siren){const o=c.createOscillator(), bp=c.createBiquadFilter(), g=c.createGain(); o.type='square'; o.frequency.value=800; bp.type='bandpass'; bp.frequency.value=1150; bp.Q.value=1.1; g.gain.value=.1; o.connect(bp); bp.connect(g); g.connect(AU.b.siren); o.start(); L.nodes.push(o); L.siren={o,next:c.currentTime,flip:0};}
  return L;
}
const SURF_SND={0:[1700,.4,.25,'bandpass'],1:[600,.5,.14,'bandpass'],2:[520,.5,.15,'bandpass'],3:[800,.5,.16,'bandpass'],4:[420,.6,.22,'lowpass'],5:[1700,.4,.25,'bandpass'],6:[900,.7,.12,'bandpass'],7:[900,.7,.12,'bandpass'],8:[1000,.7,.13,'bandpass']};
function loopsUpdate(L,p){
  const c=AU.ctx, t=c.currentTime, sp=SURF_SND[p.surf]||SURF_SND[7], vr=clamp(p.v/60,0,1.6);
  L.tire.fl.type=sp[3]; L.tire.fl.frequency.setTargetAtTime(sp[0]+p.v*6,t,.1); L.tire.fl.Q.setTargetAtTime(sp[1],t,.1);
  L.tire.g.gain.setTargetAtTime(p.v<.5?.0001:sp[2]*Math.pow(vr,1.15)*.9,t,.08);
  L.wind.fl.frequency.setTargetAtTime(700+p.v*9,t,.1); L.wind.g.gain.setTargetAtTime(clamp(.035*Math.pow(p.v/90,2),0,.14),t,.1);
  const slide=clamp((p.slip-.12)/.4,0,1), brk=(p.brake&&p.v>18&&p.surf>=6)?clamp((p.v-18)/45,0,1)*.28:0, loose=p.surf<6?0:1;
  L.skid.fl.frequency.setTargetAtTime(1300+p.v*12,t,.1); L.skid.g.gain.setTargetAtTime(loose?Math.max(slide*.3,brk*.35):.0001,t,.05);
  L.rum.o.frequency.setTargetAtTime(clamp(p.v/2.2,5,70),t,.05); L.rum.g.gain.setTargetAtTime(p.surf===8&&p.v>4?Math.min(.3,.05+p.v/260):.0001,t,.06);
  if(L.siren){const sr=L.siren; if(sr.next<t-.5) sr.next=t; while(sr.next<t+1.2){sr.o.frequency.setValueAtTime(sr.flip?640:860,sr.next); sr.next+=.46; sr.flip^=1;}}
}
/* API de course */
function auRaceStart(o){
  if(!AU.ok) return; auRaceStop(true);
  AU.race={eng:mkEng(engType(o.pm),AU.b.eng),ov:[{id:null,type:null,eng:null},{id:null,type:null,eng:null}],loops:mkLoops({rain:o.rain,siren:o.siren}),acc:0,fin:false,fade:1,ln:-1,green:false,drag:!!o.drag};
  AU.raceLevel=0; AU.dsm=0; AU.dkey=1; AU.speedFrac=0; AU.seq.cur=0; AU.seq.heldBars=0; AU.seq.level=0; auCutMenu(); auMood(o.drag?'silent':'tense');
}
function auRaceStop(quiet){
  const R_=AU.race; if(R_){engStop(R_.eng); R_.ov.forEach(v=>engStop(v.eng)); auTry(()=>{R_.loops.nodes.forEach(n=>auTry(()=>n.stop())); R_.loops.bus.disconnect();}); AU.race=null;}
  if(!quiet&&AU.ok&&AU.seq.mood!=='menu'&&AU.view!=='race'){auMood('menu');}
}
function auRaceUpdate(dt,S_){
  const R_=AU.race; if(!R_||!AU.ok) return;
  if(S_.fin&&!R_.fin) R_.fin=true;
  if(R_.fin) R_.fade=Math.max(0,R_.fade-dt/2.2);
  if(!S_.go) auMood(R_.drag?'silent':'tense'); else auMood(R_.fin?'stinger':(R_.drag?'drag':'race'));
  if(S_.go&&!R_.fin) auSetSpeed(S_.v/Math.max(10,S_.vTop));
  R_.acc+=dt; if(R_.acc<.033) return; const d=R_.acc; R_.acc=0; const f=R_.fade, now=AU.ctx.currentTime;
  engUpdate(R_.eng,{v:S_.v,vTop:S_.vTop,thr:clamp(S_.thr,0,1),vol:.75*f,pan:0,nit:S_.nit},d);
  R_.ov.forEach((sl,k)=>{
    const op=S_.opps[k];
    if(!op){ if(sl.eng) sl.eng.out.gain.setTargetAtTime(.0001,now,.1); return; }
    if(sl.id!==op.id){ if(sl.type!==op.type||!sl.eng){engStop(sl.eng); sl.eng=mkEng(op.type,AU.b.opp); sl.type=op.type;} sl.id=op.id; }
    const ov=clamp(1-op.dist/110,0,1); engUpdate(sl.eng,{v:op.v,vTop:op.vTop,thr:clamp(op.thr,0,1),vol:.65*ov*ov*f,pan:op.pan,nit:false},d);
  });
  loopsUpdate(R_.loops,{v:S_.v,surf:S_.surf,slip:S_.slip,brake:S_.brake,rumble:S_.rumble});
  R_.loops.bus.gain.setTargetAtTime(Math.max(.0001,f),now,.1);
}
/* départ : bips des feux */
function auLights(n,green){
  const R_=AU.race; if(!R_||!AU.ok) return;
  if(green){ if(!R_.green){R_.green=true; ui('green'); fxFlash('go'); auTry(auLaunch);} return; }
  if(n!==R_.ln){ if(n>R_.ln&&n>0) ui('beep'); R_.ln=n; }
}
function auFinish(won){ if(!AU.ok) return; ui(won?'claim':'error'); auTry(()=>auHorn(won)); }
/* chocs : intensité en m/s d'impulsion */
function auHit(imp,c,soft){
  if(!AU.ok||!AU.race||!RC||imp<1.2) return; const mine=(c===RC.P), t=AU.ctx.currentTime+.002, key=mine?'lhP':'lhO';
  if(t-(AU[key]||-9)<(imp>8?.05:.11)) return; AU[key]=t;
  const vol=clamp(imp/18,.08,1)*(mine?1:.45)*(soft?.6:1); if(!mine&&clamp(1-Math.hypot((c.x||0)-RC.P.x,(c.z||0)-RC.P.z)/90,0,1)<.05) return;
  LOG('hit',t,imp); const d=AU.b.hit;
  burst(t,.35,260,1,'lowpass',.5*vol,d); osc('sine',70,t,.08,d,.5*vol,.001,.25);
  if(!soft){ [420,630,910,1330].forEach((f,i)=>osc('square',f*(1+Math.random()*.03),t,.02,d,.07*vol,.001,.2+.06*i)); burst(t,.12,3200,2,'bandpass',.25*vol,d); }
}
function auSfxNitro(t0){
  const d=AU.b.amb, c=AU.ctx; LOG('nitrosfx',t0);
  const s=nsrc(AU.noise,true), bp=c.createBiquadFilter(), g=c.createGain(); bp.type='bandpass'; bp.Q.value=1.4; bp.frequency.setValueAtTime(500,t0); bp.frequency.exponentialRampToValueAtTime(4500,t0+.5);
  g.gain.setValueAtTime(.0002,t0); g.gain.exponentialRampToValueAtTime(.35,t0+.12); g.gain.exponentialRampToValueAtTime(.0002,t0+1.1); s.connect(bp); bp.connect(g); g.connect(d); s.start(t0); s.stop(t0+1.2);
  osc('sine',60,t0+.03,.3,d,.35,.005,.5);
}
/* appels depuis le jeu */
function auSpaFrame(dt){
  if(!AU.ok||!AU.race||!RC||RC.kind!=='spa') return;
  const P=RC.P, rx=-Math.sin(P.psi), rz=Math.cos(P.psi), on=P.go||RC.clock>=0;
  const opps=RC.Os.map((o,k)=>({o,k,dist:Math.hypot(o.x-P.x,o.z-P.z)})).sort((a,b)=>a.dist-b.dist).slice(0,2).map(q=>({id:q.k,type:engType(q.o.r.m),v:q.o.v,vTop:q.o.r.VM,thr:q.o.thrNow==null?1:q.o.thrNow,dist:q.dist,pan:clamp(((q.o.x-P.x)*rx+(q.o.z-P.z)*rz)/30,-.9,.9)}));
  auRaceUpdate(dt,{go:on,v:P.v,vTop:P.r.VM,thr:on?(P.thrNow||0):inThr(),brake:!!P.braking,slip:Math.abs(P.slipAng||0),surf:P.surf,nit:P.nitroT>0,rumble:P.rumble,fin:P.fin!=null,opps});
}
function auOldFrame(dt){
  if(!AU.ok||!AU.race||!RC||RC.kind!=='race') return;
  const P=RC.P, started=RC.clock>=0;
  const opps=RC.Os.map((o,k)=>({o,k,dist:Math.abs(o.x-P.x)})).sort((a,b)=>a.dist-b.dist).slice(0,2).map(q=>({id:q.k,type:engType(q.o.m),v:q.o.v,vTop:q.o.VM,thr:q.o.braking?0:1,dist:q.dist,pan:clamp((q.o.lane-P.lane)/5,-.8,.8)}));
  auRaceUpdate(dt,{go:started,v:P.v,vTop:P.VM,thr:started?(RC.auto?(P.braking?0:1):(RC.inp.b||RC.inp.kb?0:inThr())):inThr(),brake:!!P.braking,slip:P.slide?.5:0,surf:7,nit:P.nitroT>0,rumble:0,fin:P.fin!=null,opps});
}
/* menus : humeur musicale et ronronnement des podiums */
function auView(v,force){
  if(!AU.ok) return; if(AU.view===v&&!force) return; AU.view=v;
  auHum(v==='garage');
  if(v==='race') return;
  const m={garage:'garage',hub:'garage',epreuves:'prep',prep:'prep',marche:'market',base:'base',missions:'missions',result:'menu'}[v]||'menu';
  auRaceStop(true); auMood(m);
  if(v==='result'&&R&&R.result&&AU.lastResult!==R.result){AU.lastResult=R.result; auStinger(R.result.win);}
}
function auHum(on){
  const c=AU.ctx; if(!AU.ok) return;
  if(!on){ if(AU.hum){const h=AU.hum; AU.hum=null; auTry(()=>{h.g.gain.setTargetAtTime(.0001,c.currentTime,.3); setTimeout(()=>{h.nodes.forEach(n=>auTry(()=>n.stop())); auTry(()=>h.g.disconnect());},1500);});} return; }
  if(AU.hum) return;
  const g=c.createGain(); g.gain.value=.0001; g.connect(AU.b.amb); const nodes=[];
  [60,120.7,181.2].forEach((f,i)=>{const o=c.createOscillator(); o.type=i?'triangle':'sine'; o.frequency.value=f; const og=c.createGain(); og.gain.value=[.5,.25,.12][i]; o.connect(og); og.connect(g); o.start(); nodes.push(o);});
  const lfo=c.createOscillator(), lg=c.createGain(); lfo.frequency.value=.35; lg.gain.value=.012; lfo.connect(lg); lg.connect(g.gain); lfo.start(); nodes.push(lfo);
  g.gain.setTargetAtTime(.025+.01*(S&&S.pod?S.pod.tier:1),c.currentTime,.6); AU.hum={g,nodes};
}
function auInstall(){
  const un=()=>auUnlock(); ['pointerup','click','keydown','touchend'].forEach(ev=>document.addEventListener(ev,un,true));
}
/* ---------- actions ---------- */
/* ======================================================================
   MODULES (cartes de pièces), RARETÉS, TIRAGES, APPARENCE
   ====================================================================== */
const RAR=[{n:'Commun',c:'#9aa3ad',p:60,pow:2,sc:1},{n:'Peu commun',c:'#3ccf7a',p:25,pow:4,sc:3},{n:'Rare',c:'#3d8bff',p:10,pow:7,sc:8},{n:'Épique',c:'#b05cff',p:3.8,pow:11,sc:25},
  {n:'Légendaire',c:'#ffb020',p:1,pow:16,sc:80},{n:'Mythique',c:'#ff3d6e',p:.18,pow:22,sc:250},{n:'Ultra rare',c:'#00e5ff',p:.02,pow:30,sc:1000}];
const PITY=[0,0,14,50,200,700,2500], SOFT=.6;   /* garantie : rareté i ou mieux au plus tard au PITY[i]-ième tirage ; la chance monte doucement à partir de 60 % du délai */
const SHINY_P=.08, UNIQ_P=.02, INV_MAX=300;
const SLOTS=[['moteur','Moteur','⚙️'],['turbo','Turbo','🌀'],['echap','Échappement','💨'],['pneus','Pneus','⭕'],['freins','Freins','🛑'],['susp','Suspension','🔩'],['chassis','Châssis','🪶'],['aero','Aéro','🪽'],['nitro','Nitro','⚡'],['jantes','Jantes','🛞'],['peinture','Peinture','🎨']];
/* modèles de modules : [id, emplacement, nom, effets {stat: poids}] */
const MODT=[
 ['mo1','moteur','Bloc forgé',{ch:1,nm:.5}],['mo2','moteur','Arbre à cames',{ch:.7,vmax:.5}],['mo3','moteur','Culasse renforcée',{nm:.9,fia:.8}],
 ['tu1','turbo','Turbo simple',{ch:.8,fia:-.3}],['tu2','turbo','Bi-turbo',{ch:1.1,nm:.6,fia:-.6}],['tu3','turbo','Compresseur',{nm:1.1,ch:.4}],
 ['ec1','echap','Ligne inox',{ch:.4,kg:.5}],['ec2','echap','Échappement libre',{ch:.6,sty:.6}],['ec3','echap','Collecteur 4-en-1',{nm:.7,vmax:.4}],
 ['pn1','pneus','Slicks',{adh:1.2,wet:-.5}],['pn2','pneus','Pneus pluie',{wet:1.2,adh:.3}],['pn3','pneus','Pneus terre',{off:1.2,man:.4}],
 ['fr1','freins','Disques ventilés',{fre:1.1}],['fr2','freins','Étriers 6 pistons',{fre:.9,man:.4}],['fr3','freins','Carbone-céramique',{fre:1,kg:.5}],
 ['su1','susp','Combinés filetés',{man:1.1}],['su2','susp','Barres anti-roulis',{man:.7,adh:.5}],['su3','susp','Suspension rallye',{off:.9,fia:.7}],
 ['ch1','chassis','Arceau',{dmg:1.2,kg:-.3}],['ch2','chassis','Coque allégée',{kg:1.2}],['ch3','chassis','Renforts',{fia:1,man:.4}],
 ['ae1','aero','Lame avant',{adh:.6,vmax:.4}],['ae2','aero','Aileron',{adh:1,vmax:-.3}],['ae3','aero','Kit large',{sty:1,adh:.5}],
 ['ni1','nitro','Bouteille XL',{nitD:1.2}],['ni2','nitro','Injection directe',{nitP:1}],['ni3','nitro','Double étage',{nitD:.7,nitP:.6}],
 ['ja1','jantes','Jantes forgées',{kg:.6,man:.5}],['ja2','jantes','Jantes larges',{adh:.7,sty:.5}],['ja3','jantes','Jantes show',{sty:1.2,inc:.6}],
 ['pe1','peinture','Peinture nacrée',{sty:1.1}],['pe2','peinture','Covering mat',{sty:.8,inc:.8}],['pe3','peinture','Livrée course',{sty:.6,xp:1}]];
const MODI=Object.fromEntries(MODT.map(t=>[t[0],t]));
const UNIQ=[
 {n:'Le Hurleur',t:'ec2',fx:{sty:.8,ch:.4},d:'Un échappement de légende'},{n:'Cœur de Spa',t:'mo1',fx:{vmax:.6,fia:.6},d:'Préparé pour les longues lignes droites'},
 {n:'Griffes de pluie',t:'pn2',fx:{wet:.8,fre:.5},d:'Colle à la piste sous la pluie'},{n:'Souffle du dragon',t:'ni3',fx:{nitD:.6,nitP:.5},d:'Nitro plus longue et plus forte'},
 {n:'Peau de titane',t:'ch1',fx:{dmg:1.2,kg:.4},d:'Presque indestructible'},{n:'Aile fantôme',t:'ae2',fx:{adh:.6,vmax:.5},d:'De l’appui sans traînée'},
 {n:'Roues du roi',t:'ja3',fx:{inc:1.2,sty:.6},d:'Le showroom s’arrache cette voiture'},{n:'Livrée du champion',t:'pe3',fx:{xp:1,sty:.6},d:'Tout le monde te regarde'}];
const PACKS=[{id:'p1',nom:'Paquet Garage',n:3,cr:500,tok:1,boost:1,min:0,d:'3 modules'},{id:'p2',nom:'Paquet Atelier',n:4,cr:1800,tok:3,boost:1,min:1,d:'4 modules, dont un Peu commun ou mieux'},
 {id:'p3',nom:'Paquet Compétition',n:5,cr:6000,tok:8,boost:1.5,min:2,d:'5 modules, dont un Rare ou mieux. Chances d’Épique ×1,5'},{id:'p4',nom:'Paquet Légende',n:5,cr:25000,tok:30,boost:3,min:3,d:'5 modules, dont un Épique ou mieux. Chances d’Épique ×3'}];
const MULT={ch:1,nm:1,vmax:.35}, PTS={adh:1,fre:1,man:1,fia:1,sty:1};
const STATN={ch:'de puissance',nm:'de couple',vmax:'de vitesse max',adh:'d’adhérence',fre:'de freinage',man:'de maniabilité',fia:'de fiabilité',sty:'de style',wet:'d’adhérence sous la pluie',off:'d’adhérence hors asphalte',nitD:'de durée de nitro',nitP:'de poussée de nitro',dmg:'de résistance aux chocs',inc:'de revenus au showroom',xp:'d’expérience'};
const modOf=u=>u?S.mods.find(x=>x.u===u):null;
const modPow=m=>RAR[m.r].pow*m.q*(m.sh?1.25:1);
const modName=m=>m.un!=null?UNIQ[m.un].n:MODI[m.t][2];
const eqCar=u=>S.cars.find(c=>c.mods&&Object.keys(c.mods).some(k=>c.mods[k]===u));
function modFx(m){
  const p=modPow(m), T=MODI[m.t], out={}, add=(k,w)=>{out[k]=(out[k]||0)+w*p;};
  for(const k in T[3]) add(k,T[3][k]); if(m.s) add(m.s[0],m.s[1]); if(m.un!=null) for(const k in UNIQ[m.un].fx) add(k,UNIQ[m.un].fx[k]);
  return out;
}
function fxText(k,v){
  const sg=x=>(x>=0?'+':'−')+Math.abs(x).toFixed(1).replace('.',',').replace(',0','');
  if(MULT[k]) return `${sg(v*MULT[k])} % ${STATN[k]}`;
  if(k==='kg') return `${sg(-v*.4)} % de poids`;
  if(PTS[k]) return `${sg(v*.5)} ${STATN[k]}`;
  return `${sg(v)} % ${STATN[k]}`;
}
function applyMods(s,c){
  s.sp={}; if(!c||!c.mods) return;
  for(const sl in c.mods){ const m=modOf(c.mods[sl]); if(!m) continue; const fx=modFx(m);
    for(const k in fx){ const v=fx[k];
      if(MULT[k]) s[k]*=1+v/100*MULT[k]; else if(k==='kg') s.kg*=Math.max(.6,1-v/100*.4); else if(PTS[k]) s[k]+=v*.5; else s.sp[k]=(s.sp[k]||0)+v/100; } }
  if(c.sh){s.ch*=1.06; s.nm*=1.06; s.sty+=8;}
}
/* tirage d'une rareté : taux de base, garanties, bonus du paquet */
function rollRar(boost,minR){
  const w=RAR.map((x,i)=>x.p*(i>=3?boost:1)), tot=w.reduce((a,b)=>a+b,0); let x=Math.random()*tot, r=0;
  for(let i=0;i<7;i++){x-=w[i]; if(x<0){r=i; break;}}
  for(let i=6;i>=2;i--){ const P=PITY[i], n=S.pity[i]+1, a=SOFT*P; if(n>=P||(n>a&&Math.random()<(n-a)/(P-a))){r=Math.max(r,i); break;} }
  r=Math.max(r,minR||0);
  for(let i=2;i<7;i++) S.pity[i]=r>=i?0:S.pity[i]+1;
  return r;
}
function newMod(r,slot,plain){
  const pool=MODT.filter(t=>!slot||t[1]===slot), T=pool[rint(0,pool.length-1)], m={u:S.muid++,t:T[0],r,q:Math.round(rnd(.85,1.15)*100)/100};
  if(r>=2){const ks=['ch','nm','adh','fre','man','fia','sty','kg']; m.s=[ks[rint(0,ks.length-1)],Math.round(rnd(.25,.55)*100)/100];}
  if(!plain&&r>=2&&Math.random()<SHINY_P*(1+.1*pk('luck'))) m.sh=1;
  if(!plain&&r>=3&&Math.random()<UNIQ_P){const ui=rint(0,UNIQ.length-1); m.un=ui; m.t=UNIQ[ui].t; m.sn=rint(1,999);}
  S.alb[m.t]=(S.alb[m.t]||0)|(1<<r); S.stats.best=Math.max(S.stats.best||0,r); if(m.sh) S.stats.shiny=(S.stats.shiny||0)+1;
  return m;
}
function openPack(id,cur){
  const pk=PACKS.find(p=>p.id===id); if(!pk) return;
  if(S.mods.length+pk.n>invMax()) return toast('Inventaire plein : recycle ou fusionne des modules');
  if(cur==='tok'){ if(S.tok<pk.tok) return toast('Pas assez de jetons'); S.tok-=pk.tok; } else { if(S.cr<pk.cr) return toast('Pas assez de crédits'); S.cr-=pk.cr; }
  const got=[]; for(let k=0;k<pk.n;k++){const m=newMod(rollRar(pk.boost,k===pk.n-1?pk.min:0)); S.mods.push(m); got.push(m.u);}
  S.stats.packs=(S.stats.packs||0)+1; save(); render(); openSheet({t:'open',cards:got,i:0,pk:id});
}
function modHTML(m,act){
  const sl=SLOTS.find(s=>s[0]===MODI[m.t][1]), fx=modFx(m), on=eqCar(m.u);
  return `<div class="mod ${m.sh?'shiny':''} ${m.un!=null?'uniq':''}" style="--rc:${RAR[m.r].c}">
    <div class="mod-top"><span>${sl[2]} ${sl[1]}</span><span class="rar">${RAR[m.r].n}${m.sh?' ✨':''}</span></div>
    <div class="mod-name">${modName(m)}${m.un!=null?` <small>Unique n° ${String(m.sn).padStart(3,'0')}</small>`:''}</div>
    <div class="mod-fx">${Object.keys(fx).map(k=>`<span class="${fx[k]<0?'neg':''}">${fxText(k,fx[k])}</span>`).join('')}</div>
    ${m.un!=null?`<div class="mod-eq">${UNIQ[m.un].d}</div>`:''}${on?`<div class="mod-eq">Monté sur ${M[on.mid].nom}</div>`:''}${act||''}</div>`;
}
/* apparence : ce que les modules montés changent sur la voiture */
function carLook(c){
  if(!c) return {}; if(c.lk) return c.lk; const L={}; if(c.sh) L.shiny=1; if(!c.mods) return L;
  for(const sl of ['aero','jantes','peinture','echap','nitro','turbo']){const m=modOf(c.mods[sl]); if(m) L[sl]={r:m.r,t:m.t};}
  return L;
}
const lookKey=c=>{const L=carLook(c); return Object.keys(L).map(k=>k+(L[k].t||'')+(L[k].r==null?'':L[k].r)).join('.');};
function rndLook(lv){
  const L={}, r=()=>clamp(rint(0,Math.floor(lv/2)),0,5);
  if(lv>=2&&Math.random()<.6) L.jantes={r:r(),t:'ja1'}; if(lv>=3&&Math.random()<.5) L.aero={r:r(),t:['ae1','ae2','ae3'][rint(0,2)]}; if(lv>=4&&Math.random()<.4) L.peinture={r:r(),t:'pe1'}; if(lv>=5&&Math.random()<.5) L.echap={r:r(),t:'ec2'};
  return L;
}
const dayKey=()=>{const d=new Date(); return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();};
const dailyReward=()=>({cr:Math.round((300+150*S.lvl)*(1+.08*pk('dly'))),xp:25+8*S.lvl,tok:1+((S.streak||0)%7===6?2:0)});
let cTab='packs', cSlot='';
function vCartes(){
  const tabs=`<div class="subtabs">${[['packs','Paquets'],['inv',`Mes modules (${S.mods.length})`],['album','Album']].map(([id,n])=>`<button data-a="cartab" data-id="${id}" ${cTab===id?'aria-current="true"':''}>${n}</button>`).join('')}</div>`;
  let body='';
  if(cTab==='packs'){
    body=packsHTML();
  } else if(cTab==='inv'){
    const free=S.mods.filter(m=>!eqCar(m.u)), list=S.mods.filter(m=>!cSlot||MODI[m.t][1]===cSlot).sort((a,b)=>b.r-a.r||modPow(b)-modPow(a));
    const fus=RAR.map((_,r)=>r<6&&free.filter(m=>m.r===r&&!m.sh&&m.un==null).length>=5?`<button class="btn alt sm" data-a="fuse" data-id="${r}" style="box-shadow:inset 0 0 0 1.5px ${RAR[r+1].c};color:${RAR[r+1].c}">5 ${RAR[r].n} → 1 ${RAR[r+1].n}</button>`:'').join('');
    body=`<div class="row"><span class="ico">♻️</span><span class="grow"><span class="ttl">Ferraille : ${fmt(S.scrap)}</span><br><span class="sub">Recycle un module pour en obtenir. Elle sert à fabriquer un module de l’emplacement de ton choix.</span></span><button class="btn alt sm" data-a="craftopen">Fabriquer</button></div>
      ${fus?`<h3 style="margin:14px 0 8px">Fusion</h3><div class="chips" style="gap:8px">${fus}</div>`:'<p class="note">Fusion : 5 modules non montés de même rareté donnent 1 module de la rareté supérieure.</p>'}
      <div class="chips" style="margin:14px 0 10px"><button class="chip ${cSlot?'':'on'}" data-a="cslot" data-id="">Tous</button>${SLOTS.map(s=>`<button class="chip ${cSlot===s[0]?'on':''}" data-a="cslot" data-id="${s[0]}">${s[2]} ${s[1]}</button>`).join('')}</div>
      ${list.length?`<div class="mods">${list.slice(0,60).map(m=>modHTML(m,eqCar(m.u)?'':`<button class="btn sm" data-a="eqmodopen" data-id="${m.u}">Monter sur…</button><button class="btn alt sm" data-a="recycle" data-id="${m.u}">Recycler, +${Math.round(RAR[m.r].sc*(m.sh?3:1)*scrapK())} ♻️</button>`)).join('')}</div>${list.length>60?`<p class="note">${list.length-60} autres modules non affichés. Filtre par emplacement pour les voir.</p>`:''}`:'<p class="note">Aucun module ici. Ouvre un paquet pour commencer ta collection.</p>'}
      ${free.some(m=>m.r===0&&!m.sh)?`<button class="btn danger sm" style="margin-top:10px" data-a="recycleall">Recycler tous les Communs non montés</button>`:''}`;
  } else {
    const bits=MODT.reduce((t,T)=>{let b=S.alb[T[0]]||0,c=0; while(b){c+=b&1; b>>=1;} return t+c;},0);
    body=`<p class="note">Collection : ${bits} sur ${MODT.length*7} (${(bits/(MODT.length*7)*100).toFixed(1).replace('.',',')} %). Brillants obtenus : ${S.stats.shiny||0}. Uniques possédés : ${S.mods.filter(m=>m.un!=null).length} sur ${UNIQ.length}.</p>`+
      SLOTS.map(s=>`<h3 style="margin:14px 0 6px">${s[2]} ${s[1]}</h3>`+MODT.filter(T=>T[1]===s[0]).map(T=>`<div class="alb"><span>${T[2]}</span><span class="pips">${RAR.map((r,i)=>`<i style="background:${(S.alb[T[0]]||0)&(1<<i)?r.c:'transparent'};border-color:${r.c}" title="${r.n}"></i>`).join('')}</span></div>`).join('')).join('');
  }
  return `<div class="head"><h2>Cartes</h2><p>🎟 ${S.tok} jetons</p></div>${tabs}${body}`;
}
/* fiches supplémentaires : choix d'un module, ouverture de paquet, taux, fabrication, audio */
function sheetExtra(X){
  const el=$('sheet');
  if(eqSheets(X)) return true;
  if(sheet.t==='modpick'){
    const c=car(sheet.uid), sl=SLOTS.find(s=>s[0]===sheet.slot), cur=c.mods&&c.mods[sheet.slot];
    const list=S.mods.filter(m=>MODI[m.t][1]===sheet.slot&&m.u!==cur).sort((a,b)=>b.r-a.r||modPow(b)-modPow(a));
    el.innerHTML=`${X}<h2>${sl[2]} ${sl[1]}</h2><p class="note">${M[c.mid].nom}. Un module ne peut être monté que sur une voiture à la fois.</p>
      ${cur&&modOf(cur)?modHTML(modOf(cur),`<button class="btn danger sm" data-a="modun">Retirer</button>`):''}
      ${list.length?`<div class="mods">${list.slice(0,40).map(m=>modHTML(m,eqOther(m.u,c)?`<button class="btn sm mag" data-a="modeq" data-id="${m.u}">Reprendre</button>`:`<button class="btn sm" data-a="modeq" data-id="${m.u}">Monter</button>`)).join('')}</div>`:'<p>Aucun autre module pour cet emplacement. Ouvre des paquets dans Marché › Cartes.</p>'}
      <button class="btn alt wide" style="margin-top:10px" data-a="car" data-id="${c.uid}">Retour à la voiture</button>`;
    return true;
  }
  if(sheet.t==='open'){
    const n=sheet.cards.length, done=sheet.i>=n, pk=PACKS.find(p=>p.id===sheet.pk);
    el.innerHTML=`${X}<h2>${pk.nom}</h2><div class="mods open">${sheet.cards.map((u,k)=>k<sheet.i?modHTML(modOf(u)):`<button class="cardback" data-a="reveal">?</button>`).join('')}</div>
      ${done?`<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="close">Fermer</button><button class="btn" data-a="pack" data-id="${pk.id}" data-k="cr" ${S.cr<pk.cr?'disabled':''}>Encore un, ${cr(pk.cr)}</button></div><button class="btn good wide" style="margin-top:8px" data-a="eqcaropen">⚡ Équiper les meilleures pièces sur une voiture</button>`
           :`<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn" data-a="reveal">Révéler</button><button class="btn alt" data-a="revealall">Tout révéler</button></div>`}`;
    return true;
  }
  if(sheet.t==='rates'){
    el.innerHTML=`${X}<h2>Taux de tirage</h2><p class="note">Taux de base par carte, avant la garantie progressive. Les paquets Compétition et Légende multiplient les chances d’Épique et au-delà.<br>En pratique, avec la garantie progressive, tu obtiens en moyenne une Légendaire toutes les 80 cartes, une Mythique toutes les 330 et une Ultra rare toutes les 1 300 environ (paquet Garage).</p>
      ${RAR.map((r,i)=>`<div class="alb"><span style="color:${r.c};font-weight:700">${r.n}</span><span>${String(r.p).replace('.',',')} %${PITY[i]?`, garantie progressive : la chance monte dès le tirage ${Math.round(PITY[i]*SOFT)} et la carte est sûre au tirage ${PITY[i]} (${S.pity[i]} tirages depuis la dernière carte de cette rareté ou mieux)`:''}</span></div>`).join('')}
      <p class="note">Brillant : ${SHINY_P*100} % des modules Rares ou mieux, bonus +25 %. Unique : ${UNIQ_P*100} % des modules Épiques ou mieux, numéroté, avec un effet en plus. La qualité de chaque module varie de 85 à 115 %, et à partir de Rare un bonus secondaire est tiré au hasard.</p>
      <button class="btn wide" data-a="close">Fermer</button>`;
    return true;
  }
  if(sheet.t==='craft'){
    const r=sheet.r||0, cost=craftCost(r);
    el.innerHTML=`${X}<h2>Fabriquer un module</h2><p class="note">Ferraille : ${fmt(S.scrap)}. Choisis la rareté puis l’emplacement. Le modèle exact reste aléatoire.</p>
      <div class="chips" style="margin-bottom:10px">${RAR.slice(0,5).map((x,i)=>`<button class="chip ${i===r?'on':''}" data-a="craftr" data-id="${i}" style="color:${x.c}">${x.n}, ${craftCost(i)} ♻️</button>`).join('')}</div>
      <div class="slots">${SLOTS.map(s=>`<button class="slot" data-a="craft" data-id="${s[0]}" ${S.scrap<cost?'disabled':''}><b>${s[2]}</b><span>${s[1]}</span></button>`).join('')}</div>`;
    return true;
  }
  if(sheet.t==='audio'){
    const A=S.audio, rows=[['master','Volume général'],['music','Musique'],['eng','Ma voiture (moteur)'],['opp','Voitures adverses'],['siren','Sirènes'],['amb','Pneus, vent, pluie, nitro'],['hit','Chocs'],['ui','Sons des menus'],['jing','Jingles et tirages']];
    el.innerHTML=`${X}<h2>Réglages audio</h2>${RC&&RC.paused?'<p class="note">Course en pause pendant le réglage.</p>':''}
      <div class="chips" style="margin-bottom:10px">${[['equi','Équilibré'],['course','Moteurs en avant'],['musique','Musique en avant'],['calme','Discret']].map(p=>`<button class="chip" data-a="preset" data-id="${p[0]}">${p[1]}</button>`).join('')}</div>
      ${rows.map(([k,n])=>`<div class="arow"><span>${n}</span><input class="rng" type="range" min="0" max="100" value="${Math.round((A[k]==null?AUDEF[k]:A[k])*100)}" data-a="vol" data-k="${k}" aria-label="${n}"><button class="btn alt sm" data-a="autest" data-id="${k}">Tester</button></div>`).join('')}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn ${A.mute?'':'alt'}" data-a="mute2">${A.mute?'Son coupé : réactiver':'Couper tout le son'}</button><button class="btn" data-a="close">Terminé</button></div>`;
    return true;
  }
  return false;
}
const AUDEF={mute:false,master:.9,music:.7,eng:.6,opp:.55,siren:.4,amb:.8,hit:.8,ui:.8,jing:.85};
const AUPRE={equi:{master:.9,music:.7,eng:.6,opp:.55,siren:.4,amb:.8,hit:.8,ui:.8,jing:.85},course:{master:.9,music:.4,eng:.95,opp:.85,siren:.5,amb:.9,hit:.9,ui:.7,jing:.8},
  musique:{master:.9,music:1,eng:.35,opp:.3,siren:.25,amb:.55,hit:.6,ui:.7,jing:.9},calme:{master:.55,music:.5,eng:.35,opp:.3,siren:.15,amb:.5,hit:.5,ui:.5,jing:.6}};
/* ---------- apparence 3D des modules, vue 3D d'une voiture ---------- */
const RCOL=RAR.map(r=>r.c);
function paintOf(look){ if(!look||!look.peinture||!window.THREE) return null; const c=new THREE.Color(RCOL[look.peinture.r]); if(look.peinture.t==='pe2') c.multiplyScalar(.42); else if(look.peinture.t==='pe3') c.lerp(new THREE.Color(0xffffff),.25); return c; }
function tintFlame(flame,look){ const n=look&&look.nitro; if(!n) return; const c=n.r>=5?0xffc23d:n.r>=3?0xc77dff:0x7df3ff; flame.children.forEach(f=>f.material.color.setHex(c)); if(n.r>=4) flame.scale.x=1.3; }
function shineTick(c3,t){ if(c3&&c3.shine&&c3.shine.length) c3.shine.forEach(m=>m.emissive.setHSL((t*.15)%1,.9,.2)); }
function addLook0(g,D,look,wheels){
  if(!look) return;
  const dark=new THREE.MeshLambertMaterial({color:0x14151b}), neon=r=>new THREE.MeshBasicMaterial({color:new THREE.Color(RCOL[r])}), L=D.x1-D.x0, mx=(D.x0+D.x1)/2;
  const box=(w,h,d,mat,x,y,z)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat); m.position.set(x,y,z); g.add(m); return m;};
  const a=look.aero;
  if(a){
    if(a.t==='ae2'){ const hg=.16+.035*a.r, ch=.3+.03*a.r, wd=D.W*(.78+.03*Math.min(a.r,4)), x=D.x0+.05*L+ch/2, y=D.deck+hg;
      box(ch,.035,wd,dark,x,y,0); [1,-1].forEach(s=>{box(.05,hg,.05,dark,x,D.deck+hg/2,s*wd*.3); if(a.r>=2) box(ch*1.1,.16,.03,a.r>=4?neon(a.r):dark,x,y+.03,s*wd/2);}); if(a.r>=3) box(.03,.02,wd,neon(a.r),x-ch/2,y+.025,0); }
    else if(a.t==='ae1'){ box(.24+.03*a.r,.03,D.W*.92,a.r>=3?neon(a.r):dark,D.x1-.03,.13,0); if(a.r>=2) [1,-1].forEach(s=>box(.26,.13,.03,dark,D.x1-.12,.2,s*D.W*.46)); }
    else [1,-1].forEach(s=>{box(L*.5,.1,.08,dark,mx,.17,s*(D.W/2+.02)); if(a.r>=2) box(L*.5,.02,.02,neon(a.r),mx,.11,s*(D.W/2+.07));});
  }
  const j=look.jantes;
  if(j) wheels.forEach(w=>{ const sg=w.position.z>=0?1:-1, z=wheels.length>2?sg*D.ww:0;
    [0,1].forEach(k=>{ if(k&&j.r<3) return; const t=new THREE.Mesh(new THREE.TorusGeometry(D.wr*(k?.3:.62),.026+.004*j.r,6,k?14:22),neon(j.r)); t.position.z=z; w.add(t); if(wheels.length<=2){const t2=t.clone(); t.position.z=.03; t2.position.z=-.03; w.add(t2);} }); });
  const e=look.echap;
  if(e){ const zs=e.r>=5?[-.42,-.28,.28,.42]:e.r>=2?[-.35,.35]:[.35], rd=.05+.006*e.r, k=Math.min(1,D.W/1.8);
    zs.forEach(z=>{const c=new THREE.Mesh(new THREE.CylinderGeometry(rd,rd,.24,10),e.r>=3?neon(e.r):new THREE.MeshLambertMaterial({color:0x9aa0aa})); c.rotation.z=Math.PI/2; c.position.set(D.x0-.05,.2,z*k); g.add(c);}); }
  const tb=look.turbo;
  if(tb){ box(.42,.07+.012*tb.r,.36,dark,D.x1-.22*L,D.hood+.03,0); if(tb.r>=3) box(.03,.03,.36,neon(tb.r),D.x1-.22*L+.2,D.hood+.05,0); }
}
const VW={on:false,yaw:.7,pit:.28,dist:9,ptr:{},down:false,car:null,scene:null,cam:null};
function openViewer(uid){
  const c=car(uid); if(!c) return; if(!glEnsure()) return toast('La vue 3D n’est pas disponible sur cet appareil');
  if(modelsBusy) return toast('Chargement des modèles 3D…');
  closeSheet(); glStop(); const m=M[c.mid], s=st(c), el=$('viewer'), mods=SLOTS.map(sl=>modOf(c.mods&&c.mods[sl[0]])).filter(Boolean);
  el.hidden=false;
  el.innerHTML=`<div class="vw-slot" id="vslot"></div>
    <div class="vw-top"><div><b>${m.nom}${c.sh?' ✨':''}</b><small>${TIERS[m.t].n}, ${m.cat}. ${fmt(s.ch)} ch, ${fmt(s.kg)} kg, ${fmt(s.vmax)} km/h</small></div><button class="btn sm" data-a="vclose">Fermer</button></div>
    <div class="vw-bot">${mods.length?mods.map(x=>`<span class="chip" style="border-color:${RAR[x.r].c};color:${RAR[x.r].c}">${modName(x)}</span>`).join(''):'<span class="chip">Aucun module monté</span>'}<small>Glisse pour tourner, pince pour zoomer</small></div>`;
  const sc=new THREE.Scene(); sc.background=new THREE.Color(0x07050f); sc.fog=new THREE.Fog(0x07050f,30,80);
  sc.add(new THREE.HemisphereLight(0xb9c4ff,0x2a0a4a,1.2)); const dl=new THREE.DirectionalLight(0xffffff,.9); dl.position.set(-6,12,8); sc.add(dl); const d2=new THREE.DirectionalLight(0xff9af0,.5); d2.position.set(8,5,-8); sc.add(d2);
  const gt=ctex(128,128,(x,W,H)=>{x.fillStyle='#0a0a20'; x.fillRect(0,0,W,H); x.strokeStyle='rgba(0,229,255,.4)'; x.lineWidth=2; x.strokeRect(0,0,W,H);},[14,14]);
  const fl=new THREE.Mesh(new THREE.CircleGeometry(22,48),new THREE.MeshBasicMaterial({map:gt})); fl.rotation.x=-Math.PI/2; sc.add(fl);
  const tc=new THREE.Color(TIERS[m.t].c); [[3.6,3.75],[4.6,4.66]].forEach(q=>{const r=new THREE.Mesh(new THREE.RingGeometry(q[0],q[1],64),new THREE.MeshBasicMaterial({color:tc,side:THREE.DoubleSide})); r.rotation.x=-Math.PI/2; r.position.y=.02; sc.add(r);});
  const c3=buildCar(m,TIERS[m.t].c,carLook(c)); sc.add(c3.g);
  VW.car=c3; VW.scene=sc; VW.cam=new THREE.PerspectiveCamera(42,1,.1,200); VW.dist=Math.max(3.2,c3.L*2.1); VW.ptr={}; VW.down=false; VW.on=true; VW.h=Math.min(1,(c3.H||1.4)*.45);
  glAttach('vslot'); glRun(sc,VW.cam,viewerFrame,'viewer'); auTry(()=>ui('open'));
}
function viewerFrame(dt,time){
  if(!VW.down) VW.yaw+=dt*.25; const d=VW.dist, p=VW.pit;
  VW.cam.position.set(Math.cos(VW.yaw)*Math.cos(p)*d,Math.sin(p)*d+VW.h,Math.sin(VW.yaw)*Math.cos(p)*d); VW.cam.lookAt(0,VW.h,0);
  pulseSirens(VW.car,time); shineTick(VW.car,time);
}
function closeViewer(){
  if(!VW.on) return; VW.on=false; glStop(); if(VW.scene) disposeScene(VW.scene); VW.scene=null; VW.car=null;
  const el=$('viewer'); el.hidden=true; el.innerHTML=''; GG.sig=null; render();
}
function bindViewerInput(c){
  c.addEventListener('pointerdown',e=>{ if(GL.mode!=='viewer') return; VW.ptr[e.pointerId]=[e.clientX,e.clientY]; VW.down=true; try{c.setPointerCapture(e.pointerId);}catch(_){ } });
  c.addEventListener('pointermove',e=>{ if(GL.mode!=='viewer') return; const p=VW.ptr[e.pointerId]; if(!p) return; const ids=Object.keys(VW.ptr);
    if(ids.length>=2){ const o=VW.ptr[ids.find(i=>i!=e.pointerId)], d0=Math.hypot(p[0]-o[0],p[1]-o[1]), d1=Math.hypot(e.clientX-o[0],e.clientY-o[1]); if(d0>1&&d1>1) VW.dist=clamp(VW.dist*d0/d1,2.2,24); }
    else { VW.yaw+=(e.clientX-p[0])*.008; VW.pit=clamp(VW.pit+(e.clientY-p[1])*.006,.03,1.25); }
    VW.ptr[e.pointerId]=[e.clientX,e.clientY]; });
  const up=e=>{ delete VW.ptr[e.pointerId]; VW.down=Object.keys(VW.ptr).length>0; }; c.addEventListener('pointerup',up); c.addEventListener('pointercancel',up);
  c.addEventListener('wheel',e=>{ if(GL.mode!=='viewer') return; e.preventDefault(); VW.dist=clamp(VW.dist*(e.deltaY>0?1.1:.9),2.2,24); },{passive:false});
}
/* appui long sur une carte de voiture du garage : vue 3D */
let lpT=null, lpAt=0, lpXY=null;
document.addEventListener('pointerdown',e=>{
  const b=e.target&&e.target.closest&&e.target.closest('[data-a="car"]'); if(!b||view!=='garage'||sheet) return;
  lpXY=[e.clientX,e.clientY]; clearTimeout(lpT); const id=+b.dataset.id; lpT=setTimeout(()=>{lpT=null; lpAt=Date.now(); openViewer(id);},480);
},true);
['pointerup','pointercancel'].forEach(t=>document.addEventListener(t,()=>{clearTimeout(lpT); lpT=null;},true));
document.addEventListener('pointermove',e=>{ if(lpT&&lpXY&&Math.hypot(e.clientX-lpXY[0],e.clientY-lpXY[1])>10){clearTimeout(lpT); lpT=null;} },true);
document.addEventListener('contextmenu',e=>{ if(e.target&&e.target.closest&&e.target.closest('[data-a="car"]')) e.preventDefault(); });
/* sons : cartes et essais de volume */
function auCard(r,sh,un){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.01, d=AU.b.jing, f=[330,392,494,587,740,880,1175][r]; LOG('card',t,r);
  osc('triangle',f,t,.08,d,.16,.003,.3); osc('sine',f*2,t+.05,.06,d,.1,.003,.4);
  if(r>=2) [1,1.26,1.5].forEach((m,i)=>osc('sawtooth',f*m,t+.08+i*.05,.12,d,.07,.004,.5));
  if(r>=4){ osc('sine',55,t,.5,d,.5,.005,.6); burst(t,1.2,5000,.5,'highpass',.2,d,true); }
  if(r>=5){ [1,1.5,2,3].forEach((m,i)=>osc('square',f*m,t+.3+i*.08,.2,d,.06,.004,.8)); burst(t,.6,200,.8,'lowpass',.4,d); }
  if(sh||un) for(let i=0;i<7;i++) osc('sine',2400+Math.random()*2400,t+.1+i*.05,.03,d,.06,.001,.2);
}
function auTest(k){
  if(!AU.ok) return; const c=AU.ctx, t=c.currentTime+.02; LOG('test',t,k);
  if(k==='music'||k==='master'){ kick(t,.9); hat(t+STEP*2,.1); snare(t+STEP*4,.7); hat(t+STEP*6,.1); kick(t+STEP*10,.9); snare(t+STEP*12,.7); stab(t,220,.14,.3); stab(t+STEP*6,261.6,.14,.3); if(k==='music') return; }
  if(k==='eng'||k==='opp'||k==='master'){ const e=mkEng(k==='opp'?'v6':'v8',AU.b[k==='opp'?'opp':'eng']); let i=0; const iv=setInterval(()=>{ i++; auTry(()=>engUpdate(e,{v:Math.min(40,i*2.2),vTop:60,thr:i<16?1:0,vol:k==='opp'?.65:.75,pan:0,nit:false},.05)); if(i>22){clearInterval(iv); engStop(e);} },50); return; }
  if(k==='siren'){ const o=c.createOscillator(), bp=c.createBiquadFilter(), g=c.createGain(); o.type='square'; bp.type='bandpass'; bp.frequency.value=1150; bp.Q.value=1.1; g.gain.value=.09; for(let i=0;i<4;i++) o.frequency.setValueAtTime(i%2?640:860,t+i*.3); o.connect(bp); bp.connect(g); g.connect(AU.b.siren); o.start(t); o.stop(t+1.2); return; }
  if(k==='amb'){ burst(t,.7,1800,5,'bandpass',.3,AU.b.amb); burst(t+.2,.6,900,.7,'bandpass',.2,AU.b.amb); return; }
  if(k==='hit'){ const d=AU.b.hit; burst(t,.35,260,1,'lowpass',.45,d); osc('sine',70,t,.08,d,.45,.001,.25); [420,630,910].forEach((f,i)=>osc('square',f,t,.02,d,.06,.001,.2+.06*i)); return; }
  if(k==='ui'){ ui('buy'); return; }
  if(k==='jing') auLevelUp();
}
const ACT = {
  cartab(d){cTab=d.id; render(); document.querySelector('main').scrollTop=0;},
  cslot(d){cSlot=d.id; render();},
  pack(d){ const pk=PACKS.find(p=>p.id===d.id); if(!pk) return; const i=PACKS.indexOf(pk), ok=(d.k==='tok'?S.tok>=pk.tok:S.cr>=pk.cr)&&S.mods.length+pk.n<=invMax(), st=$('pk3');
    if(ok&&st&&!sheet&&!PK.busy){ PK.busy=true; st.classList.add('burst'); const e=st.querySelector('.pk[data-i="'+i+'"]'); if(e) e.classList.add('burst'); auTry(()=>auRip(i)); setTimeout(()=>{PK.busy=false; openPack(d.id,d.k);},680); return; }
    openPack(d.id,d.k); },
  reveal(){ if(!sheet||sheet.t!=='open'||sheet.i>=sheet.cards.length) return; const m=modOf(sheet.cards[sheet.i]); sheet.i++; auCard(m.r,m.sh,m.un!=null); renderSheet(); const e=$('sheet').querySelectorAll('.mod')[sheet.i-1]; if(e){e.classList.add('pop'); e.scrollIntoView&&e.scrollIntoView({block:'nearest'});} },
  revealall(){ if(!sheet||sheet.t!=='open') return; let best=null; while(sheet.i<sheet.cards.length){const m=modOf(sheet.cards[sheet.i++]); if(!best||m.r>best.r) best=m;} if(best) auCard(best.r,best.sh,best.un!=null); renderSheet(); },
  rates(){openSheet({t:'rates'});},
  recycle(d){const m=modOf(+d.id); if(!m||eqCar(m.u)) return; S.scrap+=Math.round(RAR[m.r].sc*(m.sh?3:1)*scrapK()); bump('recyN'); S.mods=S.mods.filter(x=>x!==m); save(); render();},
  recycleall(){const k=S.mods.filter(m=>m.r===0&&!m.sh&&!eqCar(m.u)); if(!k.length) return; S.scrap+=Math.round(k.length*scrapK()); bump('recyN',k.length); S.mods=S.mods.filter(m=>!k.includes(m)); toast(`${k.length} modules recyclés`); save(); render();},
  fuse(d){const r=+d.id, pool=S.mods.filter(m=>m.r===r&&!m.sh&&m.un==null&&!eqCar(m.u)).sort((a,b)=>a.q-b.q).slice(0,5); if(r>=6||pool.length<5) return;
    S.mods=S.mods.filter(m=>!pool.includes(m)); const m=newMod(r+1,null,true); S.mods.push(m); bump('fuseN'); save(); render(); openSheet({t:'open',cards:[m.u],i:0,pk:'p1'});},
  craftopen(){openSheet({t:'craft',r:0});},
  craftr(d){sheet.r=+d.id; renderSheet();},
  craft(d){const r=sheet.r||0, cost=craftCost(r); if(S.scrap<cost||S.mods.length>=invMax()) return; S.scrap-=cost; const m=newMod(r,d.id,true); S.mods.push(m); save(); render(); openSheet({t:'open',cards:[m.u],i:0,pk:'p1'});},
  modslot(d){openSheet({t:'modpick',uid:sheet.uid,slot:d.id});},
  modeq(d){const c=car(sheet.uid), u=+d.id; if(!c||!modOf(u)) return; if(eqOther(u,c)) return openSheet({t:'eqconf',uid:c.uid,slot:sheet.slot,u}); equipMod(c,u,sheet.slot); save(); sheetBackToCar(c.uid);},
  modun(){const c=car(sheet.uid); if(c&&c.mods) delete c.mods[sheet.slot]; save(); const id=c.uid; render(); openSheet({t:'car',uid:id});},
  view3d(){openViewer(sheet.uid);},
  eqbest(d){ const c=car(+(d.id||(sheet&&sheet.uid))); if(!c) return; const pl=bestPlan(c);
    pl.free.forEach(([sl,u])=>equipMod(c,u,sl)); save();
    if(pl.taken.length){ render(); openSheet({t:'eqsteal',uid:c.uid,list:pl.taken.map(x=>[x[0],x[1]])}); return; }
    toast(pl.free.length?`${pl.free.length} pièce${pl.free.length>1?'s':''} montée${pl.free.length>1?'s':''}`:'Tu as déjà les meilleures pièces disponibles'); sheetBackToCar(c.uid); },
  eqsteal(){ const c=car(sheet.uid); let n=0; sheet.list.forEach(([sl,u])=>{ if(modOf(u)){ equipMod(c,u,sl); n++; } }); toast(`${n} pièce${n>1?'s':''} reprise${n>1?'s':''}`); save(); sheetBackToCar(c.uid); },
  eqok(){ const c=car(sheet.uid), m=modOf(sheet.u); if(!c||!m) return; const o=eqCar(m.u); equipMod(c,m.u,sheet.slot); toast(`${modName(m)} déplacée${o?' depuis '+M[o.mid].nom:''}`); save(); sheetBackToCar(c.uid); },
  eqnone(){ const c=car(sheet.uid); if(!c) return; c.mods={}; toast('Modules retirés'); save(); sheetBackToCar(c.uid); },
  eqcaropen(){ openSheet({t:'eqcar'}); },
  eqmodopen(d){ openSheet({t:'eqmod',u:+d.id}); },
  eqmod(d){ const m=modOf(sheet.u), c=car(+d.id); if(!m||!c||eqCar(m.u)) return; equipMod(c,m.u,MODI[m.t][1]); toast(`${modName(m)} montée sur ${M[c.mid].nom}`); closeSheet(); save(); render(); },
  pkgo(d){ PK.tgt=clamp(Math.round(PK.tgt)+(+d.id),0,PACKS.length-1); },
  mtab(d){ mTab=d.id; render(); },
  shopbuy(d){ const it=S.shop&&S.shop.items[+d.id]; if(!it||S.cr<it.p) return; if(S.mods.length>=invMax()) return toast('Inventaire plein : recycle ou fusionne des modules');
    S.cr-=it.p; const m=Object.assign({},it.m,{u:S.muid++}); S.mods.push(m); S.alb[m.t]=(S.alb[m.t]||0)|(1<<m.r); S.stats.best=Math.max(S.stats.best||0,m.r); S.shop.items.splice(+d.id,1); bump('shopN'); toast(`${modName(m)} ajouté à ton inventaire`); save(); render(); },
  shoproll(){ if(S.cr<400) return; S.cr-=400; shopRoll(); save(); render(); },
  fleetrep(){ const fr=fleetRepair(); if(S.cr<fr||!fr) return; S.cr-=fr; S.cars.forEach(c=>{c.etat=100;}); bump('repN'); toast('Garage remis à neuf'); save(); render(); },
  insure(){ if(S.cr<900) return; S.cr-=900; S.ins=3; toast('Entretien préventif actif sur 3 épreuves'); save(); render(); },
  coach(){ if(S.cr<1200) return; S.cr-=1200; S.xpb=3; toast('Coach actif sur 3 épreuves'); save(); render(); },
  sellmods(){ const k=S.mods.filter(m=>m.r<=1&&!m.sh&&m.un==null&&!eqCar(m.u)); if(!k.length) return; const v=k.reduce((t,m)=>t+(m.r?60:20),0); S.cr+=v; S.mods=S.mods.filter(m=>!k.includes(m)); bump('recyN',k.length); toast(`${k.length} modules vendus, +${fmt(v)} cr`); save(); render(); },
  qclaim(d){ const box=S[d.k], q=(d.k==='dq'?DQ:WQ).find(x=>x.id===d.id); if(!box||!q||box.cl[q.id]||qProg(box,q)<q.n) return; box.cl[q.id]=1; giveG(qRew(q)); toast('Récompense récupérée'); save(); render(); },
  vclose(){closeViewer();},
  audio(){openSheet({t:'audio'}); if(RC&&view==='race'){RC.paused=true; renderSheet();}},
  preset(d){Object.assign(S.audio,AUPRE[d.id]||{}); auSet(S.audio); save(); renderSheet();},
  autest(d){auTest(d.id);},
  mute2(){S.audio.mute=!S.audio.mute; auSet(S.audio); save(); renderSheet();},
  daily(){const k=dayKey(); if(S.daily===k) return; const y=new Date(Date.now()-864e5), yk=y.getFullYear()+'-'+(y.getMonth()+1)+'-'+y.getDate(); S.streak=S.daily===yk?(S.streak||0)+1:1; const r=dailyReward(); S.daily=k; giveG(r); toast(`+${fmt(r.cr)} cr, +${r.xp} XP et +${r.tok} jeton(s)`); save(); render();},
  devkit(){['subi','audi','merco','velo'].forEach(id=>{ if(!S.cars.some(c=>c.mid===id)) S.cars.push({uid:S.nuid++,mid:id,etat:100,xp:0,lvl:1,up:{},inv:0,mods:{}}); }); S.cr+=50000; S.tok+=20; toast('Kit de test reçu : 4 véhicules, 50 000 cr, 20 jetons'); save(); render();},
  tab(d){leaveRace(); view=d.id; R=null; resetArm=false; render(); document.querySelector('main').scrollTop=0;},
  close(){closeSheet();},
  car(d){openSheet({t:'car',uid:+d.id});},
  repair(){
    const c=car(sheet.uid), u=repUnit(c), pts=Math.min(100-c.etat,Math.floor(S.cr/u));
    if(pts<1) return toast('Pas assez de crédits');
    S.cr-=Math.ceil(pts*u); c.etat+=pts; bump('repN');
    if(c.etat>=100){c.etat=100; S.stats.repFull++; toast('Voiture remise à neuf');} else toast(`État remonté à ${c.etat} %`);
    save(); render();
  },
  up(d){
    const c=car(sheet.uid), l=c.up[d.id]||0, k=upCost(c,l);
    if(S.cr<k||l>=Math.min(4,S.bat.atelier)) return;
    S.cr-=k; c.up[d.id]=l+1; c.inv=(c.inv||0)+k; S.stats.ups++;
    toast(`${PARTS.find(p=>p.id===d.id).nom} : palier ${PALIERS[l+1]}`); save(); render();
  },
  sell(){
    if(S.cars.length<2) return;
    if(!sheet.arm){sheet.arm=true; return renderSheet();}
    const c=car(sheet.uid), p=prixVente(c);
    S.cr+=p; bump('sellN'); S.cars=S.cars.filter(x=>x.uid!==c.uid); S.pod.slots=S.pod.slots.map(u=>u===c.uid?null:u); closeSheet(); toast(`${M[c.mid].nom} vendue, +${fmt(p)} cr`); save(); render();
  },
  ev(d){
    const ev=EVENTS.find(e=>e.id===d.id);
    if(S.lvl<ev.lvl||S.cars.length<ev.manches.length) return;
    leaveRace();
    R={ev,opps:makeOpps(ev),pick:ev.manches.map(()=>null),rows:[],auto:false,result:null};
    if(S.cars.length===1&&ev.manches.length===1) R.pick[0]=S.cars[0].uid;
    view='prep'; render(); document.querySelector('main').scrollTop=0;
  },
  slot(d){openSheet({t:'pick',i:+d.id});},
  pick(d){R.pick[sheet.i]=+d.id; closeSheet(); render();},
  go(d){if(!R||!R.pick.every(x=>x)) return; if(modelsBusy||trackBusy){toast('Chargement des modèles 3D…'); Promise.all([modelsP,trackP]).then(()=>ACT.go(d)); return;} R.auto=d.id==='auto'; R.rows=[]; startManche(0);},
  respawn(){respawnPlayer();},
  mute(){S.audio.mute=!S.audio.mute; auSet(S.audio); save(); render();},
  nextm(){if(!R||!RC) return; const n=R.ev.manches.length; if(RC.i+1<n) startManche(RC.i+1); else finalize(false);},
  quit(){if(!R) return; finalize(true);},
  buy(d){
    const o=S.offres[+d.id]; if(!o||S.cr<o.prix) return;
    S.cr-=o.prix; S.cars.push({uid:S.nuid++,mid:o.mid,etat:o.etat,xp:0,lvl:1,up:{},inv:0,mods:{},sh:Math.random()<.03?1:0}); S.offres.splice(+d.id,1);
    toast(`${M[o.mid].nom} ajoutée au garage`); save(); render();
  },
  buynew(d){
    const m=M[d.id]; if(!m||S.cr<m.val||m.t>S.bat.concession+1) return;
    S.cr-=m.val; S.cars.push({uid:S.nuid++,mid:m.id,etat:100,xp:0,lvl:1,up:{},inv:0,mods:{},sh:Math.random()<.03?1:0});
    toast(`${m.nom} ajoutée au garage`); save(); render();
  },
  refresh(){const k=100*S.bat.casse; if(S.cr<k) return; S.cr-=k; newOffres(); save(); render();},
  slot3(d){openSheet({t:'slot',i:+d.id});},
  podset(d){const i=sheet.i; if(S.lvl<POD_LVL[i]) return; S.pod.slots=S.pod.slots.map(u=>u===+d.id?null:u); S.pod.slots[i]=+d.id; closeSheet(); toast('Voiture exposée'); save(); render();},
  podclear(){S.pod.slots[sheet.i]=null; closeSheet(); save(); render();},
  podup(){const nx=POD_TIER[S.pod.tier+1]; if(!nx||S.lvl<nx.lvl||S.cr<nx.cost) return; S.cr-=nx.cost; S.pod.tier++; toast('Podiums : '+nx.n); save(); render();},
  collect(){const p=Math.floor(podPending()); S.pod.last=Date.now(); if(p<1){save(); return toast('Rien à récolter pour le moment');} S.cr+=p; toast(`+${fmt(p)} cr récoltés`); save(); render();},
  buynitro(d){const q=+(d.id||1), p={1:NITRO_PRIX,5:650,12:1500}[q]; if(!p||S.cr<p) return; S.cr-=p; S.nitro+=q; save(); render();},
  bat(d){
    const b=BATS.find(x=>x.id===d.id), l=S.bat[b.id]; if(l>=b.max||S.cr<b.cout[l]) return;
    S.cr-=b.cout[l]; S.bat[b.id]=l+1; S.stats.bats++;
    if(b.id==='casse') newOffres();
    toast(`${b.nom} : niveau ${l+1}`); save(); render();
  },
  claim(d){
    const m=MISSIONS.find(x=>x.id===d.id), [a,b]=m.p(S); if(S.claimed[m.id]||a<b) return;
    S.claimed[m.id]=1; giveG(m.g); toast('Récompense récupérée : '+gText(m.g).replace(/&nbsp;/g,' ')); save(); render();
  },
  reset(){
    if(!resetArm){resetArm=true; return render();}
    const aud=S.audio, ag18=S.age18; resetArm=false; S=fresh(); S.audio=aud; S.age18=ag18; if(ag18===true) S.charte=1; S.intro=true; R=null; view='garage'; save(); render(); toast('Nouvelle partie');
  }
};
document.addEventListener('click',e=>{
  if(Date.now()-lpAt<700) return;
  const b=e.target.closest('[data-a]'); if(!b||b.disabled) return;
  const f=ACT[b.dataset.a]; if(f){const pre={cr:S.cr,lvl:S.lvl}; f(b.dataset); auAction(b.dataset.a,b.dataset,pre);}
});
document.addEventListener('input',e=>{const el=e.target; if(el&&el.dataset&&el.dataset.a==='vol'){S.audio[el.dataset.k]=(+el.value)/100; auSet(S.audio); save();}});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&sheet) closeSheet();
  if(view==='race'&&RC&&!e.repeat){
    const k=e.key.toLowerCase();
    if(RC.kind==='spa'){
      if(k==='z'||k==='w'||e.key==='ArrowUp'){e.preventDefault(); RC.inp.k=1;}
      if(k==='s'||e.key==='ArrowDown'){e.preventDefault(); RC.inp.kb=true;}
      if(k==='q'||k==='a'||e.key==='ArrowLeft'){e.preventDefault(); RC.keyL=true;}
      if(k==='d'||e.key==='ArrowRight'){e.preventDefault(); RC.keyR=true;}
      if(e.code==='Space'){e.preventDefault(); RC.inp.hand=true;}
      if(k==='n'||e.key==='Shift') fireNitro();
      if(k==='r') respawnPlayer();
      RC.inp.sk=(RC.keyR?1:0)-(RC.keyL?1:0);
    } else if(RC.kind==='race'){
      if(k==='z'||k==='w'||e.key==='ArrowUp'){e.preventDefault(); RC.inp.k=1;}
      if(k==='q'||k==='a'||e.key==='ArrowLeft'){e.preventDefault(); RC.inp.k=.5;}
      if(k==='s'||e.key==='ArrowDown'||e.code==='Space'){e.preventDefault(); RC.inp.kb=true;}
      if(k==='n'||e.key==='Shift') fireNitro();
      if(k==='e') shiftGear(RC.P,1); if(k==='c') shiftGear(RC.P,-1);
    }
  }
});
document.addEventListener('keyup',e=>{
  if(!(view==='race'&&RC)) return; const k=e.key.toLowerCase();
  if(RC.kind==='spa'){
    if(k==='z'||k==='w'||e.key==='ArrowUp') RC.inp.k=0;
    if(k==='s'||e.key==='ArrowDown') RC.inp.kb=false;
    if(k==='q'||k==='a'||e.key==='ArrowLeft') RC.keyL=false;
    if(k==='d'||e.key==='ArrowRight') RC.keyR=false;
    if(e.code==='Space') RC.inp.hand=false;
    RC.inp.sk=(RC.keyR?1:0)-(RC.keyL?1:0);
  } else if(RC.kind==='race'){
    if(k==='z'||k==='w'||e.key==='ArrowUp'||k==='q'||k==='a'||e.key==='ArrowLeft') RC.inp.k=0;
    if(k==='s'||e.key==='ArrowDown'||e.code==='Space') RC.inp.kb=false;
  }
});

/* ======================================================================
   v0.9 : miniatures 3D, équipement des modules, paquets 3D, effets de course
   ====================================================================== */
let lastView=null;
/* ---- miniatures 3D : chaque voiture est rendue une fois avec le moteur partagé, puis mise en cache ---- */
const TH={c:{},q:[],busy:false,fail:false};
const thKey=c=>c.mid+'|'+lookKey(c)+(c.sh?'|s':'');
function thArt(c){
  const m=M[c.mid], k=thKey(c), u=TH.c[k], rust=c.etat<40;
  if(u) return `<img class="th${rust?' rust':''}" src="${u}" alt="" draggable="false">`;
  if(window.THREE&&!TH.fail&&!TH.q.some(x=>x.k===k)){ TH.q.push({k,c:{mid:c.mid,lk:carLook(c),sh:c.sh}}); setTimeout(thPump,40); }
  return `<div class="thw" data-th="${k}" data-r="${rust?1:0}">${carSVG(m,c.etat)}</div>`;
}
function thFill(k,url){
  document.querySelectorAll('[data-th]').forEach(e=>{ if(e.dataset.th!==k) return;
    e.outerHTML=`<img class="th${e.dataset.r==='1'?' rust':''}" src="${url}" alt="" draggable="false">`; });
}
function thPump(){
  if(TH.busy||TH.fail||!TH.q.length||modelsBusy||view==='race'||!glEnsure()) return;
  TH.busy=true;
  requestAnimationFrame(()=>{
    const it=TH.q.shift();
    try{ const url=thRender(it.c); if(url){TH.c[it.k]=url; thFill(it.k,url);} else TH.fail=true; }
    catch(e){ TH.fail=true; TH.q.length=0; try{console.warn('miniature',e);}catch(_){ } }
    TH.busy=false; if(TH.q.length) setTimeout(thPump,20);
  });
}
function thRender(c){
  const m=M[c.mid], tcs=TIERS[m.t].c, tc=new THREE.Color(tcs), W=640, H=384, R=GL.r;
  const sc=new THREE.Scene();
  const bg=ctex(4,256,(x,w,h)=>{const g=x.createLinearGradient(0,0,0,h); g.addColorStop(0,'#0a0919'); g.addColorStop(.58,'#1a1640'); g.addColorStop(1,'#07060f'); x.fillStyle=g; x.fillRect(0,0,w,h);});
  bg.wrapS=bg.wrapT=THREE.ClampToEdgeWrapping; sc.background=bg;
  sc.add(new THREE.HemisphereLight(0xc6d0ff,0x2a0a4a,1.25));
  const dl=new THREE.DirectionalLight(0xffffff,.95); dl.position.set(-6,12,9); sc.add(dl);
  const rim=new THREE.DirectionalLight(tc,.9); rim.position.set(8,5,-8); sc.add(rim);
  const d2=new THREE.DirectionalLight(0xff9af0,.35); d2.position.set(6,3,8); sc.add(d2);
  const gt=ctex(128,128,(x,w,h)=>{x.fillStyle='#0a0a20'; x.fillRect(0,0,w,h); x.strokeStyle='rgba(0,229,255,.38)'; x.lineWidth=2; x.strokeRect(0,0,w,h);},[16,16]);
  const fl=new THREE.Mesh(new THREE.CircleGeometry(24,48),new THREE.MeshBasicMaterial({map:gt})); fl.rotation.x=-Math.PI/2; sc.add(fl);
  [[3.5,3.66],[4.5,4.56]].forEach(q=>{const r=new THREE.Mesh(new THREE.RingGeometry(q[0],q[1],64),new THREE.MeshBasicMaterial({color:tc,side:THREE.DoubleSide})); r.rotation.x=-Math.PI/2; r.position.y=.02; sc.add(r);});
  const c3=buildCar(m,tcs,c.lk||{}); sc.add(c3.g);
  const cam=new THREE.PerspectiveCamera(30,W/H,.1,200), h=Math.min(1,(c3.H||1.4)*.45), d=Math.max(3.4,(c3.L||4)*2.6), a=.66, p=.2;
  cam.position.set(Math.cos(a)*Math.cos(p)*d,Math.sin(p)*d+h,Math.sin(a)*Math.cos(p)*d); cam.lookAt(0,h*.92,0);
  const rt=new THREE.WebGLRenderTarget(W,H,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,format:THREE.RGBAFormat});
  const buf=new Uint8Array(W*H*4);
  R.setRenderTarget(rt); R.render(sc,cam); R.readRenderTargetPixels(rt,0,0,W,H,buf); R.setRenderTarget(null);
  rt.dispose(); disposeScene(sc);
  const cv=document.createElement('canvas'); cv.width=W; cv.height=H; const x=cv.getContext('2d'), id=x.createImageData(W,H);
  for(let y=0;y<H;y++) id.data.set(buf.subarray((H-1-y)*W*4,(H-y)*W*4),y*W*4);
  x.putImageData(id,0,0);
  const o=document.createElement('canvas'); o.width=448; o.height=268; const ox=o.getContext('2d'); ox.imageSmoothingQuality='high'; ox.drawImage(cv,0,0,448,268);
  return o.toDataURL('image/jpeg',.9);
}

/* ---- équipement des modules ---- */
const eqOther=(u,c)=>{const o=eqCar(u); return o&&o!==c?o:null;};
function equipMod(c,u,slot){
  const o=eqCar(u); if(o) for(const k in o.mods) if(o.mods[k]===u) delete o.mods[k];
  c.mods=c.mods||{}; c.mods[slot]=u; bump('eqN'); S.stats.eq=Math.max(S.stats.eq||0,Object.keys(c.mods).length);
}
/* plan : pour chaque emplacement, le meilleur module libre (free) et le meilleur module pris sur une autre voiture (taken) */
function bestPlan(c){
  const free=[], taken=[];
  for(const sl of SLOTS){
    const id=sl[0], cur=c.mods&&modOf(c.mods[id]);
    const cands=S.mods.filter(m=>MODI[m.t][1]===id).sort((a,b)=>modPow(b)-modPow(a)); if(!cands.length) continue;
    const best=cands[0], bf=cands.find(m=>!eqOther(m.u,c));
    if(bf&&(!cur||modPow(bf)>modPow(cur)+1e-9)) free.push([id,bf.u]);
    const bo=eqOther(best.u,c);
    if(bo&&(!cur||modPow(best)>modPow(cur)+1e-9)&&(!bf||modPow(best)>modPow(bf)+1e-9)) taken.push([id,best.u,bo]);
  }
  return {free,taken};
}
const sheetBackToCar=uid=>{ render(); openSheet({t:'car',uid}); };
function eqSheets(X){
  const el=$('sheet');
  if(tuneSheets(X)||pilotSheets(X)||tutoSheet(X)||ranchSheet(X)||invSheet(X)||gtutoSheet(X)||labSheet(X)||wmapSheet(X)||equipSheet(X)||arcSheet(X)||ptSheet(X)||ulSheet(X)||polSheet(X)||ageSheet(X)) return true;
  if(sheet.t==='eqsteal'){
    const c=car(sheet.uid);
    el.innerHTML=`${X}<h2>Prendre des pièces ?</h2><p class="note">Ces meilleures pièces sont déjà montées sur d’autres voitures. Si tu confirmes, elles seront retirées de ces voitures et montées sur ${M[c.mid].nom}.</p>
      <div class="mods">${sheet.list.map(([sl,u])=>{const m=modOf(u), o=eqCar(u); return m?modHTML(m,`<div class="mod-eq">Retirée de : <b>${M[o.mid].nom}</b></div>`):'';}).join('')}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="car" data-id="${c.uid}">Garder comme ça</button><button class="btn mag" data-a="eqsteal">Les prendre</button></div>`;
    return true;
  }
  if(sheet.t==='eqconf'){
    const c=car(sheet.uid), m=modOf(sheet.u), o=m&&eqCar(m.u), cur=c.mods&&modOf(c.mods[sheet.slot]);
    if(!m||!o){ closeSheet(); return true; }
    el.innerHTML=`${X}<h2>Retirer cette pièce ?</h2><p class="note"><b>${modName(m)}</b> est déjà montée sur <b>${M[o.mid].nom}</b>. Une pièce ne peut équiper qu’une voiture à la fois.</p>
      ${modHTML(m)}<p class="note" style="margin-top:10px">Elle sera retirée de ${M[o.mid].nom} et montée sur ${M[c.mid].nom}${cur?`, à la place de ${modName(cur)}`:''}.</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="modslot" data-id="${sheet.slot}">Annuler</button><button class="btn mag" data-a="eqok">Confirmer le transfert</button></div>`;
    return true;
  }
  if(sheet.t==='eqcar'){
    el.innerHTML=`${X}<h2>Équiper les meilleures pièces</h2><p class="note">Choisis la voiture. Les meilleurs modules libres de chaque emplacement seront montés. Si une pièce meilleure est sur une autre voiture, je te demande avant de la prendre.</p>
      ${S.cars.map(c=>`<button class="row" data-a="eqbest" data-id="${c.uid}"><span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span><span class="grow"><span class="ttl">${M[c.mid].nom}</span><br><span class="sub">${Object.keys(c.mods||{}).length} / ${SLOTS.length} modules montés</span></span><span class="gain">Équiper</span></button>`).join('')}`;
    return true;
  }
  if(sheet.t==='eqmod'){
    const m=modOf(sheet.u); if(!m){closeSheet(); return true;} const sl=MODI[m.t][1], slN=SLOTS.find(s=>s[0]===sl);
    el.innerHTML=`${X}<h2>Monter sur quelle voiture ?</h2>${modHTML(m)}<p class="note" style="margin-top:8px">Emplacement : ${slN[2]} ${slN[1]}. Le module déjà monté sur la voiture choisie retourne dans ton inventaire.</p>
      ${S.cars.map(c=>{const cu=c.mods&&modOf(c.mods[sl]); return `<button class="row" data-a="eqmod" data-id="${c.uid}"><span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span><span class="grow"><span class="ttl">${M[c.mid].nom}</span><br><span class="sub">${cu?'Actuel : '+modName(cu)+' ('+RAR[cu.r].n+')':'Emplacement vide'}</span></span><span class="gain" style="color:${!cu||modPow(m)>modPow(cu)?'var(--good)':'var(--muted)'}">${!cu||modPow(m)>modPow(cu)?'Mieux':'Moins bon'}</span></button>`;}).join('')}`;
    return true;
  }
  return false;
}

/* ---- paquets 3D ---- */
const PKT={p1:{c1:'#6f7f96',c2:'#2d3850',c3:'#0f1626',emb:'🔧',tag:'STARTER'},p2:{c1:'#46e08a',c2:'#14804a',c3:'#07281a',emb:'⚙️',tag:'ATELIER'},
  p3:{c1:'#59a8ff',c2:'#6a3de0',c3:'#2a0a52',emb:'🏁',tag:'ÉLITE'},p4:{c1:'#ffe27a',c2:'#d98a14',c3:'#4d2400',emb:'👑',tag:'LÉGENDE'}};
const PK={pos:0,tgt:0,drag:null,vel:0,raf:0,shown:-1,busy:false,spin:0};
function pack3d(p,i){
  const th=PKT[p.id]||PKT.p1, pips=[0,1,2].map(k=>RAR[Math.min(6,p.min+k)]).map(r=>`<i style="background:${r.c}"></i>`).join('');
  return `<div class="pk" data-i="${i}" style="--c1:${th.c1};--c2:${th.c2};--c3:${th.c3}">
    <div class="lay l1"></div><div class="lay l2"></div><div class="lay l3"></div>
    <div class="lay fr"><div class="crimp t"></div><div class="crimp b"></div>
      <div class="ct"><span class="tag">${th.tag}</span><span class="emb">${th.emb}</span><div><div class="nm">${p.nom.replace('Paquet ','')}</div><div class="sb">${p.n} modules</div></div><span class="pips">${pips}</span></div><div class="shine"></div></div>
    <div class="lay bk"><div class="crimp t"></div><div class="crimp b"></div><div class="ct"><span class="tag">ROUILLE &amp; GLOIRE</span><span class="emb">🃏</span><span class="sb">${p.d}</span><span class="tag">COLLECTION</span></div></div></div>`;
}
function packsHTML(){
  return `<p class="note">Fais glisser les paquets de gauche à droite. Ils s’achètent avec des crédits ou des jetons 🎟 gagnés en jouant, jamais en argent réel.</p>
    <div class="pk3" id="pk3"><button class="pknav l" data-a="pkgo" data-id="-1" aria-label="Précédent">‹</button><div class="ring" id="pkring">${PACKS.map(pack3d).join('')}</div><div class="fl"></div><button class="pknav r" data-a="pkgo" data-id="1" aria-label="Suivant">›</button></div>
    <div class="dots" id="pkdots">${PACKS.map(()=>'<i></i>').join('')}</div><div class="pkInfo" id="pkInfo"></div>
    <button class="btn alt sm" data-a="rates" style="margin-top:12px">Voir les taux de tirage et les garanties</button>`;
}
function pkInfo(force){
  const el=$('pkInfo'); if(!el) return; const i=clamp(Math.round(PK.drag?PK.pos:PK.tgt),0,PACKS.length-1);
  if(!force&&PK.shown===i) return; PK.shown=i; const p=PACKS[i];
  el.innerHTML=`<div class="t"><b>${p.nom}</b><span>${p.n} modules</span></div><p class="note" style="margin:0">${p.d}</p>
    <div class="buy"><button class="btn" data-a="pack" data-id="${p.id}" data-k="cr" ${S.cr<p.cr?'disabled':''}>Ouvrir, ${cr(p.cr)}</button><button class="btn alt" data-a="pack" data-id="${p.id}" data-k="tok" ${S.tok<p.tok?'disabled':''}>${p.tok} 🎟</button></div>`;
  const dots=$('pkdots'); if(dots) [...dots.children].forEach((d,k)=>d.classList.toggle('on',k===i));
}
function pkLayout(time){
  const ring=$('pkring'); if(!ring){PK.raf=0; return false;}
  if(!PK.drag){ const d=PK.tgt-PK.pos; PK.pos+=d*.15; if(Math.abs(d)<.003) PK.pos=PK.tgt; }
  const spinK=PK.spin?Math.max(0,1-(time-PK.spin)/800):0; if(!spinK) PK.spin=0;
  [...ring.children].forEach(el=>{
    const i=+el.dataset.i, o=i-PK.pos, ao=Math.abs(o), sg=o<0?-1:1;
    const x=sg*(Math.min(ao,1)*108+Math.max(0,ao-1)*70), z=-Math.min(ao,2.2)*160;
    let ry=-Math.max(-1.5,Math.min(1.5,o))*44; if(ao<.5) ry+=Math.sin(time/820+i)*5*(1-ao*2);
    if(ao<.5&&spinK) ry+=360*(1-Math.pow(1-spinK,3))*-1+360;
    el.style.transform=`translate3d(${x.toFixed(1)}px,${(-ao*5).toFixed(1)}px,${z.toFixed(1)}px) rotateY(${ry.toFixed(1)}deg) scale(${(1-.06*Math.min(ao,2)).toFixed(3)})`;
    el.style.opacity=ao>2.6?0:(1-.16*Math.min(ao,2.4)).toFixed(2); el.style.zIndex=String(20-Math.round(ao*3));
    el.style.setProperty('--sx',(-30+ry*1.1+Math.sin(time/1300+i)*30).toFixed(0)+'%'); el.classList.toggle('sel',ao<.5);
  });
  pkInfo(); return true;
}
function pkLoop(t){ PK.raf=pkLayout(t)?requestAnimationFrame(pkLoop):0; }
function bindPacks(){
  const st=$('pk3'); if(!st||cTab!=='packs'){PK.raf=0; return;}
  PK.shown=-1; pkLayout(performance.now()); pkInfo(true);
  st.addEventListener('pointerdown',e=>{
    if(e.target.closest('.pknav')) return;
    PK.drag={x:e.clientX,p:PK.pos,moved:0,lx:e.clientX,lt:e.timeStamp,tg:e.target}; PK.vel=0; try{st.setPointerCapture(e.pointerId);}catch(_){}
  });
  st.addEventListener('pointermove',e=>{
    const d=PK.drag; if(!d) return; const dx=e.clientX-d.x; d.moved=Math.max(d.moved,Math.abs(dx));
    PK.pos=clamp(d.p-dx/108,-.3,PACKS.length-.7); const dt=e.timeStamp-d.lt; if(dt>0){PK.vel=PK.vel*.6+((e.clientX-d.lx)/dt)*.4; d.lx=e.clientX; d.lt=e.timeStamp;}
  });
  const up=e=>{
    const d=PK.drag; if(!d) return; PK.drag=null;
    if(d.moved<6){ const pe=d.tg&&d.tg.closest&&d.tg.closest('.pk'); if(pe){const i=+pe.dataset.i; if(i===Math.round(PK.tgt)) PK.spin=performance.now(); else PK.tgt=i;} else PK.tgt=Math.round(PK.pos); return; }
    PK.tgt=clamp(Math.round(PK.pos-PK.vel*170/108),0,PACKS.length-1); auTry(()=>ui('click'));
  };
  st.addEventListener('pointerup',up); st.addEventListener('pointercancel',up);
  if(!PK.raf) PK.raf=requestAnimationFrame(pkLoop);
}
function auRip(i){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.01, d=AU.b.jing;
  burst(t,.5,1800,.8,'bandpass',.5,d,true); burst(t+.08,.4,5200,.6,'highpass',.4,d);
  for(let k=0;k<12;k++) osc('square',1400+Math.random()*1800,t+.04*k,.01,d,.04,.001,.05);
  osc('sine',60,t+.35,.3,d,.5,.004,.4); osc('sawtooth',220*(1+i*.25),t+.4,.35,d,.07,.01,.5); burst(t+.45,.9,3200,.5,'highpass',.25,d,true);
}

/* ---- effets de course : flashs, lignes de vitesse, rampe de régime ---- */
const FXL='<div class="fxl" id="fxl"><div class="fl" id="fxF"></div><div class="sl" id="fxS"></div><div class="rev" id="fxR">'+'<i></i>'.repeat(16)+'</div></div>';
const WHEEL=`<svg viewBox="-60 -60 120 120" aria-hidden="true"><defs><linearGradient id="wg" x1="0" y1="-1" x2="0" y2="1"><stop offset="0" stop-color="#6a6f98"/><stop offset=".5" stop-color="#2a2e52"/><stop offset="1" stop-color="#0c0d20"/></linearGradient></defs>
<circle r="51" fill="none" stroke="url(#wg)" stroke-width="14"/><circle r="57.6" fill="none" stroke="#00E5FF" stroke-opacity=".5" stroke-width="1.4"/><circle r="44" fill="none" stroke="#000" stroke-opacity=".55" stroke-width="1.2"/>
<path d="M-44 -22 A50 50 0 0 1 -14 -47" fill="none" stroke="#fff" stroke-opacity=".2" stroke-width="3.5" stroke-linecap="round"/>
<path d="M-5 -59 L5 -59 L3.4 -43 L-3.4 -43 Z" fill="#FCEE0A"/>
<path d="M-45 5 Q-24 -3 -9 7 L-9 17 Q-25 11 -44 18 Z" fill="url(#wg)" stroke="#00E5FF" stroke-opacity=".4"/>
<path d="M45 5 Q24 -3 9 7 L9 17 Q25 11 44 18 Z" fill="url(#wg)" stroke="#00E5FF" stroke-opacity=".4"/>
<path d="M-9 14 L9 14 L12 44 L-12 44 Z" fill="url(#wg)" stroke="#00E5FF" stroke-opacity=".4"/>
<circle r="15" fill="#10122a" stroke="#00E5FF" stroke-width="2"/><circle r="6.5" fill="#FF2BD6"/><circle r="2.2" fill="#fff" fill-opacity=".8" cx="-2" cy="-2"/></svg>`;
function fxFlash(kind){ const f=$('fxF'); if(!f) return; f.className='fl'; void f.offsetWidth; f.className='fl '+kind; }
function fxUpdate(P,Rc){
  const vTop=Math.max(10,(P.r?P.r.VM:P.VM)||60), frac=P.drag?clamp(P.rpmF||0,0,1):clamp(P.v/vTop,0,1), nit=P.nitroT>0;
  const s=$('fxS'); if(s){ const f=clamp((P.v*3.6-80)/190,0,1)+(nit?.5:0), on=f>.12, o=(Math.min(1,f)*.9).toFixed(2); if(s._on!==on){s._on=on; s.classList.toggle('on',on);} if(s._o!==o){s._o=o; s.style.opacity=o;} }
  const r=$('fxR'); if(r){ const n=Math.round(frac*16); if(r._n!==n){ r._n=n; [...r.children].forEach((e,k)=>{ e.className=k<n?'on '+(k>=13?'r':k>=9?'y':''):''; }); } }
  if(Rc&&Rc.clock>3&&Rc.pos){ if(Rc.lastPos!=null){ if(Rc.pos<Rc.lastPos) auTry(auWhoosh); else if(Rc.pos>Rc.lastPos) auTry(auDown); } Rc.lastPos=Rc.pos; }
}

/* ======================================================================
   v0.9 : audio drag et nouveaux sons, économie, missions, marché
   ====================================================================== */
/* ---- audio : drag (tempo qui monte avec la vitesse) et nouveaux effets ---- */
function dragSD(){ const f=clamp(AU.speedFrac||0,0,1); AU.dsm=(AU.dsm||0)+(f-(AU.dsm||0))*.07; return 15/(120+68*Math.pow(AU.dsm,.85)); }
function dragSched(s,bar,t,ch){
  const q=AU.seq, L=q.level, sd=15/(120+68*Math.pow(AU.dsm||0,.85));
  if(s===0&&bar%4===0) AU.dkey=Math.pow(2,Math.min(5,Math.floor((AU.dsm||0)*6))/12);
  const k=AU.dkey||1;
  if(s===0&&bar%2===0) pad(t,sd*32,ch.pad.map(f=>f*k),.085);
  if(s%4===0) kick(t,L===0?.62:.92,{p0:170,p1:46,dec:.24});
  if(s%4===2) hat(t,.13,true); else if(L>=1&&s%2===1) hat(t,.045,false);
  if(L>=1&&(s===4||s===12)) clap(t,.42);
  if(L>=1&&s%4===2) sub(t,sd*1.7,ch.sub*2*k,.34);
  if(L>=2&&(s===0||s===6||s===10)) reese(t,sd*3,ch.bass*k,.2);
  if(L>=2) pluck(t,ch.arp[(s+bar*2)%6]*2*k,.07,'sawtooth',sd*2.2);
  if(L>=3){
    if([0,3,6,10,12].includes(s)) stab(t,ch.arp[(s>>1)%6]*2*k,.1,sd*2);
    if(s===0&&bar%2===0) crash(t,.26);
    if(s%2===1) hat(t,.06,false);
    if(bar%4===3&&s>=8) snare(t,.25+.04*(s-8),{});
  } else if(L>=2&&bar%4===3&&s>=12) snare(t,.28+.1*(s-12),{});
}
function auWhoosh(){ if(!AU.ok) return; const t=AU.ctx.currentTime+.005, b=burst(t,.42,500,1.6,'bandpass',.5,AU.b.hit); b.fl.frequency.exponentialRampToValueAtTime(3800,t+.34); osc('sine',880,t+.2,.05,AU.b.ui,.07,.002,.2); }
function auDown(){ if(!AU.ok) return; const t=AU.ctx.currentTime+.005, o=osc('triangle',300,t,.12,AU.b.ui,.16,.003,.14); o.o.frequency.exponentialRampToValueAtTime(150,t+.16); }
function auHorn(won){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.02, d=AU.b.jing;
  if(won){ [392,523.25,659.25].forEach((f,i)=>osc('sawtooth',f,t+i*.11,.34,d,.1,.01,.5)); osc('sawtooth',130.8,t,.6,d,.1,.01,.5); burst(t,.7,6000,.5,'highpass',.12,d,true); }
  else { osc('sawtooth',220,t,.5,d,.1,.01,.4); osc('sawtooth',164.8,t+.18,.6,d,.1,.01,.5); }
}
function auLaunch(){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.01, b=burst(t,.55,2300,6,'bandpass',.22,AU.b.amb); b.fl.frequency.linearRampToValueAtTime(3900,t+.5);
  const o=osc('sawtooth',90,t,.3,AU.b.hit,.1,.01,.25); o.o.frequency.exponentialRampToValueAtTime(260,t+.35);
}
function auDing(){ if(!AU.ok) return; const t=AU.ctx.currentTime+.005; osc('sine',1568,t,.08,AU.b.ui,.16,.002,.4); osc('sine',2093,t+.07,.1,AU.b.ui,.14,.002,.5); }

/* ---- économie : gains plus généreux, réparations et améliorations moins chères ---- */
const ECO={gain:1.5,up:.75,rep:.7};
const bump=(k,n)=>{S.stats[k]=(S.stats[k]||0)+(n==null?1:n);};
const wearK=()=>(S.ins>0?.3:1)*(1-.08*pk('wear'));
const invMax=()=>INV_MAX+60*(S.bat.entrepot||0);
const scrapK=()=>(1+.15*(S.bat.entrepot||0))*(1+.08*pk('scrap'));
const craftCost=r=>Math.max(1,Math.round(RAR[r].sc*6*(1-.08*(S.bat.entrepot||0))));
const giveG=g=>{S.cr+=g.cr||0; S.nitro+=g.nitro||0; S.tok+=g.tok||0; if(g.xp) addXP(g.xp);};
const gText=g=>[g.cr?cr(g.cr):'',g.nitro?`⚡ ${g.nitro}`:'',g.xp?`${g.xp} XP`:'',g.tok?`${g.tok} 🎟`:''].filter(Boolean).join(' + ');
BATS.push(
 {id:'banc',nom:'Banc de puissance',ic:'📈',max:5,cout:[3000,12000,45000,150000,500000],effet:l=>l?`+${l*2} % de puissance et de couple sur toutes tes voitures`:'Règle tes moteurs : +2 % de puissance par niveau'},
 {id:'entrepot',nom:'Entrepôt de pièces',ic:'📦',max:5,cout:[2000,8000,30000,100000,350000],effet:l=>l?`Ferraille +${l*15} %, fabrication −${l*8} %, inventaire de ${INV_MAX+60*l} modules`:'Plus de ferraille, fabrication moins chère, plus de place'},
 {id:'simu',nom:'Simulateur de course',ic:'🕹️',max:5,cout:[4000,16000,60000,200000,700000],effet:l=>l?`+${l*10} % d’expérience gagnée en course`:'Entraîne tes pilotes : +10 % d’expérience par niveau'});

/* ---- défis quotidiens et hebdomadaires ---- */
const DQ=[{id:'d_race',t:'Dispute 3 épreuves',s:'races',n:3,g:{cr:500,tok:1}},{id:'d_win',t:'Gagne 2 épreuves',s:'wins',n:2,g:{cr:800}},
 {id:'d_nit',t:'Utilise 3 bouteilles de nitro',s:'nitroN',n:3,g:{cr:400,nitro:1}},{id:'d_pack',t:'Ouvre 2 paquets',s:'packs',n:2,g:{cr:600,tok:1}},
 {id:'d_rep',t:'Répare 2 voitures',s:'repN',n:2,g:{cr:300}},{id:'d_eq',t:'Monte 2 modules',s:'eqN',n:2,g:{cr:500}},
 {id:'d_shop',t:'Achète une pièce au marché',s:'shopN',n:1,g:{cr:500}},{id:'d_spa',t:'Gagne une course sur le circuit de Spa',s:'w_circuit',n:1,g:{cr:900,tok:1}},
 {id:'d_drag',t:'Gagne un drag',s:'w_drag',n:1,g:{cr:700}}];
const WQ=[{id:'w_win',t:'Gagne 12 épreuves',s:'wins',n:12,g:{cr:6000,tok:6}},{id:'w_pack',t:'Ouvre 10 paquets',s:'packs',n:10,g:{cr:4000,tok:5}},
 {id:'w_earn',t:'Gagne 30 000 cr en course',s:'earned',n:30000,g:{cr:5000,tok:3}},{id:'w_nit',t:'Utilise 15 bouteilles de nitro',s:'nitroN',n:15,g:{cr:3000,nitro:3}},
 {id:'w_spa',t:'Gagne 5 courses sur le circuit de Spa',s:'w_circuit',n:5,g:{cr:5000,tok:4}},{id:'w_fuse',t:'Fusionne 3 fois des modules',s:'fuseN',n:3,g:{cr:3500,tok:3}}];
const weekKey=()=>{const d=new Date(), t=new Date(d.getFullYear(),0,1); return d.getFullYear()+'-w'+Math.ceil(((d-t)/864e5+t.getDay()+1)/7);};
function questsEnsure(){
  const dk=dayKey(), wk=weekKey();
  if(!S.dq||S.dq.k!==dk) S.dq={k:dk,base:Object.assign({},S.stats),ids:DQ.map(q=>q.id).sort(()=>Math.random()-.5).slice(0,3),cl:{}};
  if(!S.wq||S.wq.k!==wk) S.wq={k:wk,base:Object.assign({},S.stats),ids:WQ.map(q=>q.id).sort(()=>Math.random()-.5).slice(0,2),cl:{}};
}
const qProg=(box,q)=>Math.max(0,(S.stats[q.s]||0)-((box.base&&box.base[q.s])||0));
const qRew=q=>{const c=Math.round((q.g.cr||0)*(1+.1*S.lvl)/10)*10; return {cr:c,xp:q.g.xp||rxp(c),tok:q.g.tok||0,nitro:q.g.nitro||0};};
function questReady(){ questsEnsure(); return [['dq',DQ],['wq',WQ]].some(([k,L])=>S[k].ids.some(id=>{const q=L.find(x=>x.id===id); return !S[k].cl[id]&&qProg(S[k],q)>=q.n;})); }
const MISS2=[
 ['m17','Course','Gagne 15 épreuves',s=>[s.stats.wins,15],{cr:3000,tok:2}],['m18','Course','Gagne 40 épreuves',s=>[s.stats.wins,40],{cr:12000,tok:5}],
 ['m19','Course','Dispute 10 épreuves',s=>[s.stats.races,10],{cr:1500}],['m20','Course','Gagne un drag',s=>[s.stats.w_drag||0,1],{cr:800}],
 ['m21','Course','Gagne 3 courses sur le circuit de Spa',s=>[s.stats.w_circuit||0,3],{cr:2500,tok:1}],['m22','Course','Gagne un rallye',s=>[s.stats.w_rallye||0,1],{cr:900}],
 ['m23','Course','Gagne un drift',s=>[s.stats.w_drift||0,1],{cr:1200}],['m24','Course','Gagne une manche d’endurance',s=>[s.stats.w_endurance||0,1],{cr:1800}],
 ['m25','Course','Utilise 10 bouteilles de nitro',s=>[s.stats.nitroN||0,10],{cr:1000,nitro:2}],
 ['m26','Cartes','Ouvre 5 paquets',s=>[s.stats.packs||0,5],{tok:3}],['m27','Cartes','Ouvre 25 paquets',s=>[s.stats.packs||0,25],{cr:6000,tok:8}],
 ['m28','Cartes','Possède 15 modules',s=>[s.mods.length,15],{cr:1200}],['m29','Cartes','Obtiens un module brillant',s=>[s.stats.shiny||0,1],{tok:4}],
 ['m30','Cartes','Obtiens un module Légendaire ou mieux',s=>[(s.stats.best||0)>=4?1:0,1],{cr:8000,tok:10}],
 ['m31','Cartes','Fusionne 3 fois des modules',s=>[s.stats.fuseN||0,3],{cr:2500,tok:2}],['m32','Cartes','Recycle 20 modules',s=>[s.stats.recyN||0,20],{cr:1500}],
 ['m33','Cartes','Monte 6 modules sur une même voiture',s=>[s.stats.eq||0,6],{cr:3500,tok:3}],['m34','Cartes','Équipe les 11 emplacements d’une voiture',s=>[s.stats.eq||0,11],{cr:15000,tok:10}],
 ['m46','Cartes','Remplis 20 cases de l’album',s=>[Object.values(s.alb||{}).reduce((t,b)=>{let c=0; while(b){c+=b&1; b>>=1;} return t+c;},0),20],{cr:3000,tok:3}],
 ['m35','Collection','Possède 5 voitures',s=>[s.cars.length,5],{cr:3000}],['m36','Collection','Possède 10 voitures',s=>[s.cars.length,10],{cr:15000,tok:5}],
 ['m37','Collection','Possède une Supercar',s=>[s.cars.some(c=>M[c.mid].t>=5)?1:0,1],{cr:25000,tok:5}],
 ['m38','Progression','Atteins le niveau 5',s=>[s.lvl,5],{cr:2500}],['m39','Progression','Atteins le niveau 20',s=>[s.lvl,20],{cr:40000,tok:10}],
 ['m47','Progression','Joue 3 jours de suite',s=>[s.streak||0,3],{cr:1500,tok:2}],['m48','Progression','Joue 7 jours de suite',s=>[s.streak||0,7],{cr:5000,tok:5}],
 ['m40','Économie','Gagne 50 000 cr en course',s=>[s.stats.earned||0,50000],{cr:5000}],['m41','Économie','Gagne 500 000 cr en course',s=>[s.stats.earned||0,500000],{cr:40000,tok:10}],
 ['m42','Économie','Répare 5 fois',s=>[s.stats.repN||0,5],{cr:600}],['m43','Économie','Vends une voiture',s=>[s.stats.sellN||0,1],{cr:500}],
 ['m44','Économie','Construis le Banc de puissance',s=>[s.bat.banc||0,1],{cr:3000}],['m45','Économie','Achète 3 pièces au marché',s=>[s.stats.shopN||0,3],{cr:1500}],
 ['m51','Économie','Garde 100 000 cr en banque',s=>[s.cr,100000],{tok:5}],['m50','Économie','Podiums : niveau Or',s=>[s.pod.tier,5],{cr:50000,tok:10}]];
MISS2.forEach(m=>MISSIONS.push({id:m[0],t:m[2],p:m[3],g:m[4]}));
const MCAT={m1:'Débuts',m2:'Débuts',m3:'Débuts',m4:'Débuts',m6:'Débuts',m11:'Débuts',m5:'Course',m7:'Course',m16:'Course',m8:'Collection',m10:'Collection',m9:'Progression',m12:'Progression',m13:'Cartes',m14:'Cartes',m15:'Cartes'};
MISS2.forEach(m=>MCAT[m[0]]=m[1]);
function vMissions(){
  questsEnsure();
  const can=S.daily!==dayKey(), dr=dailyReward();
  const qRow=(box,key,L,id)=>{ const q=L.find(x=>x.id===id), a=Math.min(qProg(box,q),q.n), done=a>=q.n, got=box.cl[id], g=qRew(q);
    return `<div class="row ${got?'done locked':''}"><span class="grow"><span class="ttl">${q.t}</span><br><span class="sub">Récompense : ${gText(g)}</span>${got?'':`<div class="prog"><i style="width:${a/q.n*100}%"></i></div>`}</span>
      ${got?'<span class="sub">Terminé</span>':done?`<button class="btn sm good" data-a="qclaim" data-k="${key}" data-id="${id}">Récupérer</button>`:`<span class="num">${fmt(a)} / ${fmt(q.n)}</span>`}</div>`; };
  const mRow=m=>{ const [a,b]=m.p(S), done=a>=b, got=S.claimed[m.id];
    return `<div class="row ${got?'done locked':''}"><span class="grow"><span class="ttl">${m.t}</span><br><span class="sub">Récompense : ${gText(m.g)}</span>
      ${got?'':`<div class="prog"><i style="width:${clamp(a/b*100,0,100)}%"></i></div>`}</span>
      ${got?'<span class="sub">Terminée</span>':done?`<button class="btn sm good" data-a="claim" data-id="${m.id}">Récupérer</button>`:`<span class="num">${fmt(Math.min(a,b))} / ${fmt(b)}</span>`}</div>`; };
  const cats=['Débuts','Course','Cartes','Collection','Économie','Progression'];
  const left=MISSIONS.filter(m=>!S.claimed[m.id]).length;
  return `<div class="head"><h2>Missions</h2><p>${left} objectif${left>1?'s':''} restant${left>1?'s':''}</p></div>
  ${claimBar()}<button class="row" data-a="pilot"><span class="ico">🏅</span><span class="grow"><span class="ttl">Carte pilote</span><br><span class="sub">Titre, succès et arbre de compétences${skAvail()>0?`. ${skAvail()} point${skAvail()>1?'s':''} à dépenser`:''}${bdgReady()?`. ${bdgReady()} succès à récupérer`:''}</span></span><span class="gain">Ouvrir</span></button>
  <div class="row ${can?'':'locked'}"><span class="ico">🎁</span><span class="grow"><span class="ttl">Récompense du jour</span><br><span class="sub">${cr(dr.cr)}, ${dr.xp} XP et ${dr.tok} 🎟. Série en cours : ${S.streak||0} jour${(S.streak||0)>1?'s':''}. Un bonus tous les 7 jours.</span></span>${can?`<button class="btn sm good" data-a="daily">Récupérer</button>`:'<span class="sub">Reviens demain</span>'}</div>
  <div class="sec"><h3>Défis du jour</h3>${S.dq.ids.map(id=>qRow(S.dq,'dq',DQ,id)).join('')}</div>
  <div class="sec"><h3>Défis de la semaine</h3>${S.wq.ids.map(id=>qRow(S.wq,'wq',WQ,id)).join('')}</div>
  ${cats.map(ct=>{ const ms=MISSIONS.filter(m=>(MCAT[m.id]||'Débuts')===ct).sort((a,b)=>(S.claimed[a.id]?1:0)-(S.claimed[b.id]?1:0)); return ms.length?`<div class="sec"><h3>${ct}</h3>${ms.map(mRow).join('')}</div>`:''; }).join('')}`;
}

/* ---- marché : voitures, pièces, services ---- */
let mTab='cars';
const SHOP_P=[100,400,1700,9000];
function shopMod(r){
  const T=MODT[rint(0,MODT.length-1)], m={u:0,t:T[0],r,q:Math.round(rnd(.85,1.15)*100)/100};
  if(r>=2){const ks=['ch','nm','adh','fre','man','fia','sty','kg']; m.s=[ks[rint(0,ks.length-1)],Math.round(rnd(.25,.55)*100)/100];}
  return m;
}
function shopRoll(){
  const items=[], W=[55,28,13,4];
  for(let i=0;i<6;i++){ let x=Math.random()*100, r=0; for(;r<3;r++){x-=W[r]; if(x<0) break;} r=Math.min(r,3); const m=shopMod(r); items.push({m,p:Math.round(SHOP_P[r]*(1-.05*pk('shopd'))*(.9+m.q*.12)/10)*10}); }
  items.sort((a,b)=>b.m.r-a.m.r); S.shop={k:dayKey(),items};
}
const fleetRepair=()=>S.cars.reduce((t,c)=>t+Math.ceil((100-c.etat)*repUnit(c)*.85),0);
function vMarche(){
  if(!S.offres.length) newOffres(); if(!S.shop||S.shop.k!==dayKey()) shopRoll();
  const tabs=`<div class="subtabs">${[['cars','🚗 Voitures'],['parts','🔩 Pièces'],['serv','🛠️ Services']].map(([id,n])=>`<button data-a="mtab" data-id="${id}" ${mTab===id?'aria-current="true"':''}>${n}</button>`).join('')}</div>`;
  let body='';
  if(mTab==='cars'){
    const refresh=100*S.bat.casse, cl=S.bat.concession, neuves=cl?CARS.filter(m=>m.t<=cl+1):[];
    body=`<h3>Casse automobile</h3><p class="note">Des épaves à retaper. Les offres changent toutes les 3 épreuves.</p>
    <div class="grid">${S.offres.map((o,i)=>`<div>${cardHTML({mid:o.mid,etat:o.etat,lvl:1,up:{}},{tag:'div'})}
       <button class="btn wide sm" style="margin-top:6px" data-a="buy" data-id="${i}" ${S.cr<o.prix?'disabled':''}>Acheter ${cr(o.prix)}</button></div>`).join('')}</div>
    <button class="btn alt sm" style="margin-top:12px" data-a="refresh" ${S.cr<refresh?'disabled':''}>Voir d’autres épaves, ${cr(refresh)}</button>
    <div class="sec"><h3>Concession</h3>${cl?`<p class="note">Voitures neuves, 100 % d’état.</p><div class="grid">${neuves.map(m=>`<div>${cardHTML({mid:m.id,etat:100,lvl:1,up:{}},{tag:'div'})}
       <button class="btn wide sm" style="margin-top:6px" data-a="buynew" data-id="${m.id}" ${S.cr<m.val?'disabled':''}>Acheter ${cr(m.val)}</button></div>`).join('')}</div>`
       :`<p class="note">Construis la concession dans Atelier › Base pour acheter des voitures neuves.</p>`}</div>`;
  } else if(mTab==='parts'){
    body=`<h3>Boutique de pièces</h3><p class="note">Un stock de modules qui change chaque jour. Pas de hasard : tu vois ce que tu achètes. Pas de Légendaire ici, il faut les gagner dans les paquets.</p>
    <div class="mods">${S.shop.items.map((it,i)=>modHTML(it.m,`<button class="btn sm" data-a="shopbuy" data-id="${i}" ${S.cr<it.p?'disabled':''}>Acheter, ${cr(it.p)}</button>`)).join('')||'<p class="note">Stock épuisé.</p>'}</div>
    <button class="btn alt sm" style="margin-top:12px" data-a="shoproll" ${S.cr<400?'disabled':''}>Renouveler le stock, ${cr(400)}</button>
    <div class="sec"><h3>Atelier de fabrication</h3><p class="note">La ferraille des modules recyclés sert à fabriquer le module de ton choix.</p>
    <div class="row"><span class="ico">♻️</span><span class="grow"><span class="ttl">Ferraille : ${fmt(S.scrap)}</span><br><span class="sub">Fabrication à partir de ${craftCost(0)} ferraille. L’entrepôt la rend moins chère.</span></span><button class="btn sm" data-a="craftopen">Fabriquer</button></div></div>`;
  } else {
    const fr=fleetRepair(), need=S.cars.some(c=>c.etat<100);
    body=`<h3>Services</h3>
    <div class="row"><span class="ico">⚡</span><span class="grow"><span class="ttl">Bouteilles de nitro</span><br><span class="sub">${String(NITRO_DUREE).replace('.',',')} s de poussée. En stock : ${S.nitro}</span></span>
      <span class="pkb"><button class="btn sm" data-a="buynitro" data-id="1" ${S.cr<NITRO_PRIX?'disabled':''}>×1 · ${cr(NITRO_PRIX)}</button><button class="btn sm alt" data-a="buynitro" data-id="5" ${S.cr<650?'disabled':''}>×5 · ${cr(650)}</button><button class="btn sm alt" data-a="buynitro" data-id="12" ${S.cr<1500?'disabled':''}>×12 · ${cr(1500)}</button></span></div>
    <div class="row"><span class="ico">🔧</span><span class="grow"><span class="ttl">Révision de tout le garage</span><br><span class="sub">Remet toutes tes voitures à 100 %, 15 % moins cher que séparément.</span></span><button class="btn sm" data-a="fleetrep" ${!need||S.cr<fr?'disabled':''}>${need?cr(fr):'Rien à faire'}</button></div>
    <div class="row"><span class="ico">🛡️</span><span class="grow"><span class="ttl">Entretien préventif</span><br><span class="sub">Usure réduite de 70 % sur les 3 prochaines épreuves.${S.ins>0?` Actif : ${S.ins} restante${S.ins>1?'s':''}.`:''}</span></span><button class="btn sm" data-a="insure" ${S.cr<900?'disabled':''}>${cr(900)}</button></div>
    <div class="row"><span class="ico">🎓</span><span class="grow"><span class="ttl">Coach de pilotage</span><br><span class="sub">+50 % d’expérience sur les 3 prochaines épreuves.${S.xpb>0?` Actif : ${S.xpb} restante${S.xpb>1?'s':''}.`:''}</span></span><button class="btn sm" data-a="coach" ${S.cr<1200?'disabled':''}>${cr(1200)}</button></div>
    <div class="sec"><h3>Reprise</h3><p class="note">Revends tes modules en trop. Les modules montés et les brillants sont gardés.</p>
    <div class="row"><span class="ico">💱</span><span class="grow"><span class="ttl">Tous les Communs et Peu communs non montés</span><br><span class="sub">${S.mods.filter(m=>m.r<=1&&!m.sh&&m.un==null&&!eqCar(m.u)).length} modules concernés, payés en crédits.</span></span><button class="btn sm" data-a="sellmods" ${S.mods.some(m=>m.r<=1&&!m.sh&&m.un==null&&!eqCar(m.u))?'':'disabled'}>Vendre</button></div></div>`;
  }
  return `<div class="head"><h2>Marché</h2><p>${cr(S.cr)}</p></div>${tabs}${body}`;
}

/* ======================================================================
   v0.10 : atelier de tuning, icônes 3D, ouverture de paquet, pièces visibles, tout récupérer
   ====================================================================== */

/* ---- icônes 3D (SVG en couches empilées en profondeur, teintées par la rareté) ---- */
const ICO_SPRITE=`<svg id="icospr" width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<linearGradient id="gm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f1f5ff"/><stop offset=".42" stop-color="#9aa6c6"/><stop offset="1" stop-color="#3b4362"/></linearGradient>
<linearGradient id="gd" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#58628a"/><stop offset="1" stop-color="#171a2c"/></linearGradient>
<radialGradient id="gk" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#3a4262"/><stop offset="1" stop-color="#0b0d18"/></radialGradient></defs>
<symbol id="ic-moteur" viewBox="0 0 64 64"><rect x="8" y="28" width="42" height="24" rx="4" fill="url(#gm)"/><rect x="10" y="12" width="38" height="4" rx="2" fill="url(#gm)"/>
<g fill="url(#gd)" stroke="var(--rc)" stroke-width="1.8"><rect x="12" y="16" width="9" height="13" rx="2"/><rect x="25" y="16" width="9" height="13" rx="2"/><rect x="38" y="16" width="9" height="13" rx="2"/></g>
<circle cx="54" cy="40" r="7" fill="url(#gd)" stroke="var(--rc)" stroke-width="2"/><circle cx="54" cy="40" r="2.4" fill="var(--rc)"/><path d="M12 40h34" stroke="var(--rc)" stroke-width="2.4" stroke-linecap="round"/><rect x="12" y="45" width="30" height="3" rx="1.5" fill="#0b0d16" opacity=".45"/></symbol>
<symbol id="ic-turbo" viewBox="0 0 64 64"><path d="M44 22 L58 10 L63 21 L50 31Z" fill="url(#gm)"/><circle cx="30" cy="34" r="23" fill="url(#gm)"/><circle cx="30" cy="34" r="18" fill="url(#gk)" stroke="var(--rc)" stroke-width="2"/>
<g stroke="var(--rc)" stroke-width="3.2" stroke-linecap="round" fill="none"><path id="tb" d="M30 34 q9 -1 11 -12"/><path d="M30 34 q9 -1 11 -12" transform="rotate(60 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(120 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(180 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(240 30 34)"/><path d="M30 34 q9 -1 11 -12" transform="rotate(300 30 34)"/></g><circle cx="30" cy="34" r="4" fill="url(#gm)"/></symbol>
<symbol id="ic-echap" viewBox="0 0 64 64"><path d="M4 46 H30 Q38 46 38 38 V34" fill="none" stroke="#56607f" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 44 H30 Q36 44 36 38 V34" fill="none" stroke="#b9c4e2" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M36 22 L56 12 L60 52 L36 44Z" fill="url(#gd)" stroke="var(--rc)" stroke-width="2.4" stroke-linejoin="round"/><ellipse cx="57" cy="32" rx="3.6" ry="14" fill="#06070e" stroke="var(--rc)" stroke-width="1.6"/><path d="M60 24 q4 8 0 16 q8 -8 0 -16z" fill="var(--rc)" opacity=".9"/></symbol>
<symbol id="ic-pneus" viewBox="0 0 64 64"><circle cx="32" cy="32" r="26" fill="#0b0d16" stroke="#3b4260" stroke-width="3"/><circle cx="32" cy="32" r="26" fill="none" stroke="#6a7396" stroke-width="3.4" stroke-dasharray="5 3.2"/>
<circle cx="32" cy="32" r="19" fill="none" stroke="var(--rc)" stroke-width="2.2"/><circle cx="32" cy="32" r="14" fill="url(#gm)"/><circle cx="32" cy="32" r="5" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.6"/><g fill="#0b0d16"><circle cx="32" cy="21" r="1.8"/><circle cx="42" cy="28" r="1.8"/><circle cx="38" cy="40" r="1.8"/><circle cx="26" cy="40" r="1.8"/><circle cx="22" cy="28" r="1.8"/></g></symbol>
<symbol id="ic-freins" viewBox="0 0 64 64"><circle cx="30" cy="34" r="24" fill="url(#gm)"/><circle cx="30" cy="34" r="10" fill="url(#gd)"/><circle cx="30" cy="34" r="3.5" fill="#0b0d16"/><g fill="#0b0d16"><circle cx="30" cy="19" r="2.2"/><circle cx="40.6" cy="23.4" r="2.2"/><circle cx="45" cy="34" r="2.2"/><circle cx="40.6" cy="44.6" r="2.2"/><circle cx="30" cy="49" r="2.2"/><circle cx="19.4" cy="44.6" r="2.2"/><circle cx="15" cy="34" r="2.2"/><circle cx="19.4" cy="23.4" r="2.2"/></g>
<path d="M42 9 a26 26 0 0 1 14 22 l-10 2 a16 16 0 0 0 -7 -13z" fill="var(--rc)" stroke="#06070e" stroke-width="1.2"/><rect x="47" y="14" width="6" height="3" rx="1.5" fill="#fff" opacity=".5" transform="rotate(35 50 15)"/></symbol>
<symbol id="ic-susp" viewBox="0 0 64 64"><rect x="28" y="6" width="8" height="52" rx="3" fill="url(#gm)"/><rect x="24" y="10" width="16" height="18" rx="4" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.8"/>
<path d="M17 28 L47 33 L17 38 L47 43 L17 48 L47 53" fill="none" stroke="#06070e" stroke-width="7" stroke-linejoin="round" stroke-linecap="round" opacity=".5"/><path d="M17 28 L47 33 L17 38 L47 43 L17 48 L47 53" fill="none" stroke="var(--rc)" stroke-width="4.4" stroke-linejoin="round" stroke-linecap="round"/>
<circle cx="32" cy="8" r="5.5" fill="url(#gm)" stroke="var(--rc)" stroke-width="1.8"/><circle cx="32" cy="57" r="5.5" fill="url(#gm)" stroke="var(--rc)" stroke-width="1.8"/></symbol>
<symbol id="ic-chassis" viewBox="0 0 64 64"><g fill="none" stroke="#06070e" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" opacity=".5"><path d="M10 56 V32 L22 12 H42 L54 32 V56 M10 32 H54 M10 56 L54 32 M54 56 L10 32"/></g>
<g fill="none" stroke="#aeb9d8" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10 56 V32 L22 12 H42 L54 32 V56 M10 32 H54 M22 12 L10 32 M42 12 L54 32 M10 56 L54 32 M54 56 L10 32"/></g>
<g fill="url(#gk)" stroke="var(--rc)" stroke-width="2.2"><circle cx="10" cy="32" r="4"/><circle cx="54" cy="32" r="4"/><circle cx="22" cy="12" r="4"/><circle cx="42" cy="12" r="4"/><circle cx="32" cy="32" r="4"/></g></symbol>
<symbol id="ic-aero" viewBox="0 0 64 64"><rect x="24" y="38" width="5" height="18" rx="2" fill="url(#gd)"/><rect x="36" y="38" width="5" height="18" rx="2" fill="url(#gd)"/><rect x="18" y="54" width="28" height="4" rx="2" fill="url(#gd)"/>
<path d="M10 33 H54 L58 38 H6Z" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.6" stroke-linejoin="round"/><path d="M8 22 H56 L61 31 H3Z" fill="url(#gm)" stroke="var(--rc)" stroke-width="1.8" stroke-linejoin="round"/>
<rect x="3" y="12" width="6" height="28" rx="2" fill="var(--rc)"/><rect x="55" y="12" width="6" height="28" rx="2" fill="var(--rc)"/><rect x="12" y="25" width="40" height="2.4" rx="1.2" fill="#fff" opacity=".6"/></symbol>
<symbol id="ic-nitro" viewBox="0 0 64 64"><rect x="26" y="10" width="12" height="12" rx="3" fill="url(#gd)"/><circle cx="32" cy="8" r="5.6" fill="var(--rc)" stroke="#06070e" stroke-width="1.4"/><path d="M38 8 q14 -2 16 12" fill="none" stroke="var(--rc)" stroke-width="3" stroke-linecap="round"/>
<rect x="18" y="20" width="28" height="40" rx="10" fill="url(#gm)"/><rect x="18" y="31" width="28" height="15" fill="var(--rc)"/><rect x="21" y="24" width="4" height="32" rx="2" fill="#fff" opacity=".35"/><path d="M35 32 L27 41 H32 L29 49 L38 39 H33Z" fill="#fff" stroke="#06070e" stroke-width="1" stroke-linejoin="round"/></symbol>
<symbol id="ic-jantes" viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="url(#gk)" stroke="var(--rc)" stroke-width="3"/><circle cx="32" cy="32" r="24" fill="none" stroke="#b9c4e2" stroke-width="1.6"/>
<g stroke="#06070e" stroke-width="9" stroke-linecap="round" opacity=".5"><path d="M32 32 V9"/><path d="M32 32 V9" transform="rotate(72 32 32)"/><path d="M32 32 V9" transform="rotate(144 32 32)"/><path d="M32 32 V9" transform="rotate(216 32 32)"/><path d="M32 32 V9" transform="rotate(288 32 32)"/></g>
<g stroke="#d7dff5" stroke-width="6" stroke-linecap="round"><path d="M32 32 V10"/><path d="M32 32 V10" transform="rotate(72 32 32)"/><path d="M32 32 V10" transform="rotate(144 32 32)"/><path d="M32 32 V10" transform="rotate(216 32 32)"/><path d="M32 32 V10" transform="rotate(288 32 32)"/></g>
<circle cx="32" cy="32" r="8" fill="url(#gm)" stroke="var(--rc)" stroke-width="2"/><circle cx="32" cy="32" r="2.6" fill="#0b0d16"/></symbol>
<symbol id="ic-peinture" viewBox="0 0 64 64"><g fill="var(--rc)" opacity=".85"><circle cx="9" cy="14" r="2.6"/><circle cx="15" cy="9" r="2"/><circle cx="6" cy="22" r="2"/><circle cx="14" cy="19" r="3.2"/><circle cx="20" cy="13" r="1.8"/><circle cx="10" cy="28" r="1.6"/><circle cx="19" cy="24" r="2.2"/></g>
<rect x="26" y="8" width="7" height="8" rx="2" fill="url(#gd)"/><rect x="25" y="14" width="22" height="12" rx="3" fill="url(#gd)" stroke="var(--rc)" stroke-width="1.8"/><rect x="25" y="25" width="22" height="34" rx="6" fill="var(--rc)"/><rect x="25" y="25" width="22" height="34" rx="6" fill="url(#gd)" opacity=".28"/>
<rect x="29" y="28" width="4.5" height="28" rx="2.2" fill="#fff" opacity=".42"/><circle cx="38" cy="42" r="6" fill="#fff" opacity=".85"/><path d="M38 37 q4 5 0 10 q-4 -5 0 -10z" fill="var(--rc)"/></symbol>
</svg>`;
function ico(id,rc,sz,live){
  const u=`<svg viewBox="0 0 64 64"><use href="#ic-${id}"/></svg>`;
  return `<span class="i3${live?' live':''}" style="--rc:${rc};--s:${sz||48}px"><i class="fl"></i><span class="st"><b class="ly l3">${u}</b><b class="ly l2">${u}</b><b class="ly l1">${u}</b></span></span>`;
}
(function(){ if(!document.getElementById('icospr')) document.body.insertAdjacentHTML('afterbegin',ICO_SPRITE); })();

/* ---- ce que chaque module change visuellement ---- */
const VIS={mo1:'',tu1:'Entrée d’air sur le capot',tu2:'Double entrée d’air',tu3:'Compresseur sur le capot',ec1:'Sortie d’échappement',ec2:'Sorties d’échappement',ec3:'Sorties d’échappement',
  su1:'Caisse abaissée',su2:'Caisse légèrement abaissée',su3:'Caisse surélevée, garde au sol rallye',ja1:'Jantes forgées',ja2:'Grosses jantes',ja3:'Jantes XXL néon',
  ae1:'Lame avant',ae2:'Aileron arrière',ae3:'Bas de caisse larges',ch1:'Arceau et pare-buffle',ch2:'Capot carbone',ch3:'Ailes élargies',
  ni1:'Bouteille visible, flamme teintée',ni2:'Bouteille visible, flamme teintée',ni3:'Bouteille visible, flamme teintée',pe1:'Peinture nacrée aux couleurs de la rareté',pe2:'Teinte mate et néon sous la caisse',pe3:'Bandes de course'};
const visOf=m=>'';

/* ---- apparence : suspension, châssis, jantes plus grandes, néons ---- */
/* les modules ne changent plus l'apparence : seulement les statistiques */
carLook=function(c){ if(!c) return {}; if(c.lk) return c.lk; const L={}; if(c.sh) L.shiny=1; return L; };
rndLook=function(lv){ return {}; };
function addLook(g,D,look,wheels){
  if(!look) return;
  const j=look.jantes, s=look.susp, ch=look.chassis, pe=look.peinture, ni=look.nitro;
  const par=wheels[0]&&wheels[0].parent, glb=!!par&&par!==g, ps=glb?(par.scale.y||1):1;
  let ws=j?({ja1:1.05,ja2:1.17,ja3:1.3}[j.t]||1)+.012*j.r:1; if(s&&s.t==='su3') ws*=1.08;
  if(ws!==1) wheels.forEach(w=>{ w.scale.multiplyScalar(ws); w.position.y+=D.wr*(ws-1)/ps; });
  addLook0(g,D,look,wheels);
  const L=D.x1-D.x0, mx=(D.x0+D.x1)/2, dark=new THREE.MeshLambertMaterial({color:0x14151b}), neon=r=>new THREE.MeshBasicMaterial({color:new THREE.Color(RCOL[r])});
  const box=(w,h,d,mat,x,y,z)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat); m.position.set(x,y,z); g.add(m); return m;};
  if(ch){
    if(ch.t==='ch1'){ [1,-1].forEach(sd=>box(L*.34,.04,.04,ch.r>=3?neon(ch.r):dark,mx-.04*L,D.H+.05,sd*D.W*.3)); box(.04,.04,D.W*.6,dark,mx+.13*L,D.H+.05,0); box(.04,.04,D.W*.6,dark,mx-.21*L,D.H+.05,0);
      box(.06,.12,D.W*.84,ch.r>=2?neon(ch.r):dark,D.x1+.05,.34,0); [1,-1].forEach(sd=>box(.05,.22,.05,dark,D.x1+.04,.3,sd*D.W*.3)); }
    else if(ch.t==='ch2'){ box(L*.28,.014,D.W*.42,dark,D.x1-.18*L,D.hood+.014,0); if(ch.r>=2) [1,-1].forEach(sd=>box(L*.28,.016,.02,neon(ch.r),D.x1-.18*L,D.hood+.018,sd*D.W*.21)); box(.3,.014,D.W*.9,dark,D.x0+.1*L,D.deck+.012,0); }
    else wheels.forEach(w=>{ const sg=w.position.z>=0?1:-1, rr=D.wr*ws; box(rr*2.15,.08,.12,dark,w.position.x,rr*1.95+.02,sg*(D.W/2+.03)); if(ch.r>=2) box(rr*2.15,.02,.02,neon(ch.r),w.position.x,rr*1.95-.03,sg*(D.W/2+.09)); });
  }
  if(pe&&pe.t==='pe3'){ const mt=neon(pe.r), wm=new THREE.MeshBasicMaterial({color:0xf4f6ff}); [[D.x1-.2*L,D.hood+.016],[D.x0+.16*L,D.deck+.016]].forEach(q=>{ box(L*.3,.012,.1*D.W,wm,q[0],q[1],-.14*D.W); box(L*.3,.012,.1*D.W,mt,q[0],q[1],.0); box(L*.3,.012,.1*D.W,wm,q[0],q[1],.14*D.W); }); }
  if(ni){ const bm=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,.5,10),neon(ni.r)); bm.rotation.x=Math.PI/2; bm.position.set(D.x0+.2*L,D.deck+.09,.0); g.add(bm); box(.1,.04,.22,dark,D.x0+.2*L,D.deck+.03,0); }
  /* assiette : abaisse ou surélève la caisse, les roues restent au sol */
  let dy=0; if(s) dy={su1:-(.055+.012*s.r),su2:-(.03+.006*s.r),su3:.07+.014*s.r}[s.t]||0; if(glb) dy=Math.max(dy,-.09);
  if(dy){ g.children.slice().forEach(o=>{ if(wheels.includes(o)) return; if(o.geometry&&o.geometry.type==='PlaneGeometry'&&o.material&&o.material.blending===THREE.AdditiveBlending) return; o.position.y+=dy; });
    if(glb) wheels.forEach(w=>{ w.position.y-=dy/ps; }); }
  if(pe&&pe.t==='pe2'){ const ug=new THREE.Mesh(new THREE.PlaneGeometry(L*.96,D.W*1.2),new THREE.MeshBasicMaterial({color:new THREE.Color(RCOL[pe.r]),transparent:true,opacity:.55,blending:THREE.AdditiveBlending,depthWrite:false})); ug.rotation.x=-Math.PI/2; ug.position.set(mx,.045,0); g.add(ug); }
}

/* ---- modules : carte avec icône 3D ---- */
function modHTML(m,act){
  const sl=SLOTS.find(s=>s[0]===MODI[m.t][1]), fx=modFx(m), on=eqCar(m.u), rc=RAR[m.r].c, vs=visOf(m);
  return `<div class="mod mod3 ${m.sh?'shiny':''} ${m.un!=null?'uniq':''}" style="--rc:${rc}">
    <div class="m3h">${ico(sl[0],rc,50,m.r>=3)}<div class="m3t"><span class="rar">${RAR[m.r].n}${m.sh?' ✨':''}</span><div class="mod-name">${modName(m)}</div><span class="slotn">${sl[1]}${m.un!=null?`, unique n° ${String(m.sn).padStart(3,'0')}`:''}</span></div></div>
    ${vs?`<div class="vis">🔧 ${vs}</div>`:''}
    <div class="mod-fx">${Object.keys(fx).map(k=>`<span class="${fx[k]<0?'neg':''}">${fxText(k,fx[k])}</span>`).join('')}</div>
    ${m.un!=null?`<div class="mod-eq">${UNIQ[m.un].d}</div>`:''}${on?`<div class="mod-eq">Monté sur ${M[on.mid].nom}</div>`:''}${act||''}</div>`;
}
const tilesHTML=c=>`<div class="tiles">${SLOTS.map(sl=>{const mm=modOf((c.mods||{})[sl[0]]), rc=mm?RAR[mm.r].c:'#4a5280';
  return `<button class="tile ${mm?'on':''}" style="--rc:${rc}" data-a="modslot" data-id="${sl[0]}">${ico(sl[0],rc,46)}<b>${sl[1]}</b><small>${mm?modName(mm)+(mm.sh?' ✨':''):'Vide'}</small>${mm?`<i class="tr"></i>`:''}</button>`;}).join('')}</div>`;

/* ---- atelier de tuning ---- */
const dChip=(lab,a,b,unit,inv)=>{ const d=Math.round(b-a), good=inv?d<0:d>0; return `<span class="dc ${d===0?'':good?'up':'dn'}">${lab} <b>${fmt(Math.round(b))}${unit}</b>${d?` <i>${d>0?'+':'−'}${fmt(Math.abs(d))}</i>`:''}</span>`; };
function tuneCar(c,slot,pv){ const mods=Object.assign({},c.mods||{}); if(pv) mods[slot]=pv; return Object.assign({},c,{mods,lk:undefined}); }
function tvwHTML(c){
  const slot=sheet.slot, cur=c.mods&&c.mods[slot], pv=sheet.pv&&sheet.pv!==cur?sheet.pv:null, tc=tuneCar(c,slot,pv), s0=st(c), s1=st(tc), sl=SLOTS.find(x=>x[0]===slot);
  const rc=pv?RAR[modOf(pv).r].c:'#00e5ff';
  return `<div class="tvw ${sheet.flash?'flash':''}" style="--rc:${rc}"><div class="tvimg">${thArt(tc)}</div><div class="tscan"></div><div class="tcorner a"></div><div class="tcorner b"></div>
    <div class="tname"><b>${M[c.mid].nom}</b><span>${pv?'Essai : '+modName(modOf(pv)):'Équipement actuel'}</span></div>
    <div class="tdelta">${dChip('Puissance',s0.ch,s1.ch,' ch')}${dChip('Poids',s0.kg,s1.kg,' kg',1)}${dChip('Vmax',s0.vmax,s1.vmax,' km/h')}${dChip('Adhérence',s0.adh,s1.adh,'')}${dChip('Style',s0.sty,s1.sty,'')}</div></div>`;
}
function tbarHTML(c){
  const slot=sheet.slot, cur=c.mods&&c.mods[slot], pv=sheet.pv&&sheet.pv!==cur?modOf(sheet.pv):null, o=pv&&eqOther(pv.u,c);
  if(pv) return `<button class="btn ${o?'mag':'good'} grow2" data-a="tequip">${o?`Reprendre à ${M[o.mid].nom}`:'Monter'} : ${modName(pv)}</button><button class="btn alt" data-a="tprev" data-id="${pv.u}">Annuler</button>`;
  return `<button class="btn alt" data-a="car" data-id="${c.uid}">← Voiture</button><button class="btn good" data-a="eqbest" data-id="${c.uid}">⚡ Meilleures pièces</button>${cur?`<button class="btn danger" data-a="tunun">Retirer</button>`:''}`;
}
function tcardHTML(m,c){
  const cur=c.mods&&c.mods[sheet.slot], o=eqOther(m.u,c), rc=RAR[m.r].c, fx=modFx(m), keys=Object.keys(fx).slice(0,3), isCur=m.u===cur, sel=sheet.pv===m.u||(!sheet.pv&&isCur), vs=visOf(m);
  const cm=cur&&modOf(cur), d=cm?Math.round((modPow(m)/Math.max(.01,modPow(cm))-1)*100):null;
  return `<button class="tcard ${sel?'sel':''} ${isCur?'cur':''}" style="--rc:${rc}" data-a="tprev" data-id="${m.u}">${ico(MODI[m.t][1],rc,54,sel)}
    <span class="tc"><span class="tcn">${modName(m)}${m.sh?' ✨':''}</span><span class="tcr">${RAR[m.r].n}${m.un!=null?' · unique':''}</span>
      <span class="tcf">${keys.map(k=>`<i class="${fx[k]<0?'neg':''}">${fxText(k,fx[k])}</i>`).join('')}</span>${vs?`<span class="tcv">🔧 ${vs}</span>`:''}</span>
    <span class="tcs">${isCur?'<em class="on">Monté</em>':o?`<em class="oth">Sur ${M[o.mid].nom.split(' ')[0]}</em>`:d!=null?`<em class="${d>=0?'up':'dn'}">${d>=0?'▲ +':'▼ −'}${Math.abs(d)} %</em>`:''}</span></button>`;
}
function tuneSheets(X){
  const el=$('sheet');
  if(sheet.t==='modpick'){ sheet.t='tune'; sheet.pv=null; }
  if(sheet.t==='tune'){
    const c=car(sheet.uid); if(!c){closeSheet(); return true;} const slot=sheet.slot||SLOTS[0][0], cur=c.mods&&c.mods[slot];
    sheet.slot=slot;
    const list=S.mods.filter(m=>MODI[m.t][1]===slot).sort((a,b)=>(b.u===cur)-(a.u===cur)||(!!eqOther(a.u,c))-(!!eqOther(b.u,c))||b.r-a.r||modPow(b)-modPow(a));
    el.innerHTML=`${X}<h2>Atelier de tuning</h2><div id="tvw">${tvwHTML(c)}</div>
      <div class="tstrip">${SLOTS.map(sl=>{const mm=modOf((c.mods||{})[sl[0]]), rc=mm?RAR[mm.r].c:'#4a5280'; return `<button class="ts ${sl[0]===slot?'on':''} ${mm?'eq':''}" style="--rc:${rc}" data-a="tslot" data-id="${sl[0]}">${ico(sl[0],rc,36)}<small>${sl[1]}</small></button>`;}).join('')}</div>
      <div class="thead"><b>${SLOTS.find(s=>s[0]===slot)[1]}</b><span>${list.length} module${list.length>1?'s':''}</span></div>
      <div class="tlist">${list.length?list.slice(0,60).map(m=>tcardHTML(m,c)).join(''):`<div class="tempty">Aucun module de ce type. Ouvre des paquets pour en trouver.<button class="btn sm" data-a="tab" data-id="cartes">Aller aux paquets</button></div>`}</div>
      <div class="tbar" id="tbar">${tbarHTML(c)}</div>`;
    const on=el.querySelector('.ts.on'); if(on&&on.scrollIntoView) try{ on.scrollIntoView({block:'nearest',inline:'center'}); }catch(_){ }
    return true;
  }
  if(sheet.t==='open') return openStage(X);
  return false;
}
function tuneRefresh(){
  const c=car(sheet.uid), a=$('tvw'), b=$('tbar'); if(!c||!a||!b) return renderSheet();
  a.innerHTML=tvwHTML(c); b.innerHTML=tbarHTML(c);
  document.querySelectorAll('.tcard').forEach(e=>{ const u=+e.dataset.id, cur=c.mods&&c.mods[sheet.slot]; e.classList.toggle('sel',sheet.pv===u||(!sheet.pv&&u===cur)); });
}
Object.assign(ACT,{
  modslot(d){ openSheet({t:'tune',uid:sheet.uid,slot:d.id,pv:null}); },
  tslot(d){ sheet.slot=d.id; sheet.pv=null; sheet.flash=0; renderSheet(); },
  tprev(d){ const u=+d.id, c=car(sheet.uid); if(!c) return; sheet.pv=sheet.pv===u?null:u; sheet.flash=0; tuneRefresh(); const m=modOf(u); if(m&&sheet.pv) auTry(()=>auCard(Math.min(m.r,3),false,false)); },
  tequip(){ const c=car(sheet.uid), u=sheet.pv, m=modOf(u); if(!c||!m) return; if(eqOther(u,c)) return openSheet({t:'eqconf',uid:c.uid,slot:sheet.slot,u});
    equipMod(c,u,sheet.slot); sheet.pv=null; sheet.flash=1; bump('eqN'); save(); render(); renderSheet(); setTimeout(()=>{ if(sheet&&sheet.t==='tune') sheet.flash=0; },900); auTry(()=>auCard(m.r,m.sh,m.un!=null)); toast(`${modName(m)} montée`); },
  tunun(){ const c=car(sheet.uid); if(!c||!c.mods) return; delete c.mods[sheet.slot]; sheet.pv=null; save(); render(); renderSheet(); toast('Module retiré'); }
});

/* ---- ouverture d'un paquet : scène de révélation ---- */
const rcOf=m=>RAR[m.r].c;
function bigCard(m,anim){
  const sl=SLOTS.find(s=>s[0]===MODI[m.t][1]), fx=modFx(m), rc=rcOf(m), vs=visOf(m);
  return `<div class="bigc ${anim?'in':''} ${m.sh?'sh':''} ${m.un!=null?'un':''}" style="--rc:${rc}"><div class="foil"></div>
    <div class="bt"><span>${sl[1]}</span><span class="rar">${RAR[m.r].n}${m.sh?' ✨':''}</span></div>${ico(sl[0],rc,92,1)}
    <div class="bn">${modName(m)}</div>${m.un!=null?`<div class="bu">UNIQUE n° ${String(m.sn).padStart(3,'0')}</div>`:''}
    ${vs?`<div class="bv">🔧 ${vs}</div>`:''}<div class="bfx">${Object.keys(fx).slice(0,3).map(k=>`<span class="${fx[k]<0?'neg':''}">${fxText(k,fx[k])}</span>`).join('')}</div><div class="bq">Qualité ${Math.round(m.q*100)} %</div></div>`;
}
const backCard=(pk)=>{ const th=PKT[pk.id]||PKT.p1; return `<div class="bigc back in" style="--c1:${th.c1};--c2:${th.c2};--c3:${th.c3}"><div class="foil"></div><div class="bq0">R&amp;G</div><div class="bm">?</div><div class="bq1">${th.tag}</div></div>`; };
const burstHTML=m=>{ let s=''; const n=10+m.r*4; for(let k=0;k<n;k++){ const a=k/n*360+rint(-8,8), d=rint(90,190); s+=`<i style="--a:${a}deg;--d:${d}px;--w:${rint(4,9)}px"></i>`; } return `<div class="burst" style="--rc:${rcOf(m)}">${s}</div>`; };
function openStage(X){
  const n=sheet.cards.length, i=sheet.i, done=i>=n, pk=PACKS.find(p=>p.id===sheet.pk)||PACKS[0], el=$('sheet');
  const ms=sheet.cards.map(modOf).filter(Boolean);
  if(done){
    const best=ms.slice().sort((a,b)=>b.r-a.r||modPow(b)-modPow(a)), b0=best[0];
    el.innerHTML=`${X}<h2>${pk.nom}</h2><div class="orec" style="--rc:${b0?rcOf(b0):'#00e5ff'}"><div class="ohd">Résultat</div><p class="note" style="margin:0 0 10px">Meilleur tirage : <b style="color:${b0?rcOf(b0):'inherit'}">${b0?modName(b0):''}</b>${b0?` (${RAR[b0.r].n}${b0.sh?', brillant':''}${b0.un!=null?', unique':''})`:''}. Tout est dans ton inventaire.</p>
      <div class="rgrid">${best.map((m,k)=>{const sl=MODI[m.t][1]; return `<div class="rmini ${k===0?'top':''} ${m.sh?'sh':''}" style="--rc:${rcOf(m)};animation-delay:${k*70}ms">${ico(sl,rcOf(m),k===0?64:46,k===0)}<b>${modName(m)}</b><small>${RAR[m.r].n}${m.sh?' ✨':''}</small></div>`;}).join('')}</div></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="close">Fermer</button><button class="btn" data-a="pack" data-id="${pk.id}" data-k="cr" ${S.cr<pk.cr?'disabled':''}>Encore un, ${cr(pk.cr)}</button></div>
      <button class="btn good wide" style="margin-top:8px" data-a="eqcaropen">⚡ Équiper les meilleures pièces sur une voiture</button>`;
    return true;
  }
  const cur=i>0?modOf(sheet.cards[i-1]):null, anim=!!sheet.anim, rc=cur?rcOf(cur):'#00e5ff';
  const deck=Math.min(3,n-i-(cur?0:1));
  el.innerHTML=`${X}<h2>${pk.nom}</h2><div class="ocount"><b>${i}</b> / ${n}</div>
    <div class="ostage ${cur&&cur.r>=4&&anim?'shake':''}" data-a="reveal" style="--rc:${rc}"><div class="rays ${cur&&cur.r>=3?'on':''}"></div>
      ${Array.from({length:deck}).map((_,k)=>`<div class="dk" style="--k:${k+1}"></div>`).join('')}
      ${cur?bigCard(cur,anim):backCard(pk)}${anim&&cur&&cur.r>=2?burstHTML(cur):''}${anim&&cur&&cur.r>=3?`<div class="oflash"></div>`:''}
      <div class="ohint">${i===0?'Touche la carte pour révéler le premier module':n-i===1?'Touche pour le dernier module':'Touche pour le module suivant'}</div></div>
    <div class="otray">${sheet.cards.slice(0,Math.max(0,i-1)).map(modOf).filter(Boolean).map(m=>`<span class="mt" style="--rc:${rcOf(m)}">${ico(MODI[m.t][1],rcOf(m),32)}</span>`).join('')}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px"><button class="btn" data-a="reveal">${i===0?'Révéler':'Suivant'}</button><button class="btn alt" data-a="revealall">Tout révéler</button></div>`;
  return true;
}
Object.assign(ACT,{
  reveal(){ if(!sheet||sheet.t!=='open'||sheet.i>=sheet.cards.length) return; const m=modOf(sheet.cards[sheet.i]); sheet.i++; auCard(m.r,m.sh,m.un!=null); sheet.anim=1; renderSheet(); sheet.anim=0; if(sheet.i>=sheet.cards.length) $('sheet').scrollTop=0; },
  revealall(){ if(!sheet||sheet.t!=='open') return; let best=null; while(sheet.i<sheet.cards.length){const m=modOf(sheet.cards[sheet.i++]); if(!best||m.r>best.r) best=m;} if(best) auCard(best.r,best.sh,best.un!=null); sheet.anim=0; renderSheet(); }
});

/* ---- missions : tout récupérer ---- */
function claimList(){
  questsEnsure(); const L=[];
  if(S.daily!==dayKey()) L.push(['daily']);
  [['dq',DQ],['wq',WQ]].forEach(([k,T])=>S[k].ids.forEach(id=>{ const q=T.find(x=>x.id===id); if(q&&!S[k].cl[id]&&qProg(S[k],q)>=q.n) L.push([k,id]); }));
  MISSIONS.forEach(m=>{ if(!S.claimed[m.id]){ const p=m.p(S); if(p[0]>=p[1]) L.push(['m',m.id]); } });
  return L;
}
function claimTotal(L){
  const g={cr:0,tok:0,nitro:0,xp:0}, add=x=>{g.cr+=x.cr||0; g.tok+=x.tok||0; g.nitro+=x.nitro||0; g.xp+=x.xp||0;};
  L.forEach(([k,id])=>{ if(k==='daily') add(dailyReward()); else if(k==='m') add(MISSIONS.find(m=>m.id===id).g); else add(qRew((k==='dq'?DQ:WQ).find(x=>x.id===id))); });
  return g;
}
const claimBar=()=>{ const L=claimList(); if(!L.length) return `<div class="claimall off">Aucune récompense à récupérer pour l’instant.</div>`; const g=claimTotal(L);
  return `<button class="btn good wide claimall" data-a="claimall"><b>🎁 Tout récupérer</b><span>${L.length} récompense${L.length>1?'s':''} : ${gText(g)}</span></button>`; };
ACT.claimall=function(){
  const L=claimList(); if(!L.length) return toast('Rien à récupérer');
  const g=claimTotal(L);
  L.forEach(([k,id])=>{
    if(k==='daily'){ const y=new Date(Date.now()-864e5), yk=y.getFullYear()+'-'+(y.getMonth()+1)+'-'+y.getDate(); S.streak=S.daily===yk?(S.streak||0)+1:1; S.daily=dayKey(); }
    else if(k==='m') S.claimed[id]=1;
    else S[k].cl[id]=1;
  });
  giveG(g); toast('Tout récupéré : '+[g.cr?fmt(g.cr)+' cr':'',g.nitro?g.nitro+' nitro':'',g.xp?g.xp+' XP':'',g.tok?g.tok+' jeton'+(g.tok>1?'s':''):''].filter(Boolean).join(', ')); save(); render();
};

/* ======================================================================
   v0.11 : récompenses avec XP, audio de course, caméra, IA, pilote
   ====================================================================== */
const rxp=cr=>Math.max(8,Math.round(cr/20/5)*5);
MISSIONS.forEach(m=>{ if(m.g.xp==null) m.g.xp=rxp(m.g.cr||(m.g.tok||0)*300||200); });
/* coupure franche de la musique du menu quand on entre dans une épreuve */
function auCutMenu(){
  if(!AU.ok||!AU.ctx) return; const c=AU.ctx, t=c.currentTime;
  auTry(()=>{ AU.mus.gain.cancelScheduledValues(t); AU.mus.gain.setTargetAtTime(.0001,t,.025); AU.revIn.gain.cancelScheduledValues(t); AU.revIn.gain.setTargetAtTime(.0001,t,.025); });
  setTimeout(()=>{ if(!AU.ok) return; auTry(()=>{ auApplyVol(); AU.revIn.gain.setTargetAtTime(.5,AU.ctx.currentTime,.1); }); },450);
}
MOODS.silent={arp:[],oct:1,wave:'sine',av:0,pv:0,filt:19000,hat:false,pulse:false};

/* ---- IA : dépassements (adversaires et pilote automatique) ---- */
function aiPass(o,all,lane0,room){
  const t=RC.clock, look=10+o.v*.95*(room||1); let bl=null, bd=1e9;
  for(const q of all){ if(q===o||q.fin!=null) continue; const dp=dS(q.s,o.s); if(dp>.5&&dp<look&&Math.abs(q.d-o.d)<2.7&&(q.v<o.v+4||dp<7)&&dp<bd){bd=dp; bl=q;} }
  let ref=bl;
  if(!ref&&o.pRef){ const dp=dS(o.pRef.s,o.s); if(dp>-8&&dp<=.5&&t<o.pUntil) ref=o.pRef; else o.pRef=null; }
  if(!ref) return {lane:lane0,cap:1,brake:false};
  if(bl&&(o.pRef!==bl||t>o.pUntil)){
    const i=o.i, wl=TRK.wallL[i], wr=TRK.wallR[i], rl=wl-2.5-bl.d, rr=wr-2.5+bl.d;
    let side=rl>=rr?1:-1; if(Math.abs(rl-rr)<1.2&&o.pSide) side=o.pSide;
    const busy=s2=>all.some(q=>q!==o&&q!==bl&&q.fin==null&&Math.abs(dS(q.s,o.s))<9&&Math.abs(q.d-(bl.d+s2*3.1))<2.2);
    if(busy(side)&&!busy(-side)&&(side>0?rr:rl)>3.1) side=-side;
    o.pSide=side; o.pRef=bl; o.pUntil=t+2.5;
  }
  const lane=ref.d+(o.pSide||1)*3.1, lat=Math.abs(o.d-ref.d);
  let cap=1, brake=false;
  if(bl&&lat<2.3){ const gap=bd; if(gap<4+o.v*.18){cap=.5; if(o.v>bl.v+1&&gap<3+o.v*.1) brake=true;} else if(gap<7+o.v*.3) cap=.85; }
  return {lane,cap,brake};
}

/* ---- caméra libre en pilotage automatique ---- */
const orbitOn=()=>{ const o=RC&&RC.auto&&RC.orb; return !!(o&&(o.down||Math.abs(o.yaw)>.03||Math.abs(o.pit-.25)>.03)); };
function orbStep(o,dt){ if(o.down){o.idle=0; return;} o.idle+=dt; if(o.idle>3.2){ const k=Math.exp(-dt*2.6); o.yaw*=k; o.pit=.25+(o.pit-.25)*k; } }
function orbitSpa(cam,P,ang,dt){
  const o=RC.orb; orbStep(o,dt); const d=9+Math.min(P.v,90)*.02, rd=Math.cos(o.pit)*d, a=ang+o.yaw;
  cam.position.set(P.x-Math.cos(a)*rd,P.y+Math.max(.7,Math.sin(o.pit)*d+1.4),P.z-Math.sin(a)*rd); cam.lookAt(P.x,P.y+1.2,P.z);
}
function orbitRace(cam,P,Pa,dt){
  const o=RC.orb; orbStep(o,dt); const p=pathAt(Pa,clamp(P.x,-Pa.PRE+4,RC.tk.L+Pa.POST-6),P.lane), d=9+Math.min(P.v,90)*.02, rd=Math.cos(o.pit)*d, a=p.th+o.yaw;
  cam.position.set(p.x-Math.cos(a)*rd,Math.max(.8,Math.sin(o.pit)*d+1.4),p.z-Math.sin(a)*rd); cam.lookAt(p.x,1.1,p.z);
}
function bindOrbit(){
  const el=$('rslot'); if(!el||!RC||!RC.auto) return; RC.orb={yaw:0,pit:.25,down:false,idle:0,x:0,y:0};
  el.style.touchAction='none';
  el.addEventListener('pointerdown',e=>{ const o=RC&&RC.orb; if(!o) return; o.down=true; o.x=e.clientX; o.y=e.clientY; try{el.setPointerCapture(e.pointerId);}catch(_){ } });
  el.addEventListener('pointermove',e=>{ const o=RC&&RC.orb; if(!o||!o.down) return; o.yaw+=(e.clientX-o.x)*.012; o.pit=clamp(o.pit-(e.clientY-o.y)*.006,.03,1.2); o.x=e.clientX; o.y=e.clientY; });
  const up=()=>{ const o=RC&&RC.orb; if(o){o.down=false; o.idle=0;} };
  el.addEventListener('pointerup',up); el.addEventListener('pointercancel',up);
  const w=el.parentNode; if(w&&!w.querySelector('.orbhint')) w.insertAdjacentHTML('beforeend','<div class="orbhint">👆 Glisse sur l’écran pour regarder autour de la voiture</div>');
}

/* ---- rétroviseur (courses manuelles) ---- */
let mirTick=0;
function bindMirror(){
  const el=$('rslot'); if(!el||!RC||RC.auto||S.mirOff) return; const w=el.parentNode; if(!w||w.querySelector('.mir')) return;
  w.insertAdjacentHTML('beforeend','<canvas id="mir" class="mir" data-a="mirtog" aria-label="Rétroviseur"></canvas>');
  GL.post=mirrorPost;
}
function mirrorPost(){
  const cv=$('mir'); if(!cv||!RC||!RS||RC.auto||RC.done||GL.mode!=='race') return; if(mirTick++&1) return;
  const R=GL.r, gc=R.domElement, rr=cv.getBoundingClientRect(), gr=gc.getBoundingClientRect(), cw=Math.round(rr.width), ch=Math.round(rr.height); if(cw<20||ch<8||!gr.width) return;
  const sx=gc.clientWidth/gr.width, x=Math.round((rr.left-gr.left)*sx), top=Math.round((rr.top-gr.top)*sx), y=GL.h-top-ch;
  const mc=RS.mcam||(RS.mcam=new THREE.PerspectiveCamera(52,cw/ch,.3,700)); if(Math.abs(mc.aspect-cw/ch)>.01){mc.aspect=cw/ch; mc.updateProjectionMatrix();}
  const P=RC.P, H=(RS.pc&&RS.pc.H)||1.4;
  if(RC.kind==='spa'){ const c=Math.cos(P.psi), s=Math.sin(P.psi); mc.position.set(P.x-c*.3,P.y+H+.45,P.z-s*.3); mc.lookAt(P.x-c*30,P.y+1.1,P.z-s*30); }
  else { const p=pathAt(RS.path,clamp(P.x,-RS.path.PRE+4,RC.tk.L+RS.path.POST-6),P.lane), c=Math.cos(p.th), s=Math.sin(p.th); mc.position.set(p.x,H+.45,p.z); mc.lookAt(p.x-c*30,1.1,p.z-s*30); }
  const pc=RS.pc; if(pc) pc.g.visible=false;
  R.setScissorTest(true); R.setViewport(x,y,cw,ch); R.setScissor(x,y,cw,ch); R.render(GL.scene,mc); R.setScissorTest(false); R.setViewport(0,0,GL.w,GL.h);
  if(pc) pc.g.visible=true;
  const dpr=R.getPixelRatio(), bw=Math.round(cw*dpr), bh=Math.round(ch*dpr); if(cv.width!==bw||cv.height!==bh){cv.width=bw; cv.height=bh;}
  const ctx=cv.getContext('2d'); ctx.save(); ctx.translate(bw,0); ctx.scale(-1,1);
  try{ ctx.drawImage(gc,x*dpr,top*dpr,bw,bh,0,0,bw,bh); }catch(_){ }
  ctx.restore();
}
ACT.mirtog=function(){ S.mirOff=true; const e=document.querySelector('.mir'); if(e) e.remove(); GL.post=null; toast('Rétroviseur masqué pour cette partie'); };
const _bindRace=bindRace;
bindRace=function(){ _bindRace(); try{ if(RC&&RC.kind!=='show'){ bindOrbit(); bindMirror(); } }catch(e){ try{console.warn('bindRace+',e);}catch(_){ } } };

/* ======================================================================
   Carte pilote : titre, succès à paliers, arbre de compétences
   ====================================================================== */
const pil=()=>{ if(!S.pil) S.pil={sp:{},bdg:{}}; if(!S.pil.sp) S.pil.sp={}; if(!S.pil.bdg) S.pil.bdg={}; return S.pil; };
const pk=id=>((S.pil&&S.pil.sp)||{})[id]||0;
const sk=(c,id,k)=>(c&&c.uid>0)?1+k*pk(id):1;
const f1=x=>(Math.round(x*10)/10).toString().replace('.',',');
const SKT=[
 {b:'pil',n:'Pilotage',c:'#00e5ff',ic:'🏎️',list:[
  {id:'acc',n:'Départ canon',ic:'🚀',max:5,d:l=>`+${f1(1.5*l)} % d’accélération`},
  {id:'brk',n:'Freinage tardif',ic:'🛑',max:5,d:l=>`+${f1(2*l)} % de freinage`},
  {id:'grip',n:'Sens du grip',ic:'🛞',max:5,d:l=>`+${f1(1.2*l)} % de vitesse en virage`},
  {id:'nit',n:'Maître de la nitro',ic:'⚡',max:5,d:l=>`+${8*l} % de durée, +${4*l} % de poussée`}]},
 {b:'mec',n:'Mécanique',c:'#ff9a3c',ic:'🔧',list:[
  {id:'wear',n:'Conduite souple',ic:'🍃',max:4,d:l=>`−${8*l} % d’usure par course`},
  {id:'rep',n:'Mains en or',ic:'🛠️',max:4,d:l=>`−${7*l} % sur les réparations`},
  {id:'upg',n:'Négociateur d’atelier',ic:'💼',max:4,d:l=>`−${5*l} % sur les améliorations`},
  {id:'rel',n:'Mécano de précision',ic:'⚙️',max:3,d:l=>`−${10*l} % de risque de panne`}]},
 {b:'biz',n:'Business',c:'#3ccf7a',ic:'💰',list:[
  {id:'gain',n:'Sponsors',ic:'🤝',max:5,d:l=>`+${4*l} % de crédits en course`},
  {id:'xp',n:'Mentor',ic:'🎓',max:5,d:l=>`+${6*l} % d’expérience`},
  {id:'dly',n:'Fan club',ic:'📣',max:4,d:l=>`+${8*l} % de récompense quotidienne`},
  {id:'pod',n:'Showroom VIP',ic:'🏛️',max:5,d:l=>`+${6*l} % de revenus des podiums`}]},
 {b:'cha',n:'Chance',c:'#ff2bd6',ic:'🍀',list:[
  {id:'tok',n:'Flair',ic:'🎟',max:5,d:l=>`${6*l} % de chance de jeton bonus par victoire`},
  {id:'shopd',n:'Chineur',ic:'🛒',max:4,d:l=>`−${5*l} % sur les pièces du marché`},
  {id:'scrap',n:'Récupérateur',ic:'♻️',max:4,d:l=>`+${8*l} % de ferraille au recyclage`},
  {id:'luck',n:'Chercheur d’éclats',ic:'✨',max:5,d:l=>`+${10*l} % de chances de module brillant`}]}];
const SKI={}; SKT.forEach(b=>b.list.forEach(s=>{s.b=b; SKI[s.id]=s;}));
const RANKS=[[1,'Apprenti','#9aa3ad'],[3,'Pilote du dimanche','#3ccf7a'],[5,'Compétiteur','#3d8bff'],[8,'Professionnel','#b05cff'],[12,'As du volant','#ffb020'],[16,'Champion','#ff3d6e'],[20,'Légende','#00e5ff']];
const rankOf=()=>RANKS.filter(r=>S.lvl>=r[0]).pop();
const albCount=()=>MODT.reduce((t,T)=>{let b=S.alb[T[0]]||0,c=0; while(b){c+=b&1; b>>=1;} return t+c;},0);
const BDG=[
 {id:'races',n:'Habitué des pistes',ic:'🏁',d:'Dispute des épreuves',t:[5,30,120],v:()=>S.stats.races||0},
 {id:'wins',n:'Vainqueur',ic:'🏆',d:'Gagne des épreuves',t:[3,20,80],v:()=>S.stats.wins||0},
 {id:'wins3',n:'Série parfaite',ic:'🎯',d:'Gagne des épreuves de 3 manches ou plus',t:[1,5,20],v:()=>S.stats.wins3||0},
 {id:'pods',n:'Habitué du podium',ic:'🥇',d:'Monte sur le podium d’une épreuve à 6 voitures',t:[3,15,60],v:()=>S.stats.pods||0},
 {id:'w_drag',n:'Roi du drag',ic:'🚦',d:'Gagne des manches de drag',t:[3,15,50],v:()=>S.stats.w_drag||0},
 {id:'w_circuit',n:'Maître de Spa',ic:'🛣️',d:'Gagne des courses de circuit',t:[3,15,50],v:()=>S.stats.w_circuit||0},
 {id:'w_rallye',n:'Bête des chemins',ic:'🌲',d:'Gagne des manches de rallye',t:[3,12,40],v:()=>S.stats.w_rallye||0},
 {id:'w_drift',n:'Drifteur',ic:'💨',d:'Gagne des manches de drift',t:[3,12,40],v:()=>S.stats.w_drift||0},
 {id:'w_endurance',n:'Infatigable',ic:'⏱️',d:'Gagne des manches d’endurance',t:[2,8,25],v:()=>S.stats.w_endurance||0},
 {id:'w_elegance',n:'Œil du jury',ic:'🎩',d:'Remporte des concours d’élégance',t:[2,8,25],v:()=>S.stats.w_elegance||0},
 {id:'earned',n:'Tycoon',ic:'💰',d:'Gagne des crédits en course',t:[10000,100000,1000000],v:()=>S.stats.earned||0},
 {id:'nitroN',n:'Accro à la nitro',ic:'⚡',d:'Utilise des bouteilles de nitro',t:[10,50,200],v:()=>S.stats.nitroN||0},
 {id:'packs',n:'Ouvreur de paquets',ic:'🃏',d:'Ouvre des paquets',t:[5,30,100],v:()=>S.stats.packs||0},
 {id:'best',n:'Chasseur de légendes',ic:'🌟',d:'Obtiens un module de rareté Épique, Mythique puis Ultra rare',t:[3,5,6],v:()=>S.stats.best||0},
 {id:'shiny',n:'Chasseur d’éclats',ic:'✨',d:'Obtiens des modules brillants',t:[1,5,20],v:()=>S.stats.shiny||0},
 {id:'alb',n:'Album complet',ic:'📖',d:'Remplis l’album de modules',t:[20,80,200],v:albCount},
 {id:'fuseN',n:'Alchimiste',ic:'⚗️',d:'Fusionne des modules',t:[2,10,40],v:()=>S.stats.fuseN||0},
 {id:'eqN',n:'Tuner',ic:'🔩',d:'Monte des modules sur tes voitures',t:[10,60,250],v:()=>S.stats.eqN||0},
 {id:'repN',n:'Garagiste',ic:'🛠️',d:'Répare des voitures',t:[5,30,100],v:()=>S.stats.repN||0},
 {id:'shopN',n:'Chineur',ic:'🛒',d:'Achète des pièces au marché',t:[3,20,80],v:()=>S.stats.shopN||0},
 {id:'bats',n:'Bâtisseur',ic:'🏗️',d:'Améliore les bâtiments de la base',t:[3,10,25],v:()=>S.stats.bats||0},
 {id:'cars',n:'Collectionneur',ic:'🚗',d:'Possède des voitures en même temps',t:[3,6,12],v:()=>S.cars.length},
 {id:'lvl',n:'Ascension',ic:'📈',d:'Atteins un niveau de pilote',t:[5,10,20],v:()=>S.lvl}];
const BTIER=[{n:'Bronze',c:'#cd7f32',cr:500,xp:25,tok:0},{n:'Argent',c:'#cfd6e4',cr:2500,xp:90,tok:1},{n:'Or',c:'#ffd24a',cr:10000,xp:300,tok:3}];
const bdgDone=b=>{ const v=b.v(); return b.t.filter(x=>v>=x).length; };
const bdgGot=b=>pil().bdg[b.id]||0;
const bdgReady=()=>BDG.reduce((t,b)=>t+Math.max(0,bdgDone(b)-bdgGot(b)),0);
const bdgGold=()=>BDG.filter(b=>bdgGot(b)>=3).length;
const skTotal=()=>Math.max(0,S.lvl-1)+bdgGold();
const skSpent=()=>Object.values(pil().sp).reduce((a,b)=>a+b,0);
const skAvail=()=>skTotal()-skSpent();
const pilDot=()=>skAvail()>0||bdgReady()>0;

/* récompenses : on ajoute les succès à « tout récupérer » */
function claimList(){
  questsEnsure(); const L=[];
  if(S.daily!==dayKey()) L.push(['daily']);
  [['dq',DQ],['wq',WQ]].forEach(([k,T])=>S[k].ids.forEach(id=>{ const q=T.find(x=>x.id===id); if(q&&!S[k].cl[id]&&qProg(S[k],q)>=q.n) L.push([k,id]); }));
  MISSIONS.forEach(m=>{ if(!S.claimed[m.id]){ const p=m.p(S); if(p[0]>=p[1]) L.push(['m',m.id]); } });
  BDG.forEach(b=>{ if(bdgDone(b)>bdgGot(b)) L.push(['b',b.id]); });
  return L;
}
function claimTotal(L){
  const g={cr:0,tok:0,nitro:0,xp:0}, add=x=>{g.cr+=x.cr||0; g.tok+=x.tok||0; g.nitro+=x.nitro||0; g.xp+=x.xp||0;};
  L.forEach(([k,id])=>{ if(k==='daily') add(dailyReward()); else if(k==='m') add(MISSIONS.find(m=>m.id===id).g);
    else if(k==='b'){ const b=BDG.find(x=>x.id===id); for(let i=bdgGot(b);i<bdgDone(b);i++) add(BTIER[i]); }
    else add(qRew((k==='dq'?DQ:WQ).find(x=>x.id===id))); });
  return g;
}
ACT.claimall=function(){
  const L=claimList(); if(!L.length) return toast('Rien à récupérer');
  const g=claimTotal(L), lv0=S.lvl;
  L.forEach(([k,id])=>{
    if(k==='daily'){ const y=new Date(Date.now()-864e5), yk=y.getFullYear()+'-'+(y.getMonth()+1)+'-'+y.getDate(); S.streak=S.daily===yk?(S.streak||0)+1:1; S.daily=dayKey(); }
    else if(k==='m') S.claimed[id]=1;
    else if(k==='b'){ const b=BDG.find(x=>x.id===id); pil().bdg[id]=bdgDone(b); }
    else S[k].cl[id]=1;
  });
  giveG(g); toast('Tout récupéré : '+[g.cr?fmt(g.cr)+' cr':'',g.xp?g.xp+' XP':'',g.nitro?g.nitro+' nitro':'',g.tok?g.tok+' jeton'+(g.tok>1?'s':''):''].filter(Boolean).join(', ')); save(); render(); if(sheet&&sheet.t==='pilot') renderSheet();
};

/* ---- fenêtre pilote ---- */
const HELM=`<svg viewBox="0 0 64 64"><defs><linearGradient id="hg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f7ff"/><stop offset=".5" stop-color="#9aa6c6"/><stop offset="1" stop-color="#3b4362"/></linearGradient></defs>
<path d="M8 40 C8 20 22 8 38 8 C52 8 60 20 60 34 V46 C60 50 57 52 53 52 H18 C12 52 8 47 8 40Z" fill="url(#hg1)"/><path d="M26 22 H58 V38 H30 C25 38 22 33 24 29Z" fill="#0b0d1c" stroke="var(--rc)" stroke-width="2"/>
<path d="M8 40 C8 20 22 8 38 8" fill="none" stroke="var(--rc)" stroke-width="3" stroke-linecap="round"/><path d="M30 26 H54" stroke="#fff" stroke-width="1.6" opacity=".5" stroke-linecap="round"/><rect x="34" y="42" width="24" height="5" rx="2.5" fill="var(--rc)" opacity=".9"/></svg>`;
const pilStat=(v,l)=>`<div><b>${v}</b><span>${l}</span></div>`;
function pilotSheets(X){
  if(sheet.t!=='pilot') return false;
  const el=$('sheet'), tab=sheet.tab||'card', rk=rankOf(), nx=RANKS.find(r=>r[0]>S.lvl);
  const tabs=`<div class="subtabs">${[['card','Carte'],['skills','Compétences'+(skAvail()>0?` (${skAvail()})`:'')],['bdg','Succès'+(bdgReady()?` (${bdgReady()})`:'')]].map(([id,n])=>`<button data-a="ptab" data-id="${id}" ${tab===id?'aria-current="true"':''}>${n}</button>`).join('')}</div>`;
  let body='';
  if(tab==='card'){
    const gold=BDG.filter(b=>bdgGot(b)>=3||bdgDone(b)>=3).length, sp=skSpent();
    body=`<div class="pcard" style="--rc:${rk[2]}"><div class="pfoil"></div><div class="ptop"><span class="pav">${HELM}</span><div class="pid"><small>CARTE PILOTE</small><b>Pilote</b><span class="prank">${rk[1]}</span></div><div class="plv"><small>NIV.</small>${S.lvl}</div></div>
      <div class="pxp"><i style="width:${clamp(S.xp/need(S.lvl)*100,0,100)}%"></i></div><div class="pxpt">${fmt(S.xp)} / ${fmt(need(S.lvl))} XP${nx?` · prochain titre au niveau ${nx[0]} : ${nx[1]}`:' · rang maximal'}</div>
      <div class="pgrid">${pilStat(fmt(S.stats.races||0),'Épreuves')}${pilStat(fmt(S.stats.wins||0),'Victoires')}${pilStat(fmt(S.stats.pods||0),'Podiums')}${pilStat(fmt(S.cars.length),'Voitures')}${pilStat(fmt(S.mods.length),'Modules')}${pilStat(fmt(albCount()),'Album')}</div>
      <div class="pbad">${BDG.slice(0,12).map(b=>{const n=bdgDone(b); return `<span class="pb t${n}" title="${b.n}">${b.ic}</span>`;}).join('')}</div></div>
      <div class="prow"><button class="pbtn" data-a="ptab" data-id="skills"><b>🌳 Compétences</b><span>${skAvail()>0?`${skAvail()} point${skAvail()>1?'s':''} à dépenser`:`${sp} point${sp>1?'s':''} dépensé${sp>1?'s':''}`}</span></button><button class="pbtn" data-a="ptab" data-id="bdg"><b>🏅 Succès</b><span>${BDG.reduce((t,b)=>t+bdgDone(b),0)} / ${BDG.length*3} paliers, ${gold} en or</span></button></div>
      <p class="note">Chaque niveau donne 1 point de compétence. Un succès en or en donne un de plus.</p>`;
  } else if(tab==='skills'){
    body=`<div class="spts"><b>${skAvail()}</b><span>point${skAvail()>1?'s':''} de compétence</span><button class="btn alt sm" data-a="skreset" ${skSpent()?'':'disabled'}>${sheet.arm?'Confirmer : '+cr(skCost()):'Réinitialiser'}</button></div>
      ${SKT.map(b=>`<div class="sbr" style="--rc:${b.c}"><h3>${b.ic} ${b.n}</h3>${b.list.map(s=>{const l=pk(s.id), mx=l>=s.max;
        return `<div class="sk ${l?'on':''}"><span class="sic">${s.ic}</span><span class="sbody"><b>${s.n}</b><span class="pips">${Array.from({length:s.max},(_,i)=>`<i class="${i<l?'f':''}"></i>`).join('')}</span><small>${l?s.d(l):'Aucun niveau'}${mx?'':`<br><em>Niveau ${l+1} : ${s.d(l+1)}</em>`}</small></span>
          ${mx?'<span class="smax">MAX</span>':`<button class="btn sm ${skAvail()>0?'good':'alt'}" data-a="skup" data-id="${s.id}" ${skAvail()>0?'':'disabled'}>+1</button>`}</div>`;}).join('')}</div>`).join('')}`;
  } else {
    const rdy=bdgReady(), g=claimTotal(BDG.filter(b=>bdgDone(b)>bdgGot(b)).map(b=>['b',b.id]));
    body=`${rdy?`<button class="btn good wide claimall" data-a="claimall"><b>🎁 Tout récupérer</b><span>${rdy} palier${rdy>1?'s':''} : ${gText(g)}</span></button>`:`<p class="note">Chaque succès a trois paliers : bronze, argent, or. Les récompenses sont des crédits, de l’expérience et des jetons.</p>`}
      <div class="bgrid">${BDG.map(b=>{const v=b.v(), n=bdgDone(b), got=bdgGot(b), nxt=b.t[Math.min(n,2)], shown=Math.min(v,nxt);
        return `<div class="bd ${n?'on':''}"><span class="bmed t${n}">${b.ic}</span><b>${b.n}</b><small>${b.d}</small><div class="bp"><i style="width:${clamp(shown/nxt*100,0,100)}%"></i></div><span class="bnum">${n>=3?'Complet':fmt(Math.min(v,nxt))+' / '+fmt(nxt)}</span><span class="btier">${[0,1,2].map(i=>`<u class="${i<n?'d':''} ${i<got?'g':''}" style="--tc:${BTIER[i].c}"></u>`).join('')}</span></div>`;}).join('')}</div>`;
  }
  el.innerHTML=`${X}<h2>Pilote</h2>${tabs}${body}`;
  return true;
}
const skCost=()=>1500+500*skSpent();
Object.assign(ACT,{
  pilot(){ openSheet({t:'pilot',tab:'card'}); },
  ptab(d){ if(!sheet||sheet.t!=='pilot') return; sheet.tab=d.id; sheet.arm=false; renderSheet(); const s=$('sheet'); if(s) s.scrollTop=0; },
  skup(d){ const s=SKI[d.id]; if(!s) return; const l=pk(s.id); if(l>=s.max||skAvail()<1) return; pil().sp[s.id]=l+1; save(); render(); renderSheet(); auTry(()=>auCard(3,false,false)); toast(`${s.n} : niveau ${l+1}`); },
  skreset(){ if(!skSpent()) return; if(!sheet.arm){ sheet.arm=true; return renderSheet(); } const c=skCost(); if(S.cr<c) return toast('Pas assez de crédits'); S.cr-=c; pil().sp={}; sheet.arm=false; save(); render(); renderSheet(); toast('Compétences réinitialisées'); }
});

/* ---- mini-carte en direct (courses hors Spa) ---- */
function rmapInit(){
  const c=$('rmap'); if(!c||!RS||!RS.path||!RC||!RC.tk) return;
  const Pa=RS.path, tk=RC.tk, d=Math.min(2,window.devicePixelRatio||1), W=c.clientWidth||360;
  const vh=Math.min(window.innerHeight||800,(window.visualViewport&&window.visualViewport.height)||9999), H=Math.round(clamp(vh-c.getBoundingClientRect().top-18,84,170));
  c.style.height=H+'px';
  c.width=Math.round(W*d); c.height=Math.round(H*d);
  const a0=Math.max(0,Math.floor((Pa.PRE-18)/Pa.STEP)), a1=Math.min(Pa.n-1,Math.ceil((Pa.PRE+tk.L+28)/Pa.STEP));
  let x0=1e9,x1=-1e9,z0=1e9,z1=-1e9;
  for(let i=a0;i<=a1;i++){x0=Math.min(x0,Pa.px[i]);x1=Math.max(x1,Pa.px[i]);z0=Math.min(z0,Pa.pz[i]);z1=Math.max(z1,Pa.pz[i]);}
  const pad=26, w=Math.max(x1-x0,30), h=Math.max(z1-z0,30), k=Math.min((W-2*pad)/w,(H-2*pad)/h);
  const ox=(W-w*k)/2-x0*k, oz=(H-h*k)/2-z0*k, X=i=>Pa.px[i]*k+ox, Z=i=>Pa.pz[i]*k+oz;
  const bg=document.createElement('canvas'); bg.width=c.width; bg.height=c.height; const g=bg.getContext('2d'); g.scale(d,d);
  g.lineCap='round'; g.lineJoin='round';
  const stroke=(w2,col,filt)=>{g.lineWidth=w2; g.strokeStyle=col; g.beginPath(); let st=false;
    for(let i=a0;i<=a1;i++){const s=-Pa.PRE+i*Pa.STEP; if(filt&&!filt(s)){st=false; continue;} if(!st){g.moveTo(X(i),Z(i)); st=true;} else g.lineTo(X(i),Z(i));} g.stroke();};
  stroke(13,'#05040f'); stroke(9,'#1b1d45');
  g.shadowColor='#00E5FF'; g.shadowBlur=6; stroke(2,'#2a6fa0'); g.shadowBlur=0;
  tk.segs.filter(q=>q.t==='C').forEach(q=>stroke(4,'#FF2BD6',s=>s>=q.a&&s<=q.b));
  const bar=(s,col,txt)=>{const i=clamp(Math.round((s+Pa.PRE)/Pa.STEP),0,Pa.n-1), th=Pa.th[i], nx=Math.sin(th)*9, nz=-Math.cos(th)*9;
    g.strokeStyle=col; g.lineWidth=3; g.beginPath(); g.moveTo(X(i)-nx,Z(i)-nz); g.lineTo(X(i)+nx,Z(i)+nz); g.stroke();
    g.fillStyle=col; g.font='600 10px sans-serif'; g.textAlign='center'; g.fillText(txt,X(i),txt==='Départ'?Z(i)+22:Z(i)-14); };
  bar(0,'#3CFF9E','Départ'); bar(tk.L,'#FCEE0A','Arrivée');
  g.fillStyle='#8b90c8'; g.font='500 10px sans-serif'; g.textAlign='left'; g.fillText('Carte en direct',10,14);
  g.fillStyle='#00E5FF'; g.beginPath(); g.arc(W-84,H-12,4,0,7); g.fill(); g.fillStyle='#8b90c8'; g.fillText('toi',W-76,H-9);
  g.fillStyle='#FF2BD6'; g.beginPath(); g.arc(W-46,H-12,4,0,7); g.fill(); g.fillStyle='#8b90c8'; g.fillText('rivaux',W-38,H-9);
  RS.rm={c,W,H,d,k,ox,oz,bg};
}
function rmapDraw(){
  const m=RS&&RS.rm; if(!m||!RC) return; RS.rmt=(RS.rmt||0)+1; if(RS.rmt%2) return;
  const g=m.c.getContext('2d'), Pa=RS.path, tk=RC.tk, kk=Math.max(m.k,1.7);
  g.setTransform(1,0,0,1,0,0); g.drawImage(m.bg,0,0); g.scale(m.d,m.d);
  const pt=(r)=>{const p=pathAt(Pa,clamp(r.x,-12,tk.L+24),0); return [p.x*m.k+m.ox+Math.sin(p.th)*(r.lane||0)*kk, p.z*m.k+m.oz-Math.cos(p.th)*(r.lane||0)*kk];};
  RC.Os.forEach(o=>{const p=pt(o); g.fillStyle='#FF2BD6'; g.shadowColor='#FF2BD6'; g.shadowBlur=8; g.beginPath(); g.arc(p[0],p[1],4.6,0,7); g.fill(); g.shadowBlur=0; g.lineWidth=1.5; g.strokeStyle='#150c33'; g.stroke();});
  const p=pt(RC.P); g.fillStyle='#00E5FF'; g.shadowColor='#00E5FF'; g.shadowBlur=12; g.beginPath(); g.arc(p[0],p[1],6,0,7); g.fill(); g.shadowBlur=0; g.lineWidth=2; g.strokeStyle='#fff'; g.stroke();
}
/* ======================================================================
   Concours d'élégance : cinématique 3D (podiums, public, feux d'artifice)
   ====================================================================== */
const sstep=u=>{u=clamp(u,0,1); return u*u*(3-2*u);};
function buildShow(c,ot,row){
  const sc=new THREE.Scene(); sc.background=new THREE.Color(0x07051a); sc.fog=new THREE.Fog(0x07051a,40,130);
  sc.add(new THREE.HemisphereLight(0xaab6ff,0x2a0a4a,1.15));
  const dl=new THREE.DirectionalLight(0xffb0f4,.9); dl.position.set(-20,40,25); sc.add(dl);
  const cam=new THREE.PerspectiveCamera(55,1.5,.3,400);
  /* sol quadrillé */
  const ft=ctex(256,256,(x,W,H)=>{x.fillStyle='#0b0b22'; x.fillRect(0,0,W,H); x.strokeStyle='#2b2f6a'; x.lineWidth=2; for(let i=0;i<=8;i++){x.beginPath(); x.moveTo(i*W/8,0); x.lineTo(i*W/8,H); x.moveTo(0,i*H/8); x.lineTo(W,i*H/8); x.stroke();}},[16,16]);
  const fl=new THREE.Mesh(new THREE.PlaneGeometry(260,260),new THREE.MeshBasicMaterial({map:ft})); fl.rotation.x=-Math.PI/2; sc.add(fl);
  /* plateau tournant */
  const tt=new THREE.Mesh(new THREE.CylinderGeometry(3.7,3.9,.36,40),new THREE.MeshLambertMaterial({color:0x1a1c46})); tt.position.y=.18; sc.add(tt);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(3.75,.07,8,56),new THREE.MeshBasicMaterial({color:0x00E5FF})); ring.rotation.x=Math.PI/2; ring.position.y=.38; sc.add(ring);
  /* podiums */
  const n=ot.length+1, PX={1:0,2:-6.6,3:6.6}, PH={1:2.1,2:1.5,3:1.05}, PC={1:0xc9a227,2:0xb9c2d6,3:0xb87333}, PZ=-12;
  for(let r=1;r<=Math.min(n,3);r++){
    const b=new THREE.Mesh(new THREE.BoxGeometry(5.8,PH[r],4.4),new THREE.MeshLambertMaterial({color:PC[r]})); b.position.set(PX[r],PH[r]/2,PZ); sc.add(b);
    const e=new THREE.LineSegments(new THREE.EdgesGeometry(b.geometry),new THREE.LineBasicMaterial({color:r===1?0xFCEE0A:0x00E5FF})); e.position.copy(b.position); sc.add(e);
    const nb=labelSprite(r===1?'1er':r+'e',r===1?'#FCEE0A':'#00E5FF',3.4); nb.position.set(PX[r],PH[r]*.5,PZ+2.5); sc.add(nb);
  }
  const ban=labelSprite('CONCOURS D’ÉLÉGANCE','#FF2BD6',16); ban.position.set(0,10.5,PZ-3); sc.add(ban);
  /* voitures : les adversaires, puis la tienne */
  const ranks=[]; for(let r=1;r<=n;r++) if(r!==row.rank) ranks.push(r);
  const cars=[];
  const add=(g,rank,name,score,mine)=>{g.g.visible=false; sc.add(g.g); cars.push({q:g,rank,name,score,mine});};
  ot.slice().reverse().forEach((o,k)=>{ const idx=ot.indexOf(o); add(buildCar(M[o.o.mid],'#FF2BD6',carLook(o.o)),ranks[idx],o.nom,-o.t,false); });
  add(buildCar(M[c.mid],'#00E5FF',carLook(c)),row.rank,M[c.mid].nom,row.a,true);
  /* public : 4 couleurs, 1 corps + 1 tête par individu */
  const dm=new THREE.Object3D(), colors=[0xff2bd6,0x00e5ff,0xfcee0a,0x8f6bff], per=24, crowd=[];
  const bodyG=new THREE.CylinderGeometry(.34,.4,1.1,8), headG=new THREE.SphereGeometry(.27,8,6);
  const heads=new THREE.InstancedMesh(headG,new THREE.MeshLambertMaterial({color:0xe8b894}),per*colors.length);
  const bodies=colors.map(cl=>new THREE.InstancedMesh(bodyG,new THREE.MeshLambertMaterial({color:cl}),per));
  let hi=0;
  colors.forEach((cl,ci)=>{ for(let k=0;k<per;k++){
    let X,Z,rw,tries=0;
    do{ const a=Math.random()*6.283; rw=Math.floor(Math.random()*3); const rad=15+rw*2.6+Math.random()*1.2; X=Math.sin(a)*rad; Z=Math.cos(a)*rad-1; tries++; }while(Z<-5&&Math.abs(X)<14&&tries<40);
    crowd.push({ci,k,i:hi++,x:X,z:Z,y:rw*.55,ph:Math.random()*6.28,sp:5+Math.random()*3});
  } });
  heads.frustumCulled=false; bodies.forEach(b=>{b.frustumCulled=false; sc.add(b);}); sc.add(heads);
  /* faisceaux de projecteurs */
  const beams=[]; for(let k=0;k<4;k++){
    const bm=new THREE.Mesh(new THREE.ConeGeometry(2.6,18,20,1,true),new THREE.MeshBasicMaterial({color:[0x00E5FF,0xFF2BD6,0xFCEE0A,0x8f6bff][k],transparent:true,opacity:.13,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide}));
    const pv=new THREE.Group(); pv.position.set(Math.cos(k*1.57+.8)*14,0,Math.sin(k*1.57+.8)*14-4); bm.position.y=9; pv.add(bm); sc.add(pv); beams.push(pv);
  }
  /* feux d'artifice */
  const NB=9, NP=64, tot=NB*NP, fpos=new Float32Array(tot*3), fcol=new Float32Array(tot*3), fvel=new Float32Array(tot*3), fb=[];
  for(let b=0;b<NB;b++) fb.push({life:0,col:new THREE.Color()});
  const fg=new THREE.BufferGeometry(); const pa=new THREE.BufferAttribute(fpos,3), ca=new THREE.BufferAttribute(fcol,3); pa.setUsage(THREE.DynamicDrawUsage); ca.setUsage(THREE.DynamicDrawUsage);
  fg.setAttribute('position',pa); fg.setAttribute('color',ca);
  const fw=new THREE.Points(fg,new THREE.PointsMaterial({size:1.1,vertexColors:true,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,sizeAttenuation:true})); fw.frustumCulled=false; sc.add(fw);
  for(let i=0;i<tot;i++) fpos[i*3+1]=-50;
  return {scene:sc,cam,cars,crowd,heads,bodies,dm,beams,fw,pa,ca,fpos,fcol,fvel,fb,NB,NP,nb:0,nextFw:.4,PX,PH,PZ,n,fov:55};
}
function showFire(S_,t,dt,big){
  const o=S_;
  if(t>=o.nextFw){ o.nextFw=t+(big?.2:.5); const b=o.fb[o.nb%o.NB], bi=o.nb%o.NB; o.nb++; b.life=1.7; b.col.setHSL(Math.random(),1,.6);
    const cx=(Math.random()-.5)*44, cy=14+Math.random()*12, cz=-34+Math.random()*22;
    for(let k=0;k<o.NP;k++){ const i=(bi*o.NP+k)*3, a=Math.random()*6.283, e=Math.acos(2*Math.random()-1), sp=6+Math.random()*6;
      o.fpos[i]=cx; o.fpos[i+1]=cy; o.fpos[i+2]=cz; o.fvel[i]=Math.sin(e)*Math.cos(a)*sp; o.fvel[i+1]=Math.cos(e)*sp; o.fvel[i+2]=Math.sin(e)*Math.sin(a)*sp; } }
  for(let bi=0;bi<o.NB;bi++){ const b=o.fb[bi]; if(b.life<=0) continue; b.life-=dt; const f=Math.max(0,b.life/1.7);
    for(let k=0;k<o.NP;k++){ const i=(bi*o.NP+k)*3; o.fvel[i+1]-=6*dt; o.fpos[i]+=o.fvel[i]*dt; o.fpos[i+1]+=o.fvel[i+1]*dt; o.fpos[i+2]+=o.fvel[i+2]*dt;
      o.fcol[i]=b.col.r*f; o.fcol[i+1]=b.col.g*f; o.fcol[i+2]=b.col.b*f; }
    if(b.life<=0) for(let k=0;k<o.NP;k++){ const i=(bi*o.NP+k)*3; o.fpos[i+1]=-50; o.fcol[i]=o.fcol[i+1]=o.fcol[i+2]=0; } }
  o.pa.needsUpdate=true; o.ca.needsUpdate=true;
}
function startShow(i,row,c,ot){
  const has3d=glEnsure(); RC={kind:'row',i,row}; if(has3d) auTry(()=>{ auCutMenu(); auMood('fete'); });
  if(has3d){
    try{
      RS=buildShow(c,ot,row); RC={kind:'show',i,row,ot,clock:0,end:0,cap:'',nm:''};
      const n=ot.length+1; RC.tP=1.8+2.4*ot.length; RC.tC=RC.tP+6.6; RC.end=Math.min(19.6,RC.tC+n*1.1+2.6);
    }catch(e){ try{console.warn('show',e);}catch(_){ } RS=null; RC={kind:'row',i,row}; }
  }
  view='race'; render(); document.querySelector('main').scrollTop=0;
}
function vShow(){
  return `<div class="race"><div class="rwrap"><div class="rs" id="rslot" style="height:clamp(360px,62vh,560px)"></div>
    <div class="shw"><div class="shw-top"><b>🏆 Concours d’élégance</b><button class="btn alt sm" data-a="showskip">Passer ▶</button></div>
      <div class="shw-cap"><b id="shName"></b><span id="shCap"></span></div></div></div></div>`;
}
function endShow(){
  if(!RC||RC.kind!=='show') return; const i=RC.i, row=RC.row;
  glStop(); if(RS&&RS.scene) disposeScene(RS.scene); RS=null; RC={kind:'row',i,row}; auTry(()=>auMood('menu'));
  render(); document.querySelector('main').scrollTop=0;
}
function bindShow(){
  if(!GL.r||!RS){ endShow(); return; }
  glAttach('rslot'); glRun(RS.scene,RS.cam,showFrame,'show');
}
function showFrame(dt,time){
  if(!RC||RC.kind!=='show'||!RS){ return; }
  RC.clock+=dt; const t=RC.clock, o=RS, cam=o.cam, n=o.n, nOpp=n-1, tP=RC.tP, tC=RC.tC;
  if(t>=RC.end){ endShow(); return; }
  /* quelle voiture est sur le plateau ? */
  let cur=-1; if(t>=1.8&&t<tC){ cur=t<tP?Math.min(nOpp-1,Math.floor((t-1.8)/2.4)):nOpp; }
  const tt0=cur<0?0:(cur<nOpp?1.8+2.4*cur:tP), lt=t-tt0;
  o.cars.forEach((cr,k)=>{
    const q=cr.q, g=q.g;
    if(t<tC){ g.visible=(k===cur); if(g.visible){ g.position.set(0,.36,0); g.rotation.y=t*.75; if(q.flame){ q.flame.visible=cr.mine&&lt>1&&lt<5; if(q.flame.visible){const f=.8+Math.random()*.6; q.flame.scale.set(f,1,f);} } } }
    else {
      const idx=n-cr.rank, ta=tC+.2+idx*1.1, u=sstep((t-ta)/1.4), px=o.PX[Math.min(cr.rank,3)]||0, ph=o.PH[Math.min(cr.rank,3)]||1;
      g.visible=t>=ta; g.position.set(px,ph,o.PZ+(1-u)*30); g.rotation.y=-Math.PI/2+.5*(cr.rank===2?1:cr.rank===3?-1:.0)+Math.sin(t*.8)*.12; if(q.flame) q.flame.visible=false;
    }
    if(q.wheels) q.wheels.forEach(w=>{w.rotation.z-=dt*(t<tC?3:0);}); pulseSirens(q,time); shineTick(q,time);
  });
  /* caméra */
  const a=.6+t*.38, r=9.4, wide=sstep((t-tC)/1.6), intro=1-sstep(t/1.8);
  let px=Math.sin(a)*r, py=2.7+Math.sin(t*.7)*.5, pz=Math.cos(a)*r, lx=0, ly=1.3, lz=0;
  px=px*(1-intro)+0*intro; py=py*(1-intro)+7*intro; pz=pz*(1-intro)+26*intro; ly=ly*(1-intro)+4*intro; lz=lz*(1-intro)+(-8)*intro;
  px=px*(1-wide)+Math.sin(t*.4)*3*wide; py=py*(1-wide)+5.4*wide; pz=pz*(1-wide)+16*wide; lx=lx*(1-wide); ly=ly*(1-wide)+3*wide; lz=lz*(1-wide)+(-12)*wide;
  cam.position.set(px,py,pz); cam.lookAt(lx,ly,lz);
  /* public, projecteurs, feux */
  const exc=t<tC?(.35+.2*Math.min(1,t/6)):1.2, dm=o.dm;
  o.crowd.forEach(p=>{ const y=p.y+Math.abs(Math.sin(t*p.sp+p.ph))*.5*exc;
    dm.position.set(p.x,y+.55,p.z); dm.rotation.set(0,0,0); dm.updateMatrix(); o.bodies[p.ci].setMatrixAt(p.k,dm.matrix);
    dm.position.set(p.x,y+1.4,p.z); dm.updateMatrix(); o.heads.setMatrixAt(p.i,dm.matrix); });
  o.bodies.forEach(b=>{b.instanceMatrix.needsUpdate=true;}); o.heads.instanceMatrix.needsUpdate=true;
  o.beams.forEach((b,k)=>{ b.rotation.z=Math.sin(t*.9+k*1.7)*.35; b.rotation.x=Math.cos(t*.7+k)*.3; });
  showFire(o,t,dt,t>=tC);
  /* légende */
  let nm='', cp='';
  if(t<1.8){ nm='Le public s’installe'; cp=''; }
  else if(t<tC){ const cr=o.cars[cur]; nm=cr.mine?'Ta voiture : '+cr.name:cr.name; const tt=cur<nOpp?1.8+2.4*cur:tP; cp=(t-tt>(cr.mine?4.6:1.2))?'Note du jury : '+fmt(cr.score)+' pts':'Le jury observe…'; }
  else { const rk=RC.row.rank; nm=rk===1?'Victoire !':ordF(rk)+' place'; cp='Le jury a rendu son verdict'; }
  if(RC.nm!==nm){RC.nm=nm; const e=$('shName'); if(e) e.textContent=nm;} if(RC.cap!==cp){RC.cap=cp; const e=$('shCap'); if(e) e.textContent=cp;}
}

ACT.showskip=()=>endShow();
/* ---- tuto pour les nouveaux joueurs : court, avec bouton « Passer » ---- */
const TUTO=[
 {v:'garage',ic:'🏎️',t:'Bienvenue dans High & Rouillé',x:'Tu démarres avec une vieille épave rouillée offerte par le jeu, 1 500 cr et 3 jetons de paquet. Ce tour dure 30 secondes, et tu peux le passer quand tu veux.'},
 {v:'garage',ic:'🚗',t:'Ton garage',x:'Touche une voiture pour la réparer, l’équiper de modules ou l’améliorer. Les podiums du showroom exposent tes plus belles voitures et rapportent des crédits pendant que tu joues.'},
 {v:'epreuves',ic:'🏁',t:'Les épreuves',x:'Choisis une épreuve, puis place la bonne voiture sur chaque manche. Prends le volant (gaz, frein, nitro) ou laisse le pilote automatique. Plus tu finis haut, plus la prime est grosse.'},
 {v:'cartes',ic:'🃏',t:'Cartes et paquets',x:'Dépense tes jetons pour ouvrir des paquets : voitures et modules de tuning, en 7 raretés. Les modules se montent dans l’atelier de chaque voiture pour gagner en stats.'},
 {v:'marche',ic:'🛒',t:'Marché et base',x:'Au marché, achète ou vends voitures et pièces, les offres changent au fil des courses. Dans la base, construis des bâtiments qui rapportent plus de crédits et d’XP, et règle le son.'},
 {v:'missions',ic:'📜',t:'Missions et pilote',x:'Les missions et les badges donnent crédits, XP et jetons : récupère-les ici. Touche ton niveau en haut de l’écran pour ouvrir ta carte pilote et dépenser tes points de compétence.'},
 {v:'garage',ic:'🎯',t:'Premier objectif',x:'Répare ton épave au garage, puis lance « Run du parking » dans les épreuves. Bonne route !'}
];
function tutoSheet(X){
  if(!sheet||sheet.t!=='tuto') return false;
  const i=sheet.i||0, T=TUTO[i], last=i===TUTO.length-1;
  $('sheet').innerHTML=`<div class="tuto"><div class="tu-ic">${T.ic}</div><h2>${T.t}</h2><p>${T.x}</p>
    <div class="tu-dots">${TUTO.map((_,k)=>`<i class="${k===i?'on':k<i?'d':''}"></i>`).join('')}</div>
    <div class="tu-btns">${last?'':'<button class="btn alt" data-a="tutoskip">Passer le tuto</button>'}<button class="btn" data-a="tutonext">${last?'C’est parti':'Suivant'}</button></div></div>`;
  return true;
}
function tutoEnd(){ closeSheet(); view='garage'; R=null; render(); document.querySelector('main').scrollTop=0; }
ACT.tuto=()=>{ openSheet({t:'tuto',i:0}); };
ACT.tutoskip=()=>{ tutoEnd(); };
ACT.tutonext=()=>{ if(!sheet||sheet.t!=='tuto') return; const i=(sheet.i||0)+1; if(i>=TUTO.length){ tutoEnd(); return; }
  sheet.i=i; const v=TUTO[i].v; if(v&&v!==view){ view=v; R=null; render(); } else renderSheet(); $('sheet').scrollTop=0; };
/* ---- sélection automatique des voitures + musique festive ---- */
function autoPick(){
  const ev=R.ev, ms=ev.manches, cs=S.cars.slice();
  const sc=(c,i)=>{ const mn=ms[i], top=Math.max(1,...R.opps[i].map(o=>indice(o,mn))); return Math.min(2,indice(c,mn)/top); };
  const cand=ms.map((mn,i)=>cs.map(c=>({u:c.uid,s:sc(c,i)})).sort((a,b)=>b.s-a.s).slice(0,ms.length+2));
  let best=-1, bp=null; const cur=[];
  (function rec(i,sum){ if(i===ms.length){ if(sum>best){best=sum; bp=cur.slice();} return; }
    for(const c of cand[i]){ if(cur.includes(c.u)) continue; cur.push(c.u); rec(i+1,sum+c.s); cur.pop(); } })(0,0);
  if(bp) R.pick=bp; return !!bp;
}
ACT.autopick=()=>{ if(!R||!R.ev) return; if(autoPick()){ toast('Meilleures voitures choisies, tu peux les changer à la main'); render(); } else toast('Pas assez de voitures'); };
MOODS.fete={arp:[],oct:2,wave:'triangle',av:0,pv:.07,filt:7000,hat:false,pulse:false};
function feteSched(s,bar,t,ch){
  if(s===0&&bar%2===0) pad(t,BAR*2,ch.pad,.09);
  if(s===0||s===8) kick(t,.7,{p0:140,p1:45,dec:.2});
  if(s===4||s===12) clap(t,.35);
  if(s%2===1) hat(t,.06,false);
  if(s%4===2) pluck(t,ch.bass*2,.2,'triangle',.4);
  if(s%2===0) pluck(t,ch.arp[((s>>1)+bar*2)%6]*2,.15,'triangle',.3);
  if(s===0&&bar%4===0) crash(t,.25);
}
/* ======================================================================
   Monde 3D : grand garage à la première personne, PNJ en tenue, podiums
   ====================================================================== */
const HUB={scene:null,cam:null,sig:'',pos:{x:0,z:12},yaw:0,pit:0,inp:{x:0,z:0},keys:{},nkey:'',t:0,walk:0,ents:null,obs:[],kb:false,look:null};
const HUB_NPC=[
 {id:'cartes',   lab:'🃏 Paquets',   s:-1, z:-4,  col:0xff2bd6, css:'#FF2BD6', txt:'Ouvrir la boutique de cartes', o:{torso:0x6a1b9a,legs:0x1d1830,arm:0xf2f2f8,bow:0xff2bd6,hat:'news',hatCol:0x30204a,longHair:true,hair:0x2a1810}},
 {id:'marche',   lab:'🛒 Concession',s:1,  z:-4,  col:0xfcee0a, css:'#FCEE0A', txt:'Aller au marché', o:{torso:0x1b2145,legs:0x1b2145,arm:0x1b2145,shirt:true,tie:0xd0202a,hair:0x151515}},
 {id:'base',     lab:'🏗️ Chantiers', s:-1, z:11,  col:0xff9a1a, css:'#FF9A1A', txt:'Atelier et chantiers', o:{torso:0x4d5568,legs:0x2f3d6b,arm:0x4d5568,vest:0xff7a00,hat:'hard',hatCol:0xffd400,shoe:0x5a3a1a,hair:0x3a2a1a}},
 {id:'missions', lab:'📜 Missions',  s:1,  z:11,  col:0x8f6bff, css:'#A58BFF', txt:'Missions, badges et récompenses', o:{torso:0xb59a6a,legs:0x2b2b35,arm:0xb59a6a,glasses:true,clip:true,hair:0x6b4b2a}},
 {id:'epreuves', lab:'🏁 Épreuves',  f:-16,  col:0x3cff9e, css:'#3CFF9E', txt:'Choisir une épreuve', o:{torso:0xe53935,legs:0xe53935,arm:0xe53935,stripe:0xffffff,hat:'helmet',hatCol:0xffffff,hatAcc:0x00e5ff,glove:true}},
 {id:'meca',     lab:'🔧 Mécano',    f:16,   col:0x00e5ff, css:'#00E5FF', txt:'Réviser tout le garage', o:{torso:0x1d4f9a,legs:0x1d4f9a,arm:0x1d4f9a,hat:'cap',hatCol:0xc89a1a,wrench:true,stain:true,hair:0x2a2018}}
];
function hubFigure(o){
  const g=new THREE.Group(), L=c=>new THREE.MeshLambertMaterial({color:c}), skin=o.skin||0xe8b894;
  const add=(geo,col,x,y,z,par)=>{ const m=new THREE.Mesh(geo,L(col)); m.position.set(x,y,z); (par||g).add(m); return m; };
  const B=(w,h,d)=>new THREE.BoxGeometry(w,h,d), C=(a,b,h)=>new THREE.CylinderGeometry(a,b,h,12), S=r=>new THREE.SphereGeometry(r,12,10);
  [-1,1].forEach(s=>{ add(B(.22,.85,.26),o.legs,s*.14,.43,0); add(B(.25,.12,.36),o.shoe||0x15151f,s*.14,.06,.05); });
  add(B(.58,.68,.32),o.torso,0,1.2,0);
  if(o.shirt){ add(B(.2,.44,.02),0xffffff,0,1.24,.165); add(B(.07,.36,.03),o.tie,0,1.2,.18); add(B(.1,.07,.04),o.tie,0,1.4,.18); }
  if(o.bow){ add(B(.08,.07,.04),o.bow,-.06,1.43,.17); add(B(.08,.07,.04),o.bow,.06,1.43,.17); add(B(.2,.4,.02),0xffffff,0,1.24,.165); }
  if(o.vest){ add(B(.6,.52,.34),o.vest,0,1.22,0); add(B(.62,.05,.35),0xe8e8e8,0,1.12,0); add(B(.62,.05,.35),0xe8e8e8,0,1.34,0); }
  if(o.stripe){ add(B(.6,.07,.34),o.stripe,0,1.28,0); add(B(.12,.07,.34),0x111122,0,1.12,0); }
  if(o.stain){ add(B(.2,.16,.02),0x23262e,-.12,1.1,.165); add(B(.12,.1,.02),0x23262e,.14,1.32,.165); add(B(.14,.3,.02),0x23262e,.14,.55,.135); }
  const arms=[-1,1].map(s=>{ const p=new THREE.Group(); p.position.set(s*.38,1.5,0); g.add(p); add(B(.15,.62,.17),o.arm,0,-.3,0,p); add(S(.08),o.glove?0x111118:skin,0,-.66,0,p); return p; });
  if(o.clip){ const c=add(B(.3,.38,.03),0x8a5a2b,0,-.62,.14,arms[1]); add(B(.24,.32,.02),0xffffff,0,0,.02,c); arms[1].rotation.x=-.9; }
  if(o.wrench){ add(B(.05,.46,.05),0xa0a6b0,.02,-.72,.06,arms[1]); add(B(.14,.08,.05),0xa0a6b0,.02,-.96,.06,arms[1]); arms[1].rotation.x=-.5; }
  const head=new THREE.Group(); head.position.y=1.8; g.add(head);
  add(C(.07,.08,.1),skin,0,-.2,0,head); add(S(.18),skin,0,0,0,head);
  if(o.hat==='helmet'){
    const h=add(S(.235),o.hatCol,0,.02,0,head); h.scale.set(1,1.05,1.08); add(B(.34,.11,.12),0x0a1426,0,-.01,.17,head); add(B(.05,.3,.5),o.hatAcc,0,.06,0,head);
  }else{
    [-1,1].forEach(s=>add(B(.035,.035,.02),0x15151c,s*.07,.02,.17,head));
    if(o.glasses){ [-1,1].forEach(s=>add(B(.11,.07,.02),0x15151c,s*.07,.02,.18,head)); }
    const hr=add(S(.188),o.hair||0x2a1810,0,.035,-.025,head); hr.scale.set(1,.92,1);
    if(o.longHair) add(B(.32,.42,.1),o.hair,0,-.12,-.15,head);
    if(o.hat==='hard'){ add(C(.2,.21,.11),o.hatCol,0,.15,0,head); add(B(.4,.03,.3),o.hatCol,0,.1,.04,head); }
    if(o.hat==='cap'){ add(C(.19,.2,.1),o.hatCol,0,.15,0,head); add(B(.26,.03,.16),o.hatCol,0,.11,.2,head); }
    if(o.hat==='news'){ add(C(.22,.2,.08),o.hatCol,0,.14,0,head); add(B(.22,.03,.12),o.hatCol,0,.11,.18,head); }
  }
  return {g,arms,head};
}
function hubLabel(txt,css,sc_,x,z){
  const l=labelSprite(txt,css,sc_); l.material.depthTest=false; l.material.depthWrite=false; l.renderOrder=20; l.userData.hx=x; l.userData.hz=z;
  if(HUB.labels&&sc_<20) HUB.labels.push(l); return l;
}
function hubBuild(){
  if(HUB.map&&HUB.map!=='garage') return (typeof WORLD!=='undefined'&&WORLD[HUB.map]?worldBuild:growBuild)(HUB.map);
  const sc=new THREE.Scene(); sc.background=new THREE.Color(0x07051a); sc.fog=new THREE.Fog(0x07051a,60,150);
  sc.add(new THREE.HemisphereLight(0xc4ccff,0x2a0a4a,1.3)); const dl=new THREE.DirectionalLight(0xffd0f8,.7); dl.position.set(-20,40,25); sc.add(dl);
  const cam=new THREE.PerspectiveCamera(100,1.5,.1,300), HX=36, HZ=26;
  const ft=ctex(512,512,(x,W,H)=>{ x.fillStyle='#1c1e36'; x.fillRect(0,0,W,H);
    for(let i=0;i<900;i++){ x.fillStyle=`rgba(${120+Math.random()*80|0},${120+Math.random()*80|0},${160+Math.random()*80|0},${.03+Math.random()*.06})`; x.fillRect(Math.random()*W,Math.random()*H,1+Math.random()*3,1+Math.random()*3); }
    x.strokeStyle='#0d0e20'; x.lineWidth=4; x.strokeRect(2,2,W-4,H-4); x.strokeStyle='rgba(255,255,255,.05)'; x.lineWidth=2; x.beginPath(); x.moveTo(W/2,0); x.lineTo(W/2,H); x.moveTo(0,H/2); x.lineTo(W,H/2); x.stroke();
    x.fillStyle='#d9b400'; [[6,6],[W-14,6],[6,H-14],[W-14,H-14]].forEach(q=>x.fillRect(q[0],q[1],8,8)); },[9,6.5]);
  const fl=new THREE.Mesh(new THREE.PlaneGeometry(HX*2,HZ*2),new THREE.MeshLambertMaterial({map:ft})); fl.rotation.x=-Math.PI/2; sc.add(fl);
  const ce=new THREE.Mesh(new THREE.PlaneGeometry(HX*2,HZ*2),new THREE.MeshBasicMaterial({color:0x0b0b1e,side:THREE.DoubleSide})); ce.rotation.x=Math.PI/2; ce.position.y=11; sc.add(ce);
  const wallM=new THREE.MeshLambertMaterial({color:0x1b1d44}), neon=c=>new THREE.MeshBasicMaterial({color:c});
  const box=(w,h,d,x,y,z,mat)=>{ const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat); m.position.set(x,y,z); sc.add(m); return m; };
  box(HX*2+1,11,.6,0,5.5,-HZ-.3,wallM); box(HX*2+1,11,.6,0,5.5,HZ+.3,wallM); box(.6,11,HZ*2,-HX-.3,5.5,0,wallM); box(.6,11,HZ*2,HX+.3,5.5,0,wallM);
  [[HX*2,.18,.1,0,2.2,-HZ+.1,0x00E5FF],[HX*2,.18,.1,0,2.2,HZ-.1,0x00E5FF],[.1,.18,HZ*2,-HX+.1,2.2,0,0xFF2BD6],[.1,.18,HZ*2,HX-.1,2.2,0,0xFF2BD6]].forEach(a=>box(a[0],a[1],a[2],a[3],a[4],a[5],neon(a[6])));
  for(let i=-3;i<=3;i++) for(let j=-1;j<=1;j++) box(8,.1,1.2,i*10,10.9,j*14,neon(0xddeeff));
  [-1,1].forEach(a=>[-1,1].forEach(b=>box(1.2,11,1.2,a*14,5.5,b*8,wallM)));
  const ban=hubLabel('MON GARAGE','#00E5FF',26,0,0); ban.position.set(0,8.5,-HZ+.9); sc.add(ban); HUB.labels=[];
  const E={npcs:[],pods:[]}; HUB.obs=[];
  const slots=(S.pod&&S.pod.slots)||[];
  for(let i=0;i<POD_MAX;i++){
    const x=-28+8*i, z=-18, open=S.lvl>=POD_LVL[i], uid=slots[i], c=uid&&car(uid);
    const d=new THREE.Mesh(new THREE.CylinderGeometry(3.1,3.4,.45,32),new THREE.MeshLambertMaterial({color:open?0x2a2e6a:0x15162e})); d.position.set(x,.23,z); sc.add(d);
    const rg=new THREE.Mesh(new THREE.TorusGeometry(3.15,.09,8,44),neon(open?0x00E5FF:0x444866)); rg.rotation.x=Math.PI/2; rg.position.set(x,.47,z); sc.add(rg);
    let cg=null; if(open&&c){ try{ cg=buildCar(M[c.mid],'#00E5FF',carLook(c)); cg.g.position.set(x,.46,z); sc.add(cg.g); }catch(e){ cg=null; } }
    const lb=hubLabel(!open?'🔒 Niv. '+POD_LVL[i]:(c?M[c.mid].nom:'Podium '+(i+1)),open?'#00E5FF':'#8b90c8',5.6,x,z+2.2); lb.position.set(x,4.2,z+2.2); sc.add(lb);
    E.pods.push({i,x,z,open,cg,c}); HUB.obs.push({x,z,r:3.3});
  }
  HUB_NPC.forEach((n,k)=>{
    let nx,nz,cx,cz,px,pz,sx,sz;
    if(n.s){ nx=n.s*33.2; nz=n.z; cx=n.s*31.6; cz=n.z; px=n.s*35.2; pz=n.z; sx=.3; sz=7; HUB.obs.push({x0:cx-.6,x1:cx+.6,z0:cz-2.4,z1:cz+2.4}); box(1.2,1.1,4.8,cx,.55,cz,new THREE.MeshLambertMaterial({color:0x23265a})); box(1.3,.08,4.9,cx,1.12,cz,neon(n.col)); }
    else { nx=n.f; nz=24.2; cx=n.f; cz=22.6; px=n.f; pz=25.4; sx=7; sz=.3; HUB.obs.push({x0:cx-2.4,x1:cx+2.4,z0:cz-.6,z1:cz+.6}); box(4.8,1.1,1.2,cx,.55,cz,new THREE.MeshLambertMaterial({color:0x23265a})); box(4.9,.08,1.3,cx,1.12,cz,neon(n.col)); }
    box(sx,5.2,sz,px,2.6,pz,new THREE.MeshLambertMaterial({color:0x14163a}));
    box(n.s?.1:6.8,.16,n.s?6.8:.1,px+(n.s?-n.s*.2:0),4.4,pz+(n.s?0:-.2),neon(n.col));
    /* accessoires de métier */
    if(n.id==='cartes'){ [0,1,2,3].forEach(j=>box(.5,.7,.04,cx,1.5+.0,cz-1.5+j*1,new THREE.MeshBasicMaterial({color:[0xff2bd6,0x00e5ff,0xfcee0a,0x8f6bff][j]}))); }
    if(n.id==='marche'){ box(.9,.3,1.8,cx,1.35,cz,new THREE.MeshLambertMaterial({color:0xc33})); box(.6,.18,1.0,cx,1.58,cz,new THREE.MeshLambertMaterial({color:0x9ad})); }
    if(n.id==='base'){ [-1,0,1].forEach(j=>{ const cn=new THREE.Mesh(new THREE.ConeGeometry(.3,.8,12),new THREE.MeshLambertMaterial({color:0xff6a00})); cn.position.set(n.s*28.8,.4,n.z-3.5+j*3.5); sc.add(cn); }); box(1.4,1.2,1.4,n.s*29.2,.6,n.z+4.2,new THREE.MeshLambertMaterial({color:0x8a6a3a})); }
    if(n.id==='missions'){ box(.1,2.6,3.6,n.s*34.6,2.4,n.z,new THREE.MeshLambertMaterial({color:0x2a2218})); [0,1,2,3,4].forEach(j=>box(.04,.5,.4,n.s*34.5,1.6+(j%2)*.9,n.z-1.4+j*.7,new THREE.MeshBasicMaterial({color:[0xffffff,0xfcee0a,0xff9acb][j%3]}))); }
    if(n.id==='epreuves'){ box(.4,5,.4,n.f-3.2,2.5,21,neon(n.col)); box(.4,5,.4,n.f+3.2,2.5,21,neon(n.col)); const ck=ctex(128,32,(x,W,H)=>{ for(let i=0;i<16;i++) for(let j=0;j<4;j++){ x.fillStyle=(i+j)%2?'#fff':'#111'; x.fillRect(i*8,j*8,8,8);} }); box(6.8,.8,.3,n.f,5.2,21,new THREE.MeshBasicMaterial({map:ck})); }
    if(n.id==='meca'){ [-1,1].forEach(j=>{ for(let t=0;t<3;t++){ const tr=new THREE.Mesh(new THREE.CylinderGeometry(.5,.5,.28,16),new THREE.MeshLambertMaterial({color:0x15151a})); tr.position.set(n.f+j*4.4,.14+t*.3,22); sc.add(tr); } }); box(1,.5,.5,n.f+2.8,1.38,cz,new THREE.MeshLambertMaterial({color:0xc02020})); }
    const f=hubFigure(n.o); f.g.position.set(nx,0,nz); sc.add(f.g);
    const rg=new THREE.Mesh(new THREE.TorusGeometry(1.6,.06,8,36),neon(n.col)); rg.rotation.x=Math.PI/2; rg.position.set(n.s?cx-n.s*1.8:cx,.06,n.s?cz:cz-1.8); sc.add(rg);
    const lb=hubLabel(n.lab,n.css,5.2,nx,nz); lb.position.set(n.s?px-n.s*1.2:px,3.9,n.s?pz:pz-1.2); sc.add(lb);
    E.npcs.push({n,f,rg,k,x:nx,z:nz}); HUB.obs.push({x:nx,z:nz,r:.9});
  });
  hubDecor(sc,HX,HZ,neon,box); hubSecret(sc,box,neon);
  HUB.scene=sc; HUB.cam=cam; HUB.ents=E; HUB.bx=35.2; HUB.bz=25.2; HUB.pois=null; HUB.plots=null; HUB.fans=null; HUB.map='garage';
}
function hubFrame(dt,time){
  const H=HUB, E=H.ents; if(!E||view!=='hub') return; H.t+=dt; if(H.map&&H.map!=='garage'){ if(GROW[H.map]) growTick(dt); else worldTick(dt); }
  let ix=H.inp.x, iz=H.inp.z; const k=H.keys;
  if(k.KeyA||k.KeyQ) ix-=1; if(k.KeyD) ix+=1; if(k.KeyW||k.KeyZ) iz-=1; if(k.KeyS) iz+=1;
  if(k.ArrowLeft) H.yaw+=1.9*dt; if(k.ArrowRight) H.yaw-=1.9*dt; if(k.ArrowUp) H.pit=Math.min(1.1,H.pit+1.4*dt); if(k.ArrowDown) H.pit=Math.max(-1.1,H.pit-1.4*dt);
  const m=Math.hypot(ix,iz); if(m>1){ ix/=m; iz/=m; }
  const sy=Math.sin(H.yaw), cy=Math.cos(H.yaw), vx=sy*iz+cy*ix, vz=cy*iz-sy*ix, sp=8, p=H.pos;
  let nx=clamp(p.x+vx*sp*dt,-(H.bx||35.2),H.bx||35.2), nz=clamp(p.z+vz*sp*dt,-(H.bz||25.2),H.bz||25.2);
  H.obs.forEach(o=>{
    if(o.r!=null){ const dx=nx-o.x, dz=nz-o.z, d=Math.hypot(dx,dz), r=o.r+.45; if(d<r&&d>1e-4){ nx=o.x+dx/d*r; nz=o.z+dz/d*r; } }
    else{ const qx=clamp(nx,o.x0,o.x1), qz=clamp(nz,o.z0,o.z1), dx=nx-qx, dz=nz-qz, d=Math.hypot(dx,dz); if(d<.45&&d>1e-4){ nx=qx+dx/d*.45; nz=qz+dz/d*.45; } }
  });
  p.x=nx; p.z=nz; const mv=m>.08; if(mv) H.walk+=dt*9;
  E.npcs.forEach(q=>{ const g=q.f.g, a=Math.atan2(p.x-q.x,p.z-q.z); let d2=a-g.rotation.y; d2=Math.atan2(Math.sin(d2),Math.cos(d2)); g.rotation.y+=d2*Math.min(1,dt*3); g.position.y=Math.abs(Math.sin(H.t*1.6+q.k))*.025;
    q.f.arms.forEach((a2,j)=>{ if(!a2.userData.b) a2.userData.b=a2.rotation.x; a2.rotation.x=a2.userData.b+Math.sin(H.t*1.8+q.k+j*3)*.06; });
    const s=1+.06*Math.sin(H.t*3+q.k); q.rg.scale.set(s,s,s); });
  E.pods.forEach(q=>{ if(q.cg){ q.cg.g.rotation.y=H.t*.3+q.i; if(q.cg.wheels) q.cg.wheels.forEach(w=>{w.rotation.z-=dt*.6;}); pulseSirens(q.cg,time); shineTick(q.cg,time); } });
  const cam=H.cam, ey=1.75+(mv?Math.sin(H.walk)*.04:0), asp=cam.aspect||1, fv=Math.min(105,2*Math.atan(Math.tan(55*Math.PI/180)/asp)*180/Math.PI);
  if(Math.abs(cam.fov-fv)>.1){ cam.fov=fv; cam.updateProjectionMatrix(); }
  cam.position.set(p.x+Math.sin(H.yaw)*.5,ey,p.z+Math.cos(H.yaw)*.5);
  (H.labels||[]).forEach(l=>{ l.visible=Math.hypot(p.x-l.userData.hx,p.z-l.userData.hz)<22; });
  const cp=Math.cos(H.pit); cam.lookAt(cam.position.x-Math.sin(H.yaw)*cp*10,ey+Math.sin(H.pit)*10,cam.position.z-Math.cos(H.yaw)*cp*10);
  let best=null, bd=1e9;
  E.npcs.forEach(q=>{ const d=Math.hypot(p.x-q.x,p.z-q.z); if(d<3.6&&d<bd){ bd=d; best={t:'n',n:q.n}; } });
  E.pods.forEach(q=>{ const d=Math.hypot(p.x-q.x,p.z-q.z); if(d<5.6&&d<bd){ bd=d; best={t:'p',q}; } });
  if(HUB.map&&HUB.map!=='garage') best=HUB.gbest?{t:'q',q:HUB.gbest}:null;
  else if(!best&&HUB.sec&&Math.hypot(p.x-HUB.sec.x,p.z-HUB.sec.z)<2.3) best={t:'s'};
  if(!best&&(!HUB.map||HUB.map==='garage')&&Math.abs(p.x)<7&&p.z>HZ_DOOR-6) best={t:'d'};
  hubAct(best);
}
const HZ_DOOR=26;
function hubAct(b){
  const el=$('hubAct'); if(!el) return; let h='';
  if(b&&b.t==='n'){
    let tx=b.n.txt; if(b.n.id==='meca'){ const fr=fleetRepair(); tx=fr?`Réviser tout le garage, ${fmt(fr)} cr`:'Garage en parfait état'; }
    h=`<div class="hn">${b.n.lab}</div><button class="btn wide" data-a="hubgo" data-id="${b.n.id}">${tx}</button>`;
  }else if(b&&b.t==='p'){
    const q=b.q; h=q.open?`<div class="hn">Podium ${q.i+1}</div><button class="btn wide" data-a="hubgo" data-id="pod${q.i}">${q.c?'Changer la voiture exposée':'Exposer une voiture'}</button>`:`<div class="hn">🔒 Podium ${q.i+1}</div><p class="note" style="margin:0">Ce podium s’ouvre au niveau ${POD_LVL[q.i]}.</p>`;
  }
  if(b&&b.t==='q'){ const q=b.q; h=`<div class="hn">${q.title()}</div><div class="brow">`+q.btns().map(x=>`<button class="btn ${x.alt?'alt ':''}" data-a="${q.a||'growgo'}" data-id="${q.id}" data-v="${x.id}">${x.tx}</button>`).join('')+'</div>'; }
  if(b&&b.t==='d') h=`<div class="hn">🏁 Piste d’essai · tout le circuit de Spa</div><button class="btn wide" data-a="hubgo" data-id="ptdoor">Ouvrir la grande porte</button>`;
  if(b&&b.t==='s') h=labLv()<8?`<div class="hn">🔒 Cloison scellée</div><p class="note" style="margin:0">Quelque chose se cache derrière… Reviens au niveau 8.</p>`:`<div class="hn">🌿 Cloison suspecte…</div><button class="btn wide" data-a="hubgo" data-id="ranch">Pousser la cloison</button>`;
  if(HUB.nkey!==h){ HUB.nkey=h; el.innerHTML=h; el.classList.toggle('on',!!h); }
}
function vHub(){
  return `<div class="rwrap hubw"><div class="rs" id="hubslot" style="height:clamp(420px,calc(100vh - 150px),760px)"></div>
    <button class="hubback" data-a="${hubBackA()}" data-id="garage">← Retour</button><div class="growhud" id="growhud"></div><button class="bagbtn" data-a="inv">🎒</button><button class="bagbtn hlp" data-a="gtuto">?</button><button class="bagbtn mapb" data-a="wmap">🗺️</button><div class="joy" id="joy"><i id="joyK"></i></div><div class="hubhint">Joystick : marcher · Glisse à droite : regarder</div><div class="hubact" id="hubAct"></div></div>`;
}
function bindHub(){
  const slot=$('hubslot'); if(!slot) return;
  if(!glEnsure()){ slot.innerHTML='<p class="note" style="padding:20px">La 3D n’est pas disponible sur cet appareil.</p>'; return; }
  const sig=JSON.stringify([S.pod&&S.pod.slots,S.lvl,S.cars.map(c=>c.uid+c.mid),HUB.map||'garage']);
  if(!HUB.scene||HUB.sig!==sig){ if(HUB.scene) disposeScene(HUB.scene); hubBuild(); HUB.sig=sig; }
  HUB.nkey=''; HUB.inp.x=HUB.inp.z=0; glAttach('hubslot'); glRun(HUB.scene,HUB.cam,hubFrame,'hub'); GL.r.domElement.style.touchAction='none';
  const j=$('joy'), kn=$('joyK'); let id=null;
  const upd=e=>{ const r=j.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2; let dx=(e.clientX-cx)/(r.width/2), dy=(e.clientY-cy)/(r.height/2); const m=Math.hypot(dx,dy); if(m>1){dx/=m; dy/=m;}
    HUB.inp.x=Math.abs(dx)<.12?0:dx; HUB.inp.z=Math.abs(dy)<.12?0:dy; kn.style.transform=`translate(${dx*34}px,${dy*34}px)`; };
  j.addEventListener('pointerdown',e=>{ e.preventDefault(); id=e.pointerId; try{j.setPointerCapture(id);}catch(_){} upd(e); });
  j.addEventListener('pointermove',e=>{ if(e.pointerId===id) upd(e); });
  const end=e=>{ if(e.pointerId!==id) return; id=null; HUB.inp.x=HUB.inp.z=0; kn.style.transform=''; };
  j.addEventListener('pointerup',end); j.addEventListener('pointercancel',end);
  /* regarder : on glisse n'importe où sur la vue, hors du joystick */
  let lid=null, lx=0, ly=0;
  slot.addEventListener('pointerdown',e=>{ if(lid!=null) return; lid=e.pointerId; lx=e.clientX; ly=e.clientY; try{slot.setPointerCapture(lid);}catch(_){} });
  slot.addEventListener('pointermove',e=>{ if(e.pointerId!==lid) return; HUB.yaw-=(e.clientX-lx)*.0055; HUB.pit=clamp(HUB.pit-(e.clientY-ly)*.0045,-1.1,1.1); lx=e.clientX; ly=e.clientY; });
  const le=e=>{ if(e.pointerId===lid) lid=null; }; slot.addEventListener('pointerup',le); slot.addEventListener('pointercancel',le);
  if(!HUB.kb){ HUB.kb=true;
    document.addEventListener('keydown',e=>{ if(view!=='hub'||sheet) return; HUB.keys[e.code]=true; if(e.code.startsWith('Arrow')) e.preventDefault(); });
    document.addEventListener('keyup',e=>{ HUB.keys[e.code]=false; }); }
}
ACT.hubgo=d=>{
  const id=d.id;
  if(id.startsWith('pod')){ const i=+id.slice(3); if(S.lvl>=POD_LVL[i]) openSheet({t:'slot',i}); return; }
  if(id==='ptdoor'){ return ACT.ptest(); }
  if(id==='ranch'){ ACT.ranch(); return; }
  if(id==='meca'){ const fr=fleetRepair(); if(!fr) return toast('Ton garage est déjà en parfait état'); ACT.fleetrep(); return; }
  ACT.tab({id});
};
ACT.prep_rep=d=>{
  const c=car(+d.id); if(!c) return; const u=repUnit(c), pts=Math.min(100-c.etat,Math.floor(S.cr/u));
  if(pts<1) return toast('Pas assez de crédits');
  S.cr-=Math.ceil(pts*u); c.etat+=pts; bump('repN');
  if(c.etat>=100){ c.etat=100; S.stats.repFull++; toast(M[c.mid].nom+' remise à neuf'); } else toast(`État remonté à ${c.etat} %`);
  save(); render();
};

/* ---- décor du garage : sol balisé, chemins, plantes, pneus, outils, ponts élévateurs ---- */
function hubInst(sc,geo,mat,items){
  if(!items.length) return null; const m=new THREE.InstancedMesh(geo,mat,items.length), d=new THREE.Object3D();
  items.forEach((a,i)=>{ d.position.set(a[0],a[1],a[2]); d.rotation.set(0,a[3]||0,0); d.scale.set(a[4]||1,a[5]||a[4]||1,a[6]||a[4]||1); d.updateMatrix(); m.setMatrixAt(i,d.matrix); });
  m.instanceMatrix.needsUpdate=true; m.frustumCulled=false; sc.add(m); return m;
}
function hubDecor(sc,HX,HZ,neon,box){
  const Lm=c=>new THREE.MeshLambertMaterial({color:c}), flat=(w,h,x,y,z,ry,mat)=>{ const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),mat); m.position.set(x,y,z); m.rotation.order='YXZ'; m.rotation.set(0,ry||0,0); sc.add(m); return m; };
  const obs=(x,z,r)=>HUB.obs.push({x,z,r}), obb=(x0,x1,z0,z1)=>HUB.obs.push({x0,x1,z0,z1});
  /* chemins fléchés vers chaque stand */
  const chev=ctex(128,64,(x,W,H)=>{ x.strokeStyle='#fff'; x.lineWidth=11; x.lineCap='round'; x.lineJoin='round'; x.beginPath(); x.moveTo(36,12); x.lineTo(84,32); x.lineTo(36,52); x.stroke(); });
  const path=(len,wd,x,z,th,col)=>{ const t=chev.clone(); t.needsUpdate=true; t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(len/2.2,1);
    const m=new THREE.Mesh(new THREE.PlaneGeometry(len,wd),new THREE.MeshBasicMaterial({map:t,color:col,transparent:true,opacity:.85,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));
    m.rotation.order='YXZ'; m.rotation.set(-Math.PI/2,th,0); m.position.set(x,.03,z); sc.add(m); };
  path(38,3,0,5,Math.PI/2,0x00e5ff);
  path(29,2.4,-15,-4,Math.PI,0xff2bd6); path(29,2.4,15,-4,0,0xfcee0a);
  path(29,2.4,-15,11,Math.PI,0xff9a1a); path(29,2.4,15,11,0,0xa58bff);
  path(10,2.4,-16,16,-Math.PI/2,0x3cff9e); path(10,2.4,16,16,-Math.PI/2,0x00e5ff);
  /* emblème au centre */
  const em=ctex(256,256,(x,W,H)=>{ x.translate(W/2,H/2); ['#00E5FF','#FF2BD6','#FCEE0A'].forEach((c,i)=>{ x.strokeStyle=c; x.lineWidth=10; x.beginPath(); x.arc(0,0,112-i*26,i*2,i*2+4.2); x.stroke(); }); x.fillStyle='#fff'; x.font='700 52px sans-serif'; x.textAlign='center'; x.textBaseline='middle'; x.fillText('R&G',0,4); });
  const emm=new THREE.Mesh(new THREE.CircleGeometry(6.5,40),new THREE.MeshBasicMaterial({map:em,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3})); emm.rotation.x=-Math.PI/2; emm.position.set(0,.04,-1); sc.add(emm);
  /* plinthes jaunes et noires le long des murs */
  const hz=ctex(128,32,(x,W,H)=>{ x.fillStyle='#111'; x.fillRect(0,0,W,H); x.fillStyle='#e5b800'; for(let i=-2;i<10;i++){ x.beginPath(); x.moveTo(i*16,H); x.lineTo(i*16+16,0); x.lineTo(i*16+32,0); x.lineTo(i*16+16,H); x.fill(); } });
  [[0,-HZ+.05,0,HX*2],[0,HZ-.05,Math.PI,HX*2],[-HX+.05,0,Math.PI/2,HZ*2],[HX-.05,0,-Math.PI/2,HZ*2]].forEach(a=>{ const t=hz.clone(); t.needsUpdate=true; t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(a[3]/2,1); const m=new THREE.Mesh(new THREE.PlaneGeometry(a[3],.5),new THREE.MeshBasicMaterial({map:t})); m.position.set(a[0],.25,a[1]); m.rotation.y=a[2]; sc.add(m); });
  /* piliers rayés */
  [-14,14].forEach(px=>[-8,8].forEach(pz=>{ const t=hz.clone(); t.needsUpdate=true; t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(2,1); box(1.34,1.1,1.34,px,.55,pz,new THREE.MeshBasicMaterial({map:t})); obs(px,pz,.95); }));
  /* pneus */
  const tg=new THREE.CylinderGeometry(.52,.52,.3,18), tm=Lm(0x15151b), tires=[];
  [[-33.6,-23.5,4],[-32,-24.2,3],[33.6,-23.5,4],[32,-24.2,3],[-26,24.6,3],[26,24.6,4],[-33.5,21.5,3],[33.5,21.5,4],[-4,24.7,3],[4,24.7,3]].forEach(a=>{ for(let k=0;k<a[2];k++) tires.push([a[0]+(k%2)*.06,.15+k*.3,a[1],k*.7]); obs(a[0],a[1],.8); });
  hubInst(sc,tg,tm,tires);
  /* bidons */
  const bg=new THREE.CylinderGeometry(.42,.42,1,14), br=[[-34,-13,0],[-34,-11.8,0],[34,-13,0],[34.2,-11.8,0],[-30,24.6,0],[30,24.6,0],[-34,3.6,0],[34,3.6,0]]; hubInst(sc,bg,Lm(0xc02a2a),br.filter((_,i)=>i%2===0).map(a=>[a[0],.5,a[1]]));
  hubInst(sc,bg,Lm(0x2a4fc0),br.filter((_,i)=>i%2===1).map(a=>[a[0],.5,a[1]])); br.forEach(a=>obs(a[0],a[1],.6));
  /* caisses */
  const cg=new THREE.BoxGeometry(1,1,1), cr=[[-34,-21,1],[-34,-19.6,.8],[34,-21,1],[33.9,-19.6,.8],[-23,24.6,1.1],[23,24.6,1.1]]; hubInst(sc,cg,Lm(0x8a6a3a),cr.map(a=>[a[0],a[2]/2,a[1],.3,a[2],a[2],a[2]])); cr.forEach(a=>obs(a[0],a[1],.8));
  /* pots de fleurs */
  const pg=new THREE.CylinderGeometry(.36,.27,.55,12), fg=new THREE.SphereGeometry(.46,10,8), pts=[];
  [24,17.5,6,-1.5,-8,-12.4].forEach(z=>[-3.4,3.4].forEach(x=>pts.push([x,z]))); [[-9,-1],[9,-1],[-9,8],[9,8],[-22,-12],[22,-12],[-22,6],[22,6],[-6,23.5],[6,23.5]].forEach(a=>pts.push(a));
  hubInst(sc,pg,Lm(0xb5532f),pts.map(a=>[a[0],.28,a[1]])); hubInst(sc,fg,Lm(0x2f9e4a),pts.map((a,i)=>[a[0],.9,a[1],0,1,.85,1]));
  const fgm=new THREE.SphereGeometry(.1,6,5); [0xff5fa8,0xfcee0a,0xffffff].forEach((c,ci)=>hubInst(sc,fgm,new THREE.MeshBasicMaterial({color:c}),pts.flatMap((a,i)=>[0,1,2].map(k=>{ const an=i*1.7+k*2.1+ci; return [a[0]+Math.cos(an)*.36,1.05+(k%2)*.1+ci*.06,a[1]+Math.sin(an)*.36]; }))));
  pts.forEach(a=>obs(a[0],a[1],.55));
  /* ponts élévateurs avec une voiture */
  const lift=(lx,lz,col)=>{ box(3.6,.14,6.6,lx,.07,lz,Lm(0x2a2d3a)); [-1,1].forEach(s=>box(.28,4.4,.28,lx+s*1.7,2.2,lz-1.2,Lm(0xd9b400)));
    box(3.2,.16,5.2,lx,1.5,lz,Lm(0x4a4f60)); box(2.1,.6,4.5,lx,2.1,lz,Lm(col)); box(1.8,.55,2.3,lx,2.68,lz+.2,Lm(0x16324a));
    const wg=new THREE.CylinderGeometry(.36,.36,.26,14); [[-1.05,1.4],[1.05,1.4],[-1.05,-1.4],[1.05,-1.4]].forEach(w=>{ const m=new THREE.Mesh(wg,Lm(0x111115)); m.rotation.x=Math.PI/2; m.rotation.z=Math.PI/2; m.position.set(lx+w[0],1.85,lz+w[1]); sc.add(m); });
    obb(lx-2,lx+2,lz-3.4,lz+3.4); };
  lift(-26.5,19,0xd0202a); lift(26.5,19,0x2a6fd0);
  /* établis et outils */
  const bench=(bx,bz)=>{ box(3.4,.12,1.2,bx,1,bz,Lm(0x8a6a3a)); [-1.5,1.5].forEach(s=>box(.12,1,1.0,bx+s,.5,bz,Lm(0x3a3d4a))); box(.9,.4,.5,bx-.9,1.32,bz,Lm(0xc02020)); box(.3,.3,.3,bx+1,1.2,bz,Lm(0xa0a6b0)); box(.12,.5,.12,bx+.2,1.3,bz,Lm(0xfcee0a)); obb(bx-1.8,bx+1.8,bz-.7,bz+.7); };
  bench(-10,24.8); bench(10,24.8);
  /* étagères */
  [-1,1].forEach(s=>{ const sx=s*34.8; [.5,1.4,2.3].forEach(y=>box(.7,.07,5,sx,y,19,Lm(0x555a70))); [-2.4,2.4].forEach(dz=>box(.08,2.5,.08,sx,1.25,19+dz,Lm(0x555a70)));
    [0,1,2].forEach(r=>[0,1,2,3].forEach(c=>box(.5,.4,.8,sx,.75+r*.9,17.2+c*1.2,Lm([0xff5fa8,0x3cff9e,0x00b8d4,0xfcee0a][(r+c)%4])))); obb(sx-.6,sx+.6,16.5,21.5); });
  /* panneaux muraux : outils et affiches */
  const peg=ctex(512,256,(x,W,H)=>{ x.fillStyle='#262a3e'; x.fillRect(0,0,W,H); x.strokeStyle='#33385a'; for(let i=0;i<W;i+=16){ x.beginPath(); x.moveTo(i,0); x.lineTo(i,H); x.stroke(); }
    for(let i=0;i<7;i++){ const px=30+i*68; x.fillStyle=['#c0c6d0','#d9b400','#d0202a','#00b8d4'][i%4]; x.fillRect(px,40,14,110); x.beginPath(); x.arc(px+7,40,20,0,7); x.fill(); x.fillStyle='#111'; x.beginPath(); x.arc(px+7,40,9,0,7); x.fill(); x.fillStyle='#8a6a3a'; x.fillRect(px+22,160,10,70); x.fillStyle='#c0c6d0'; x.fillRect(px+10,150,34,16); } });
  const pm=new THREE.MeshBasicMaterial({map:peg}); flat(7,3.4,-HX+.35,3.2,3.5,Math.PI/2,pm); flat(7,3.4,HX-.35,3.2,3.5,-Math.PI/2,pm); flat(7,3.4,-24,3.2,HZ-.35,Math.PI,pm); flat(7,3.4,24,3.2,HZ-.35,Math.PI,pm);
  const pos=ctex(256,360,(x,W,H)=>{ const g=x.createLinearGradient(0,0,0,H); g.addColorStop(0,'#2b0a5a'); g.addColorStop(1,'#ff2bd6'); x.fillStyle=g; x.fillRect(0,0,W,H); x.fillStyle='#00E5FF'; x.beginPath(); x.arc(W/2,120,60,0,7); x.fill(); x.fillStyle='#07051a'; x.fillRect(30,230,W-60,46); x.fillRect(60,250,W-120,60); x.fillStyle='#fff'; x.font='700 34px sans-serif'; x.textAlign='center'; x.fillText('ROUILLE',W/2,60); x.fillText('& GLOIRE',W/2,350); });
  const pm2=new THREE.MeshBasicMaterial({map:pos}); [-8,-16,-22].forEach(z=>{ flat(2.6,3.6,-HX+.35,4.3,z,Math.PI/2,pm2); flat(2.6,3.6,HX-.35,4.3,z,-Math.PI/2,pm2); });
  /* grande porte de piste */
  const dr=ctex(256,256,(x,W,H)=>{ x.fillStyle='#2a2d46'; x.fillRect(0,0,W,H); for(let i=0;i<8;i++){ x.fillStyle=i%2?'#343857':'#2a2d46'; x.fillRect(0,i*32,W,30); x.fillStyle='#1a1c30'; x.fillRect(0,i*32+30,W,2); } });
  flat(12,7,0,3.6,HZ-.35,Math.PI,new THREE.MeshBasicMaterial({map:dr})); box(12.6,.3,.3,0,7.2,HZ-.5,neon(0x3CFF9E)); [-6.3,6.3].forEach(s=>box(.3,7.2,.3,s,3.6,HZ-.5,neon(0x3CFF9E)));
  const dl=labelSprite('PISTE D’ESSAI','#3CFF9E',9); dl.material.depthTest=false; dl.renderOrder=20; dl.position.set(0,8.2,HZ-1); sc.add(dl);
  /* bancs au centre */
  [[-9,3],[9,3]].forEach(a=>{ box(3,.14,.9,a[0],.5,a[1],Lm(0x8a6a3a)); box(3,.8,.1,a[0],.95,a[1]-.4,Lm(0x6a4a2a)); [-1.2,1.2].forEach(s=>box(.1,.5,.8,a[0]+s,.25,a[1],Lm(0x23265a))); obb(a[0]-1.6,a[0]+1.6,a[1]-.6,a[1]+.6); });
  /* suspensions lumineuses */
  const lg=new THREE.ConeGeometry(.9,.6,18,1,true); const lamps=[]; for(let i=-3;i<=3;i++) for(let j=-1;j<=1;j++) lamps.push([i*10,9.9,j*14]);
  const lm=hubInst(sc,lg,new THREE.MeshBasicMaterial({color:0xffe9b0,side:THREE.DoubleSide}),lamps);
}

/* mode paysage obligatoire dans le garage */
function rotNow(on){
  try{ if(window.RGNative&&RGNative.setLandscape){ RGNative.setLandscape(on); return true; } }catch(_){}
  try{ const d=document.documentElement; const go=()=>screen.orientation&&screen.orientation.lock&&screen.orientation.lock(on?'landscape':'portrait').catch(()=>{});
    if(on&&!document.fullscreenElement&&d.requestFullscreen) d.requestFullscreen().then(go).catch(go); else go(); }catch(_){}
  return false;
}
ACT.rotok=()=>{ const ok=rotNow(true); const m=document.getElementById('rotmsg'); if(m) m.textContent=ok?'Rotation demandée…':'Ton application Android n’est pas à jour (ancienne version installée). Désinstalle-la puis réinstalle l’APK du dernier téléchargement.'; };
let hubWas=false;
function hubMode(){
  const on=view==='hub'; document.body.classList.toggle('hubmode',on);
  if(on!==hubWas){ hubWas=on; rotNow(on); if(!on){ try{ if(document.fullscreenElement) document.exitFullscreen(); }catch(_){} } }
  let o=document.getElementById('rotov');
  if(!o){ o=document.createElement('div'); o.id='rotov'; o.innerHTML='<div><div style="font-size:54px">📱↻</div><p>Tourne ton téléphone en mode paysage pour entrer dans le garage.</p><p id="rotmsg" style="font-size:13px;color:#FF8BEA"></p><button class="btn" data-a="rotok" style="min-width:140px">OK</button><br><button class="btn alt" data-a="tab" data-id="garage">← Retour</button></div>'; document.body.appendChild(o); }
}
/* ===== v0.18 : boîte de vitesses (drag), drift (circuits + épreuves de drift) ===== */
const GFR=[.28,.46,.64,.82,1], GK=[1.5,1.25,1.05,.92,.82];
function gearK(r,dt){
  if(!r.drag) return 1;
  if(r.shiftT>0) r.shiftT-=dt; if(r.gBoost>0) r.gBoost-=dt;
  const vg=r.VM*GFR[r.gear-1]*(r.nitroT>0?1.12:1), f=r.v/vg; r.rpmF=f;
  if(r.autoG&&r.shiftT<=0&&r.gear<5&&f>=r.shAt){ r.gear++; r.shiftT=.16; return 0; }
  const pw=f<.3?.6+f*1.3:f<.88?1:f<1?1-(f-.88)*3:.25;
  return r.shiftT>0?0:GK[r.gear-1]*pw*(r.gBoost>0?1.18:1);
}
function shiftGear(r,d){
  if(!r||!r.drag||!r.go||r.fin!=null||r.shiftT>0||r.autoG) return;
  const ng=clamp(r.gear+d,1,5); if(ng===r.gear) return; const f=r.rpmF||0;
  if(d>0){ if(f>=.82&&f<=1.02){ r.gBoost=1.3; r.msg2='perfect'; r.gp++; } else if(f>1.02){ r.shiftT=.4; r.msg2='over'; } else if(f<.55) r.msg2='early'; }
  else if(r.v/(r.VM*GFR[ng-1])>1.15){ r.msg2='over'; r.shiftT=.45; }
  r.gear=ng; r.shiftT=Math.max(r.shiftT,.16); try{navigator.vibrate&&navigator.vibrate(18);}catch(_){}
}
function dragMsg(P){
  if(!P.drag) return;
  const m=P.msg2; P.msg2=null;
  if(m==='perfect') flash('Rapport parfait','#3CFF9E',.7); else if(m==='over') flash('Sur-régime','#FF4D6D',.8); else if(m==='early') flash('Trop tôt','#FCEE0A',.6);
  else if(!P.autoG&&P.go&&P.fin==null&&P.gear<5&&P.rpmF>.97&&(!RC.flash||RC.clock>=RC.flash.until)) flash('Rapport sup. !','#FCEE0A',.35);
}
function shiftPad(auto){
  return `<div class="shiftp"><button id="pUp" ${auto?'disabled':''}>▲<small>${auto?'Auto':'Rapport sup.'}</small></button><button id="pDn" ${auto?'disabled':''}>▼<small>${auto?'Auto':'Rétrograder'}</small></button></div>`;
}
function hudGear(){ return (RC&&RC.kind==='race'&&RC.mn.d==='drag')?'<span class="gear" id="hGear">1</span><span class="rpm" id="hRpm"></span>':''; }
function hudGearUpd(P){
  if(!P.drag) return; const g=$('hGear'); if(!g) return;
  const t=String(P.gear), rp=Math.round((900+clamp(P.rpmF,0,1.08)*7600)/50)*50;
  if(g._t!==t){g._t=t; g.textContent=t;} const r=$('hRpm'), rt=fmt(rp)+' tr/min'; if(r&&r._t!==rt){r._t=rt; r.textContent=rt;}
  const hot=!P.autoG&&P.rpmF>.96; g.classList.toggle('hot',hot);
}
function bindShift(){
  const up=$('pUp'), dn=$('pDn'); if(!up||!dn) return;
  up.addEventListener('pointerdown',e=>{e.preventDefault(); shiftGear(RC.P,1); up.classList.add('on');});
  dn.addEventListener('pointerdown',e=>{e.preventDefault(); shiftGear(RC.P,-1); dn.classList.add('on');});
  [up,dn].forEach(b=>{ const off=()=>b.classList.remove('on'); b.addEventListener('pointerup',off); b.addEventListener('pointercancel',off); b.addEventListener('contextmenu',e=>e.preventDefault()); });
}
/* ---- drift ---- */
function driftBank(d,P){
  const g=Math.round(d.chain*d.mult); d.live=false;
  if(g>0){ d.pts+=g; d.best=Math.max(d.best,g); d.n++; if(g>=150) flash('Drift +'+fmt(g),'#FF2BD6',1.1); }
  if(d.t>=1.5&&RC.mn.d!=='drift'&&P.boostT<1){ P.boostT=1.0; flash('Drift boost','#00E5FF',.9); }
  d.chain=0; d.t=0; d.mult=1; d.grace=0;
}
function driftTick(P,h){
  const d=P.dr; if(!d||!P.go||P.fin!=null) return;
  const sl=Math.abs(P.slipAng||0), on=P.surf>=6&&P.v>10&&sl>.17&&sl<1.3;
  if(P.hitFlash>.6&&d.live){ d.chain*=.25; driftBank(d,P); return; }
  if(on){ d.live=true; d.t+=h; d.grace=.55; d.chain+=P.v*sl*h*6; d.mult=1+Math.min(5,Math.floor(d.t/1.4)); }
  else if(d.live){ d.grace-=h; if(d.grace<=0) driftBank(d,P); }
}
function hudDrift(P){
  const d=P.dr, el=$('hDrift'); if(!d||!el) return;
  const mode=RC.mn.d==='drift', live=d.live?Math.round(d.chain*d.mult):0;
  let txt=''; if(d.live) txt=`DRIFT ×${d.mult}  +${fmt(live)}`; else if(mode) txt='Drift : glisse dans les virages';
  if(el._t!==txt){el._t=txt; el.textContent=txt; el.classList.toggle('on',d.live);}
  if(mode){ sT('hPos',fmt(d.pts+live)+' pts'); sT('hGap',RC.dlim?`Reste ${Math.max(0,Math.ceil(RC.dlim-RC.clock))} s`:''); }
}
function driftRow(P,c){
  const mn=RC.mn, d=P.dr; if(d.live) driftBank(d,P);
  const pts=Math.round(RC.auto?indice(c,mn)*110*rnd(.94,1.06):d.pts*({RWD:1.15,AWD:1,FWD:.85}[P.r.m.tr]||1));
  const ot=RC.Os.map(o=>({nom:o.pil+' ('+o.r.nom+')',t:-Math.round(indice(o.r.c,mn)*110*rnd(.85,1.15))}));
  const row=mkRow(mn,c,-pts,ot,{jury:true,an:P.r.nom,hits:P.hits,xpB:P.r.xB||0}); row.a=pts; row.b=-row.b; return row;
}
/* ===== v0.20 : Le Ranch & l'Atelier caché (culture, réseau illégal, livraisons en voiture) — jeu de fiction ===== */
const STR=[ /* id, nom, type, THC %, veg min, floraison min, rendement g/plante, prix cr/g, lumens idéaux, soif, difficulté, rép. requise, prix graine */
 {id:'nl',nom:'Northern Lights',ty:'Indica',thc:18,veg:2.5,fl:7.5,y:34,px:5,lm:32000,eau:1.0,d:1,rep:0,sd:120,ic:'🌙'},
 {id:'ww',nom:'White Widow',ty:'Hybride',thc:19,veg:2.5,fl:8,y:32,px:6,lm:34000,eau:1.0,d:1,rep:0,sd:150,ic:'🤍'},
 {id:'ak',nom:'AK-47',ty:'Hybride',thc:20,veg:2.7,fl:8,y:36,px:6.5,lm:36000,eau:1.0,d:2,rep:2,sd:190,ic:'🔫'},
 {id:'cm',nom:'Critical Mass',ty:'Indica',thc:19,veg:2.7,fl:8,y:48,px:5.5,lm:36000,eau:1.2,d:2,rep:4,sd:230,ic:'⚖️'},
 {id:'bd',nom:'Blue Dream',ty:'Sativa',thc:20,veg:3,fl:9.5,y:46,px:7,lm:40000,eau:1.1,d:2,rep:6,sd:280,ic:'💙'},
 {id:'og',nom:'OG Kush',ty:'Hybride',thc:23,veg:3,fl:8.5,y:30,px:9,lm:42000,eau:1.0,d:3,rep:10,sd:360,ic:'🌲'},
 {id:'gp',nom:'Granddaddy Purple',ty:'Indica',thc:20,veg:3,fl:8,y:34,px:8,lm:40000,eau:.95,d:3,rep:12,sd:380,ic:'🍇'},
 {id:'jh',nom:'Jack Herer',ty:'Sativa',thc:20,veg:3.2,fl:9.5,y:38,px:8.5,lm:44000,eau:1.0,d:3,rep:14,sd:420,ic:'🧑‍🌾'},
 {id:'ph',nom:'Purple Haze',ty:'Sativa',thc:19,veg:3.2,fl:9,y:34,px:8,lm:44000,eau:1,d:3,rep:16,sd:430,ic:'🟣'},
 {id:'gs',nom:'Girl Scout Cookies',ty:'Hybride',thc:25,veg:3.2,fl:9,y:34,px:11,lm:48000,eau:1.0,d:4,rep:20,sd:600,ic:'🍪'},
 {id:'sd',nom:'Sour Diesel',ty:'Sativa',thc:21,veg:3.5,fl:10,y:40,px:10,lm:50000,eau:1.1,d:4,rep:24,sd:640,ic:'⛽'},
 {id:'dp',nom:'Durban Poison',ty:'Sativa',thc:22,veg:3.4,fl:9,y:38,px:10.5,lm:50000,eau:.9,d:4,rep:28,sd:680,ic:'🌍'},
 {id:'zk',nom:'Zkittlez',ty:'Indica',thc:23,veg:3.2,fl:8.5,y:30,px:12.5,lm:46000,eau:1,d:4,rep:32,sd:760,ic:'🍬'},
 {id:'gg',nom:'Gorilla Glue #4',ty:'Hybride',thc:27,veg:3.5,fl:9,y:42,px:14,lm:52000,eau:1.1,d:5,rep:40,sd:950,ic:'🦍'},
 {id:'wc',nom:'Wedding Cake',ty:'Hybride',thc:25,veg:3.5,fl:9,y:36,px:13.5,lm:52000,eau:1,d:5,rep:48,sd:980,ic:'🎂'},
 {id:'am',nom:'Amnesia Haze',ty:'Sativa',thc:22,veg:3.8,fl:11,y:44,px:13,lm:56000,eau:1.2,d:5,rep:56,sd:1050,ic:'🌫️'},
 {id:'ge',nom:'Gelato',ty:'Hybride',thc:26,veg:3.6,fl:9,y:34,px:16,lm:54000,eau:1,d:5,rep:64,sd:1250,ic:'🍨'}
];
const SID={}; STR.forEach(s=>SID[s.id]=s);
const LAMP=[ /* lumens par emplacement, watts, chaleur */
 {id:'t5',nom:'Néon T5',lm:9000,w:55,h:.4,px:300,ic:'💡'},
 {id:'led',nom:'LED blanche 100 W',lm:22000,w:100,h:.6,px:900,ic:'🔆'},
 {id:'led2',nom:'LED spectre complet 240 W',lm:38000,w:240,h:.9,px:2800,ic:'🌈'},
 {id:'cmh',nom:'Iodure céramique 315 W',lm:50000,w:315,h:1.3,px:5200,ic:'🟡'},
 {id:'hps',nom:'Sodium HPS 600 W',lm:78000,w:600,h:2.2,px:7800,ic:'🟠'},
 {id:'ledp',nom:'LED Pro 480 W',lm:95000,w:480,h:1.2,px:16000,ic:'⚡'}
];
const LID={}; LAMP.forEach(l=>LID[l.id]=l);
const MED={terreau:{nom:'Terreau',ic:'🟤',eau:1,sp:1,y:1,ph:6.3,px:0},coco:{nom:'Fibre de coco',ic:'🥥',eau:1.3,sp:1.1,y:1.08,ph:5.9,px:25},hydro:{nom:'Hydroponie',ic:'💧',eau:1.7,sp:1.25,y:1.18,ph:5.8,px:70}};
const CHEM={
 N:{nom:'Azote (N)',sub:'urée / nitrate d’ammonium',px:14,ic:'🟩'},P:{nom:'Phosphore (P)',sub:'superphosphate',px:16,ic:'🟧'},K:{nom:'Potassium (K)',sub:'sulfate de potasse',px:15,ic:'🟪'},
 CM:{nom:'Calcium-Magnésium',sub:'anti-carence',px:20,ic:'⚪'},PHm:{nom:'pH −',sub:'acide phosphorique dilué',px:10,ic:'🔻'},PHp:{nom:'pH +',sub:'carbonate de potassium',px:10,ic:'🔺'},
 BOOST:{nom:'Booster floraison',sub:'PK 13-14',px:90,ic:'🚀'},ENZ:{nom:'Enzymes racinaires',sub:'racines + vitesse',px:60,ic:'🧪'},
 FONG:{nom:'Fongicide',sub:'soufre / bicarbonate',px:40,ic:'🍄'},INSEC:{nom:'Insecticide',sub:'savon / neem',px:40,ic:'🐛'}
};
const ILL=[
 {id:'x1',nom:'Go-fast Bruxelles → Anvers',ill:'cargo',lvl:3,rep:3,gain:1500,xp:60,cargo:40,prem:2.1,heat:14,opp:{t:[1,2],up:0,etat:[45,75]},manches:[{d:'circuit',m:'sec',sp:'s1'}],txt:'Une manche. 40 g à livrer avant les flics.'},
 {id:'x2',nom:'Livraison de nuit',ill:'cargo',lvl:4,rep:8,gain:2600,xp:90,cargo:70,prem:2.2,heat:18,opp:{t:[1,3],up:1,etat:[55,85]},manches:[{d:'rallye',m:'pluie'}],txt:'Chemins de campagne sous la pluie, 70 g.'},
 {id:'x3',nom:'Convoi de la frontière',ill:'cargo',lvl:7,rep:20,gain:7000,xp:200,cargo:150,prem:2.5,heat:26,opp:{t:[3,4],up:2,etat:[75,100]},manches:[{d:'circuit',m:'pluie',sp:'s2'},{d:'endurance',m:'sec'}],txt:'Deux manches, 150 g, gros risque.'},
 {id:'x4',nom:'Go-fast Marseille express',ill:'cargo',lvl:10,rep:45,gain:18000,xp:420,cargo:300,prem:2.8,heat:34,opp:{t:[4,5],up:2,etat:[90,100]},manches:[{d:'circuit',m:'sec',sp:'s4'},{d:'rallye',m:'sec'},{d:'drag',m:'sec'}],txt:'Trois manches, 300 g. Le gros coup.'},
 {id:'b1',nom:'Course du parking (mise 1 000)',ill:'bet',bet:1000,lvl:2,rep:0,gain:1200,xp:40,heat:6,opp:{t:[1,1],up:0,etat:[40,65]},manches:[{d:'drag',m:'sec'}],txt:'Course clandestine. Tu mises 1 000 cr.'},
 {id:'b2',nom:'Drift de nuit (mise 3 000)',ill:'bet',bet:3000,lvl:5,rep:6,gain:3600,xp:110,heat:8,opp:{t:[2,3],up:1,etat:[60,90]},manches:[{d:'drift',m:'sec'}],txt:'Seul le meilleur score ramasse la mise.'},
 {id:'b3',nom:'Touge illégale (mise 8 000)',ill:'bet',bet:8000,lvl:8,rep:18,gain:9000,xp:240,heat:12,opp:{t:[3,4],up:2,etat:[80,100]},manches:[{d:'circuit',m:'pluie',sp:'s3'},{d:'drift',m:'sec'}],txt:'Deux manches, grosse mise.'},
 {id:'b4',nom:'Le Grand Jeu (mise 25 000)',ill:'bet',bet:25000,lvl:11,rep:40,gain:30000,xp:520,heat:16,opp:{t:[5,6],up:3,etat:[100,100]},manches:[{d:'drag',m:'sec'},{d:'circuit',m:'sec',sp:'tour'},{d:'drift',m:'sec'}],txt:'Trois manches contre l’élite.'}
];
ILL.forEach(e=>EVENTS.push(e));
const ROOMS={atelier:{nom:'Atelier caché',ic:'🏚️',slots:6,max:12,out:false,heat:1},ranch:{nom:'Ranch',ic:'🌾',slots:8,max:24,out:true,heat:1.6}};
function farm(){
  const F=S.farm||(S.farm={found:0,rep:0,seeds:{},chem:{N:6,P:6,K:6,CM:2,PHm:2,PHp:2,BOOST:0,ENZ:0,FONG:1,INSEC:1},lamps:{t5:2,led:0},stock:{},dry:[],water:80,tank:200,tick:Date.now(),
    heat:{atelier:0,ranch:0},rooms:{atelier:{on:1,slots:[],fan:0,filter:0,irri:0},ranch:{on:0,slots:[],fan:0,filter:0,irri:0}},stats:{harv:0,sold:0,raids:0,deliv:0,busted:0}});
  for(const k in ROOMS){ const r=F.rooms[k]; while(r.slots.length<ROOMS[k].slots+(r.extra||0)) r.slots.push(null); }
  return F;
}
const nz=(v,m)=>Math.max(0,Math.min(m,v));
const band=(v,lo,hi)=>v<lo?v/lo:v>hi?Math.max(0,1-(v-hi)/(100-hi)):1;
function lampLm(room,sl){ if(ROOMS[room].out){ const d=Math.floor(Date.now()/864e5); return 36000+9000*Math.sin(d*1.7); } return sl.lamp?LID[sl.lamp].lm:0; }
function newPlant(sid,med,lamp){ return {sid,med,lamp,st:'germ',stAge:0,age:0,w:70,N:50,P:50,K:50,ph:MED[med].ph+(Math.random()-.5)*.4,hp:100,q:60,pest:null,prot:0,cyc:18,rip:0,boost:0,enz:0}; }
function plantFit(room,sl){
  const sv=SID[sl.sid], md=MED[sl.med], L=lampLm(room,sl), stF={germ:.3,veg:.65,flo:1,ready:1}[sl.st];
  const ideal=sv.lm*stF, lf=L<=0?0:L<ideal?Math.max(.1,L/ideal):L>ideal*1.35?Math.max(.2,1-(L-ideal*1.35)/ideal):1;
  const nf=(band(sl.N,35,80)+band(sl.P,35,80)+band(sl.K,35,80))/3, wf=band(sl.w,30,88), pf=Math.max(0,1-Math.abs(sl.ph-md.ph)/1.4);
  const cf=sl.st==='flo'?(sl.cyc===12?1:.35):sl.st==='veg'?(sl.cyc===18?1:.6):1;
  return {lf,nf,wf,pf,cf,L,ideal};
}
function stepSlot(room,sl,dt,F){
  if(!sl||sl.st==='ready'){ if(sl&&sl.st==='ready'){ sl.rip+=dt; if(sl.rip>4) sl.q=Math.max(10,sl.q-dt*2); } return; }
  const sv=SID[sl.sid], md=MED[sl.med], f=plantFit(room,sl), irri=F.rooms[room].irri;
  if(sl.prot>0) sl.prot-=dt; if(sl.boost>0) sl.boost-=dt; if(sl.enz>0) sl.enz-=dt;
  if(irri&&sl.w<38&&F.tank>=3){ sl.w=Math.min(90,sl.w+30); F.tank-=3; }
  sl.w=nz(sl.w-dt*(3.2*sv.eau*md.eau)*(sl.st==='flo'?1.25:1)*(room==='ranch'?1.25:1),100);
  const dm=sl.st==='flo'?[.9,2.5,1.9]:sl.st==='veg'?[2.3,.8,1.5]:[.4,.4,.4];
  sl.N=nz(sl.N-dt*dm[0]*sv.eau,100); sl.P=nz(sl.P-dt*dm[1]*sv.eau,100); sl.K=nz(sl.K-dt*dm[2]*sv.eau,100);
  sl.ph+=(Math.random()-.5)*.02*dt+((7-sl.ph)*.004*dt);
  const comp=f.lf*.34+f.nf*.26+f.wf*.16+f.pf*.14+f.cf*.1, boost=sl.boost>0?1.15:1;
  sl.hp=nz(sl.hp+(comp-.6)*5*dt-(sl.pest?3*dt:0)-(sl.w>96?1*dt:0)-(f.lf>.99&&f.L>f.ideal*1.35?.8*dt:0),100);
  sl.q=nz(sl.q+((comp*100*boost+(sl.st==='flo'&&sl.cyc===12?4:0))-sl.q)*.05*dt,100);
  if(sl.hp<=0){ sl.st='dead'; return; }
  const sp=(.3+.7*f.lf)*(.5+.5*f.nf)*(.55+.45*f.wf)*(.7+.3*f.pf)*f.cf*md.sp*(sl.enz>0?1.2:1)*(sl.boost>0?1.1:1);
  const need={germ:1,veg:sv.veg,flo:sv.fl}[sl.st]; sl.stAge+=dt*sp; sl.age+=dt;
  if(sl.st==='germ'&&sl.stAge>=need){ sl.st='veg'; sl.stAge=0; }
  else if(sl.st==='flo'&&sl.stAge>=need){ sl.st='ready'; sl.rip=0; }
  if(!sl.pest&&sl.prot<=0){ const R=ROOMS[room], hum=(room==='ranch'?1.6:1)*(1-.2*Math.min(3,F.rooms[room].fan))*(sl.st==='flo'?1.4:1), pr=(.012+.01*sv.d*.3)*hum*dt; if(Math.random()<pr) sl.pest=Math.random()<.6?'mold':'mites'; }
}
function roomHeatTarget(room,F){
  const r=F.rooms[room]; let t=0;
  r.slots.forEach(sl=>{ if(sl&&sl.st==='flo') t+=4.5; else if(sl&&sl.st==='ready') t+=5.5; else if(sl&&sl.st==='veg') t+=1; });
  const lam=ROOMS[room].out?0:r.slots.reduce((a,sl)=>a+(sl&&sl.lamp?LID[sl.lamp].h:0),0)*1.2;
  return Math.min(100,(t*ROOMS[room].heat+lam)*Math.max(.15,1-.2*r.filter)*(1-clamp(karma(),-50,50)/250)+(ROOMS[room].out?4:0));
}
function ranchSim(){
  const F=farm(), now=Date.now(); let dt=Math.min((now-F.tick)/60000,600); F.tick=now; if(dt<=0) return;
  let left=dt, ch=0;
  while(left>1e-4){
    const d=Math.min(left,.5); left-=d; ch++;
    for(const room in ROOMS){ const R=F.rooms[room]; if(!R.on) continue;
      let watts=0; R.slots.forEach(sl=>{ if(sl&&sl.lamp&&sl.st!=='dead'&&sl.st!=='ready'&&!ROOMS[room].out) watts+=LID[sl.lamp].w; });
      const cost=watts/100*d; if(cost>0){ if(S.cr>=cost) S.cr-=cost; else { R.slots.forEach(sl=>{ if(sl&&sl.lamp) sl.w=sl.w; }); continue; } }
      R.slots.forEach(sl=>stepSlot(room,sl,d,F));
      const tg=roomHeatTarget(room,F); F.heat[room]+=(tg-F.heat[room])*Math.min(1,.12*d);
      if(F.heat[room]>60&&Math.random()<(F.heat[room]-60)/100*.04*d) ranchRaid(room,F);
    }
    if(F.water<F.tank) F.water=Math.min(F.tank,F.water+d*(F.rooms.ranch.on?.8:0));
    F.dryT=(F.dryT||0)+d;
  }
  F.dry=F.dry||[]; for(let i=F.dry.length-1;i>=0;i--){ F.dry[i].t-=dt; if(F.dry[i].t<=0){ const b=F.dry.splice(i,1)[0]; const st=F.stock[b.sid]||(F.stock[b.sid]={g:0,q:0}); st.q=(st.q*st.g+b.q*b.g)/Math.max(1,st.g+b.g); st.g+=b.g; } }
}
function ranchRaid(room,F){
  F.heat[room]=22; F.stats.raids++; karmaAdd(-4); const R=F.rooms[room], lost=[];
  R.slots.forEach((sl,i)=>{ if(sl&&(sl.st==='flo'||sl.st==='ready')&&Math.random()<.7){ lost.push(SID[sl.sid].nom); R.slots[i]=null; } });
  const fine=Math.round(S.cr*.12); S.cr-=fine; for(const k in F.stock) F.stock[k].g=Math.floor(F.stock[k].g*.6);
  banner(`🚨 <b>Descente de police</b> à ${ROOMS[room].nom} !<br>${lost.length} plantes saisies, 40 % du stock perdu, amende ${fmt(fine)} cr.`);
}
function banner(html){
  let b=document.getElementById('rbn'); if(!b){ b=document.createElement('div'); b.id='rbn'; document.body.appendChild(b); }
  b.innerHTML=html; b.classList.add('on'); clearTimeout(banner.t); banner.t=setTimeout(()=>b.classList.remove('on'),7000);
}
function sellPrice(sid,q){ const sv=SID[sid]; return 2.5*sv.px*(.55+.9*q/100)*(.85+.15*sv.thc/20)*(1+Math.max(0,-karma())/400); }
function stockTotal(){ const F=farm(); let g=0; for(const k in F.stock) g+=F.stock[k].g; return g; }
/* ---------- interface ---------- */
let RY={tab:'atelier',slot:null,pick:null,shop:'seeds',sel:null,down:false,lastTick:0};
const rBar=(v,c,l)=>`<div class="rb"><span>${l}</span><i style="width:${Math.round(nz(v,100))}%;background:${c}"></i></div>`;
function ranchHead(){
  const F=farm(), h=Math.max(F.heat.atelier,F.heat.ranch);
  return `<div class="rhd"><b>🌿 Réseau</b><span>${fmt(S.cr)} cr</span><span>Rép. ${fmt(F.rep)}</span><span class="${h>60?'hot':''}">Chaleur ${Math.round(h)} %</span></div>
  <div class="rtabs">${[['atelier','🏚️ Atelier'],['ranch','🌾 Ranch'],['shop','🛒 Boutique'],['stock','📦 Stock'],['net','🚗 Réseau']].map(t=>`<button class="${RY.tab===t[0]?'on':''}" data-a="rtab" data-id="${t[0]}">${t[1]}</button>`).join('')}</div>`;
}
function ranchSheet(X){
  if(!sheet||sheet.t!=='ranch') return false;
  ranchSim(); const F=farm(); let h=X+ranchHead();
  if(RY.tab==='atelier'||RY.tab==='ranch') h+=RY.slot!=null?rSlotView(RY.tab,RY.slot):rRoomView(RY.tab);
  else if(RY.tab==='shop') h+=rShop(); else if(RY.tab==='stock') h+=rStock(); else h+=rNet();
  const sc=$('sheet').scrollTop; $('sheet').innerHTML=h; $('sheet').scrollTop=sc; return true;
}
function rRoomView(room){
  const F=farm(), R=F.rooms[room], RM=ROOMS[room];
  if(!R.on) return `<div class="rcard"><h3>${RM.ic} ${RM.nom}</h3><p>Une grande ferme à l’écart de la ville : lumière du soleil gratuite, jusqu’à ${RM.max} parcelles, mais bien plus visible pour la police.</p><button class="btn wide" data-a="rbuyranch" ${S.cr<30000||F.rep<12?'disabled':''}>Acheter le ranch — 30 000 cr (rép. 12)</button></div>`;
  const heat=F.heat[room];
  let h=`<div class="rcard"><div class="rrow"><b>${RM.ic} ${RM.nom}</b><span>Chaleur ${Math.round(heat)} %</span></div>${rBar(heat,heat>60?'#FF4D6D':heat>35?'#FCEE0A':'#3CFF9E','Police')}
  <div class="rrow sm"><span>💧 Citerne ${Math.round(F.tank?F.water:0)} / ${F.tank} L</span><button class="btn alt sm" data-a="rwater">Remplir (1 cr/L)</button></div>
  <div class="rrow sm"><span>🌀 Ventil. ${R.fan} · 🧯 Filtre ${R.filter} · 🚿 Irrig. ${R.irri?'oui':'non'}</span><button class="btn alt sm" data-a="rtab" data-id="shop" data-v="gear">Matériel</button></div></div>
  <div class="rgrid">`;
  R.slots.forEach((sl,i)=>{
    if(!sl){ h+=`<button class="rslot empty" data-a="rslot" data-id="${i}"><span class="ri">＋</span><small>Planter</small></button>`; return; }
    const sv=SID[sl.sid]; let pc=sl.st==='ready'?100:sl.st==='dead'?0:Math.round(nz(sl.stAge/({germ:1,veg:sv.veg,flo:sv.fl}[sl.st]||1)*100,100));
    const lab={germ:'Germination',veg:'Croissance',flo:'Floraison',ready:'Prête !',dead:'Morte'}[sl.st];
    h+=`<button class="rslot ${sl.st==='ready'?'ready':''} ${sl.pest?'sick':''}" data-a="rslot" data-id="${i}"><span class="ri">${sv.ic}</span><b>${sv.nom}</b><small>${lab}${sl.pest?' ⚠️':''}</small><div class="rb sm"><i style="width:${pc}%;background:#00E5FF"></i></div><div class="rb sm"><i style="width:${Math.round(sl.hp)}%;background:#3CFF9E"></i></div></button>`;
  });
  return h+'</div>'+(R.slots.length<RM.max?`<button class="btn alt wide" data-a="rbuyslot" data-id="${room}">+1 emplacement — ${fmt(1500+R.slots.length*900)} cr</button>`:'');
}
function rSlotView(room,i){
  const F=farm(), R=F.rooms[room], sl=R.slots[i];
  let h=`<button class="btn alt sm" data-a="rback">← Retour</button>`;
  if(!sl){
    const seeds=STR.filter(s=>(F.seeds[s.id]||0)>0), P=RY.pick||{};
    h+=`<div class="rcard"><h3>Planter</h3>`;
    if(!seeds.length) return h+`<p>Tu n’as aucune graine. Achète-en à la boutique.</p><button class="btn wide" data-a="rtab" data-id="shop">Aller à la boutique</button></div>`;
    h+=`<p class="sm">Variété</p><div class="rchips">${seeds.map(s=>`<button class="${P.sid===s.id?'on':''}" data-a="rpick" data-id="sid" data-v="${s.id}">${s.ic} ${s.nom} ×${F.seeds[s.id]}</button>`).join('')}</div>
    <p class="sm">Substrat</p><div class="rchips">${Object.keys(MED).map(k=>`<button class="${P.med===k?'on':''}" data-a="rpick" data-id="med" data-v="${k}">${MED[k].ic} ${MED[k].nom}${MED[k].px?` (${MED[k].px} cr)`:''}</button>`).join('')}</div>`;
    if(!ROOMS[room].out){ const ls=LAMP.filter(l=>(F.lamps[l.id]||0)>0); h+=`<p class="sm">Lampe</p><div class="rchips">${ls.length?ls.map(l=>`<button class="${P.lamp===l.id?'on':''}" data-a="rpick" data-id="lamp" data-v="${l.id}">${l.ic} ${l.nom} (${(l.lm/1000)|0} k lm)</button>`).join(''):'<span class="sm">Aucune lampe en stock : boutique → Lampes</span>'}</div>`; }
    const okP=P.sid&&P.med&&(ROOMS[room].out||P.lamp); return h+`<button class="btn wide" data-a="rplant" data-id="${i}" ${okP?'':'disabled'}>Planter</button></div>`;
  }
  const sv=SID[sl.sid], f=plantFit(room,sl), md=MED[sl.med], lab={germ:'Germination',veg:'Croissance',flo:'Floraison',ready:'Prête à récolter',dead:'Morte'}[sl.st];
  const need={germ:1,veg:sv.veg,flo:sv.fl}[sl.st]||1, pc=sl.st==='ready'?100:Math.round(nz(sl.stAge/need*100,100));
  h+=`<div class="rcard"><div class="rrow"><b>${sv.ic} ${sv.nom}</b><span>${sv.ty} · ${sv.thc} % THC</span></div><div class="rrow sm"><span>${lab} ${sl.st==='ready'||sl.st==='dead'?'':pc+' %'}</span><span>${md.ic} ${md.nom}</span></div>
  ${rBar(pc,'#00E5FF','Avancement')}${rBar(sl.hp,'#3CFF9E','Santé')}${rBar(sl.q,'#FCEE0A','Qualité')}
  ${rBar(sl.w,'#4aa8ff','Eau')}${rBar(sl.N,'#3cff9e','Azote N')}${rBar(sl.P,'#ff9a1a','Phosphore P')}${rBar(sl.K,'#a58bff','Potassium K')}
  <div class="rrow sm"><span>pH ${sl.ph.toFixed(1)} <i class="sm">(idéal ${md.ph})</i></span><span>Lumière ${Math.round(f.L/1000)} k lm <i class="sm">(idéal ${Math.round(f.ideal/1000)} k)</i></span></div>
  ${sl.pest?`<p class="warn">⚠️ ${sl.pest==='mold'?'Moisissure':'Acariens'} détectés ! Traite vite.</p>`:''}
  ${f.cf<1?`<p class="warn">Cycle lumineux ${sl.cyc}/${24-sl.cyc} inadapté (${sl.st==='flo'?'12/12 requis':'18/6 conseillé'}).</p>`:''}</div>`;
  if(sl.st==='dead') return h+`<button class="btn wide" data-a="rclear" data-id="${i}">Évacuer la plante morte</button>`;
  if(sl.st==='ready') return h+`<button class="btn wide" data-a="rharvest" data-id="${i}">✂️ Récolter (${Math.round(sv.y*md.y*(sl.hp/100)*(.5+.5*sl.q/100)*(room==='ranch'?1.15:1))} g environ)</button>`;
  const c=k=>`${F.chem[k]||0}`;
  h+=`<div class="rcard"><h3>Soins</h3><div class="rbtns">
   <button data-a="rcare" data-id="${i}" data-v="water">💧 Arroser</button>
   <button data-a="rcare" data-id="${i}" data-v="N">🟩 N (${c('N')})</button><button data-a="rcare" data-id="${i}" data-v="P">🟧 P (${c('P')})</button><button data-a="rcare" data-id="${i}" data-v="K">🟪 K (${c('K')})</button>
   <button data-a="rcare" data-id="${i}" data-v="mixV">🥗 Mix croiss. 3-1-2</button><button data-a="rcare" data-id="${i}" data-v="mixF">🌸 Mix flor. 1-3-2</button>
   <button data-a="rcare" data-id="${i}" data-v="PHm">🔻 pH − (${c('PHm')})</button><button data-a="rcare" data-id="${i}" data-v="PHp">🔺 pH + (${c('PHp')})</button>
   <button data-a="rcare" data-id="${i}" data-v="CM">⚪ Cal-Mag (${c('CM')})</button><button data-a="rcare" data-id="${i}" data-v="ENZ">🧪 Enzymes (${c('ENZ')})</button>
   <button data-a="rcare" data-id="${i}" data-v="BOOST">🚀 Booster (${c('BOOST')})</button><button data-a="rcare" data-id="${i}" data-v="FONG">🍄 Fongicide (${c('FONG')})</button><button data-a="rcare" data-id="${i}" data-v="INSEC">🐛 Insecticide (${c('INSEC')})</button></div></div>
  <div class="rcard"><h3>Lumière</h3><div class="rbtns"><button class="${sl.cyc===18?'on':''}" data-a="rcycle" data-id="${i}" data-v="18">☀️ Cycle 18/6 (croissance)</button><button class="${sl.cyc===12?'on':''}" data-a="rcycle" data-id="${i}" data-v="12">🌙 Cycle 12/12 (floraison)</button></div>
  ${sl.st==='veg'&&pc>=50?`<button class="btn wide" data-a="rflower" data-id="${i}">🌸 Passer en floraison</button>`:''}
  ${!ROOMS[room].out?`<p class="sm">Lampe : ${sl.lamp?LID[sl.lamp].nom:'—'}</p><div class="rchips">${LAMP.filter(l=>(F.lamps[l.id]||0)>0||l.id===sl.lamp).map(l=>`<button class="${sl.lamp===l.id?'on':''}" data-a="rlamp" data-id="${i}" data-v="${l.id}">${l.ic} ${(l.lm/1000)|0} k lm</button>`).join('')}</div>`:'<p class="sm">Plein soleil du ranch (variable selon les jours).</p>'}</div>
  <button class="btn alt wide" data-a="rclear" data-id="${i}">Arracher la plante</button>`;
  return h;
}
function rShop(){
  const F=farm(); let h=`<div class="rchips big">${[['seeds','🌱 Graines'],['chem','🧴 Engrais & chimie'],['lamps','💡 Lampes'],['gear','🛠️ Matériel']].map(t=>`<button class="${RY.shop===t[0]?'on':''}" data-a="rshop" data-id="${t[0]}">${t[1]}</button>`).join('')}</div>`;
  if(RY.shop==='seeds') STR.forEach(s=>{ const lock=F.rep<s.rep; h+=`<div class="rit ${lock?'lock':''}"><span class="ri">${s.ic}</span><div class="grow"><b>${s.nom}</b> <small>${s.ty} · ${s.thc} % THC</small><br><small>Croiss. ${s.veg} min · Flor. ${s.fl} min · ~${s.y} g · ${s.px} cr/g · ${'★'.repeat(s.d)}${'☆'.repeat(5-s.d)} · ${(s.lm/1000)|0} k lm</small></div>${lock?`<small>Rép. ${s.rep}</small>`:`<button class="btn sm" data-a="rbuy" data-id="seed:${s.id}">${fmt(s.sd)} cr<br>(×${F.seeds[s.id]||0})</button>`}</div>`; });
  else if(RY.shop==='chem') Object.keys(CHEM).forEach(k=>{ const c=CHEM[k]; h+=`<div class="rit"><span class="ri">${c.ic}</span><div class="grow"><b>${c.nom}</b><br><small>${c.sub}</small></div><button class="btn sm" data-a="rbuy" data-id="chem:${k}">${c.px} cr<br>(×${F.chem[k]||0})</button></div>`; });
  else if(RY.shop==='lamps') LAMP.forEach(l=>{ h+=`<div class="rit"><span class="ri">${l.ic}</span><div class="grow"><b>${l.nom}</b><br><small>${fmt(l.lm)} lumens · ${l.w} W (${(l.w/100).toFixed(1)} cr/min) · chaleur ${l.h}</small></div><button class="btn sm" data-a="rbuy" data-id="lamp:${l.id}">${fmt(l.px)} cr<br>(×${F.lamps[l.id]||0})</button></div>`; });
  else { const tp=[['fan','🌀 Ventilation','Réduit moisissure',2500],['filter','🧯 Filtre à charbon','−20 % de chaleur / odeur',4000],['irri','🚿 Irrigation auto','Arrose seule (consomme la citerne)',9000]];
    ['atelier','ranch'].forEach(room=>{ const R=F.rooms[room]; if(!R.on) return; h+=`<h3 class="rh">${ROOMS[room].ic} ${ROOMS[room].nom}</h3>`; tp.forEach(t=>{ const lv=R[t[0]]||0, max=t[0]==='irri'?1:3; h+=`<div class="rit"><div class="grow"><b>${t[1]}</b> <small>niv. ${lv}/${max}</small><br><small>${t[2]}</small></div><button class="btn sm" data-a="rbuy" data-id="gear:${room}:${t[0]}" ${lv>=max?'disabled':''}>${lv>=max?'Max':fmt(t[3]*(lv+1))+' cr'}</button></div>`; }); });
    h+=`<div class="rit"><div class="grow"><b>🛢️ Citerne +100 L</b><br><small>Capacité ${F.tank} L</small></div><button class="btn sm" data-a="rbuy" data-id="tank:0">1 200 cr</button></div>
    <div class="rit"><div class="grow"><b>🕴️ Pot-de-vin (−30 % de chaleur)</b><br><small>Fait baisser la pression partout</small></div><button class="btn sm" data-a="rbuy" data-id="bribe:0">${fmt(1500+Math.round(Math.max(F.heat.atelier,F.heat.ranch)*80))} cr</button></div>`; }
  return h;
}
function rStock(){
  const F=farm(); let h='';
  const ks=Object.keys(F.stock).filter(k=>F.stock[k].g>0);
  h+=`<div class="rcard"><h3>📦 Stock séché</h3>${ks.length?ks.map(k=>{ const s=F.stock[k], sv=SID[k], p=sellPrice(k,s.q);
    return `<div class="rit"><span class="ri">${sv.ic}</span><div class="grow"><b>${sv.nom}</b><br><small>${Math.floor(s.g)} g · qualité ${Math.round(s.q)} % · ${p.toFixed(1)} cr/g</small></div>
    <div class="rbtns tight"><button data-a="rsell" data-id="${k}" data-v="street10">Rue ×10 g</button><button data-a="rsell" data-id="${k}" data-v="street">Rue tout</button>${F.rep>=10?`<button data-a="rsell" data-id="${k}" data-v="contact">Contact</button>`:''}${F.rep>=30&&s.q>=65?`<button data-a="rsell" data-id="${k}" data-v="vip">VIP</button>`:''}</div></div>`; }).join(''):'<p>Rien en stock. Récolte une plante : elle sèche pendant 2 minutes.</p>'}
  <p class="sm">Rue : 75 % du prix, risqué. Contact (rép. 10) : prix normal. VIP (rép. 30, qualité 65 %) : 135 %. Les livraisons en voiture paient le mieux.</p></div>`;
  if((F.dry||[]).length) h+=`<div class="rcard"><h3>🧺 En séchage</h3>${F.dry.map(b=>`<div class="rrow sm"><span>${SID[b.sid].ic} ${SID[b.sid].nom} · ${Math.round(b.g)} g</span><span>${Math.ceil(b.t*60)} s</span></div>`).join('')}</div>`;
  return h;
}
function rNet(){
  const F=farm(); let h=`<div class="rcard"><p>Ton réseau te propose des coups à faire <b>au volant</b>. Les go-fast écoulent ta marchandise à prix fort (×2 à ×2,8) ; les courses clandestines se jouent à la mise. Une manche ratée = cargaison perdue et chaleur.</p></div>`;
  ILL.forEach(e=>{ const lock=S.lvl<e.lvl||F.rep<e.rep, best=bestCargo(e), few=S.cars.length<e.manches.length;
    const need=e.ill==='cargo'?`${e.cargo} g de marchandise`:`mise ${fmt(e.bet)} cr`;
    h+=`<div class="rit ${lock?'lock':''}"><span class="ri">${e.ill==='cargo'?'📦':'🏁'}</span><div class="grow"><b>${e.nom}</b><br><small>${e.txt}</small><br><small>${need} · prime ${fmt(e.gain)} cr · chaleur +${e.heat}</small></div>${lock?`<small>Niv. ${e.lvl}<br>Rép. ${e.rep}</small>`:`<button class="btn sm" data-a="illgo" data-id="${e.id}" ${(e.ill==='cargo'&&!best)||(e.ill==='bet'&&S.cr<e.bet)||few?'disabled':''}>Go</button>`}</div>`; });
  return h;
}
function bestCargo(e){ if(e.ill!=='cargo') return null; const F=farm(); let b=null; for(const k in F.stock){ const s=F.stock[k]; if(s.g>=e.cargo&&(!b||sellPrice(k,s.q)>sellPrice(b.sid,b.q))) b={sid:k,g:e.cargo,q:s.q}; } return b; }
/* ---------- actions ---------- */
Object.assign(ACT,{
  ranch(){ const F=farm(); F.found=1; ranchSim(); RY.tab='atelier'; RY.slot=null; openSheet({t:'ranch'}); },
  rtab(d){ RY.tab=d.id; RY.slot=null; if(d.v) RY.shop=d.v; renderSheet(); },
  rback(){ RY.slot=null; RY.pick=null; renderSheet(); },
  rshop(d){ RY.shop=d.id; renderSheet(); },
  rslot(d){ RY.slot=+d.id; RY.pick=null; renderSheet(); },
  rpick(d){ RY.pick=RY.pick||{}; RY.pick[d.id]=d.v; renderSheet(); },
  rplant(d){ const F=farm(), room=RY.tab, R=F.rooms[room], P=RY.pick||{}, i=+d.id; if(R.slots[i]) return;
    if((F.seeds[P.sid]||0)<1) return toast('Plus de graines'); const mp=MED[P.med].px; if(S.cr<mp) return toast('Pas assez de crédits');
    if(!ROOMS[room].out){ if((F.lamps[P.lamp]||0)<1) return toast('Pas de lampe'); }
    F.seeds[P.sid]--; S.cr-=mp; R.slots[i]=newPlant(P.sid,P.med,ROOMS[room].out?null:P.lamp); RY.pick=null; save(); renderSheet(); },
  rcare(d){ const F=farm(), sl=F.rooms[RY.tab].slots[+d.id], k=d.v; if(!sl||sl.st==='ready'||sl.st==='dead') return;
    const use=(c,n)=>{ if((F.chem[c]||0)<n){ toast('Il t’en faut : '+CHEM[c].nom); return false; } F.chem[c]-=n; return true; };
    if(k==='water'){ if((F.can||0)>0) F.can--; else { if(F.water<3) return toast('Citerne vide : remplis-la'); F.water-=3; } sl.w=Math.min(100,sl.w+38); }
    else if(k==='N'||k==='P'||k==='K'){ if(!use(k,1)) return; sl[k]=Math.min(100,sl[k]+20); }
    else if(k==='mixV'){ if((F.chem.N<3)||(F.chem.P<1)||(F.chem.K<2)) return toast('Il te faut 3 N, 1 P, 2 K'); F.chem.N-=3; F.chem.P-=1; F.chem.K-=2; sl.N=Math.min(100,sl.N+30); sl.P=Math.min(100,sl.P+10); sl.K=Math.min(100,sl.K+20); }
    else if(k==='mixF'){ if((F.chem.N<1)||(F.chem.P<3)||(F.chem.K<2)) return toast('Il te faut 1 N, 3 P, 2 K'); F.chem.N-=1; F.chem.P-=3; F.chem.K-=2; sl.N=Math.min(100,sl.N+10); sl.P=Math.min(100,sl.P+30); sl.K=Math.min(100,sl.K+20); }
    else if(k==='PHm'){ if(!use(k,1)) return; sl.ph-=.45; } else if(k==='PHp'){ if(!use(k,1)) return; sl.ph+=.45; }
    else if(k==='CM'){ if(!use(k,1)) return; sl.hp=Math.min(100,sl.hp+8); sl.N=Math.min(100,sl.N+6); sl.P=Math.min(100,sl.P+6); sl.K=Math.min(100,sl.K+6); }
    else if(k==='ENZ'){ if(!use(k,1)) return; sl.enz=4; } else if(k==='BOOST'){ if(sl.st!=='flo') return toast('À utiliser en floraison'); if(!use(k,1)) return; sl.boost=4; sl.q=Math.min(100,sl.q+6); }
    else if(k==='FONG'){ if(sl.pest!=='mold'&&sl.pest) return toast('Ce n’est pas de la moisissure'); if(!use(k,1)) return; sl.pest=null; sl.prot=4; }
    else if(k==='INSEC'){ if(sl.pest&&sl.pest!=='mites') return toast('Ce n’est pas des acariens'); if(!use(k,1)) return; sl.pest=null; sl.prot=4; }
    save(); renderSheet(); },
  rcycle(d){ const sl=farm().rooms[RY.tab].slots[+d.id]; if(sl){ sl.cyc=+d.v; save(); renderSheet(); } },
  rflower(d){ const sl=farm().rooms[RY.tab].slots[+d.id]; if(sl&&sl.st==='veg'){ sl.st='flo'; sl.stAge=0; sl.cyc=12; save(); renderSheet(); } },
  rlamp(d){ const F=farm(), sl=F.rooms[RY.tab].slots[+d.id]; if(!sl||sl.lamp===d.v) return; if((F.lamps[d.v]||0)<1) return; sl.lamp=d.v; save(); renderSheet(); },
  rclear(d){ const R=farm().rooms[RY.tab]; R.slots[+d.id]=null; RY.slot=null; save(); renderSheet(); },
  rharvest(d){ const F=farm(), R=F.rooms[RY.tab], sl=R.slots[+d.id]; if(!sl||sl.st!=='ready') return; const sv=SID[sl.sid], md=MED[sl.med];
    const g=Math.max(1,sv.y*md.y*(sl.hp/100)*(.5+.5*sl.q/100)*(RY.tab==='ranch'?1.15:1)); (F.dry=F.dry||[]).push({sid:sl.sid,g,q:sl.q,t:2});
    F.stats.harv++; F.rep+=Math.round(sv.d*.6*10)/10; R.slots[+d.id]=null; RY.slot=null; toast(`Récolte : ${Math.round(g)} g de ${sv.nom}, séchage 2 min`); save(); renderSheet(); },
  rwater(){ const F=farm(), n=Math.floor(Math.min(F.tank-F.water,S.cr)); if(n<1) return toast(n<1&&S.cr<1?'Pas de crédits':'Citerne pleine'); F.water+=n; S.cr-=n; save(); renderSheet(); },
  rbuy(d){ const F=farm(), [t,a,b]=d.id.split(':');
    const pay=n=>{ if(S.cr<n){ toast('Pas assez de crédits'); return false; } S.cr-=n; return true; };
    if(t==='seed'){ const s=SID[a]; if(F.rep<s.rep||!pay(s.sd)) return; F.seeds[a]=(F.seeds[a]||0)+1; }
    else if(t==='chem'){ if(!pay(CHEM[a].px)) return; F.chem[a]=(F.chem[a]||0)+1; }
    else if(t==='lamp'){ const l=LID[a]; if(!pay(l.px)) return; F.lamps[a]=(F.lamps[a]||0)+1; }
    else if(t==='gear'){ const R=F.rooms[a], pr={fan:2500,filter:4000,irri:9000}[b], max=b==='irri'?1:3; if((R[b]||0)>=max||!pay(pr*((R[b]||0)+1))) return; R[b]=(R[b]||0)+1; }
    else if(t==='tank'){ if(!pay(1200)) return; F.tank+=100; }
    else if(t==='bribe'){ const c=1500+Math.round(Math.max(F.heat.atelier,F.heat.ranch)*80); if(!pay(c)) return; F.heat.atelier*=.7; F.heat.ranch*=.7; }
    save(); renderSheet(); },
  rbuyslot(d){ const F=farm(), R=F.rooms[d.id], RM=ROOMS[d.id], c=1500+R.slots.length*900; if(R.slots.length>=RM.max) return; if(S.cr<c) return toast('Pas assez de crédits'); S.cr-=c; R.extra=(R.extra||0)+1; R.slots.push(null); save(); renderSheet(); },
  rbuyranch(){ const F=farm(); if(S.cr<30000||F.rep<12) return; S.cr-=30000; F.rooms.ranch.on=1; RY.tab='ranch'; save(); renderSheet(); },
  rsell(d){ const F=farm(), s=F.stock[d.id]; if(!s||s.g<1) return; const ch=d.v, p=sellPrice(d.id,s.q); let g=ch==='street10'?Math.min(10,s.g):s.g, m=ch.startsWith('street')?.75:ch==='contact'?1:1.35, ht=ch.startsWith('street')?g*.35:ch==='contact'?g*.12:g*.18;
    if(ch==='vip'&&s.q<65) return toast('Qualité insuffisante');
    g=Math.floor(g); const gain=Math.round(g*p*m); s.g-=g; S.cr+=gain; F.stats.sold+=g; F.rep+=g*.02; karmaAdd(-g*(ch.startsWith('street')?.04:.02)); F.heat.atelier=Math.min(100,F.heat.atelier+ht*.4); F.heat.ranch=Math.min(100,F.heat.ranch+ht*.4); toast(`${g} g vendus, +${fmt(gain)} cr`); save(); renderSheet(); },
  illgo(d){ const e=ILL.find(x=>x.id===d.id), F=farm(); if(!e||S.lvl<e.lvl||F.rep<e.rep||S.cars.length<e.manches.length) return;
    let cargo=null; if(e.ill==='cargo'){ cargo=bestCargo(e); if(!cargo) return toast('Pas assez de marchandise'); } else { if(S.cr<e.bet) return toast('Pas assez pour la mise'); }
    closeSheet(); ACT.ev({id:e.id}); if(R&&R.ev&&R.ev.id===e.id) R.cargo=cargo; }
});
function illResolve(ev,pay,win,pod){
  if(!ev.ill){ if(win) karmaAdd(Math.min(3,1+(ev.lvl>>2))); else if(pod) karmaAdd(.5); return; } const F=farm(); let msg='';
  if(ev.ill==='cargo'){ const c=R.cargo; if(!c) return; const s=F.stock[c.sid]; if(s) s.g=Math.max(0,s.g-c.g);
    if(pod){ const v=Math.round(c.g*sellPrice(c.sid,c.q)*ev.prem*Math.max(.6,pay)); S.cr+=v; F.rep+=ev.rep*.25+1; F.stats.deliv++; const h=ev.heat*.5; F.heat.atelier=Math.min(100,F.heat.atelier+h); F.heat.ranch=Math.min(100,F.heat.ranch+h); karmaAdd(-2); msg=`📦 <b>Livraison réussie</b> : ${c.g} g écoulés, +${fmt(v)} cr.`; }
    else{ F.stats.busted++; karmaAdd(-3); const fine=Math.round(S.cr*.08); S.cr-=fine; F.heat.atelier=Math.min(100,F.heat.atelier+ev.heat); F.heat.ranch=Math.min(100,F.heat.ranch+ev.heat); msg=`🚔 <b>Interpellé !</b> Cargaison saisie, amende ${fmt(fine)} cr, chaleur en hausse.`; } }
  else{ if(win){ karmaAdd(-1); S.cr+=ev.bet; F.rep+=1+ev.rep*.1; msg=`🏁 <b>Course gagnée</b> : +${fmt(ev.bet)} cr de mise ramassée.`; }
    else if(pod){ msg='🏁 Tu sauves ta mise, mais sans gloire.'; }
    else { S.cr=Math.max(0,S.cr-ev.bet); msg=`🏁 <b>Perdu</b> : la mise de ${fmt(ev.bet)} cr est partie.`; }
    F.heat.atelier=Math.min(100,F.heat.atelier+ev.heat*.3); }
  save(); setTimeout(()=>banner(msg),400);
}
setInterval(()=>{ try{ if(S&&S.farm&&S.farm.found){ ranchSim(); if(sheet&&sheet.t==='ranch'&&!RY.down&&Date.now()-RY.lastTick>3500){ RY.lastTick=Date.now(); renderSheet(); } } }catch(_){} },1000);
document.addEventListener('pointerdown',()=>{RY.down=true; RY.lastTick=Date.now();},true); document.addEventListener('pointerup',()=>{RY.down=false; RY.lastTick=Date.now();},true);
/* ---------- entrée secrète dans le garage 3D ---------- */
function hubSecret(sc,box,neon){
  const px=34.55, pz=-16;
  box(.06,.12,3.4,px-.04,.9,pz,neon(0x3CFF9E)); box(.06,3.6,.06,px-.04,2.6,pz+1.7,neon(0x18301f)); /* fine ligne verte : l'indice */
  HUB.sec={x:33.6,z:pz};
}
/* ===== v0.21 : High & Rouillé — karma, visuels cannabis, menus du réseau refaits ===== */
const karma=()=>{ const F=farm(); return F.karma||0; };
function karmaAdd(n){ const F=farm(); F.karma=clamp((F.karma||0)+n,-100,100); }
function karmaPrize(ev){ const k=karma(); return ev&&ev.ill?1:1+Math.max(0,k)/100*.15; }
const KT=[[80,'Saint du bitume','😇'],[40,'Bon samaritain','😊'],[15,'Citoyen modèle','🙂'],[-15,'Entre deux eaux','😐'],[-40,'Fripon','😏'],[-80,'Truand','😈'],[-101,'Parrain','👹']];
const karmaTitle=()=>{ const k=karma(); return KT.find(t=>k>=t[0])||KT[KT.length-1]; };
/* ---- dessins : feuille de cannabis, graine, terreau, plante par stade ---- */
(function(){
  const leaflet=(len,wd,teeth)=>{ const n=teeth*2, R=[], L=[]; for(let i=1;i<=n;i++){ const t=i/n, y=-len*t, w=(wd/2)*Math.sin(Math.PI*Math.pow(t,.72))*(i%2?.62:1); R.push([w,y]); L.unshift([-w,y]); }
    return 'M0 0 '+R.map(p=>'L'+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ')+' L0 '+(-len-3)+' '+L.map(p=>'L'+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ')+' Z'; };
  const defs=[[0,64,13,9],[28,52,11,8],[-28,52,11,8],[58,40,9,7],[-58,40,9,7],[88,26,7,5],[-88,26,7,5]];
  const lf=defs.map(d=>`<path transform="translate(50 90) rotate(${d[0]})" d="${leaflet(d[1],d[2],d[3])}"/>`).join('')+'<path d="M50 100 L50 88" stroke="currentColor" stroke-width="3" fill="none"/>'+defs.slice(0,5).map(d=>`<path transform="translate(50 90) rotate(${d[0]})" d="M0 -4 L0 ${-d[1]*.8}" stroke="rgba(0,0,0,.28)" stroke-width="1.2" fill="none"/>`).join('');
  const h=`<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs><symbol id="lf" viewBox="0 0 100 100" fill="currentColor">${lf}</symbol>
   <radialGradient id="gl"><stop offset="0" stop-color="#ffd36a" stop-opacity=".9"/><stop offset="1" stop-color="#ffd36a" stop-opacity="0"/></radialGradient>
   <linearGradient id="sd" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d9b27a"/><stop offset="1" stop-color="#7a5230"/></linearGradient></defs></svg>`;
  window.addEventListener('DOMContentLoaded',()=>document.body.insertAdjacentHTML('afterbegin',h)); if(document.body) document.body.insertAdjacentHTML('afterbegin',h);
})();
const leafIc=(col,s)=>`<svg class="lfic" width="${s||18}" height="${s||18}" viewBox="0 0 100 100" style="color:${col||'#3cff9e'}"><use href="#lf"/></svg>`;
const seedIc=(s)=>`<svg class="sdic" width="${s||26}" height="${s||26}" viewBox="0 0 40 40"><ellipse cx="20" cy="21" rx="14" ry="10" transform="rotate(-28 20 21)" fill="url(#sd)" stroke="#4a2f1d" stroke-width="1.2"/><path d="M9 25 Q16 14 30 15 M11 28 Q20 20 32 20 M14 30 Q22 25 33 24" stroke="#3a2412" stroke-width="1.6" fill="none" opacity=".75"/><path d="M12 22 Q16 17 21 16" stroke="#fff" opacity=".35" stroke-width="1.4" fill="none"/></svg>`;
function soilIc(k,s){ s=s||34; const b={
  terreau:'<ellipse cx="20" cy="30" rx="17" ry="5" fill="#2c1b10"/><path d="M4 30 Q20 8 36 30Z" fill="#5a3a22"/><circle cx="14" cy="26" r="1.6" fill="#8a6038"/><circle cx="22" cy="22" r="1.4" fill="#2c1b10"/><circle cx="27" cy="27" r="1.8" fill="#8a6038"/><circle cx="18" cy="29" r="1.3" fill="#2c1b10"/>',
  coco:'<ellipse cx="20" cy="30" rx="17" ry="5" fill="#4a2c12"/><path d="M4 30 Q20 10 36 30Z" fill="#9a6a38"/><path d="M10 28 Q16 20 24 24 M16 29 Q24 18 31 27 M8 29 Q12 24 18 26" stroke="#d1a06a" stroke-width="1.2" fill="none"/>',
  hydro:'<rect x="5" y="22" width="30" height="13" rx="3" fill="#1b4f8c"/><rect x="5" y="22" width="30" height="5" fill="#4aa8ff" opacity=".7"/><circle cx="12" cy="20" r="3.2" fill="#c9774a"/><circle cx="19" cy="18" r="3.6" fill="#b4623a"/><circle cx="26" cy="20" r="3.2" fill="#d08a5a"/><circle cx="31" cy="21" r="2.6" fill="#b4623a"/>'}[k];
  return `<svg width="${s}" height="${s}" viewBox="0 0 40 40">${b}</svg>`; }
const PURP={gp:1,ph:1,zk:1};
function plantSVG(st,pc,sid,sick,size){
  const sv=SID[sid]||STR[0], pu=!!PURP[sid], col=pu?'#7a55d6':sv.ty==='Sativa'?'#8be03c':sv.ty==='Indica'?'#1f9d55':'#3cc46a', dark=pu?'#5a3aa8':sv.ty==='Sativa'?'#5aa82a':sv.ty==='Indica'?'#157a42':'#2a9a52', bud=pu?'#c07cff':'#b8f04a', pist='#ff9a1a';
  const L=(x,y,s,r,c)=>`<use href="#lf" x="${x-s/2}" y="${y-s*.9}" width="${s}" height="${s}" transform="rotate(${r} ${x} ${y})" style="color:${c}"/>`;
  const B=(x,y,r,glow)=>{ let o=glow?`<circle cx="${x}" cy="${y}" r="${r*2.3}" fill="url(#gl)"/>`:''; const cs=[[0,0,1],[-.55,.9,.8],[.55,.9,.8],[0,1.7,.7],[0,-.9,.7]];
    cs.forEach((c,i)=>{ o+=`<circle cx="${x+c[0]*r*.8}" cy="${y+c[1]*r*.8}" r="${r*c[2]*.78}" fill="${i%2?bud:pu?'#a85de8':'#9ee03a'}" stroke="${pu?'#7a3fc0':'#5aa82a'}" stroke-width=".6"/>`; });
    for(let i=0;i<7;i++){ const an=i*.9+x, px=x+Math.cos(an)*r*.8, py=y+Math.sin(an*1.3)*r*1.1; o+=`<path d="M${px.toFixed(1)} ${py.toFixed(1)} l${(Math.cos(an)*3).toFixed(1)} ${(Math.sin(an)*3-1).toFixed(1)}" stroke="${pist}" stroke-width="1.3" stroke-linecap="round"/>`; }
    return o; };
  let g=`<ellipse cx="60" cy="108" rx="46" ry="10" fill="#2c1b10"/><path d="M16 108 Q60 76 104 108Z" fill="#4f321e"/><circle cx="40" cy="100" r="1.8" fill="#8a6038"/><circle cx="70" cy="96" r="1.6" fill="#2c1b10"/><circle cx="84" cy="103" r="2" fill="#8a6038"/><circle cx="55" cy="104" r="1.5" fill="#2c1b10"/>`;
  const p=Math.max(0,Math.min(100,pc||0))/100;
  if(st==='germ'){ g+=`<ellipse cx="60" cy="92" rx="9" ry="6" transform="rotate(-20 60 92)" fill="url(#sd)" stroke="#4a2f1d"/>`+(p>.35?`<path d="M60 90 L60 ${86-p*14}" stroke="${col}" stroke-width="2.5"/><ellipse cx="${53-p*2}" cy="${84-p*14}" rx="${4+p*4}" ry="2.6" fill="${col}"/><ellipse cx="${67+p*2}" cy="${84-p*14}" rx="${4+p*4}" ry="2.6" fill="${col}"/>`:''); }
  else if(st==='dead'){ g+=`<path d="M60 96 Q62 70 52 58" stroke="#6b4f2a" stroke-width="3" fill="none"/>`+L(52,60,26,-70,'#7a6032')+L(58,76,24,60,'#6b4f2a')+L(62,84,22,-60,'#5a4424'); }
  else{
    const h=st==='veg'?20+p*50:74, top=96-h; g+=`<path d="M60 98 L60 ${top}" stroke="${dark}" stroke-width="3.4"/>`;
    const sz=st==='veg'?26+p*30:40;
    [.25,.5,.75].forEach((f,i)=>{ const y=96-h*f; g+=L(60,y,sz*(1.1-i*.12),-66-i*8,col)+L(60,y,sz*(1.1-i*.12),66+i*8,dark); });
    g+=L(60,top+2,sz*1.05,0,col);
    if(st==='flo'||st==='ready'){ const r=st==='ready'?6.2:2.6+p*3.6, gl=st==='ready';
      g+=B(60,top-2,r*1.25,gl)+B(47,96-h*.62,r*.8,gl)+B(73,96-h*.62,r*.8,gl)+B(49,96-h*.38,r*.65,gl)+B(72,96-h*.38,r*.65,gl);
      if(gl) g+=[[40,40],[84,52],[62,30],[28,62],[90,78]].map(q=>`<path d="M${q[0]} ${q[1]-4}v8M${q[0]-4} ${q[1]}h8" stroke="#fff" stroke-width="1.4" class="spk"/>`).join(''); }
  }
  if(sick) g+=sick==='mold'?[[48,70],[66,62],[58,84],[72,80]].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="4" fill="#e8e8f0" opacity=".85"/>`).join(''):[[50,64],[68,72],[56,82],[64,58]].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="2.2" fill="#ff3d3d"/>`).join('');
  const sz2=size||110; return `<svg class="plant st-${st}" width="${sz2}" height="${sz2}" viewBox="0 0 120 120">${g}</svg>`;
}
const budIc=(sid,s)=>`<svg width="${s||34}" height="${s||34}" viewBox="0 0 40 40"><circle cx="20" cy="20" r="13" fill="url(#gl)"/><circle cx="20" cy="22" r="8.5" fill="${PURP[sid]?'#c07cff':'#b8f04a'}"/><circle cx="15" cy="17" r="6" fill="${PURP[sid]?'#a85de8':'#8fd32a'}"/><circle cx="25" cy="16" r="5.4" fill="${PURP[sid]?'#b36cf0':'#a0e03a'}"/><path d="M16 14q-3 -4 -5 -3M24 12q3 -4 5 -3M20 28q0 4 2 6M13 22q-4 1 -5 -1M28 22q4 1 5 -1" stroke="#ff9a1a" stroke-width="1.4" fill="none"/></svg>`;
/* ---- portrait / paysage : le menu caché s'ouvre en portrait ---- */
const _ranch0=ACT.ranch;
/* ---- menus ---- */
let RY2={sub:'water'};
function ranchHead(){
  const F=farm(), h=Math.max(F.heat.atelier,F.heat.ranch), kt=karmaTitle(), k=Math.round(karma());
  return `<div class="rhero"><div class="rlogo">${leafIc('#3cff9e',30)}<div><b>High &amp; Rouillé</b><small>Le réseau</small></div></div>
  <div class="rstats"><div><small>Crédits</small><b>${fmt(S.cr)}</b></div><div><small>Réputation</small><b>${fmt(F.rep)}</b></div><div class="${h>60?'hot':''}"><small>Chaleur</small><b>${Math.round(h)} %</b></div><div><small>Karma</small><b>${kt[2]} ${k>0?'+':''}${k}</b></div></div></div>
  <div class="rtabs">${[['atelier',leafIc('#3cff9e',18),'Atelier'],['ranch','🌾','Ranch'],['shop','🛒','Boutique'],['stock','🫙','Stock'],['net','🚗','Réseau']].map(t=>`<button class="${RY.tab===t[0]?'on':''}" data-a="rtab" data-id="${t[0]}"><span>${t[1]}</span>${t[2]}</button>`).join('')}</div>`;
}
function ranchSheet(X){
  if(!sheet||sheet.t!=='ranch') return false;
  ranchSim(); let h=X+ranchHead();
  if(RY.tab==='atelier'||RY.tab==='ranch') h+=RY.slot!=null?rSlotView(RY.tab,RY.slot):rRoomView(RY.tab);
  else if(RY.tab==='shop') h+=rShop(); else if(RY.tab==='stock') h+=rStock(); else h+=rNet();
  const sh=$('sheet'), sc=sh.scrollTop; sh.classList.add('rch'); sh.innerHTML=h+'<div class="rfoot"></div>'; sh.scrollTop=sc; return true;
}
function rRoomView(room){
  const F=farm(), R=F.rooms[room], RM=ROOMS[room];
  if(!R.on) return `<div class="rcard haze"><h3>${RM.ic} ${RM.nom}</h3><p>Une grande ferme à l’écart de la ville : soleil gratuit, jusqu’à ${RM.max} parcelles, mais plus visible pour la police.</p><button class="btn wide" data-a="rbuyranch" ${S.cr<30000||F.rep<12?'disabled':''}>Acheter le ranch · 30 000 cr (rép. 12)</button></div>`;
  const heat=F.heat[room];
  let h=`<div class="rcard"><div class="rrow"><b>${RM.ic} ${RM.nom}</b><span class="${heat>60?'warn':'sm'}">Police ${Math.round(heat)} %</span></div>${rBar(heat,heat>60?'#FF4D6D':heat>35?'#FCEE0A':'#3CFF9E','Chaleur')}
  <div class="rmini"><span>💧 ${Math.round(F.water)}/${F.tank} L</span><span>🌀 ${R.fan}</span><span>🧯 ${R.filter}</span><span>🚿 ${R.irri?'oui':'non'}</span></div>
  <div class="rbtns two"><button data-a="rwater">💧 Remplir la citerne</button><button data-a="rtab" data-id="shop" data-v="gear">🛠️ Matériel</button></div></div><div class="rgrid">`;
  R.slots.forEach((sl,i)=>{
    if(!sl){ h+=`<button class="rslot empty" data-a="rslot" data-id="${i}">${seedIc(30)}<b>Planter</b><small>emplacement ${i+1}</small></button>`; return; }
    const sv=SID[sl.sid], pc=sl.st==='ready'?100:sl.st==='dead'?0:Math.round(nz(sl.stAge/({germ:1,veg:sv.veg,flo:sv.fl}[sl.st]||1)*100,100));
    const lab={germ:'Germination',veg:'Croissance',flo:'Floraison',ready:'À récolter',dead:'Morte'}[sl.st];
    h+=`<button class="rslot ${sl.st==='ready'?'ready':''} ${sl.pest?'sick':''}" data-a="rslot" data-id="${i}">${plantSVG(sl.st,pc,sl.sid,sl.pest,74)}<b>${sv.nom}</b><small>${lab}${sl.pest?' ⚠️':''}</small><div class="rb sm"><i style="width:${pc}%;background:#00E5FF"></i></div><div class="rb sm"><i style="width:${Math.round(sl.hp)}%;background:#3CFF9E"></i></div></button>`; });
  return h+'</div>'+(R.slots.length<RM.max?`<button class="btn alt wide" data-a="rbuyslot" data-id="${room}">＋ Emplacement · ${fmt(1500+R.slots.length*900)} cr</button>`:'');
}
const cbtn=(i,k,ic,lab,n)=>`<button class="cb ${n===0?'dim':''}" data-a="rcare" data-id="${i}" data-v="${k}"><span>${ic}</span><b>${lab}</b>${n==null?'':`<i>×${n}</i>`}</button>`;
function rSlotView(room,i){
  const F=farm(), R=F.rooms[room], sl=R.slots[i];
  let h=`<button class="btn alt sm" data-a="rback">← Retour à ${ROOMS[room].nom}</button>`;
  if(!sl){
    const seeds=STR.filter(s=>(F.seeds[s.id]||0)>0), P=RY.pick||{};
    h+=`<div class="rcard haze"><h3>${seedIc(24)} Planter une graine</h3>`;
    if(!seeds.length) return h+`<p>Tu n’as aucune graine.</p><button class="btn wide" data-a="rtab" data-id="shop">Aller à la boutique</button></div>`;
    h+=`<p class="sm">1 · Variété</p><div class="rpicks">${seeds.map(s=>`<button class="${P.sid===s.id?'on':''}" data-a="rpick" data-id="sid" data-v="${s.id}">${leafIc(PURP[s.id]?'#a85de8':s.ty==='Sativa'?'#8be03c':'#3cc46a',26)}<b>${s.nom}</b><small>${s.ty} · ×${F.seeds[s.id]}</small></button>`).join('')}</div>
    <p class="sm">2 · Substrat</p><div class="rpicks">${Object.keys(MED).map(k=>`<button class="${P.med===k?'on':''}" data-a="rpick" data-id="med" data-v="${k}">${soilIc(k,32)}<b>${MED[k].nom}</b><small>${MED[k].px?MED[k].px+' cr':'gratuit'} · pH ${MED[k].ph}</small></button>`).join('')}</div>`;
    if(!ROOMS[room].out){ const ls=LAMP.filter(l=>(F.lamps[l.id]||0)>0); h+=`<p class="sm">3 · Lampe</p><div class="rpicks">${ls.length?ls.map(l=>`<button class="${P.lamp===l.id?'on':''}" data-a="rpick" data-id="lamp" data-v="${l.id}"><span class="big">${l.ic}</span><b>${l.nom}</b><small>${(l.lm/1000)|0} k lumens</small></button>`).join(''):'<span class="sm">Aucune lampe : boutique → Lampes</span>'}</div>`; }
    const okP=P.sid&&P.med&&(ROOMS[room].out||P.lamp); return h+`<button class="btn wide" data-a="rplant" data-id="${i}" ${okP?'':'disabled'}>🌱 Planter</button></div>`;
  }
  const sv=SID[sl.sid], f=plantFit(room,sl), md=MED[sl.med], lab={germ:'Germination',veg:'Croissance',flo:'Floraison',ready:'Prête à récolter',dead:'Morte'}[sl.st];
  const need={germ:1,veg:sv.veg,flo:sv.fl}[sl.st]||1, pc=sl.st==='ready'?100:Math.round(nz(sl.stAge/need*100,100));
  h+=`<div class="rhero2"><div class="pl">${plantSVG(sl.st,pc,sl.sid,sl.pest,150)}</div><div class="pi"><b>${sv.nom}</b><small>${sv.ty} · ${sv.thc} % THC</small><span class="chip">${lab}${sl.st==='ready'||sl.st==='dead'?'':' '+pc+' %'}</span><span class="chip">${soilIc(sl.med,16)} ${md.nom}</span></div></div>
  <div class="rcard">${rBar(pc,'#00E5FF','Avancement')}${rBar(sl.hp,'#3CFF9E','Santé')}${rBar(sl.q,'#FCEE0A','Qualité')}${rBar(sl.w,'#4aa8ff','Eau')}${rBar(sl.N,'#3cff9e','Azote N')}${rBar(sl.P,'#ff9a1a','Phosphore P')}${rBar(sl.K,'#a58bff','Potassium K')}
  <div class="rrow sm"><span>pH ${sl.ph.toFixed(1)} <i>(idéal ${md.ph})</i></span><span>${Math.round(f.L/1000)} k lm <i>(idéal ${Math.round(f.ideal/1000)} k)</i></span></div>
  ${sl.pest?`<p class="warn">⚠️ ${sl.pest==='mold'?'Moisissure : fongicide !':'Acariens : insecticide !'}</p>`:''}${f.cf<1?`<p class="warn">Cycle ${sl.cyc}/${24-sl.cyc} inadapté (${sl.st==='flo'?'12/12 requis':'18/6 conseillé'}).</p>`:''}</div>`;
  if(sl.st==='dead') return h+`<button class="btn wide" data-a="rclear" data-id="${i}">Évacuer la plante</button>`;
  if(sl.st==='ready') return h+`<button class="btn wide" data-a="rharvest" data-id="${i}">✂️ Récolter · environ ${Math.round(sv.y*md.y*(sl.hp/100)*(.5+.5*sl.q/100)*(room==='ranch'?1.15:1))} g</button>`;
  const c=k=>F.chem[k]||0, sub=RY2.sub;
  h+=`<div class="rtabs sub">${[['water','💧','Eau & engrais'],['care','🧪','Soins'],['light','💡','Lumière']].map(t=>`<button class="${sub===t[0]?'on':''}" data-a="rsub" data-id="${t[0]}"><span>${t[1]}</span>${t[2]}</button>`).join('')}</div><div class="rcard">`;
  if(sub==='water') h+=`<div class="cgrid">${cbtn(i,'water','💧','Arroser',null)}${cbtn(i,'N','🟩','Azote',c('N'))}${cbtn(i,'P','🟧','Phosphore',c('P'))}${cbtn(i,'K','🟪','Potassium',c('K'))}${cbtn(i,'mixV','🥗','Mix croissance',null)}${cbtn(i,'mixF','🌸','Mix floraison',null)}</div><p class="sm">Mix croissance = 3 N · 1 P · 2 K. Mix floraison = 1 N · 3 P · 2 K.</p>`;
  else if(sub==='care') h+=`<div class="cgrid">${cbtn(i,'PHm','🔻','pH −',c('PHm'))}${cbtn(i,'PHp','🔺','pH +',c('PHp'))}${cbtn(i,'CM','⚪','Cal-Mag',c('CM'))}${cbtn(i,'ENZ','🧪','Enzymes',c('ENZ'))}${cbtn(i,'BOOST','🚀','Booster',c('BOOST'))}${cbtn(i,'FONG','🍄','Fongicide',c('FONG'))}${cbtn(i,'INSEC','🐛','Insecticide',c('INSEC'))}</div>`;
  else h+=`<div class="cgrid"><button class="cb ${sl.cyc===18?'on':''}" data-a="rcycle" data-id="${i}" data-v="18"><span>☀️</span><b>18 / 6</b><i>croissance</i></button><button class="cb ${sl.cyc===12?'on':''}" data-a="rcycle" data-id="${i}" data-v="12"><span>🌙</span><b>12 / 12</b><i>floraison</i></button></div>
    ${sl.st==='veg'&&pc>=50?`<button class="btn wide" data-a="rflower" data-id="${i}">🌸 Passer en floraison</button>`:''}
    ${!ROOMS[room].out?`<p class="sm">Lampe : ${sl.lamp?LID[sl.lamp].nom:'—'}</p><div class="rchips">${LAMP.filter(l=>(F.lamps[l.id]||0)>0||l.id===sl.lamp).map(l=>`<button class="${sl.lamp===l.id?'on':''}" data-a="rlamp" data-id="${i}" data-v="${l.id}">${l.ic} ${(l.lm/1000)|0} k lm</button>`).join('')}</div>`:'<p class="sm">Plein soleil du ranch, variable selon les jours.</p>'}`;
  return h+`</div><button class="btn alt wide" data-a="rclear" data-id="${i}">Arracher la plante</button>`;
}
ACT.rsub=d=>{ RY2.sub=d.id; renderSheet(); };
function rShop(){
  const F=farm(); let h=`<div class="rtabs sub">${[['seeds',seedIc(18),'Graines'],['chem','🧴','Engrais'],['lamps','💡','Lampes'],['gear','🛠️','Matériel']].map(t=>`<button class="${RY.shop===t[0]?'on':''}" data-a="rshop" data-id="${t[0]}"><span>${t[1]}</span>${t[2]}</button>`).join('')}</div>`;
  if(RY.shop==='seeds') STR.filter(s=>!s.hy).forEach(s=>{ const lock=F.rep<s.rep, lc=PURP[s.id]?'#a85de8':s.ty==='Sativa'?'#8be03c':s.ty==='Indica'?'#1f9d55':'#3cc46a'; h+=`<div class="rit ${lock?'lock':''}"><div class="rart">${leafIc(lc,34)}${seedIc(20)}</div><div class="grow"><b>${s.nom}</b><small>${s.ty} · ${s.thc} % THC · ${s.px} cr/g</small><small>Croiss. ${s.veg} min · Flor. ${s.fl} min · ~${s.y} g · ${(s.lm/1000)|0} k lm</small><span class="dif">${leafIc('#3cff9e',11).repeat(s.d)}${leafIc('#2b2f60',11).repeat(5-s.d)}</span></div>${lock?`<small class="lk">🔒 Rép. ${s.rep}</small>`:`<button class="btn sm" data-a="rbuy" data-id="seed:${s.id}">${fmt(s.sd)}<br><i>×${F.seeds[s.id]||0}</i></button>`}</div>`; });
  else if(RY.shop==='chem') Object.keys(CHEM).forEach(k=>{ const c=CHEM[k]; h+=`<div class="rit"><div class="rart"><span class="big">${c.ic}</span></div><div class="grow"><b>${c.nom}</b><small>${c.sub}</small></div><button class="btn sm" data-a="rbuy" data-id="chem:${k}">${c.px}<br><i>×${F.chem[k]||0}</i></button></div>`; });
  else if(RY.shop==='lamps') LAMP.forEach(l=>{ h+=`<div class="rit"><div class="rart"><span class="big">${l.ic}</span></div><div class="grow"><b>${l.nom}</b><small>${fmt(l.lm)} lumens · ${l.w} W · ${(l.w/100).toFixed(1)} cr/min</small>${rBar(l.lm/950,'#FCEE0A','Puissance')}</div><button class="btn sm" data-a="rbuy" data-id="lamp:${l.id}">${fmt(l.px)}<br><i>×${F.lamps[l.id]||0}</i></button></div>`; });
  else { const tp=[['fan','🌀 Ventilation','Moins de moisissure',2500],['filter','🧯 Filtre à charbon','−20 % de chaleur',4000],['irri','🚿 Irrigation auto','Arrose seule',9000]];
    ['atelier','ranch'].forEach(room=>{ const R=F.rooms[room]; if(!R.on) return; h+=`<h3 class="rh">${ROOMS[room].ic} ${ROOMS[room].nom}</h3>`; tp.forEach(t=>{ const lv=R[t[0]]||0, max=t[0]==='irri'?1:3; h+=`<div class="rit"><div class="grow"><b>${t[1]}</b><small>niv. ${lv}/${max} · ${t[2]}</small></div><button class="btn sm" data-a="rbuy" data-id="gear:${room}:${t[0]}" ${lv>=max?'disabled':''}>${lv>=max?'Max':fmt(t[3]*(lv+1))}</button></div>`; }); });
    h+=`<div class="rit"><div class="grow"><b>🛢️ Citerne +100 L</b><small>Capacité ${F.tank} L</small></div><button class="btn sm" data-a="rbuy" data-id="tank:0">1 200</button></div><div class="rit"><div class="grow"><b>🕴️ Pot-de-vin</b><small>−30 % de chaleur partout</small></div><button class="btn sm" data-a="rbuy" data-id="bribe:0">${fmt(1500+Math.round(Math.max(F.heat.atelier,F.heat.ranch)*80))}</button></div>`; }
  return h;
}
function rStock(){
  const F=farm(); const ks=Object.keys(F.stock).filter(k=>F.stock[k].g>=1);
  let h=`<div class="rcard haze"><h3>🫙 Stock séché</h3>${ks.length?ks.map(k=>{ const s=F.stock[k], sv=SID[k], p=sellPrice(k,s.q);
    return `<div class="rjar"><div class="jb">${budIc(k,46)}</div><div class="grow"><b>${sv.nom}</b><small>${Math.floor(s.g)} g · qualité ${Math.round(s.q)} % · ${p.toFixed(1)} cr/g</small></div></div>
    <div class="rbtns tight"><button data-a="rsell" data-id="${k}" data-v="street10">Rue · 10 g</button><button data-a="rsell" data-id="${k}" data-v="street">Rue · tout</button>${F.rep>=10?`<button data-a="rsell" data-id="${k}" data-v="contact">Contact</button>`:'<button class="dim" disabled>Contact · rép. 10</button>'}${F.rep>=30&&s.q>=65?`<button data-a="rsell" data-id="${k}" data-v="vip">VIP</button>`:'<button class="dim" disabled>VIP · rép. 30</button>'}</div>`; }).join(''):'<p>Rien en stock. Une plante récoltée sèche pendant 2 minutes.</p>'}
  <p class="sm">Rue : 75 % du prix, risqué, karma −. Contact : prix normal. VIP : 135 %. Les livraisons en voiture paient le mieux.</p></div>`;
  if((F.dry||[]).length) h+=`<div class="rcard"><h3>🧺 En séchage</h3>${F.dry.map(b=>`<div class="rrow sm"><span>${budIc(b.sid,22)} ${SID[b.sid].nom} · ${Math.round(b.g)} g</span><span>${Math.ceil(b.t*60)} s</span></div>`).join('')}</div>`;
  return h;
}
function rNet(){
  const F=farm(), k=Math.round(karma()), kt=karmaTitle(), pos=(k+100)/2;
  let h=`<div class="rcard karma"><div class="rrow"><b>${kt[2]} ${kt[1]}</b><span>${k>0?'+':''}${k}</span></div><div class="kbar"><i style="left:${pos}%"></i></div><div class="rrow sm"><span>😈 Truand</span><span>😇 Saint</span></div>
  <p class="sm">${k>=15?`Bonne réputation : +${Math.round(k*.15)} % sur les gains légaux, police moins pressante.`:k<=-15?`Mauvaise réputation : acheteurs +${Math.round(-k/4)} % plus généreux, mais police plus pressante.`:'Ni ange ni démon. Les épreuves légales montent le karma, le trafic le fait chuter.'}</p>
  <div class="rbtns tight">${[['Banque alimentaire',1500,3],['Club de jeunes pilotes',8000,10],['Hôpital',30000,30]].map((d,i)=>`<button data-a="rdon" data-id="${i}" ${S.cr<d[1]?'class="dim"':''}>❤️ ${d[0]}<br><small>${fmt(d[1])} cr · +${d[2]}</small></button>`).join('')}</div></div>
  <div class="rcard"><p>Les go-fast écoulent ta marchandise à prix fort ; les courses clandestines se jouent à la mise. Une manche ratée = cargaison perdue, chaleur et karma −.</p></div>`;
  ILL.forEach(e=>{ const lock=S.lvl<e.lvl||F.rep<e.rep, best=bestCargo(e), few=S.cars.length<e.manches.length, need=e.ill==='cargo'?`${e.cargo} g de marchandise`:`mise ${fmt(e.bet)} cr`;
    h+=`<div class="rit ${lock?'lock':''}"><div class="rart"><span class="big">${e.ill==='cargo'?'📦':'🏁'}</span></div><div class="grow"><b>${e.nom}</b><small>${e.txt}</small><small>${need} · prime ${fmt(e.gain)} · chaleur +${e.heat}</small></div>${lock?`<small class="lk">Niv. ${e.lvl}<br>Rép. ${e.rep}</small>`:`<button class="btn sm" data-a="illgo" data-id="${e.id}" ${(e.ill==='cargo'&&!best)||(e.ill==='bet'&&S.cr<e.bet)||few?'disabled':''}>Go</button>`}</div>`; });
  return h;
}
ACT.rdon=d=>{ const t=[[1500,3],[8000,10],[30000,30]][+d.id]; if(!t||S.cr<t[0]) return toast('Pas assez de crédits'); S.cr-=t[0]; karmaAdd(t[1]); toast('Merci pour ton don ❤️ karma +'+t[1]); save(); renderSheet(); };
/* ===== v0.22 : hangar / ranch 3D, plots à poser, arrosoir, interactions ===== */
const GROW={atelier:{bx:29,bz:19,spawn:{x:26,z:-14,yaw:Math.PI/2},cols:[-18,-6,6,18],rows:[-9,3,14],out:false},
            ranch:{bx:33,bz:29,spawn:{x:0,z:21,yaw:0},cols:[-20,-12,-4,4,12,20],rows:[-17,-9,-1,7],out:true}};
let GC=null; /* géométries et matériaux partagés */
function growCache(){
  if(GC) return GC; const D=THREE.DoubleSide;
  const leafT=ctex(128,128,(x,W,H)=>{ x.translate(64,122); x.fillStyle='#fff'; const L=[[0,92,17,9],[28,74,15,8],[-28,74,15,8],[58,56,12,7],[-58,56,12,7],[88,36,9,5],[-88,36,9,5]];
    L.forEach(d=>{ x.save(); x.rotate(d[0]*Math.PI/180); x.beginPath(); x.moveTo(0,0); const n=d[3]*2,len=d[1],wd=d[2];
      for(let i=1;i<=n;i++){ const t=i/n, w=(wd/2)*Math.sin(Math.PI*Math.pow(t,.72))*(i%2?.62:1); x.lineTo(w,-len*t); } x.lineTo(0,-len-3);
      for(let i=n;i>=1;i--){ const t=i/n, w=(wd/2)*Math.sin(Math.PI*Math.pow(t,.72))*(i%2?.62:1); x.lineTo(-w,-len*t); } x.closePath(); x.fill();
      x.strokeStyle='rgba(0,0,0,.35)'; x.lineWidth=1.4; x.beginPath(); x.moveTo(0,0); x.lineTo(0,-len*.85); x.stroke(); x.restore(); }); });
  const glowT=ctex(64,64,(x,W,H)=>{ const g=x.createRadialGradient(32,32,2,32,32,32); g.addColorStop(0,'rgba(255,230,130,.95)'); g.addColorStop(1,'rgba(255,200,80,0)'); x.fillStyle=g; x.fillRect(0,0,W,H); });
  const leafG=new THREE.PlaneGeometry(1,1); leafG.translate(0,.5,0);
  const lm=c=>new THREE.MeshLambertMaterial({map:leafT,color:c,transparent:true,alphaTest:.35,side:D});
  GC={leafG,stem:(()=>{ const g=new THREE.CylinderGeometry(.045,.07,1,6); g.translate(0,.5,0); return g; })(),bud:new THREE.SphereGeometry(1,8,6),pist:new THREE.SphereGeometry(.2,4,3),
    glowM:new THREE.SpriteMaterial({map:glowT,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}),
    leaf:{ind:lm(0x1f9d55),sat:lm(0x7bd93a),hyb:lm(0x3cc46a),pur:lm(0x7a55d6),dead:lm(0x7a6032)},
    stemM:new THREE.MeshLambertMaterial({color:0x2a8a46}),stemD:new THREE.MeshLambertMaterial({color:0x6b4f2a}),
    budM:new THREE.MeshLambertMaterial({color:0xa6e02e}),budP:new THREE.MeshLambertMaterial({color:0xb36cf0}),pistM:new THREE.MeshBasicMaterial({color:0xff9a1a}),
    mold:new THREE.MeshBasicMaterial({color:0xf0f0f8}),mite:new THREE.MeshBasicMaterial({color:0xff3d3d}),
    soil:{terreau:new THREE.MeshLambertMaterial({color:0x4a2f1d}),coco:new THREE.MeshLambertMaterial({color:0x9a6a38}),hydro:new THREE.MeshBasicMaterial({color:0x2a8ae0})},
    bed:new THREE.MeshLambertMaterial({color:0x23262e}),bedE:new THREE.MeshBasicMaterial({color:0x3cff9e}),
    ring:{empty:new THREE.MeshBasicMaterial({color:0x4a4f80,transparent:true,opacity:.7,side:D}),ok:new THREE.MeshBasicMaterial({color:0x00e5ff,transparent:true,opacity:.8,side:D}),ready:new THREE.MeshBasicMaterial({color:0x3cff9e,transparent:true,opacity:.95,side:D}),sick:new THREE.MeshBasicMaterial({color:0xff4d6d,transparent:true,opacity:.95,side:D}),ghost:new THREE.MeshBasicMaterial({color:0xfcee0a,transparent:true,opacity:.55,side:D})}};
  return GC;
}
function plant3D(sl,pc){
  const C=growCache(), g=new THREE.Group(), sv=SID[sl.sid], pu=!!PURP[sl.sid], lm=sl.st==='dead'?C.leaf.dead:pu?C.leaf.pur:sv.ty==='Sativa'?C.leaf.sat:sv.ty==='Indica'?C.leaf.ind:C.leaf.hyb, p=pc/100;
  const stem=(h)=>{ const s=new THREE.Mesh(C.stem,sl.st==='dead'?C.stemD:C.stemM); s.scale.set(1,h,1); g.add(s); };
  const leaf=(y,ang,size,tilt)=>{ const pv=new THREE.Group(); pv.position.y=y; pv.rotation.y=ang; const m=new THREE.Mesh(C.leafG,lm); m.scale.set(size,size,size); m.rotation.x=tilt; m.position.z=.02; pv.add(m); g.add(pv); };
  if(sl.st==='germ'){ stem(.15+p*.2); leaf(.2+p*.2,0,.28+p*.2,.9); leaf(.2+p*.2,Math.PI,.28+p*.2,.9); }
  else if(sl.st==='dead'){ stem(1); [0,1.7,3.4,5].forEach((a,i)=>leaf(.35+i*.18,a,.7,1.5)); }
  else{
    const h=sl.st==='veg'?.5+p*1.5:2.1, n=sl.st==='veg'?3+Math.floor(p*3):5, sz=sl.st==='veg'?.55+p*.55:.85;
    stem(h); for(let i=0;i<n;i++){ const f=(i+1)/(n+1), y=h*f; for(let k=0;k<3;k++) leaf(y,i*1.1+k*2.1,sz*(1.15-f*.35),.95+f*.2); }
    leaf(h,0,sz*.8,.25);
    if(sl.st==='flo'||sl.st==='ready'){ const rd=sl.st==='ready', r=rd?.2:.07+p*.12, bm=pu?C.budP:C.budM;
      [[0,h+.05,0,1.4],[.3,h*.72,0,.8],[-.3,h*.72,.1,.8],[.1,h*.5,.3,.65],[-.12,h*.5,-.3,.65],[.28,h*.88,-.1,.7],[-.25,h*.9,.1,.7]].forEach(b=>{ const m=new THREE.Mesh(C.bud,bm); m.scale.set(r*b[3],r*b[3]*1.35,r*b[3]); m.position.set(b[0],b[1],b[2]); g.add(m);
        for(let q=0;q<3;q++){ const ps=new THREE.Mesh(C.pist,C.pistM); ps.position.set(b[0]+Math.cos(q*2.4)*r*b[3]*.8,b[1]+Math.sin(q*1.7)*r*b[3]*.8,b[2]+Math.sin(q*2.4)*r*b[3]*.8); g.add(ps); }
        if(rd){ const sp=new THREE.Sprite(C.glowM); sp.scale.set(r*b[3]*4,r*b[3]*4,1); sp.position.set(b[0],b[1],b[2]); g.add(sp); } }); }
  }
  if(sl.pest){ for(let i=0;i<9;i++){ const m=new THREE.Mesh(C.bud,sl.pest==='mold'?C.mold:C.mite); m.scale.setScalar(.045); m.position.set(Math.cos(i*2.3)*.5,.4+i*.18,Math.sin(i*2.3)*.5); g.add(m); } }
  return g;
}
const LAMPC={t5:0xe8f4ff,led:0xffffff,led2:0xd69bff,cmh:0xffd9a0,hps:0xffa24a,ledp:0xff6af0};
function growPlots(room){
  const G=GROW[room], F=farm(), R=F.rooms[room], C=growCache(), grp=new THREE.Group(), pts=[]; HUB.plots=[];
  G.rows.forEach(z=>G.cols.forEach(x=>pts.push([x,z])));
  const max=ROOMS[room].max;
  pts.slice(0,max).forEach((q,i)=>{
    const [x,z]=q, sl=R.slots[i], pg=new THREE.Group(); pg.position.set(x,0,z); grp.add(pg);
    const own=i<R.slots.length, free=i===R.slots.length;
    let st='empty'; if(sl){ st=sl.st==='ready'?'ready':sl.pest?'sick':'ok'; }
    const ring=new THREE.Mesh(new THREE.RingGeometry(1.45,1.62,28),own?C.ring[st]:C.ring[free?'ghost':'empty']); ring.rotation.x=-Math.PI/2; ring.position.y=.03; pg.add(ring); pg.userData.ring=ring;
    if(own){ const bed=new THREE.Mesh(new THREE.BoxGeometry(2,.5,2),C.bed); bed.position.y=.25; pg.add(bed);
      const top=new THREE.Mesh(new THREE.PlaneGeometry(1.8,1.8),C.soil[sl?sl.med:'terreau']); top.rotation.x=-Math.PI/2; top.position.y=.51; pg.add(top);
      const e=new THREE.Mesh(new THREE.BoxGeometry(2.04,.05,2.04),C.bedE); e.position.y=.5; e.scale.set(1,1,1); pg.add(e);
      if(sl){ const sv=SID[sl.sid], pc=sl.st==='ready'?100:Math.round(nz(sl.stAge/({germ:1,veg:sv.veg,flo:sv.fl}[sl.st]||1)*100,100));
      const pl=plant3D(sl,pc); pl.position.y=.5; pl.userData.sway=i; pg.add(pl); pg.userData.plant=pl; }
      if(!ROOMS[room].out&&sl&&sl.lamp){ const lc=LAMPC[sl.lamp]||0xffffff, hy=6.4;
        const cab=new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,4.6,4),new THREE.MeshBasicMaterial({color:0x333344})); cab.position.y=hy+2.3; pg.add(cab);
        const shade=new THREE.Mesh(new THREE.BoxGeometry(sl.lamp==='t5'?2.2:1.7,.16,sl.lamp==='t5'?.35:1.7),new THREE.MeshBasicMaterial({color:lc})); shade.position.y=hy; pg.add(shade);
        const cone=new THREE.Mesh(new THREE.CylinderGeometry(.5,1.7,hy-.55,16,1,true),new THREE.MeshBasicMaterial({color:lc,transparent:true,opacity:.07+LID[sl.lamp].lm/1200000,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide})); cone.position.y=(hy-.55)/2+.55; pg.add(cone); }
    }else{ const m=new THREE.Mesh(new THREE.PlaneGeometry(2,2),new THREE.MeshBasicMaterial({color:free?0xfcee0a:0x2b2f60,transparent:true,opacity:free?.14:.07,depthWrite:false})); m.rotation.x=-Math.PI/2; m.position.y=.04; pg.add(m);
      if(free){ const lb=hubLabel('＋ Poser un plot','#FCEE0A',4,x,z); lb.position.set(x,1.4,z); pg.add(lb); HUB.labels.push(lb); } }
    HUB.plots.push({i,x,z,pg});
  });
  return grp;
}
function growSig(room){ const R=farm().rooms[room]; return room+R.slots.length+R.slots.map(s=>!s?'-':s.sid+s.st+Math.floor(s.stAge*1.7)+(s.pest||'')+(s.lamp||'')+s.med+Math.floor(s.hp/25)).join('|'); }
function growBuild(room){
  const G=GROW[room], out=G.out, F=farm(); HUB.labels=[]; HUB.obs=[]; HUB.pois=[]; HUB.bx=G.bx; HUB.bz=G.bz; HUB.ents={npcs:[],pods:[]}; HUB.map=room;
  const sc=new THREE.Scene(), cam=new THREE.PerspectiveCamera(100,1.5,.1,320);
  const bg=out?0x2a1a4a:0x06120f; sc.background=new THREE.Color(bg); sc.fog=new THREE.Fog(bg,out?60:50,out?170:120);
  sc.add(new THREE.HemisphereLight(out?0xfff0d0:0xb8ffd8,out?0x3a2a5a:0x2a0a4a,out?1.5:1.25)); const dl=new THREE.DirectionalLight(out?0xffe2a8:0xff9af0,out?1.1:.45); dl.position.set(-20,50,30); sc.add(dl);
  const neon=c=>new THREE.MeshBasicMaterial({color:c}), L=c=>new THREE.MeshLambertMaterial({color:c});
  const box=(w,h,d,x,y,z,mat)=>{ const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat); m.position.set(x,y,z); sc.add(m); return m; };
  const BX=G.bx+1, BZ=G.bz+1;
  const gt=ctex(256,256,(x,W,H)=>{ if(out){ x.fillStyle='#1d4a2a'; x.fillRect(0,0,W,H); for(let i=0;i<1200;i++){ x.fillStyle=`rgba(${40+Math.random()*60|0},${110+Math.random()*80|0},${50+Math.random()*50|0},.5)`; x.fillRect(Math.random()*W,Math.random()*H,2,5); } }
    else{ x.fillStyle='#161a22'; x.fillRect(0,0,W,H); for(let i=0;i<700;i++){ x.fillStyle=`rgba(150,170,190,${.03+Math.random()*.05})`; x.fillRect(Math.random()*W,Math.random()*H,2,2); } x.strokeStyle='rgba(60,255,158,.18)'; x.lineWidth=2; x.strokeRect(1,1,W-2,H-2); x.strokeStyle='rgba(255,43,214,.1)'; x.beginPath(); x.moveTo(W/2,0); x.lineTo(W/2,H); x.moveTo(0,H/2); x.lineTo(W,H/2); x.stroke(); } },[BX*2/8,BZ*2/8]);
  const fl=new THREE.Mesh(new THREE.PlaneGeometry(BX*2+(out?160:0),BZ*2+(out?160:0)),new THREE.MeshLambertMaterial({map:gt})); fl.rotation.x=-Math.PI/2; sc.add(fl);
  if(!out){
    const wt=ctex(128,128,(x,W,H)=>{ x.fillStyle='#202a2c'; x.fillRect(0,0,W,H); for(let i=0;i<W;i+=8){ x.fillStyle=i%16?'#273234':'#1a2224'; x.fillRect(i,0,6,H); } },[BX/4,1.6]);
    const wm=new THREE.MeshLambertMaterial({map:wt}), HH=12;
    box(BX*2+1,HH,.6,0,HH/2,-BZ-.3,wm); box(BX*2+1,HH,.6,0,HH/2,BZ+.3,wm); box(.6,HH,BZ*2,-BX-.3,HH/2,0,wm); box(.6,HH,BZ*2,BX+.3,HH/2,0,wm);
    const ce=new THREE.Mesh(new THREE.PlaneGeometry(BX*2,BZ*2),new THREE.MeshBasicMaterial({color:0x07100e,side:THREE.DoubleSide})); ce.rotation.x=Math.PI/2; ce.position.y=HH; sc.add(ce);
    for(let i=-4;i<=4;i++) box(BX*2,.35,.35,0,HH-.3,i*5,L(0x2a3438)); for(let i=-5;i<=5;i++) box(.35,.35,BZ*2,i*6,HH-.7,0,L(0x2a3438));
    [[BX*2,.14,.08,0,3,-BZ+.1,0x3cff9e],[BX*2,.14,.08,0,3,BZ-.1,0xff2bd6],[.08,.14,BZ*2,-BX+.1,3,0,0x3cff9e],[.08,.14,BZ*2,BX-.1,3,0,0xff2bd6]].forEach(a=>box(a[0],a[1],a[2],a[3],a[4],a[5],neon(a[6])));
    for(let i=-2;i<=2;i++) [-1,1].forEach(s=>box(.9,.07,10,i*11,HH-.9,s*8,neon(0xe8fff4)));
    [-1,1].forEach(s=>[0,1,2].forEach(k=>{ const p=new THREE.Mesh(new THREE.CylinderGeometry(.25,.25,BX*2,10),L(0x3a4650)); p.rotation.z=Math.PI/2; p.position.set(0,2.4+k*.9,s*(BZ-.5)); sc.add(p); })); /* tuyaux */
    HUB.fans=[]; [[-12,-BZ+.4],[12,-BZ+.4]].forEach(a=>{ const f=new THREE.Group(); f.position.set(a[0],7.5,a[1]); [0,1,2,3].forEach(k=>{ const b=new THREE.Mesh(new THREE.BoxGeometry(2.6,.06,.5),L(0x8a949c)); b.rotation.z=k*Math.PI/2; b.position.z=.1; f.add(b); }); const ring=new THREE.Mesh(new THREE.TorusGeometry(1.5,.12,6,20),L(0x3a4650)); f.add(ring); sc.add(f); HUB.fans.push(f); });
    /* DA rasta-psyché : bandes néon + posters mandala + enseignes */
    [[0xff2d2d,3.6],[0xffd400,4.0],[0x1fe06a,4.4]].forEach(a=>{ box(BX*2,.16,.08,0,a[1],-BZ+.12,neon(a[0])); box(.08,.16,BZ*2,BX-.12,a[1],0,neon(a[0])); });
    const mand=(c1,c2)=>ctex(256,256,(x,W,H)=>{ x.fillStyle='#0a0418'; x.fillRect(0,0,W,H); x.translate(128,128); for(let r=0;r<9;r++){ for(let k=0;k<14;k++){ x.save(); x.rotate(k/14*6.283+r*.12); x.fillStyle=`hsl(${(r*40+k*12+c1)%360},95%,${52+r*2}%)`; x.globalAlpha=.9; x.beginPath(); x.ellipse(0,-(18+r*12),7+r*.8,13+r*1.2,0,0,6.283); x.fill(); x.restore(); } } x.globalAlpha=1; x.fillStyle=c2; x.beginPath(); x.arc(0,0,14,0,6.283); x.fill(); x.fillStyle='#0a0418'; x.font='bold 22px sans-serif'; x.textAlign='center'; x.textBaseline='middle'; x.fillText('🌿',0,1); x.setTransform(1,0,0,1,0,0); x.strokeStyle='#ffd400'; x.lineWidth=6; x.strokeRect(3,3,W-6,H-6); });
    [[-18,0,'#ffd400'],[18,140,'#1fe06a']].forEach(a=>{ const pm=new THREE.Mesh(new THREE.PlaneGeometry(6,6),new THREE.MeshBasicMaterial({map:mand(a[1],a[2])})); pm.position.set(a[0],6.6,-BZ+.35); sc.add(pm); });
    const ol=labelSprite('ONE LOVE · IRIE','#FFD400',18); ol.position.set(0,6.6,-BZ+.5); ol.material.depthTest=false; ol.renderOrder=19; sc.add(ol);
    const ban=labelSprite('SERRE · HIGH & ROUILLÉ','#3CFF9E',26); ban.position.set(0,9.2,-BZ+1); ban.material.depthTest=false; ban.renderOrder=20; sc.add(ban);
  }else{
    for(let i=-BX;i<=BX;i+=4){ box(.25,2,.25,i,1,-BZ,L(0x6a4a2a)); box(.25,2,.25,i,1,BZ,L(0x6a4a2a)); } for(let i=-BZ;i<=BZ;i+=4){ box(.25,2,.25,-BX,1,i,L(0x6a4a2a)); box(.25,2,.25,BX,1,i,L(0x6a4a2a)); }
    [[BX*2,.18,.12,0,1.5,-BZ],[BX*2,.18,.12,0,1.5,BZ],[.12,.18,BZ*2,-BX,1.5,0],[.12,.18,BZ*2,BX,1.5,0]].forEach(a=>box(a[0],a[1],a[2],a[3],a[4],a[5],L(0x8a6a3a)));
    box(14,8,10,-24,4,-BZ-9,L(0x8a2a22)); box(15,.6,11,-24,8.4,-BZ-9,L(0x3a2a2a)); /* grange */
    for(let i=0;i<18;i++){ const a=i/18*6.28, t=new THREE.Mesh(new THREE.ConeGeometry(3,9,7),L(0x14502a)); t.position.set(Math.cos(a)*(BX+22),4.5,Math.sin(a)*(BZ+22)); sc.add(t); }
    const sun=new THREE.Sprite(new THREE.SpriteMaterial({map:growCache().glowM.map,color:0xffd36a,fog:false})); sun.scale.set(80,80,1); sun.position.set(-60,70,-150); sc.add(sun);
  }
  /* décor + points d'interaction */
  const poi=(id,x,z,r,title,btns)=>HUB.pois.push({id,x,z,r,title,btns});
  const wall=out?BZ:BZ;
  if(!out){
    /* citerne + robinet */
    const tk=new THREE.Mesh(new THREE.CylinderGeometry(1.5,1.5,3.4,16),new THREE.MeshLambertMaterial({color:0x2a7ad0})); tk.position.set(-24,1.7,-BZ+2); sc.add(tk); box(.3,2.6,.3,-22.2,3.2,-BZ+2,L(0x9aa4ac)); box(1,.2,.2,-21.8,4.3,-BZ+2,L(0x9aa4ac)); box(3.5,.02,2.5,-22,.02,-BZ+4.5,neon(0x1d5aa0)); HUB.obs.push({x:-24,z:-BZ+2,r:1.9});
    const tl=hubLabel('💧 EAU','#4aa8ff',5,-24,-BZ+2); tl.position.set(-24,5,-BZ+2); sc.add(tl);
    poi('tap',-23,-BZ+5,3.6,()=>`💧 Point d’eau · arrosoir ${F.can||0}/6 · citerne ${Math.round(F.water)}/${F.tank} L`,()=>[{id:'can',tx:'🪣 Remplir l’arrosoir'},{id:'tank',tx:'🛢️ Remplir la citerne',alt:1}]);
    /* étagère engrais */
    [.5,1.5,2.5].forEach(y=>box(6,.1,1,-8,y,-BZ+1,L(0x4a5660))); [[0x3cff9e],[0xff9a1a],[0xa58bff],[0x4aa8ff],[0xff4d6d]].forEach((c,i)=>{ for(let k=0;k<3;k++){ box(.5,.9,.5,-10+i*1.4+(k%2)*.05,.95+k*1,-BZ+1,neon(c[0])); box(.2,.25,.2,-10+i*1.4,1.5+k*1,-BZ+1,L(0xdddddd)); } });
    const sl=hubLabel('🛒 BOUTIQUE','#FCEE0A',6,-8,-BZ+1); sl.position.set(-8,4.6,-BZ+1); sc.add(sl); HUB.obs.push({x0:-11.2,x1:-4.8,z0:-BZ,z1:-BZ+2});
    poi('shop',-8,-BZ+4,3.8,()=>'🛒 Boutique du réseau',()=>[{id:'shop',tx:'Graines, engrais, lampes'},{id:'seeds',tx:'🌱 Graines',alt:1}]);
    /* bureau / ordinateur */
    box(5,.15,2,10,1,-BZ+1.5,L(0x2a3438)); [-2.2,2.2].forEach(s=>box(.15,1,1.8,10+s,.5,-BZ+1.5,L(0x2a3438))); box(2.4,1.5,.15,10,2.1,-BZ+.8,neon(0x00e5ff)); box(2.6,1.7,.1,10,2.1,-BZ+.7,L(0x111118)); HUB.obs.push({x0:7.4,x1:12.6,z0:-BZ,z1:-BZ+2.6});
    const nl=hubLabel('🚗 RÉSEAU','#00E5FF',6,10,-BZ+1); nl.position.set(10,4.4,-BZ+1); sc.add(nl);
    poi('net',10,-BZ+4,3.8,()=>'🚗 Terminal du réseau',()=>[{id:'net',tx:'Missions & karma'},{id:'stock',tx:'🫙 Stock & vente',alt:1}]);
    /* séchoir */
    for(let i=0;i<3;i++){ box(.1,3.6,.1,20+i*2.2,1.8,-BZ+1.2,L(0x4a5660)); } box(5,.1,.1,22.2,3.5,-BZ+1.2,L(0x4a5660));
    (F.dry||[]).slice(0,8).forEach((b,i)=>{ const m=new THREE.Mesh(growCache().bud,PURP[b.sid]?growCache().budP:growCache().budM); m.scale.set(.25,.4,.25); m.position.set(20.2+i*.55,3,-BZ+1.2); sc.add(m); });
    const dl2=hubLabel('SÉCHOIR','#FF9A1A',5,22,-BZ+1); dl2.position.set(22,4.6,-BZ+1); sc.add(dl2);
    /* portes */
    const door=(x,z,rot,col,txt)=>{ box(rot?.5:4,6,rot?4:.5,x,3,z,L(0x1a1f24)); box(rot?.6:4.4,.25,rot?4.4:.6,x,6.1,z,neon(col)); const d=hubLabel(txt,'#'+col.toString(16).padStart(6,'0'),6,x,z); d.position.set(x,7.2,z); sc.add(d); };
    door(BX-.5,-14,1,0x3cff9e,'↩ GARAGE'); door(-BX+.5,2,1,0xfcee0a,'🌾 RANCH');
    poi('exit',BX-3.5,-14,3.6,()=>'Cloison du garage',()=>[{id:'exit',tx:'↩ Retourner au garage'}]);
    poi('ranch',-BX+3.5,2,3.6,()=>'🌾 Porte du ranch',()=>[{id:'ranch',tx:F.rooms.ranch.on?'Aller au ranch':'Le ranch (à acheter)'}]);
    /* flèches au sol */
    const chev=ctex(64,64,(x,W,H)=>{ x.strokeStyle='#3cff9e'; x.lineWidth=7; x.lineCap='round'; x.beginPath(); x.moveTo(14,12); x.lineTo(46,32); x.lineTo(14,52); x.stroke(); });
    [[0,-4.5,Math.PI/2,52,2.2]].forEach(a=>{ const t=chev.clone(); t.needsUpdate=true; t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(a[3]/2.4,1); const m=new THREE.Mesh(new THREE.PlaneGeometry(a[3],a[4]),new THREE.MeshBasicMaterial({map:t,transparent:true,opacity:.55,depthWrite:false})); m.rotation.order='YXZ'; m.rotation.set(-Math.PI/2,0,0); m.position.set(0,.035,a[1]+1.4); sc.add(m); });
  }else{
    const wl=hubLabel('💧 PUITS','#4aa8ff',5,-28,-24); wl.position.set(-28,4.6,-24); sc.add(wl); const wm=new THREE.Mesh(new THREE.CylinderGeometry(1.4,1.6,1.2,14),L(0x6a6a72)); wm.position.set(-28,.6,-24); sc.add(wm); box(.2,3,.2,-29.3,2.4,-24,L(0x6a4a2a)); box(.2,3,.2,-26.7,2.4,-24,L(0x6a4a2a)); box(3.2,.2,.9,-28,4,-24,L(0x8a2a22)); HUB.obs.push({x:-28,z:-24,r:2});
    poi('tap',-28,-21,3.8,()=>`💧 Puits · arrosoir ${F.can||0}/6 · citerne ${Math.round(F.water)}/${F.tank} L`,()=>[{id:'can',tx:'🪣 Remplir l’arrosoir'},{id:'tank',tx:'🛢️ Remplir la citerne',alt:1}]);
    const gl=hubLabel('🛒 GRANGE','#FCEE0A',6,-24,-BZ-3); gl.position.set(-24,10,-BZ-3); sc.add(gl);
    poi('shop',-24,-BZ+3,4,()=>'🛒 Grange du ranch',()=>[{id:'shop',tx:'Graines, engrais, lampes'}]);
    box(5,.15,2,26,1,-24,L(0x4a3a2a)); box(2.4,1.5,.15,26,2.1,-24.6,neon(0x00e5ff)); const nl=hubLabel('🚗 RÉSEAU','#00E5FF',6,26,-24); nl.position.set(26,4.4,-24); sc.add(nl); HUB.obs.push({x0:23.4,x1:28.6,z0:-25.2,z1:-22.8});
    poi('net',26,-21,3.8,()=>'🚗 Terminal du réseau',()=>[{id:'net',tx:'Missions & karma'},{id:'stock',tx:'🫙 Stock & vente',alt:1}]);
    poi('exit',0,BZ-2,4,()=>'Portail du ranch',()=>[{id:'back',tx:'↩ Retour à l’atelier'}]);
    box(6,3,.3,-3.5,1.5,BZ,L(0x6a4a2a)); box(6,3,.3,3.5,1.5,BZ,L(0x6a4a2a)); const bl=hubLabel('↩ ATELIER','#3CFF9E',6,0,BZ); bl.position.set(0,5,BZ); sc.add(bl);
  }
  /* plots dynamiques */
  HUB.plotGroup=growPlots(room); sc.add(HUB.plotGroup); HUB.gsig=growSig(room); HUB.gAcc=0;
  /* un POI par plot (recalculés à la volée) */
  HUB.scene=sc; HUB.cam=cam; HUB.pos={x:G.spawn.x,z:G.spawn.z}; HUB.yaw=G.spawn.yaw; HUB.pit=0;
}
function plotPoi(room,pl){
  const F=farm(), R=F.rooms[room], sl=R.slots[pl.i], free=pl.i===R.slots.length;
  if(pl.i>R.slots.length) return null;
  if(!sl&&!free) return {id:'plot'+pl.i,title:()=>`🪴 Plot n° ${pl.i+1} · vide`,btns:()=>[{id:'open',tx:'🌱 Planter'}]};
  if(free) return {id:'plot'+pl.i,title:()=>`＋ Nouveau plot (n° ${pl.i+1})`,btns:()=>[{id:'place',tx:`Poser un plot · ${fmt(1500+R.slots.length*900)} cr`}]};
  const sv=SID[sl.sid], lab={germ:'Germination',veg:'Croissance',flo:'Floraison',ready:'Prête',dead:'Morte'}[sl.st], pcf=()=>{ if(sl.st==='ready') return 100; const v=Math.round(nz((sl.stAge||0)/(({germ:1,veg:sv.veg,flo:sv.fl}[sl.st])||1)*100,100)); return isFinite(v)?v:0; };
  return {id:'plot'+pl.i,title:()=>`${sv.ic} ${sv.nom} · ${lab} ${sl.st==='ready'||sl.st==='dead'?'':pcf()+' %'} · eau ${Math.round(sl.w)} %${sl.pest?' · ⚠️':''}`,
    btns:()=>{ const b=[]; if(sl.st==='ready') b.push({id:'harvest',tx:'✂️ Récolter'}); else if(sl.st==='dead') b.push({id:'clear',tx:'Évacuer'}); else b.push({id:'water',tx:`💧 Arroser${(F.can||0)?` (${F.can})`:''}`}); b.push({id:'open',tx:'📋 Fiche',alt:1}); return b; }};
}
function growTick(dt){
  const H=HUB, room=H.map, F=farm(); H.gAcc+=dt;
  if(H.fans) H.fans.forEach(f=>{ f.rotation.z+=dt*6; });
  (H.plots||[]).forEach(pl=>{ const pg=pl.pg, p=pg.userData.plant; if(p){ p.rotation.z=Math.sin(H.t*1.3+pl.i)*.018; p.rotation.x=Math.cos(H.t*1.1+pl.i)*.015; } if(pg.userData.ring&&pg.userData.ring.material.opacity>.9) pg.userData.ring.material.opacity=.55+.4*Math.abs(Math.sin(H.t*3)); });
  if(H.gAcc>1.3){ H.gAcc=0; ranchSim(); const sg=growSig(room); if(sg!==H.gsig){ H.gsig=sg; const keep=H.labels.filter(l=>!(HUB.plotGroup&&HUB.plotGroup.children.some(c=>c.children.includes(l)))); H.labels=keep; H.scene.remove(H.plotGroup); H.plotGroup=growPlots(room); H.scene.add(H.plotGroup); }
    const gh=$('growhud'); if(gh){ const h=Math.round(F.heat[room]), kt=karmaTitle(); gh.innerHTML=`<span>💰 ${fmt(S.cr)}</span><span>🎟 ${fmt((S.arc&&S.arc.tk)||0)}</span><span>🪣 ${F.can||0}/6</span><span class="${h>60?'hot':''}">🚨 ${h}%</span><span>${kt[2]} ${Math.round(karma())}</span>`; } }
  /* POI le plus proche */
  const p=H.pos; let best=null, bd=1e9;
  (H.pois||[]).forEach(q=>{ const d=Math.hypot(p.x-q.x,p.z-q.z); if(d<q.r&&d<bd){ bd=d; best=q; } });
  (H.plots||[]).forEach(pl=>{ const d=Math.hypot(p.x-pl.x,p.z-(pl.z+(ROOMS[room].out?1.7:1.7))); if(d<3.3&&d<bd){ const q=plotPoi(room,pl); if(q){ bd=d; best=q; } } });
  H.gbest=best;
}
ACT.growgo=d=>{
  const F=farm(), room=HUB.map, id=d.id, v=d.v; RY.tab=room;
  if(id.startsWith('plot')){ const i=+id.slice(4), R=F.rooms[room], sl=R.slots[i];
    if(v==='place') return ACT.rbuyslot({id:room});
    if(v==='open'){ RY.slot=i; RY.pick=null; return openSheet({t:'ranch'}); }
    if(v==='water'){ ACT.rcare({id:String(i),v:'water'}); HUB.gsig=''; return; }
    if(v==='harvest'){ ACT.rharvest({id:String(i)}); HUB.gsig=''; return; }
    if(v==='clear'){ ACT.rclear({id:String(i)}); HUB.gsig=''; return; } return; }
  if(id==='tap'){ if(v==='can'){ if(F.water<3) return toast('Citerne vide : remplis-la'); const n=Math.min(6-(F.can||0),Math.floor(F.water/3)); if(n<=0) return toast('Arrosoir plein'); F.can=(F.can||0)+n; F.water-=n*3; toast('Arrosoir rempli : '+F.can+'/6'); save(); } else ACT.rwater(); return; }
  if(id==='shop'){ RY.tab='shop'; RY.shop=v==='seeds'?'seeds':RY.shop; RY.slot=null; return openSheet({t:'ranch'}); }
  if(id==='net'){ RY.tab=v==='stock'?'stock':'net'; RY.slot=null; return openSheet({t:'ranch'}); }
  if(id==='exit'){ if(v==='back') return growEnter('atelier'); return growExit(); }
  if(id==='ranch'){ if(F.rooms.ranch.on) return growEnter('ranch'); RY.tab='ranch'; RY.slot=null; return openSheet({t:'ranch'}); }
};
ACT.growexit=()=>growExit();
function growEnter(room){ HUB.map=room; HUB.sig=''; HUB.nkey=''; closeSheet(); render(); }
function growExit(){ HUB.map='garage'; HUB.sig=''; HUB.nkey=''; closeSheet(); render(); HUB.pos={x:31.4,z:-16}; HUB.yaw=Math.PI/2; HUB.pit=0; }
ACT.ranchSheet=function(){ rotNow(false); RY.rot=true; _ranch0(); };
ACT.ranch=function(){ const F=farm(); F.found=1; if(view==='hub'&&glEnsure()&&window.THREE){ growEnter('atelier'); } else ACT.ranchSheet(); };
function ranchLeft(){ $('sheet').classList.remove('rch'); if(RY.rot){ RY.rot=false; if(view==='hub') rotNow(true); } if(view==='hub'&&HUB.map&&HUB.map!=='garage') HUB.gsig=''; }
function hubBackA(){ return HUB.map&&HUB.map!=='garage'?'growexit':'tab'; }
/* ===== v0.23 : sac à dos (inventaire) + tuto complet du labo caché ===== */
const GT=[
 {ic:'🚪',t:'Tu as trouvé le labo !',x:'Derrière la cloison du garage se cache <b>ton labo clandestin</b> : un hangar où tu fais pousser, sèches et vends ta récolte. L’argent gagné ici sert à acheter des voitures, des pièces, et à payer des courses illégales. <b>Kit de départ offert</b> : 2 graines de Northern Lights, 2 lampes néon et un peu d’engrais.'},
 {ic:'🕹️',t:'Se déplacer & agir',x:'Joystick à gauche pour marcher, glisse le doigt sur la scène pour regarder autour. <b>Approche-toi</b> d’un plot, du robinet, du bureau ou d’une porte : des <b>boutons s’affichent en haut de l’écran</b>. C’est comme ça qu’on fait tout. Le bouton <b>🎒</b> ouvre ton sac, <b>❓</b> relance ce tuto.'},
 {ic:'🪴',t:'1 · Poser un plot',x:'Un <b>plot</b> = un bac où pousse une plante. Tu en as 6 au départ. Le cercle <b>jaune « ＋ »</b> est le prochain emplacement à acheter (jusqu’à 12 dans l’atelier). Va sur un plot vide et appuie <b>🌱 Planter</b> : choisis la graine, le support (terreau, coco, hydro) et la lampe.'},
 {ic:'💧',t:'2 · L’eau',x:'Va au <b>point d’eau (coin bleu, à gauche)</b> : <b>🪣 Remplir l’arrosoir</b> (6 charges, tirées de la citerne). Ensuite, devant une plante, appuie <b>💧 Arroser</b>. Une plante assoiffée (eau &lt; 30 %) perd de la santé. La citerne se remplit à <b>1 cr par litre</b>.'},
 {ic:'🌱',t:'3 · Le cycle de la plante',x:'<b>Germination</b> (courte) → <b>Croissance</b> → <b>Floraison</b> → <b>Prête ✨</b> (le cercle au sol devient vert et pulse). Chaque variété a sa durée. Une plante qui meurt (manque d’eau, maladie) est à évacuer. Le temps passe aussi quand le jeu est fermé.'},
 {ic:'🧪',t:'4 · Engrais, pH, lampes',x:'Dans la <b>📋 Fiche</b> d’un plot : N-P-K (vert/orange/violet), <b>pH</b> à garder proche de 6 (±), Cal-Mag, enzymes, booster de floraison. Une lampe plus puissante = plus de lumens = meilleure croissance, mais plus de <b>chaleur</b>. Moisissures ⚪ et acariens 🔴 s’soignent avec fongicide / insecticide.'},
 {ic:'✂️',t:'5 · Récolter, sécher, vendre',x:'Plante prête → <b>✂️ Récolter</b>. La récolte va <b>sécher</b> au séchoir (coin orange, quelques minutes) puis entre dans ton <b>stock</b>. Au <b>bureau 🚗 Réseau</b> → <b>Stock &amp; vente</b> : vends à la rue (rapide, risqué), au dealer ou en gros. La qualité fait le prix.'},
 {ic:'🚨',t:'6 · Chaleur & karma',x:'Plus tu produis et vends, plus la <b>chaleur 🚨</b> monte (barre en haut à droite). À 100 %, <b>descente de police</b> : saisie et amende. Baisse-la avec ventilation, filtres, ou en pot-de-vin. Le <b>karma</b> change selon tes choix : dons et courses légales = positif, vente de rue et deals = négatif. Il influe sur les prix et les primes.'},
 {ic:'🏁',t:'7 · Le lien avec les courses',x:'Au bureau, onglet <b>Missions</b> : go-fast (livre de la marchandise de ton stock en course) et courses à mise. Tu gagnes des crédits, de la réputation et de la chaleur. Plus ta <b>réputation</b> monte, plus il y a de missions — et le <b>Ranch 🌾</b> (porte à gauche) se débloque : un grand champ extérieur avec 24 plots.'},
 {ic:'🎒',t:'8 · Ton sac à dos',x:'Le <b>🎒</b> liste tout ce que tu possèdes <b>et où l’utiliser</b> : arrosoir et citerne, graines, engrais, lampes, séchoir, stock à vendre, cargaison. Rien à gérer à la main : le jeu prend ce qu’il faut automatiquement. Première étape conseillée : <b>pose et plante un premier plot, remplis l’arrosoir, arrose</b>. Bonne pousse !'}
];
function giveKit(){ const F=farm(); if(F.kit) return; F.kit=1; F.seeds.nl=(F.seeds.nl||0)+2; F.can=6; save(); }
function gtutoSheet(X){
  if(!sheet||sheet.t!=='gtuto') return false;
  const i=sheet.i||0, T=GT[i], last=i===GT.length-1;
  $('sheet').innerHTML=`<div class="tuto gtu">${X}<div class="tu-ic">${T.ic}</div><h2>${T.t}</h2><p>${T.x}</p>
   <div class="tu-dots">${GT.map((_,k)=>`<i class="${k===i?'on':k<i?'d':''}"></i>`).join('')}</div>
   <div class="tu-btns">${i?'<button class="btn alt" data-a="gtunext" data-id="-1">‹ Retour</button>':'<button class="btn alt" data-a="close">Passer</button>'}<button class="btn" data-a="${last?'close':'gtunext'}" data-id="1">${last?'C’est parti !':'Suivant ›'}</button></div></div>`;
  return true;
}
ACT.gtunext=d=>{ if(!sheet||sheet.t!=='gtuto') return; sheet.i=clamp((sheet.i||0)+(+d.id),0,GT.length-1); renderSheet(); $('sheet').scrollTop=0; };
ACT.gtuto=()=>{ giveKit(); farm().tutoSeen=1; openSheet({t:'gtuto',i:0}); };
function invRow(ic,n,q,where){ return `<div class="inv-r"><span class="inv-i">${ic}</span><div class="inv-t"><b>${n}</b><small>${where||''}</small></div><span class="inv-q">${q}</span></div>`; }
function invSheet(X){
  if(!sheet||sheet.t!=='inv') return false;
  const F=farm(), sec=(t,b)=>b?`<div class="inv-s"><h3>${t}</h3>${b}</div>`:'';
  const seeds=STR.filter(s=>(F.seeds[s.id]||0)>0).map(s=>invRow(s.ic,s.nom,'×'+F.seeds[s.id],`${s.ty} · ${s.veg+s.fl} sem. · à planter sur un plot vide`)).join('');
  const chem=Object.keys(CHEM).filter(k=>(F.chem[k]||0)>0).map(k=>invRow(CHEM[k].ic,CHEM[k].nom,'×'+F.chem[k],CHEM[k].sub+' · dans la Fiche d’un plot')).join('');
  const lamps=LAMP.filter(l=>(F.lamps[l.id]||0)>0).map(l=>invRow(l.ic,l.nom,'×'+F.lamps[l.id],`${l.lm.toLocaleString('fr')} lm · ${l.w} W · choisie en plantant`)).join('');
  const stock=Object.keys(F.stock).filter(k=>F.stock[k].g>=.5).map(k=>invRow(SID[k].ic,SID[k].nom+' (sec)',Math.floor(F.stock[k].g)+' g',`qualité ${Math.round(F.stock[k].q)} % · à vendre au bureau 🚗`)).join('');
  const dry=(F.dry||[]).map(b=>invRow(SID[b.sid]?SID[b.sid].ic:'🌿',(SID[b.sid]?SID[b.sid].nom:'Récolte')+' (humide)',Math.round(b.g||0)+' g','en séchage · coin orange de l’atelier')).join('');
  const gear=[['🪣','Arrosoir',(F.can||0)+'/6','se remplit au point d’eau 💧'],['🛢️','Citerne',Math.round(F.water)+'/'+F.tank+' L','1 cr / litre · point d’eau'],['🌬️','Ventilation',(F.rooms.atelier.fan?'oui':'non'),'réduit la chaleur'],['🧯','Filtre à charbon',(F.rooms.atelier.filter?'oui':'non'),'réduit la chaleur'],['🚿','Irrigation',(F.rooms.atelier.irri?'oui':'non'),'arrose seule les plots']].map(a=>invRow(a[0],a[1],a[2],a[3])).join('');
  const c=(typeof R!=='undefined'&&R&&R.cargo)?invRow('📦','Cargaison en cours',Math.round(R.cargo.g)+' g','à livrer pendant la course'):'';
  const h=Math.round(Math.max(F.heat.atelier,F.heat.ranch)), kt=karmaTitle();
  $('sheet').innerHTML=`<div class="inv">${X}<h2>🎒 Sac à dos</h2>
   <div class="inv-top"><span>💰 ${fmt(S.cr)} cr</span><span>🚨 chaleur ${h} %</span><span>${kt[2]} karma ${Math.round(karma())}</span></div>
   ${sec('🪣 Matériel',gear)}${sec('🌱 Graines',seeds||'<p class="sm">Aucune graine — boutique du labo (étagère jaune).</p>')}${sec('🧴 Engrais & produits',chem||'<p class="sm">Rien — boutique du labo.</p>')}${sec('💡 Lampes',lamps||'<p class="sm">Aucune lampe.</p>')}${sec('🌿 Au séchage',dry)}${sec('🫙 Stock à vendre',stock||'<p class="sm">Pas de stock : récolte puis sèche une plante.</p>')}${sec('📦 Cargaison',c)}
   <div class="tu-btns"><button class="btn alt" data-a="gtuto">❓ Revoir le tuto</button><button class="btn" data-a="close">Fermer</button></div></div>`;
  return true;
}
ACT.inv=()=>{ openSheet({t:'inv'}); };
/* premier passage dans le labo : kit + tuto */
const _growEnter=growEnter;
growEnter=function(room){ _growEnter(room); const F=farm(); if(GROW[room]&&!F.tutoSeen){ F.tutoSeen=1; giveKit(); setTimeout(()=>openSheet({t:'gtuto',i:0}),500); } };
/* menus du monde ouvert : le téléphone repasse en portrait à l'ouverture, en paysage à la fermeture */
const _openSheet0=openSheet;
openSheet=function(s){ if(view==='hub'&&document.body.classList.contains('hubmode')&&!HUB.rot){ HUB.rot=true; document.body.classList.add('menuport'); rotNow(false); } _openSheet0(s); };
const _closeSheet0=closeSheet;
closeSheet=function(){ _closeSheet0(); if(HUB.rot){ HUB.rot=false; document.body.classList.remove('menuport'); if(view==='hub') rotNow(true); } };
/* ===== v0.27 : paquets — rotation au doigt, déchirure par swipe, voiture complète (ultra rare) ===== */
PK.ry=0; PK.rv=0; PK.arm=null; PK.snap=null;
const CAR_P={p1:.0004,p2:.0008,p3:.002,p4:.006}; /* chance par paquet : 0,04 % → 0,6 % */
function pack3d(p,i){
  const th=PKT[p.id]||PKT.p1, pips=[0,1,2].map(k=>RAR[Math.min(6,p.min+k)]).map(r=>`<i style="background:${r.c}"></i>`).join('');
  return `<div class="pk" data-i="${i}" style="--c1:${th.c1};--c2:${th.c2};--c3:${th.c3}">
    <div class="lay l1"></div><div class="lay l2"></div><div class="lay l3"></div>
    <div class="lay fr"><div class="crimp t"></div><div class="crimp b"></div>
      <div class="ct"><span class="tag">${th.tag}</span><span class="emb">${th.emb}</span><div><div class="nm">${p.nom.replace('Paquet ','')}</div><div class="sb">${p.n} modules</div></div><span class="pips">${pips}</span></div><div class="shine"></div><div class="tearln"></div><div class="tearfill"></div></div>
    <div class="lay bk"><div class="crimp t"></div><div class="crimp b"></div><div class="ct"><span class="tag">HIGH &amp; ROUILLÉ</span><span class="emb">🃏</span><span class="sb">${p.d}</span><span class="tag">COLLECTION</span></div></div></div>`;
}
function pkInfo(force){
  const el=$('pkInfo'); if(!el) return; const i=clamp(Math.round(PK.drag?PK.pos:PK.tgt),0,PACKS.length-1);
  if(PK.arm&&PK.arm.id!==PACKS[i].id){ PK.arm=null; force=true; }
  if(!force&&PK.shown===i) return; PK.shown=i; const p=PACKS[i];
  if(PK.arm){ el.innerHTML=`<div class="t"><b>${p.nom}</b><span>${p.n} modules</span></div><p class="tearhint">✂️ <b>Déchire le paquet !</b> Glisse ton doigt de gauche à droite sur la ligne jaune, en haut.</p>
    <div class="buy"><button class="btn alt" data-a="packcancel">Annuler</button><button class="btn alt" data-a="packfast">Ouvrir sans déchirer</button></div>`; }
  else el.innerHTML=`<div class="t"><b>${p.nom}</b><span>${p.n} modules</span></div><p class="note" style="margin:0">${p.d}</p>
    <p class="note sm" style="margin:2px 0 6px">👆 Tourne le paquet au doigt pour voir son dos.</p>
    <div class="buy"><button class="btn" data-a="pack" data-id="${p.id}" data-k="cr" ${S.cr<p.cr?'disabled':''}>Déchirer, ${cr(p.cr)}</button><button class="btn alt" data-a="pack" data-id="${p.id}" data-k="tok" ${S.tok<p.tok?'disabled':''}>${p.tok} 🎟</button></div>`;
  const dots=$('pkdots'); if(dots) [...dots.children].forEach((d,k)=>d.classList.toggle('on',k===i));
}
function pkLayout(time){
  const ring=$('pkring'); if(!ring){PK.raf=0; return false;}
  if(!PK.drag||PK.drag.mode!=='car'){ /* le carrousel suit sa cible */ if(!PK.drag){ const d=PK.tgt-PK.pos; PK.pos+=d*.15; if(Math.abs(d)<.003) PK.pos=PK.tgt; } }
  /* rotation libre du paquet : inertie puis aimantation face / dos */
  if(!(PK.drag&&PK.drag.mode==='rot')){
    if(Math.abs(PK.rv)>.25){ PK.ry+=PK.rv; PK.rv*=.94; }
    else{ PK.rv=0; const tg=PK.snap!=null?PK.snap:Math.round(PK.ry/180)*180; PK.ry+=(tg-PK.ry)*.14; if(Math.abs(tg-PK.ry)<.3){ PK.ry=tg; PK.snap=null; } }
  }
  [...ring.children].forEach(el=>{
    const i=+el.dataset.i, o=i-PK.pos, ao=Math.abs(o), sg=o<0?-1:1;
    const x=sg*(Math.min(ao,1)*108+Math.max(0,ao-1)*70), z=-Math.min(ao,2.2)*160;
    let ry=-Math.max(-1.5,Math.min(1.5,o))*44; const front=ao<.5; if(front&&Math.abs(PK.rv)<.25&&Math.abs(PK.ry%360)<1) ry+=Math.sin(time/820+i)*5*(1-ao*2); if(front) ry+=PK.ry;
    el.style.transform=`translate3d(${x.toFixed(1)}px,${(-ao*5).toFixed(1)}px,${z.toFixed(1)}px) rotateY(${ry.toFixed(1)}deg) scale(${(1-.06*Math.min(ao,2)).toFixed(3)})`;
    el.style.opacity=ao>2.6?0:(1-.16*Math.min(ao,2.4)).toFixed(2); el.style.zIndex=String(20-Math.round(ao*3));
    el.style.setProperty('--sx',(-30+ry*1.1+Math.sin(time/1300+i)*30).toFixed(0)+'%'); el.classList.toggle('sel',front);
    el.classList.toggle('arm',!!PK.arm&&front);
  });
  pkInfo(); return true;
}
function pkTear(el,i){ /* animation : le haut du paquet part en lambeau */
  const pc=document.createElement('div'); pc.className='tearpiece'; pc.style.setProperty('--c1',getComputedStyle(el).getPropertyValue('--c1')); el.parentNode.parentNode.appendChild(pc);
  const r=el.getBoundingClientRect(), pr=el.parentNode.parentNode.getBoundingClientRect(); pc.style.left=(r.left-pr.left)+'px'; pc.style.top=(r.top-pr.top)+'px'; pc.style.width=r.width+'px';
  setTimeout(()=>pc.remove(),900);
}
function bindPacks(){
  const st=$('pk3'); if(!st||cTab!=='packs'){PK.raf=0; return;}
  PK.shown=-1; pkLayout(performance.now()); pkInfo(true);
  st.addEventListener('pointerdown',e=>{
    if(e.target.closest('.pknav')) return;
    const pe=e.target.closest&&e.target.closest('.pk'), sel=pe&&+pe.dataset.i===Math.round(PK.tgt);
    let mode='car', zone=false;
    if(sel){ mode='rot'; if(PK.arm){ const r=pe.getBoundingClientRect(); zone=Math.abs(PK.ry%360)<30&&(e.clientY-r.top)<r.height*.42; if(zone) mode='tear'; } }
    PK.drag={x:e.clientX,p:PK.pos,moved:0,lx:e.clientX,lt:e.timeStamp,tg:e.target,mode,r0:PK.ry,pe,w:pe?pe.getBoundingClientRect().width:158}; PK.vel=0; PK.rv=0; PK.snap=null; try{st.setPointerCapture(e.pointerId);}catch(_){}
  });
  st.addEventListener('pointermove',e=>{
    const d=PK.drag; if(!d) return; const dx=e.clientX-d.x; d.moved=Math.max(d.moved,Math.abs(dx));
    const dt=e.timeStamp-d.lt;
    if(d.mode==='car'){ PK.pos=clamp(d.p-dx/108,-.3,PACKS.length-.7); if(dt>0){PK.vel=PK.vel*.6+((e.clientX-d.lx)/dt)*.4; d.lx=e.clientX; d.lt=e.timeStamp;} }
    else if(d.mode==='rot'){ PK.ry=d.r0+dx*1.5; if(dt>0){ PK.rv=PK.rv*.5+((e.clientX-d.lx)*1.5)*.5*(16/Math.max(8,dt)); d.lx=e.clientX; d.lt=e.timeStamp; } }
    else if(d.mode==='tear'&&d.pe){ const p=clamp(dx/(d.w*.85),0,1); d.pe.style.setProperty('--tp',p.toFixed(3)); if(p>=1&&!d.done){ d.done=1; const a=PK.arm; PK.arm=null; pkTear(d.pe,0); try{ st.releasePointerCapture(e.pointerId); }catch(_){} PK.drag=null; auTry(()=>auRip(Math.round(PK.tgt))); setTimeout(()=>{ if(d.pe) d.pe.style.setProperty('--tp',0); ACT.packgo({id:a.id,k:a.k}); },380); } }
  });
  const up=e=>{
    const d=PK.drag; if(!d) return; PK.drag=null;
    if(d.mode==='tear'){ if(d.pe) d.pe.style.setProperty('--tp',0); return; }
    if(d.moved<6){ const pe=d.tg&&d.tg.closest&&d.tg.closest('.pk'); if(pe){ const i=+pe.dataset.i; if(i===Math.round(PK.tgt)){ const pp=PACKS[i]; ACT.pack({id:pp.id,k:S.cr>=pp.cr?'cr':'tok'}); } else PK.tgt=i; } else PK.tgt=Math.round(PK.pos); return; }
    if(d.mode==='rot'){ if(Math.abs(PK.rv)<2) PK.rv=0; auTry(()=>ui('click')); return; }
    PK.tgt=clamp(Math.round(PK.pos-PK.vel*170/108),0,PACKS.length-1); auTry(()=>ui('click'));
  };
  st.addEventListener('pointerup',up); st.addEventListener('pointercancel',up);
  if(!PK.raf) PK.raf=requestAnimationFrame(pkLoop);
}
/* achat : d'abord on arme la déchirure */
ACT.packgo=ACT.pack;
ACT.pack=function(d){ const pk=PACKS.find(p=>p.id===d.id); if(!pk) return; const ok=(d.k==='tok'?S.tok>=pk.tok:S.cr>=pk.cr);
  if(!ok) return toast('Pas assez pour ce paquet'); if(S.mods.length+pk.n>invMax()) return toast('Inventaire plein : recycle ou fusionne des modules');
  if(sheet||!$('pk3')){ return ACT.packgo(d); } /* « Encore un » depuis le résultat : direct */
  PK.arm={id:d.id,k:d.k}; PK.snap=Math.round(PK.ry/360)*360; PK.rv=0; PK.shown=-1; pkInfo(true); };
ACT.packcancel=()=>{ PK.arm=null; PK.shown=-1; pkInfo(true); };
ACT.packfast=()=>{ const a=PK.arm; PK.arm=null; if(a) ACT.packgo({id:a.id,k:a.k}); };
/* voiture complète : ultra rare */
function carPrize(){
  const w=CARS.map(c=>1/Math.pow(c.t,3.2)), tot=w.reduce((a,b)=>a+b,0); let x=Math.random()*tot; for(let i=0;i<CARS.length;i++){ x-=w[i]; if(x<0) return CARS[i]; } return CARS[0];
}
const _openPack0=openPack;
openPack=function(id,cur){
  const n0=S.mods.length, c0=S.cars.length; _openPack0(id,cur);
  if(S.mods.length===n0||!sheet||sheet.t!=='open') return;
  if(Math.random()<(CAR_P[id]||.0005)*(1+.1*pk('luck'))){ const m=carPrize(), c={uid:S.nuid++,mid:m.id,etat:100,xp:0,lvl:1,up:{},inv:0,mods:{},sh:Math.random()<.06?1:0}; S.cars.push(c); sheet.car=c.uid; S.stats.carpack=(S.stats.carpack||0)+1; save(); }
};
const _openStage0=openStage;
openStage=function(X){
  const done=sheet.i>=sheet.cards.length;
  if(done&&sheet.car&&!sheet.carSeen){ const c=car(sheet.car), m=c&&M[c.mid]; if(!c){ sheet.car=null; return _openStage0(X); }
    $('sheet').innerHTML=`${X}<div class="carwin"><div class="cw-rays"></div><div class="cw-t">JACKPOT !</div><h2>Une voiture dans le paquet !</h2>
      <div class="cw-car" style="--t:${TIERS[m.t].c}">${carSVG(m,100)}</div><div class="cw-n">${m.nom}${c.sh?' ✨ brillante':''}</div><p class="note">${m.an} · ${m.cat} · ${TIERS[m.t].n}. Elle est déjà dans ton garage.</p>
      <button class="btn wide" data-a="carseen">Voir mes cartes du paquet</button></div>`; return true; }
  return _openStage0(X);
};
ACT.carseen=()=>{ if(sheet){ sheet.carSeen=1; sheet.i=sheet.cards.length; renderSheet(); } };
/* ---- cartes : tout tient sur un écran, achat toujours visible ---- */
function packsHTML(){
  return `<div class="pk3" id="pk3"><button class="pknav l" data-a="pkgo" data-id="-1" aria-label="Précédent">‹</button><div class="ring" id="pkring">${PACKS.map(pack3d).join('')}</div><div class="fl"></div><button class="pknav r" data-a="pkgo" data-id="1" aria-label="Suivant">›</button></div>
    <div class="dots" id="pkdots">${PACKS.map(()=>'<i></i>').join('')}</div><div class="pkInfo" id="pkInfo"></div>`;
}
const _pkInfo1=pkInfo;
pkInfo=function(force){ _pkInfo1(force); const el=$('pkInfo'); if(el&&!el.querySelector('.rlink')&&!PK.arm){ const t=el.querySelector('.t'); if(t) t.insertAdjacentHTML('beforeend','<button class="rlink" data-a="rates">ℹ️ taux</button>'); } };
function pkFit(){ const st=$('pk3'), ring=$('pkring'); if(!st||!ring) return; const h=st.clientHeight||318; ring.style.transformOrigin='50% 44%'; ring.style.transform=`scale(${Math.min(1,h/318).toFixed(3)})`; }
const _bindPacks1=bindPacks;
bindPacks=function(){ _bindPacks1(); pkFit(); window.addEventListener('resize',pkFit); };
/* ---- guide d'objectif : toujours dire quoi faire ensuite ---- */
function goalNext(){
  const st=S.stats||{}, F=S.farm;
  if(!st.races) return ['🏁','Fais ta première épreuve : c’est ce qui rapporte crédits et expérience','epreuves','Aller aux épreuves'];
  if(!st.packs&&(S.tok>=1||S.cr>=500)) return ['🃏','Ouvre ton premier paquet de cartes pour améliorer tes voitures','cartes','Aux cartes'];
  if(S.mods.length&&!S.cars.some(c=>c.mods&&Object.keys(c.mods).length)) return ['🔧','Tu as des pièces ! Monte-les sur une voiture pour la rendre plus rapide','garage','Au garage'];
  if(!S.pod.slots.some(Boolean)) return ['🏛️','Place une voiture sur un podium : elle te rapporte des crédits même quand tu ne joues pas','garage','Au garage'];
  if(labLv()>=8&&!(F&&F.found)) return ['🕵️','Une cloison cache un secret dans le garage 3D… va faire un tour dans le Monde','hub','Entrer dans le Monde'];
  if(F&&F.found&&!F.tutoSeen) return ['🌿','Reviens dans le labo caché pour suivre le tuto','hub','Au Monde'];
  return null;
}
function goalUpd(){
  let g=$('goal'); if(!g){ const t=$('top'); if(!t) return; g=document.createElement('div'); g.id='goal'; t.after(g); }
  const n=(view==='race'||document.body.classList.contains('racing')||document.body.classList.contains('hubmode'))?null:goalNext();
  if(!n){ g.style.display='none'; return; } const k=n[0]+n[1]+n[2];
  if(g.dataset.k!==k){ g.dataset.k=k; g.innerHTML=`<span class="gi">${n[0]}</span><span class="gt"><small>OBJECTIF</small>${n[1]}</span><button class="gb" data-a="tab" data-id="${n[2]}">${n[3]} ›</button>`; }
  g.style.display=(view===n[2])?'none':'flex';
}
const _render0=render;
render=function(){ _render0.apply(this,arguments); try{ goalUpd(); }catch(e){} };
/* ---- écran de démarrage : son mécanique + sortie ---- */
(function(){
  const sp=document.getElementById('splash'); if(!sp) return; let played=false, gone=false;
  const bye=()=>{ if(gone) return; gone=true; sp.style.transition='opacity .3s'; sp.style.opacity='0'; setTimeout(()=>sp.remove(),320); };
  sp.addEventListener('pointerdown',()=>{ playS(); bye(); }); setTimeout(bye,3600);
  function playS(){
    if(played) return; try{ if(S&&S.audio&&S.audio.mute) return; }catch(_){}
    const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
    try{ const c=new AC(); if(c.state==='suspended'){ c.resume(); } if(c.state==='suspended') return; played=true;
      const t=c.currentTime+.05, M=c.createGain(); M.gain.value=.5; M.connect(c.destination);
      const lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.setValueAtTime(300,t); lp.frequency.exponentialRampToValueAtTime(2400,t+1.5); lp.connect(M);
      const o=c.createOscillator(), g=c.createGain(); o.type='sawtooth'; o.frequency.setValueAtTime(38,t); o.frequency.exponentialRampToValueAtTime(150,t+1.0); o.frequency.setValueAtTime(110,t+1.05); o.frequency.exponentialRampToValueAtTime(230,t+1.6);
      g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.35,t+.4); g.gain.linearRampToValueAtTime(.3,t+1.5); g.gain.exponentialRampToValueAtTime(.001,t+2.2); o.connect(g); g.connect(lp); o.start(t); o.stop(t+2.3);
      const o2=c.createOscillator(), g2=c.createGain(); o2.type='square'; o2.frequency.setValueAtTime(19,t); o2.frequency.exponentialRampToValueAtTime(75,t+1.0); o2.frequency.setValueAtTime(55,t+1.05); o2.frequency.exponentialRampToValueAtTime(115,t+1.6); g2.gain.setValueAtTime(.0,t); g2.gain.linearRampToValueAtTime(.2,t+.5); g2.gain.exponentialRampToValueAtTime(.001,t+2); o2.connect(g2); g2.connect(lp); o2.start(t); o2.stop(t+2.1);
      /* cliquetis de pignons qui s'engrènent */
      for(let k=0;k<22;k++){ const tk=t+.05+k*(.07-k*.0016), cl=c.createOscillator(), cg=c.createGain(); cl.type='square'; cl.frequency.value=1500+(k%4)*420; cg.gain.setValueAtTime(.07,tk); cg.gain.exponentialRampToValueAtTime(.001,tk+.03); const hp=c.createBiquadFilter(); hp.type='bandpass'; hp.frequency.value=2400; hp.Q.value=2; cl.connect(cg); cg.connect(hp); hp.connect(M); cl.start(tk); cl.stop(tk+.04); }
      /* VOUF : souffle qui passe */
      const len=c.sampleRate*1.2, buf=c.createBuffer(1,len,c.sampleRate), d=buf.getChannelData(0); for(let i=0;i<len;i++) d[i]=Math.random()*2-1;
      const ns=c.createBufferSource(); ns.buffer=buf; const bp=c.createBiquadFilter(); bp.type='bandpass'; bp.Q.value=1.4; bp.frequency.setValueAtTime(250,t+1.45); bp.frequency.exponentialRampToValueAtTime(3800,t+1.95); bp.frequency.exponentialRampToValueAtTime(600,t+2.4);
      const ng=c.createGain(); ng.gain.setValueAtTime(0,t+1.45); ng.gain.linearRampToValueAtTime(.55,t+1.8); ng.gain.exponentialRampToValueAtTime(.001,t+2.5); ns.connect(bp); bp.connect(ng); ng.connect(M); ns.start(t+1.45); ns.stop(t+2.6);
      /* choc de logo */
      const b=c.createOscillator(), bg=c.createGain(); b.type='sine'; b.frequency.setValueAtTime(110,t+2.0); b.frequency.exponentialRampToValueAtTime(38,t+2.4); bg.gain.setValueAtTime(.5,t+2.0); bg.gain.exponentialRampToValueAtTime(.001,t+2.6); b.connect(bg); bg.connect(M); b.start(t+2.0); b.stop(t+2.7);
      setTimeout(()=>{ try{ c.close(); }catch(_){} },3500);
    }catch(e){}
  }
  playS(); /* si le navigateur l'autorise d'office */
})();
/* ===== v0.30 : ouverture de paquet plein écran, tracé au doigt (style TCG) ===== */
let OV=null;
function pkArt(p){ const th=PKT[p.id]||PKT.p1, pips=[0,1,2].map(k=>RAR[Math.min(6,p.min+k)]).map(r=>`<i style="background:${r.c}"></i>`).join('');
  return `<div class="crimp t"></div><div class="crimp b"></div><div class="ct"><span class="tag">${th.tag}</span><span class="emb">${th.emb}</span><div><div class="nm">${p.nom.replace('Paquet ','')}</div><div class="sb">${p.n} modules</div></div><span class="pips">${pips}</span></div>`; }
function pkOverlay(id,k){
  const p=PACKS.find(x=>x.id===id); if(!p||OV) return; const th=PKT[p.id]||PKT.p1;
  const d=document.createElement('div'); d.id='pkov';
  d.innerHTML=`<button class="pkx" aria-label="Annuler">×</button><div class="pkov-t">${p.nom}</div>
   <div class="pkst"><div class="pk big" style="--c1:${th.c1};--c2:${th.c2};--c3:${th.c3}"><div class="lay fr bp-body">${pkArt(p)}</div><div class="lay fr bp-top">${pkArt(p)}</div>
     <svg class="bp-trace" viewBox="0 0 100 100" preserveAspectRatio="none"><path class="tr0" d="M6 17 L94 17" pathLength="100"/><path class="tr1" d="M6 17 L94 17" pathLength="100"/></svg><div class="bp-h"></div><div class="bp-sp"></div></div><div class="bp-light"></div></div>
   <div class="pkov-h">Suis la ligne lumineuse du doigt <b>→</b></div><button class="pkov-s">Ouvrir sans déchirer</button>`;
  document.body.appendChild(d); requestAnimationFrame(()=>d.classList.add('on'));
  const pk=d.querySelector('.pk.big'), st=d.querySelector('.pkst'), h=d.querySelector('.bp-h'), sp=d.querySelector('.bp-sp'), tr1=d.querySelector('.tr1'), top=d.querySelector('.bp-top'), body=d.querySelector('.bp-body');
  OV={id,k,prog:0,dp:0,act:false,done:false,fx:0,fy:0,raf:0};
  const close=()=>{ if(!OV) return; cancelAnimationFrame(OV.raf); const e=d; e.classList.remove('on'); setTimeout(()=>e.remove(),260); OV=null; PK.arm=null; };
  const finish=(skip)=>{ if(!OV||OV.done) return; OV.done=true; OV.prog=OV.dp=1; auTry(()=>auRip(PACKS.findIndex(x=>x.id===id))); try{ navigator.vibrate&&navigator.vibrate([12,30,18]); }catch(_){}
    d.classList.add('torn'); const a=OV; setTimeout(()=>{ d.classList.add('fade'); },520); setTimeout(()=>{ cancelAnimationFrame(a.raf); d.remove(); OV=null; PK.arm=null; openPack(a.id,a.k); },820); };
  const lineY=()=>{ const r=pk.getBoundingClientRect(); return {top:r.top+r.height*.17,left:r.left,w:r.width,h:r.height}; };
  const tick=()=>{ if(!OV) return; const o=OV; if(!o.done){ if(!o.act) o.prog=Math.max(0,o.prog-.05); o.dp+=(o.prog-o.dp)*.4; if(Math.abs(o.prog-o.dp)<.001) o.dp=o.prog; }
    const q=o.dp; tr1.style.strokeDashoffset=String(100-q*88/88*100*.88+0); tr1.style.strokeDasharray='100'; tr1.style.strokeDashoffset=String(100-q*100);
    h.style.left=(6+q*88)+'%'; h.style.opacity=o.done?0:1;
    if(!o.done){ pk.style.transform=`rotateZ(${(q*1.6).toFixed(2)}deg) translateY(${(-q*6).toFixed(1)}px) scale(${(1+q*.03).toFixed(3)})`; top.style.transform=`rotate(${(q*3).toFixed(2)}deg) translateY(${(-q*5).toFixed(1)}px)`; top.style.transformOrigin='100% 100%'; }
    o.raf=requestAnimationFrame(tick); };
  OV.raf=requestAnimationFrame(tick);
  const pos=e=>{ const L=lineY(), x=(e.clientX-L.left)/L.w, dy=Math.abs(e.clientY-L.top); return {x,dy,L}; };
  st.addEventListener('pointerdown',e=>{ if(!OV||OV.done) return; const q=pos(e); if(q.dy>80) return; OV.act=true; OV.prog=Math.max(OV.prog,0); try{ st.setPointerCapture(e.pointerId); }catch(_){} try{ navigator.vibrate&&navigator.vibrate(6); }catch(_){} });
  st.addEventListener('pointermove',e=>{ if(!OV||!OV.act||OV.done) return; const q=pos(e); sp.style.opacity=1; sp.style.left=(e.clientX-q.L.left)+'px'; sp.style.top=(e.clientY-q.L.top+q.L.h*.17)+'px';
    if(q.dy<110){ const x=clamp((q.x-.06)/.88,0,1); if(x>OV.prog-.04) OV.prog=Math.max(OV.prog,Math.min(x,OV.prog+.3)); if(OV.prog>=.9) finish(); } });
  const up=()=>{ if(!OV) return; OV.act=false; sp.style.opacity=0; };
  st.addEventListener('pointerup',up); st.addEventListener('pointercancel',up);
  d.querySelector('.pkx').onclick=close; d.querySelector('.pkov-s').onclick=()=>finish(true);
  d.addEventListener('pointerdown',e=>{ if(e.target===d) close(); });
}
ACT.pack=function(dd){ const pk=PACKS.find(p=>p.id===dd.id); if(!pk) return; const ok=(dd.k==='tok'?S.tok>=pk.tok:S.cr>=pk.cr);
  if(!ok) return toast('Pas assez pour ce paquet'); if(S.mods.length+pk.n>invMax()) return toast('Inventaire plein : recycle ou fusionne des modules');
  if(sheet) closeSheet(); pkOverlay(dd.id,dd.k); };
/* ===== v0.31 : Mon labo (accès rapide), alertes, album de variétés, croisements, taille, butin de course ===== */
const HY_R=[['Commun','#9aa4c8',1,.70],['Rare','#3cc46a',1.1,.22],['Épique','#a85de8',1.2,.06],['Légendaire','#ffd400',1.35,.02]];
function regHyb(){ const F=S.farm; if(!F||!F.hyb) return; F.hyb.forEach(h=>{ if(!SID[h.id]){ STR.push(h); SID[h.id]=h; if(h.pu) PURP[h.id]=1; } }); }
const _farm0=farm;
farm=function(){ const F=_farm0(); if(F.hyb&&F.hyb.some(h=>!SID[h.id])) regHyb(); F.alb2=F.alb2||{}; return F; };
function hyName(a0,b0){ const sw=Math.random()<.5, a=sw?b0:a0, b=sw?a0:b0; const x=a.nom.split(' ')[0], y=b.nom.split(' ').pop(); let n=x.slice(0,Math.ceil(x.length/2))+y.slice(Math.floor(y.length/2)); n=n.charAt(0).toUpperCase()+n.slice(1).toLowerCase(); const F=farm(); let k=2, nn=n; while(STR.some(s=>s.nom===nn)) nn=n+' #'+(k++); return nn; }
function crossMake(a,b){
  const F=farm(), L=1+.1*pk('luck'); let r=Math.random(), ri=0, acc=0; const w=HY_R.map((x,i)=>i?x[3]*L:x[3]); const tot=w.reduce((s,v)=>s+v,0); r*=tot; for(let i=0;i<4;i++){ r-=w[i]; if(r<0){ ri=i; break; } }
  const m=HY_R[ri][2], av=k=>(a[k]+b[k])/2, jit=()=>rnd(.92,1.1);
  const h={id:'x'+(F.hybN=(F.hybN||0)+1),nom:hyName(a,b),ty:a.ty===b.ty?a.ty:'Hybride',thc:Math.round(av('thc')*m*jit()*10)/10,veg:Math.round(av('veg')*rnd(.9,1.04)*10)/10,fl:Math.round(av('fl')*rnd(.9,1.04)*10)/10,y:Math.round(av('y')*m*jit()),px:Math.round(av('px')*(1+(m-1)*.8)*jit()*10)/10,lm:Math.round(av('lm')/1000)*1000,eau:Math.round(av('eau')*10)/10,d:Math.max(a.d,b.d),rep:0,sd:Math.round(av('sd')*1.4),ic:'🧬',hy:1,rar:ri,pa:[a.id,b.id],pu:!!(PURP[a.id]||PURP[b.id])};
  return h;
}
const CR={a:null,b:null};
function labSheet(X){
  if(!sheet||(sheet.t!=='strains'&&sheet.t!=='cross')) return false;
  const F=farm(), el=$('sheet');
  if(sheet.t==='strains'){
    const row=s=>{ const own=F.seeds[s.id]||0, hv=(F.alb2[s.id]||0), known=own||hv||s.hy; const rc=s.hy?HY_R[s.rar][1]:'#2b2f60';
      return `<div class="inv-r" style="border-color:${rc}"><span class="inv-i">${known?s.ic:'❔'}</span><div class="inv-t"><b>${known?s.nom:'Variété inconnue'}${s.hy?` <i class="hyt" style="color:${rc}">${HY_R[s.rar][0]}</i>`:''}</b><small>${known?`${s.ty} · ${s.thc} % THC · ~${s.y} g · ${s.veg+s.fl} min${s.pa?' · '+SID[s.pa[0]].nom.split(' ')[0]+' × '+SID[s.pa[1]].nom.split(' ')[0]:''}`:'Plante-la ou croise-la pour la découvrir'}</small></div><span class="inv-q">${own?'×'+own:hv?'✓':''}</span></div>`; };
    const hy=(F.hyb||[]).slice().reverse();
    el.innerHTML=`<div class="inv">${X}<h2>📖 Album des variétés</h2><p class="note">${STR.filter(s=>!s.hy&&((F.seeds[s.id]||0)||F.alb2[s.id])).length} / ${STR.filter(s=>!s.hy).length} variétés de base · ${hy.length} hybride(s) créés</p>
     <button class="btn wide" data-a="crossopen">🧬 Croiser deux variétés</button>
     ${hy.length?`<div class="inv-s"><h3>🧬 Tes hybrides</h3>${hy.map(row).join('')}</div>`:''}
     <div class="inv-s"><h3>🌱 Variétés de base</h3>${STR.filter(s=>!s.hy).map(row).join('')}</div></div>`; return true; }
  const parents=STR.filter(s=>(F.seeds[s.id]||0)>0), A=SID[CR.a], B=SID[CR.b], cost=600;
  const chips=(k)=>parents.map(s=>`<button class="${CR[k]===s.id?'on':''}" data-a="crpick" data-id="${k}" data-v="${s.id}">${s.ic} ${s.nom} ×${F.seeds[s.id]}</button>`).join('');
  const need=(CR.a&&CR.a===CR.b)?2:1, okS=A&&B&&(F.seeds[CR.a]||0)>=need&&(F.seeds[CR.b]||0)>=need;
  el.innerHTML=`<div class="inv">${X}<h2>🧬 Croisement</h2><p class="note">Choisis deux variétés dont tu as la graine. Le croisement consomme <b>1 graine de chaque</b> + ${cost} cr et donne <b>2 graines</b> d’un hybride inédit… dont la rareté est aléatoire (jusqu’à Légendaire !).</p>
   ${parents.length?`<p class="sm">Parent A</p><div class="rchips">${chips('a')}</div><p class="sm">Parent B</p><div class="rchips">${chips('b')}</div>`:'<p class="note">Tu n’as aucune graine. Achètes-en à la boutique du labo.</p>'}
   ${A&&B?`<div class="inv-r"><span class="inv-i">🧬</span><div class="inv-t"><b>${A.nom.split(' ')[0]} × ${B.nom.split(' ')[0]}</b><small>THC ≈ ${((A.thc+B.thc)/2).toFixed(0)} % · rendement ≈ ${Math.round((A.y+B.y)/2)} g · ${HY_R.map(r=>r[0]).join(' / ')}</small></div></div>`:''}
   <button class="btn wide" data-a="crossgo" ${okS&&S.cr>=cost?'':'disabled'}>Croiser · ${cost} cr</button>${okS||!A||!B?'':'<p class="note">Pas assez de graines pour ce couple.</p>'}
   <button class="btn alt wide" style="margin-top:8px" data-a="strainopen">← Album</button></div>`; return true;
}
Object.assign(ACT,{
  strainopen(){ openSheet({t:'strains'}); }, crossopen(){ openSheet({t:'cross'}); },
  crpick(d){ CR[d.id]=d.v; renderSheet(); },
  crossgo(){ const F=farm(), a=SID[CR.a], b=SID[CR.b]; if(!a||!b||S.cr<600) return; const need=CR.a===CR.b?2:1; if((F.seeds[CR.a]||0)<need||(F.seeds[CR.b]||0)<need) return; if((F.hyb||[]).length>=40) return toast('Album plein (40 hybrides)');
    S.cr-=600; F.seeds[CR.a]-=1; F.seeds[CR.b]-=1; const h=crossMake(a,b); (F.hyb=F.hyb||[]).push(h); regHyb(); F.seeds[h.id]=2; F.alb2[h.id]=F.alb2[h.id]||0; save(); sheet.t='cross'; CR.a=CR.b=null;
    const rc=HY_R[h.rar]; auTry(()=>auCard(Math.min(6,2+h.rar*1.5|0),h.rar>=2,false));
    $('sheet').innerHTML=`<div class="inv"><button class="x" data-a="close">×</button><div class="carwin"><div class="cw-t" style="color:${rc[1]};-webkit-text-fill-color:${rc[1]}">${rc[0].toUpperCase()}</div><h2>Nouvel hybride !</h2><div class="cw-car" style="font-size:64px">🧬</div><div class="cw-n">${h.nom}</div><p class="note">${h.ty} · ${h.thc} % THC · ~${h.y} g · ${h.veg+h.fl} min de culture · ${h.px} cr/g<br>2 graines ajoutées à ton sac.</p><button class="btn wide" data-a="strainopen">📖 Voir l’album</button></div></div>`; },
  labopen(){ ACT.ranchSheet(); },
  waterall(){ ranchSim(); const F=farm(); let n=0,stop=false; for(const room in F.rooms){ if(!F.rooms[room].on) continue; F.rooms[room].slots.forEach(sl=>{ if(stop||!sl||sl.st==='ready'||sl.st==='dead'||sl.w>=75) return; if((F.can||0)>0) F.can--; else if(F.water>=3) F.water-=3; else { stop=true; return; } sl.w=Math.min(100,sl.w+38); n++; }); }
    toast(n?`💧 ${n} plante${n>1?'s':''} arrosée${n>1?'s':''}`+(stop?' · citerne vide':''):stop?'Citerne vide : remplis-la':'Rien à arroser'); save(); if(sheet) renderSheet(); else render(); },
  harvestall(){ ranchSim(); const F=farm(); let n=0; const keep=RY.tab; for(const room in F.rooms){ if(!F.rooms[room].on) continue; F.rooms[room].slots.forEach((sl,i)=>{ if(sl&&sl.st==='ready'){ RY.tab=room; _rh0({id:String(i)}); n++; F.alb2[sl.sid]=(F.alb2[sl.sid]||0)+1; } }); } RY.tab=keep;
    toast(n?`✂️ ${n} récolte${n>1?'s':''} · séchage en cours`:'Rien à récolter'); save(); if(sheet) renderSheet(); else render(); }
});
/* récolte manuelle = mini-jeu de taille */
const _rh0=ACT.rharvest;
ACT.rharvest=function(d){ const F=farm(), sl=F.rooms[RY.tab].slots[+d.id]; if(!sl||sl.st!=='ready') return; const room=RY.tab, sid=sl.sid;
  trimGame(bonus=>{ const s2=farm().rooms[room].slots[+d.id]; if(!s2||s2.st!=='ready') return; s2.q=Math.min(100,s2.q+bonus); RY.tab=room; farm().alb2[sid]=(farm().alb2[sid]||0)+1; _rh0(d); if(bonus>0) setTimeout(()=>toast(`✂️ Taille ${bonus>=10?'parfaite':'réussie'} : qualité +${bonus}`),60); }); };
function trimGame(done){
  const o=document.createElement('div'); o.id='trimov';
  const leaves=[]; for(let i=0;i<11;i++){ const a=i/11*6.283+.3, r=i%2?96:62, x=150+Math.cos(a)*r, y=150+Math.sin(a)*r; leaves.push([x,y,a*57.3+90]); }
  o.innerHTML=`<button class="pkx" aria-label="Passer">×</button><div class="pkov-t">Taille de la récolte</div><div class="tm-st" id="tmst"><div class="tm-bud"></div>${leaves.map((l,i)=>`<div class="tm-l" data-i="${i}" style="left:${l[0]}px;top:${l[1]}px;transform:translate(-50%,-50%) rotate(${l[2]}deg)">${leafIc('#2fbf63',46)}</div>`).join('')}</div>
   <div class="tm-bar"><i id="tmb"></i></div><div class="pkov-h">Passe le doigt sur les <b>feuilles</b> pour les couper — plus tu en coupes, meilleure est la qualité</div><button class="btn" id="tmok">Terminer</button>`;
  document.body.appendChild(o); requestAnimationFrame(()=>o.classList.add('on'));
  const st=o.querySelector('#tmst'), els=[...o.querySelectorAll('.tm-l')], cut=new Set(); let fin=false, act=false;
  const upd=()=>{ o.querySelector('#tmb').style.width=(cut.size/els.length*100)+'%'; if(cut.size===els.length) setTimeout(end,350); };
  const hit=e=>{ const r=st.getBoundingClientRect(), sc=r.width/300, x=(e.clientX-r.left)/sc, y=(e.clientY-r.top)/sc; els.forEach((el,i)=>{ if(cut.has(i)) return; const L=leaves[i]; if(Math.hypot(x-L[0],y-L[1])<34){ cut.add(i); el.classList.add('cut'); try{ navigator.vibrate&&navigator.vibrate(5); }catch(_){} auTry(()=>ui('click')); } }); upd(); };
  st.addEventListener('pointerdown',e=>{ act=true; try{ st.setPointerCapture(e.pointerId); }catch(_){} hit(e); }); st.addEventListener('pointermove',e=>{ if(act) hit(e); }); st.addEventListener('pointerup',()=>act=false);
  const end=skip=>{ if(fin) return; fin=true; const b=skip===true?0:Math.round(cut.size/els.length*14); o.classList.remove('on'); setTimeout(()=>o.remove(),250); done(b); };
  o.querySelector('#tmok').onclick=()=>end(); o.querySelector('.pkx').onclick=()=>end(true);
}
/* carte « Mon labo » dans Garage et Base */
function labStat(){ const F=S.farm; if(!F||!F.found) return null; const o={plants:0,ready:0,thirst:0,sick:0}; for(const room in F.rooms){ const R=F.rooms[room]; if(!R.on) continue; R.slots.forEach(sl=>{ if(!sl) return; o.plants++; if(sl.st==='ready') o.ready++; else if(sl.st!=='dead'){ if(sl.w<35) o.thirst++; if(sl.pest) o.sick++; } }); } o.heat=Math.round(Math.max(F.heat.atelier,F.heat.ranch)); o.dry=(F.dry||[]).length; o.stock=Object.values(F.stock||{}).reduce((t,v)=>t+(v.g||0),0); return o; }
function labCard(){ try{ ranchSim(); }catch(_){} const s=labStat(); if(!s) return ''; const F=farm();
  return `<div class="labcard"><div class="lc-h"><span class="lc-t">${leafIc('#3cff9e',22)} Mon labo</span><span class="lc-s ${s.heat>60?'hot':''}">🚨 ${s.heat} %</span></div>
   <div class="lc-st"><span>🌱 ${s.plants} plante${s.plants>1?'s':''}</span><span class="${s.ready?'ok':''}">✂️ ${s.ready} prête${s.ready>1?'s':''}</span><span class="${s.thirst?'warn':''}">💧 ${s.thirst} soif</span>${s.sick?`<span class="warn">🦠 ${s.sick}</span>`:''}<span>🫙 ${Math.floor(s.stock)} g</span></div>
   <div class="lc-b"><button class="btn" data-a="labopen">Ouvrir</button><button class="btn alt" data-a="waterall">💧 Tout arroser</button><button class="btn alt" data-a="harvestall" ${s.ready?'':'disabled'}>✂️ Tout récolter</button><button class="btn alt" data-a="strainopen">📖 Variétés</button></div></div>`; }
const _vGarage0=vGarage, _vBase0=vBase;
vGarage=function(){ try{ ranchSim(); }catch(_){} return _vGarage0(); }; vBase=function(){ return _vBase0(); };
/* alertes : pastille sur Base + notification quand une plante est prête */
let _labPrev=-1;
function labAlert(){ try{ const s=labStat(); const nav=$('nav'); if(!nav) return; const b=nav.querySelector('button[data-id="base"]'); if(!b) return; let d=b.querySelector('.dot'); const need=s&&(s.ready||s.thirst||s.sick);
  if(need&&!d){ b.insertAdjacentHTML('beforeend','<i class="dot lab"></i>'); } else if(!need&&d&&d.classList.contains('lab')) d.remove(); } catch(_){} }
function labTick(){ try{ const F=S.farm; if(!F||!F.found) return; ranchSim(); const s=labStat(); if(_labPrev>=0&&s.ready>_labPrev&&!document.body.classList.contains('racing')) toast('🌿 Une plante est prête à récolter !'); _labPrev=s.ready; labAlert(); if(!sheet&&(view==='garage'||view==='base')&&!document.getElementById('pkov')&&!document.getElementById('trimov')) { const c=document.querySelector('.labcard'); if(c){ const t=document.createElement('div'); t.innerHTML=labCard(); c.replaceWith(t.firstChild); } } }catch(_){} }
setInterval(labTick,12000);
const _render1=render; render=function(){ _render1.apply(this,arguments); labAlert(); };
/* butin de course : graines et engrais */
const _kp1=karmaPrize;
karmaPrize=function(ev){ try{ const F=S.farm; if(F&&F.found&&ev&&!ev.ill&&Math.random()<.3){ let msg; if(Math.random()<.65){ const k=['N','P','K','CM','PHm','PHp','FONG','INSEC'][rint(0,7)], n=rint(1,3); F.chem[k]=(F.chem[k]||0)+n; msg=`${n} × ${CHEM[k].nom}`; } else { const bs=STR.filter(s=>!s.hy&&s.rep<=F.rep+5); const s=bs[rint(0,Math.min(bs.length-1,5))]; F.seeds[s.id]=(F.seeds[s.id]||0)+1; msg=`1 graine de ${s.nom}`; } setTimeout(()=>toast('🎁 Butin de course : '+msg),1500); } }catch(_){} return _kp1(ev); };
/* objectifs du labo */
const _goal2=goalNext;
goalNext=function(){ const r=_goal2(); if(r) return r; const F=S.farm; if(F&&F.found){ const pl=labStat(); if(pl&&pl.ready) return ['✂️','Une plante est prête à récolter !','base','Mon labo']; if(pl&&!pl.plants&&!(F.stats&&F.stats.harv)) return ['🌱','Plante ta première graine dans ton labo','base','Mon labo']; if(F.stats&&F.stats.harv>=2&&!(F.hyb&&F.hyb.length)) return ['🧬','Croise deux variétés pour créer un hybride unique','base','Mon labo']; } return null; };

GT.splice(GT.length-1,0,{ic:'⚡',t:'Raccourci : Mon labo',x:'Plus besoin de marcher jusqu’à la cloison à chaque fois : la carte <b>🌿 Mon labo</b> en haut de <b>Garage</b> et de <b>Atelier › Base</b> montre tes plantes en direct, avec <b>Tout arroser</b> et <b>Tout récolter</b>. Une pastille verte sur Base t’avertit quand une plante est prête ou a soif. En récoltant à la main, tu fais un petit <b>jeu de taille</b> : plus tu coupes de feuilles, meilleure est la qualité.'},{ic:'🧬',t:'Croiser des variétés',x:'Dans <b>📖 Variétés</b>, croise deux variétés dont tu as la graine pour créer un <b>hybride inédit</b>, de Commun à <b>Légendaire</b>. Tu peux aussi gagner des graines et des engrais en butin après tes courses légales.'});
/* ===== v0.32 : deux univers — gestion (onglets) / Monde 3D (cartes à explorer) ===== */
(()=>{ const i=TABS.findIndex(t=>t[0]==='hub'); if(i>=0) TABS.splice(i,1); })();
const WORLD={
 beach:{nom:'Plage Irie',ic:'🏝️',bx:44,bz:30,spawn:{x:0,z:22,yaw:0},lvl:2},
 street:{nom:'Rue Néon',ic:'🌃',bx:58,bz:14.5,spawn:{x:50,z:0,yaw:-Math.PI/2},lvl:3}
};
const DEST=[
 {id:'garage',ic:'🏛️',nom:'Mon garage',d:'Tes voitures sur leurs podiums, les comptoirs du réseau.',ok:()=>true},
 {id:'atelier',ic:'🌿',nom:'Labo caché',d:'Plots, eau, lampes : ta culture.',ok:()=>!!farm().found,why:'Trouve la cloison dans le garage'},
 {id:'ranch',ic:'🌾',nom:'Ranch',d:'Grand champ en plein air (24 plots).',ok:()=>!!farm().rooms.ranch.on,why:'À acheter dans le labo'},
 {id:'beach',ic:'🏝️',nom:'Plage Irie',d:'Coucher de soleil, bar tiki, feu de camp, reggae et tes voitures sur le sable.',ok:()=>S.lvl>=2,why:'Niveau 2 requis'},
 {id:'street',ic:'🌃',nom:'Rue Néon',d:'Ruelle sous la pluie, tes voitures en vitrine, départ de course, kiosques.',ok:()=>S.lvl>=3,why:'Niveau 3 requis'}
];
/* ---------- matériaux & aides ---------- */
let WC=null;
function worldCache(){ if(WC) return WC; const D=THREE.DoubleSide;
  const frond=ctex(128,128,(x,W,H)=>{ x.translate(W/2,H); x.fillStyle='#fff'; x.strokeStyle='#fff'; x.lineWidth=3; x.beginPath(); x.moveTo(0,0); x.lineTo(0,-122); x.stroke();
    for(let i=1;i<18;i++){ const t=i/18, y=-t*118, len=40*(1-t*.65); [-1,1].forEach(s=>{ x.beginPath(); x.moveTo(0,y); x.lineTo(s*len,y+len*.55); x.lineTo(0,y+7); x.closePath(); x.fill(); }); } });
  const rasta=ctex(64,64,(x,W,H)=>{ x.fillStyle='#e22'; x.fillRect(0,0,W/3,H); x.fillStyle='#fc0'; x.fillRect(W/3,0,W/3,H); x.fillStyle='#1c6'; x.fillRect(2*W/3,0,W/3,H); },[3,1]);
  const flag=ctex(64,48,(x,W,H)=>{ x.fillStyle='#e22'; x.fillRect(0,0,W,H/3); x.fillStyle='#fc0'; x.fillRect(0,H/3,W,H/3); x.fillStyle='#1c6'; x.fillRect(0,2*H/3,W,H/3); });
  WC={frond:new THREE.MeshLambertMaterial({map:frond,color:0x2e9a46,transparent:true,alphaTest:.4,side:D}),
   trunk:new THREE.MeshLambertMaterial({color:0x8a6a42}),umb:new THREE.MeshLambertMaterial({map:rasta,side:D}),flag:new THREE.MeshBasicMaterial({map:flag,side:D}),
   fg:new THREE.PlaneGeometry(1.5,3.4).translate(0,1.7,0),tg:new THREE.CylinderGeometry(.2,.3,1,7)};
  return WC; }
function wNeon(c){ return new THREE.MeshBasicMaterial({color:c}); }
function wLamb(c){ return new THREE.MeshLambertMaterial({color:c}); }
function wGlow(col,s){ const m=growCache().glowM.clone(); m.color=new THREE.Color(col); const sp=new THREE.Sprite(m); sp.scale.set(s,s,1); return sp; }
function skyDome(sc,stops){ const t=ctex(8,256,(x,W,H)=>{ const g=x.createLinearGradient(0,0,0,H); stops.forEach(s=>g.addColorStop(s[0],s[1])); x.fillStyle=g; x.fillRect(0,0,W,H); }); t.wrapS=t.wrapT=THREE.ClampToEdgeWrapping;
  const m=new THREE.Mesh(new THREE.SphereGeometry(300,18,12),new THREE.MeshBasicMaterial({map:t,side:THREE.BackSide,fog:false})); sc.add(m); return m; }
function parkCars(W,spots,rotY,label){ let list=((S.pod&&S.pod.slots)||[]).map(u=>u&&car(u)).filter(Boolean); if(!list.length) list=S.cars.slice(0,spots.length); list=list.slice(0,spots.length);
  list.forEach((c,i)=>{ const p=spots[i]; try{ const cg=buildCar(M[c.mid],'#00E5FF',carLook(c)); cg.g.position.set(p[0],p[2]||0,p[1]); cg.g.rotation.y=rotY; W.sc.add(cg.g);
    const ug=wGlow(0x00e5ff,7); ug.position.set(p[0],.3+(p[2]||0),p[1]); W.sc.add(ug); const lb=hubLabel(M[c.mid].nom,'#00E5FF',5,p[0],p[1]); lb.position.set(p[0],3.2+(p[2]||0),p[1]); W.sc.add(lb); W.obs.push({x:p[0],z:p[1],r:2.6}); }catch(e){} });
  return list.length; }
function palm(W,x,z,h,lean){ const C=worldCache(), g=new THREE.Group(); g.position.set(x,0,z); const n=6; let ox=0,oy=0;
  for(let i=0;i<n;i++){ const s=new THREE.Mesh(C.tg,C.trunk); s.scale.set(1-i*.08,h/n,1); s.position.set(ox,oy+h/n/2,0); s.rotation.z=-lean*.12; g.add(s); oy+=h/n*Math.cos(lean*.12*i); ox+=h/n*Math.sin(lean*.12)*(1); }
  const top=new THREE.Group(); top.position.set(ox,oy,0); g.add(top);
  for(let k=0;k<9;k++){ const pv=new THREE.Group(); pv.rotation.y=k/9*6.283+Math.random()*.3; const m=new THREE.Mesh(C.fg,C.frond); m.rotation.x=.9+(k%3)*.3; m.scale.setScalar(1.5+Math.random()*.4); pv.add(m); top.add(pv); }
  [[.18,.1],[-.15,.2],[.05,-.18]].forEach(c=>{ const co=new THREE.Mesh(new THREE.SphereGeometry(.22,6,5),new THREE.MeshLambertMaterial({color:0x5a3a1a})); co.position.set(c[0],-.2,c[1]); top.add(co); });
  W.sc.add(g); W.obs.push({x,z,r:.7}); (W.sway=W.sway||[]).push(top); return g; }
/* ---------- plage ---------- */
function buildBeach(W){
  const sc=W.sc; sc.background=new THREE.Color(0xff8b6a); sc.fog=new THREE.Fog(0xf59a7a,70,260);
  sc.add(new THREE.HemisphereLight(0xffd2b0,0x6a4aa0,1.35)); const dl=new THREE.DirectionalLight(0xffb27a,.9); dl.position.set(-60,40,-80); sc.add(dl);
  skyDome(sc,[[0,'#2a1650'],[.38,'#8a3a8e'],[.55,'#ff6a6a'],[.62,'#ffb066'],[.7,'#ffd9a0'],[1,'#ffe9c0']]);
  const sand=ctex(256,256,(x,Wd,H)=>{ x.fillStyle='#e8c88e'; x.fillRect(0,0,Wd,H); for(let i=0;i<1500;i++){ x.fillStyle=`rgba(${150+Math.random()*80|0},${120+Math.random()*60|0},${70+Math.random()*40|0},.25)`; x.fillRect(Math.random()*Wd,Math.random()*H,2,2); } },[22,18]);
  const fl=new THREE.Mesh(new THREE.PlaneGeometry(240,150),new THREE.MeshLambertMaterial({map:sand})); fl.rotation.x=-Math.PI/2; fl.position.set(0,0,22); sc.add(fl);
  const wet=new THREE.Mesh(new THREE.PlaneGeometry(240,8),new THREE.MeshLambertMaterial({color:0xa98558})); wet.rotation.x=-Math.PI/2; wet.position.set(0,.01,-27); sc.add(wet);
  const sea=new THREE.Mesh(new THREE.PlaneGeometry(700,360),new THREE.MeshBasicMaterial({map:ctex(64,64,(x,Wd,H)=>{ x.fillStyle='#2a6aa8'; x.fillRect(0,0,Wd,H); for(let i=0;i<14;i++){ x.fillStyle='rgba(255,210,150,.12)'; x.fillRect(Math.random()*Wd,Math.random()*H,16,2); } },[60,30])})); sea.rotation.x=-Math.PI/2; sea.position.set(0,-.25,-210); sc.add(sea); W.sea=sea;
  const foam=new THREE.Mesh(new THREE.PlaneGeometry(240,2.2),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.7,depthWrite:false})); foam.rotation.x=-Math.PI/2; foam.position.set(0,.05,-30.6); sc.add(foam); W.foam=foam;
  const sun=wGlow(0xffd27a,150); sun.position.set(-60,14,-230); sc.add(sun); const sun2=wGlow(0xfff2c0,60); sun2.position.set(-60,14,-229); sc.add(sun2);
  const refl=new THREE.Mesh(new THREE.PlaneGeometry(22,170),new THREE.MeshBasicMaterial({color:0xffc27a,transparent:true,opacity:.35,blending:THREE.AdditiveBlending,depthWrite:false})); refl.rotation.x=-Math.PI/2; refl.position.set(-60,-.2,-150); sc.add(refl); W.refl=refl;
  /* palmiers */
  [[-40,-20,9,.8],[-34,12,8,-.6],[-42,4,10,.5],[38,-18,9,-.7],[40,8,8,.6],[34,24,9,-.5],[-30,26,8,.7],[22,-22,8,.4],[-14,-24,9,-.4],[6,28,8,.6],[44,-4,10,-.6],[-44,-12,8,.4]].forEach(p=>palm(W,p[0],p[1],p[2],p[3]));
  /* bar tiki */
  const bx=-26, bz=-14; W.box(9,1.2,2.2,bx,.6,bz,wLamb(0x7a4a22)); W.box(9.4,.15,2.6,bx,1.25,bz,wLamb(0xa86a32)); [[-4.4,-1],[4.4,-1],[-4.4,1.8],[4.4,1.8]].forEach(q=>W.box(.3,4.2,.3,bx+q[0],2.1,bz+q[1],wLamb(0x6a4a22)));
  const roof=new THREE.Mesh(new THREE.ConeGeometry(7.2,3,4),new THREE.MeshLambertMaterial({color:0xc9a24a})); roof.rotation.y=Math.PI/4; roof.position.set(bx,5.7,bz+.4); roof.scale.set(1.15,1,.6); sc.add(roof);
  [0xff4d4d,0xffd400,0x3cff9e,0x00e5ff,0xff2bd6].forEach((c,i)=>W.box(.3,.8,.3,bx-3+i*1.5,1.7,bz,wNeon(c)));
  const bl=hubLabel('🥥 IRIE BAR','#FFD400',9,bx,bz); bl.position.set(bx,4.4,bz+2); sc.add(bl); W.obs.push({x0:bx-4.6,x1:bx+4.6,z0:bz-1.4,z1:bz+2});
  for(let i=0;i<11;i++){ const b=wGlow([0xff4d4d,0xffd400,0x3cff9e,0xff2bd6][i%4],1.4); b.position.set(bx-5+i,3.9-Math.sin(i/10*Math.PI)*.4,bz+2.2); sc.add(b); }
  W.poi('bar',bx,bz+4,4.2,()=>'🥥 Bar tiki · Irie',()=>[{id:'drink',tx:'🍹 Rhum-coco · 600 cr (+50 % XP, 3 courses)'}]);
  /* feu de camp */
  const fx=0, fz=-6; for(let i=0;i<6;i++){ const a=i/6*6.283, lg=new THREE.Mesh(new THREE.CylinderGeometry(.14,.14,1.8,6),wLamb(0x4a2a12)); lg.position.set(fx+Math.cos(a)*.9,.25,fz+Math.sin(a)*.9); lg.rotation.z=Math.PI/2; lg.rotation.y=-a; lg.rotation.x=.3; sc.add(lg); const st=new THREE.Mesh(new THREE.SphereGeometry(.35,6,5),wLamb(0x6a6a70)); st.position.set(fx+Math.cos(a)*2.1,.2,fz+Math.sin(a)*2.1); sc.add(st); }
  W.flames=[]; [[1,.9],[.8,1.2],[.6,.8]].forEach((f,i)=>{ const fm=new THREE.Mesh(new THREE.ConeGeometry(.5*f[0],1.9*f[1],6),new THREE.MeshBasicMaterial({color:[0xff6a1a,0xffb02a,0xffe27a][i],transparent:true,opacity:.85,blending:THREE.AdditiveBlending,depthWrite:false})); fm.position.set(fx+(i-1)*.15,.9*f[1],fz); sc.add(fm); W.flames.push(fm); });
  const fg=wGlow(0xff8a3a,9); fg.position.set(fx,1.2,fz); sc.add(fg); W.fire=fg; W.obs.push({x:fx,z:fz,r:2.3});
  W.poi('fire',fx,fz+3.4,3.6,()=>'🔥 Feu de camp',()=>[{id:'meditate',tx:'🧘 Méditer · karma +1 (toutes les 15 min)'}]);
  /* hamac */
  const hx=18, hz=-14; palm(W,hx-5,hz,9,.3); palm(W,hx+5,hz,9,-.3); for(let i=0;i<9;i++){ const t=i/8, y=3.2-Math.sin(t*Math.PI)*1.4; W.box(.9,.12,1.2,hx-4+t*8,y,hz,new THREE.MeshLambertMaterial({color:i%3===0?0xe22:i%3===1?0xfc0:0x1c6})); }
  W.poi('hammock',hx,hz+3,3.6,()=>'🛏️ Hamac',()=>[{id:'rest',tx:'😴 Se reposer · chaleur −15 % (toutes les 10 min)'}]);
  /* sono */
  const mx=10, mz=8; W.box(2.6,2.2,1.4,mx,1.1,mz,wLamb(0x4a2a68)); [[.22,0xff3a2d],[.36,0xffd400],[.5,0x1fe06a]].forEach(q=>W.box(2.64,.1,1.44,mx,q[0],mz,wNeon(q[1]))); [-.7,.7].forEach(s=>{ const sp=new THREE.Mesh(new THREE.CylinderGeometry(.5,.5,.1,14),wNeon(0x1fe06a)); sp.rotation.x=Math.PI/2; sp.position.set(mx+s,1.1,mz+.75); sc.add(sp); });
  W.box(2.7,.12,1.5,mx,2.25,mz,wNeon(0xffd400)); const ml=hubLabel('🔊 RIDDIM','#1FE06A',6,mx,mz); ml.position.set(mx,3.8,mz); sc.add(ml); W.obs.push({x:mx,z:mz,r:2.6});
  W.poi('music',mx,mz+3,3.6,()=>WM.on?'🔊 Sono · musique en cours':'🔊 Sono · reggae chill',()=>[{id:'music',tx:WM.on?'⏹ Couper la musique':'▶ Lancer reggae + vagues'}]);
  /* parasols + drapeau */
  [[-8,12],[-16,6],[24,14],[30,-6]].forEach(p=>{ const C=worldCache(), pl=new THREE.Mesh(new THREE.CylinderGeometry(.08,.08,3.4,6),wLamb(0xdddddd)); pl.position.set(p[0],1.7,p[1]); sc.add(pl); const um=new THREE.Mesh(new THREE.ConeGeometry(2.6,1,12),C.umb); um.position.set(p[0],3.6,p[1]); sc.add(um); W.box(1.4,.25,2.4,p[0]+1.8,.3,p[1]+1,wLamb(0xf0f0f0)); });
  const C=worldCache(), fp=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,7,6),wLamb(0xcccccc)); fp.position.set(-4,3.5,16); sc.add(fp); const fgm=new THREE.Mesh(new THREE.PlaneGeometry(3.2,2.2),C.flag); fgm.position.set(-2.4,6,16); sc.add(fgm); W.flag=fgm;
  const ol=hubLabel('ONE LOVE','#FFD400',9,0,0); ol.position.set(-4,8.4,16); sc.add(ol);
  /* voitures sur le sable */
  const n=parkCars(W,[[-22,16],[-12,20],[4,22],[14,18],[26,22]],Math.PI/2+.3); if(!n){ const t=hubLabel('Mets des voitures sur tes podiums !','#8b90c8',9,0,0); t.position.set(0,2,18); sc.add(t); }
  /* retour */
  W.box(.3,.3,5,36,.2,8,wNeon(0x3cff9e)); const gl=hubLabel('↩ GARAGE','#3CFF9E',7,38,8); gl.position.set(38,3.2,8); sc.add(gl);
  W.poi('gate',37,8,3.8,()=>'Sentier du garage',()=>[{id:'gate',tx:'↩ Retourner au garage'}]);
  W.anim=(dt,t)=>{ if(W.flames) W.flames.forEach((f,i)=>{ f.scale.set(1+Math.sin(t*9+i)*.12,1+Math.sin(t*7+i*2)*.18,1+Math.cos(t*8+i)*.12); }); W.fire.material.opacity=.85+Math.sin(t*11)*.1; W.foam.position.z=-30.6+Math.sin(t*.7)*1.1; W.foam.material.opacity=.45+.3*Math.sin(t*.7+1); W.sea.material.map.offset.x=t*.01; W.refl.material.opacity=.3+Math.sin(t*1.3)*.06; W.flag.rotation.y=Math.sin(t*2)*.25; if(W.sway) W.sway.forEach((s,i)=>{ s.rotation.z=Math.sin(t*1.1+i)*.03; s.rotation.x=Math.cos(t*.9+i)*.03; }); };
}
/* ---------- rue néon ---------- */
function winTex(seed){ let r=seed*9301+49297; const R=()=>{ r=(r*9301+49297)%233280; return r/233280; };
  return ctex(128,256,(x,W,H)=>{ x.fillStyle='#070a16'; x.fillRect(0,0,W,H); const cs=['#ffd27a','#7fe8ff','#ff7ad9','#9dffb0']; for(let gx=0;gx<8;gx++) for(let gy=0;gy<16;gy++){ x.fillStyle=R()<.42?cs[(R()*4)|0]:'#0f1630'; x.fillRect(gx*16+3,gy*16+4,10,8); } }); }
function buildStreet(W){
  const sc=W.sc; sc.background=new THREE.Color(0x070816); sc.fog=new THREE.Fog(0x0a0c20,40,170);
  sc.add(new THREE.HemisphereLight(0x6a78c8,0x1a0a2a,1.2)); const dl=new THREE.DirectionalLight(0xff9af0,.35); dl.position.set(20,50,10); sc.add(dl);
  skyDome(sc,[[0,'#0a0c24'],[.5,'#1a1040'],[.8,'#3a1458'],[1,'#5a1a6a']]);
  const BX=W.bx, road=ctex(256,256,(x,Wd,H)=>{ x.fillStyle='#14161e'; x.fillRect(0,0,Wd,H); for(let i=0;i<600;i++){ x.fillStyle=`rgba(120,130,160,${.03+Math.random()*.05})`; x.fillRect(Math.random()*Wd,Math.random()*H,2,2); }
    x.fillStyle='rgba(0,229,255,.12)'; x.fillRect(30,0,6,H); x.fillStyle='rgba(255,43,214,.10)'; x.fillRect(160,0,8,H); },[BX/6,1]);
  const rd=new THREE.Mesh(new THREE.PlaneGeometry(BX*2+60,18),new THREE.MeshLambertMaterial({map:road})); rd.rotation.x=-Math.PI/2; rd.position.set(0,0,0); sc.add(rd);
  const dash=ctex(64,16,(x,Wd,H)=>{ x.fillStyle='#ffd400'; x.fillRect(0,5,36,5); },[BX*2/6,1]); const dm=new THREE.Mesh(new THREE.PlaneGeometry(BX*2,.5),new THREE.MeshBasicMaterial({map:dash,transparent:true,opacity:.8})); dm.rotation.x=-Math.PI/2; dm.position.set(0,.03,0); sc.add(dm);
  [-1,1].forEach(s=>{ const sw=new THREE.Mesh(new THREE.PlaneGeometry(BX*2+60,10),new THREE.MeshLambertMaterial({color:0x2a2c3a})); sw.rotation.x=-Math.PI/2; sw.position.set(0,.06,s*14); sc.add(sw); W.box(BX*2+60,.2,.3,0,.15,s*9.1,wNeon(s<0?0x00e5ff:0xff2bd6)); });
  /* immeubles */
  const tx=[1,2,3,4].map(winTex), cols=[0x00e5ff,0xff2bd6,0xffd400,0x3cff9e,0xff4d4d];
  [-1,1].forEach(s=>{ for(let x=-BX-20,k=0;x<BX+30;x+=15,k++){ const h=16+((k*37+s*11)%5+5)*3.4, w=14, tt=tx[(k+(s>0?1:0))%4].clone(); tt.needsUpdate=true; tt.repeat.set(1,h/26);
      const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,10),new THREE.MeshBasicMaterial({map:tt,color:0xcfd4ff})); b.position.set(x,h/2,s*(24+((k*13)%3))); sc.add(b);
      W.box(w+.4,.3,.3,x,h+.15,s*(24+((k*13)%3))-s*5,wNeon(cols[(k+2)%5])); }});
  /* enseignes */
  [[-12,1,'GARAGE 24','#00E5FF']].forEach(sg=>{ const kk=Math.round((sg[0]+BX+20)/15), sx=-BX-20+15*kk, fz=24+((kk*13)%3)-5, sz=sg[1]; const l=hubLabel(sg[2],sg[3],10,sx,sz*(fz-2)); l.position.set(sx,8,sz*(fz-.3)); sc.add(l); const sgl=wGlow(parseInt(sg[3].slice(1),16),12); sgl.position.set(sx,8,sz*(fz-2.5)); sc.add(sgl); });
  /* lampadaires */
  for(let x=-BX+4;x<=BX-4;x+=14){ [-1,1].forEach(s=>{ W.box(.25,7,.25,x,3.5,s*9.4,wLamb(0x3a3e50)); W.box(1.6,.2,.25,x,7,s*9.4-s*.7,wLamb(0x3a3e50)); const g=wGlow(0xaee8ff,6); g.position.set(x,6.8,s*8.7); sc.add(g); }); }
  /* flaques / reflets néon */
  [[-30,2,0xff2bd6],[-12,-3,0x00e5ff],[8,3,0xffd400],[26,-2,0x3cff9e],[40,3,0xff4d6d]].forEach(p=>{ const pm=new THREE.Mesh(new THREE.PlaneGeometry(9,3),new THREE.MeshBasicMaterial({color:p[2],transparent:true,opacity:.16,blending:THREE.AdditiveBlending,depthWrite:false})); pm.rotation.x=-Math.PI/2; pm.position.set(p[0],.04,p[1]); sc.add(pm); });
  /* pluie */
  const N=520, pos=new Float32Array(N*6); const drops=[]; for(let i=0;i<N;i++){ drops.push([Math.random()*BX*2-BX,Math.random()*26,Math.random()*34-17]); }
  const rg=new THREE.BufferGeometry(); rg.setAttribute('position',new THREE.BufferAttribute(pos,3)); const rain=new THREE.LineSegments(rg,new THREE.LineBasicMaterial({color:0x9ad7ff,transparent:true,opacity:.3})); rain.frustumCulled=false; sc.add(rain);
  /* voitures en vitrine */
  const n=parkCars(W,[[-24,-4.5],[-10,-4.5],[4,-4.5],[18,-4.5],[32,-4.5]],0); if(!n){ const t=hubLabel('Mets des voitures sur tes podiums !','#8b90c8',9,0,0); t.position.set(0,2,-4.5); sc.add(t); }
  /* ligne de départ */
  const chk=ctex(64,16,(x,Wd,H)=>{ for(let i=0;i<8;i++) for(let j=0;j<2;j++){ x.fillStyle=(i+j)%2?'#fff':'#111'; x.fillRect(i*8,j*8,8,8); } },[1,1]); const sl=new THREE.Mesh(new THREE.PlaneGeometry(1.6,18),new THREE.MeshBasicMaterial({map:chk})); sl.rotation.x=-Math.PI/2; sl.position.set(-44,.04,0); sc.add(sl);
  W.box(.4,6,.4,-44,3,-9.5,wLamb(0x3a3e50)); W.box(.4,6,.4,-44,3,9.5,wLamb(0x3a3e50)); W.box(.5,.6,19.5,-44,6,0,wNeon(0xfcee0a)); const rl=hubLabel('🏁 DÉPART','#FCEE0A',8,-44,0); rl.position.set(-44,8,0); sc.add(rl);
  W.poi('race',-41,0,4.2,()=>'🏁 Ligne de départ',()=>[{id:'epreuves',tx:'🏁 Choisir une épreuve'},{id:'missions',tx:'📜 Missions',alt:1}]);
  /* kiosques */
  const kiosk=(x,z,col,txt)=>{ W.box(4,3,3,x,1.5,z,wLamb(0x1a1c2e)); W.box(4.4,.3,3.4,x,3.1,z,wNeon(col)); const l=hubLabel(txt,'#'+col.toString(16).padStart(6,'0'),6,x,z); l.position.set(x,4.6,z); sc.add(l); W.obs.push({x0:x-2.2,x1:x+2.2,z0:z-1.7,z1:z+1.7}); };
  kiosk(-2,-12.5,0xffd400,'🛒 MARCHÉ'); kiosk(30,-12.5,0x00e5ff,'🏗️ BASE'); kiosk(14,12.5,0xff2bd6,'🍜 RAMEN');
  W.poi('market',-2,-9.2,3.6,()=>'🛒 Marché des voitures',()=>[{id:'marche',tx:'Acheter / vendre des voitures'}]);
  W.poi('base',30,-9.2,3.6,()=>'🏗️ Ton quartier général',()=>[{id:'base',tx:'Bâtiments & améliorations'}]);
  W.poi('ramen',14,9.2,3.6,()=>'🍜 Stand de ramen',()=>[{id:'ramen',tx:'🍜 Ramen néon · 250 cr (+25 XP)'}]);
  /* portail */
  W.box(.3,6,6,56,3,0,wNeon(0x3cff9e)); const gl=hubLabel('↩ GARAGE','#3CFF9E',7,56,0); gl.position.set(56,7.4,0); sc.add(gl);
  W.poi('gate',53,0,3.8,()=>'Porte du garage',()=>[{id:'gate',tx:'↩ Retourner au garage'}]);
  W.anim=(dt,t)=>{ const a=rg.attributes.position.array; for(let i=0;i<N;i++){ const d=drops[i]; d[1]-=dt*32; if(d[1]<0) d[1]+=26; a[i*6]=d[0]; a[i*6+1]=d[1]; a[i*6+2]=d[2]; a[i*6+3]=d[0]+.15; a[i*6+4]=d[1]+.9; a[i*6+5]=d[2]; } rg.attributes.position.needsUpdate=true; };
}
const WBUILD={beach:buildBeach,street:buildStreet};
function worldBuild(id){
  const D=WORLD[id]; HUB.labels=[]; HUB.obs=[]; HUB.pois=[]; HUB.ents={npcs:[],pods:[]}; HUB.map=id; HUB.bx=D.bx; HUB.bz=D.bz; HUB.plots=null; HUB.fans=null; HUB.plotGroup=null; HUB.anim=null;
  const sc=new THREE.Scene(), cam=new THREE.PerspectiveCamera(100,1.5,.1,500);
  const W={sc,bx:D.bx,bz:D.bz,obs:HUB.obs,
    box:(w,h,d,x,y,z,mat)=>{ const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat); m.position.set(x,y,z); sc.add(m); return m; },
    poi:(id,x,z,r,title,btns)=>HUB.pois.push({id,x,z,r,title,btns,a:'wgo'})};
  WBUILD[id](W); HUB.anim=W.anim;
  HUB.scene=sc; HUB.cam=cam; HUB.pos={x:D.spawn.x,z:D.spawn.z}; HUB.yaw=D.spawn.yaw; HUB.pit=0; HUB.gAcc=0;
}
function worldTick(dt){
  const H=HUB; if(H.anim) H.anim(dt,H.t); H.gAcc=(H.gAcc||0)+dt;
  if(H.gAcc>1.3){ H.gAcc=0; const gh=$('growhud'); if(gh){ const kt=karmaTitle(); gh.innerHTML=`<span>💰 ${fmt(S.cr)}</span><span>🎟 ${fmt((S.arc&&S.arc.tk)||0)}</span><span>${WORLD[H.map]?WORLD[H.map].ic:''} ${WORLD[H.map]?WORLD[H.map].nom:''}</span>${WM.on?'<span>🎵</span>':''}${S.age18===true?`<span>${kt[2]} ${Math.round(karma())}</span>`:''}`; } }
  const p=H.pos; let best=null, bd=1e9; (H.pois||[]).forEach(q=>{ const d=Math.hypot(p.x-q.x,p.z-q.z); if(d<q.r&&d<bd){ bd=d; best=q; } }); H.gbest=best;
}
/* ---------- musique reggae + vagues ---------- */
const WM={ctx:null,on:false,timer:0,next:0,step:0,master:null,wave:null};
function musicStart(){ if(WM.on) return; const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return toast('Audio indisponible');
  try{ WM.ctx=WM.ctx||new AC(); const c=WM.ctx; if(c.state==='suspended') c.resume(); WM.master=c.createGain(); WM.master.gain.value=.55; WM.master.connect(c.destination);
    const len=c.sampleRate*3, buf=c.createBuffer(1,len,c.sampleRate), d=buf.getChannelData(0); let l=0; for(let i=0;i<len;i++){ l=(l+(Math.random()*2-1)*.06)*.985; d[i]=l*4; } WM.nbuf=buf;
    const ns=c.createBufferSource(); ns.buffer=buf; ns.loop=true; const lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=700; const g=c.createGain(); g.gain.value=.14; const lfo=c.createOscillator(), lg=c.createGain(); lfo.frequency.value=.13; lg.gain.value=.09; lfo.connect(lg); lg.connect(g.gain); ns.connect(lp); lp.connect(g); g.connect(WM.master); ns.start(); lfo.start(); WM.wave=[ns,lfo];
    WM.on=true; WM.step=0; WM.next=c.currentTime+.1; WM.timer=setInterval(musicSched,110); }catch(e){ WM.on=false; } }
function musicStop(){ if(!WM.on) return; WM.on=false; clearInterval(WM.timer); try{ WM.master.gain.setTargetAtTime(0,WM.ctx.currentTime,.15); const w=WM.wave, m=WM.master; setTimeout(()=>{ try{ w[0].stop(); w[1].stop(); m.disconnect(); }catch(_){} },600); }catch(_){} }
function musicSched(){ const c=WM.ctx; if(!c||!WM.on) return; while(WM.next<c.currentTime+.35){ musicStep(WM.step,WM.next); WM.next+=60/76/2; WM.step=(WM.step+1)%32; } }
function musicStep(s,t){ const c=WM.ctx, M=WM.master, bar=(s>>3)%4, st=s%8, roots=[45,50,45,52], hz=m=>440*Math.pow(2,(m-69)/12);
  const tone=(type,f,t0,dur,vol,lpf)=>{ const o=c.createOscillator(), g=c.createGain(); o.type=type; o.frequency.value=f; g.gain.setValueAtTime(0,t0); g.gain.linearRampToValueAtTime(vol,t0+.01); g.gain.exponentialRampToValueAtTime(.001,t0+dur); let n=o; if(lpf){ const f2=c.createBiquadFilter(); f2.type='lowpass'; f2.frequency.value=lpf; o.connect(f2); n=f2; } n.connect(g); g.connect(M); o.start(t0); o.stop(t0+dur+.05); };
  const noise=(t0,dur,vol,f,type)=>{ const ns=c.createBufferSource(); ns.buffer=WM.nbuf; const fl=c.createBiquadFilter(); fl.type=type||'highpass'; fl.frequency.value=f; const g=c.createGain(); g.gain.setValueAtTime(vol,t0); g.gain.exponentialRampToValueAtTime(.001,t0+dur); ns.connect(fl); fl.connect(g); g.connect(M); ns.start(t0,Math.random()*2); ns.stop(t0+dur+.02); };
  if([0,3,4,6].includes(st)) tone('triangle',hz(roots[bar]),t,.42,.3,500);
  if(st===4){ const k=c.createOscillator(), g=c.createGain(); k.frequency.setValueAtTime(120,t); k.frequency.exponentialRampToValueAtTime(42,t+.2); g.gain.setValueAtTime(.55,t); g.gain.exponentialRampToValueAtTime(.001,t+.26); k.connect(g); g.connect(M); k.start(t); k.stop(t+.3); noise(t,.08,.25,1500,'bandpass'); }
  if(st%2===1) [0,3,7,10].forEach(i=>tone('square',hz(roots[bar]+12+i),t,.11,.045,1700));
  noise(t,.04,st%2?.07:.035,7500);
}
/* ---------- actions ---------- */
const cdLeft=(k,min)=>{ const F=farm(); F.cd=F.cd||{}; return Math.max(0,Math.ceil((min*60000-(Date.now()-(F.cd[k]||0)))/60000)); };
ACT.wgo=d=>{ const id=d.id, v=d.v, F=farm();
  const leave=tab=>{ HUB.map='garage'; HUB.sig=''; musicStop(); closeSheet(); ACT.tab({id:tab}); };
  if(id==='gate') return growExit();
  if(id==='race'||id==='market'||id==='base') return leave(v);
  if(id==='bar'){ if(S.cr<600) return toast('Pas assez de crédits'); S.cr-=600; S.xpb=3; toast('🍹 Rhum-coco ! +50 % d’XP sur 3 épreuves'); save(); return; }
  if(id==='ramen'){ if(S.cr<250) return toast('Pas assez de crédits'); S.cr-=250; addXP(25); toast('🍜 Miam. +25 XP'); save(); return; }
  if(id==='music'){ if(WM.on){ musicStop(); toast('Musique coupée'); } else { musicStart(); toast('🎵 Irie !'); } HUB.gAcc=9; return; }
  if(id==='meditate'){ const m=cdLeft('fire',15); if(m>0) return toast(`Reviens dans ${m} min`); F.cd.fire=Date.now(); karmaAdd(1); toast('🧘 Paix intérieure : karma +1'); save(); return; }
  if(id==='rest'){ const m=cdLeft('hamm',10); if(m>0) return toast(`Reviens dans ${m} min`); F.cd.hamm=Date.now(); F.heat.atelier=Math.max(0,F.heat.atelier*.85-1); F.heat.ranch=Math.max(0,F.heat.ranch*.85-1); toast('😴 Tu te sens plus léger : chaleur −15 %'); save(); return; }
};
function wmapSheet(X){
  if(!sheet||sheet.t!=='wmap') return false;
  $('sheet').innerHTML=`<div class="inv">${X}<h2>🗺️ Carte du Monde</h2><p class="note">Choisis où aller. Les nouveaux lieux se débloquent en progressant.</p>
   ${DEST.map(d=>{ const ok=d.ok(), here=(HUB.map||'garage')===d.id; return `<div class="inv-r ${ok?'':'lock'}"><span class="inv-i">${d.ic}</span><div class="inv-t"><b>${d.nom}${here?' · tu es ici':''}</b><small>${ok?d.d:'🔒 '+d.why}</small></div>${ok&&!here?`<button class="btn sm" data-a="wtravel" data-id="${d.id}">Aller</button>`:''}</div>`; }).join('')}</div>`; return true; }
ACT.wmap=()=>openSheet({t:'wmap'});
ACT.wtravel=d=>{ const D=DEST.find(x=>x.id===d.id); if(!D||!D.ok()) return; musicStop(); if(d.id==='garage') return growExit(); growEnter(d.id); };
/* retour / entrées : compatible avec les nouvelles cartes */
const _growExit0=growExit;
growExit=function(){ const was=HUB.map; musicStop(); _growExit0(); if(WORLD[was]||was==='beach'||was==='street'){ HUB.pos={x:0,z:12}; HUB.yaw=0; } };
const _tab1=ACT.tab; ACT.tab=function(d){ if(d&&d.id==='hub'&&HUB.map!=='garage'){ HUB.map='garage'; HUB.sig=''; } return _tab1.call(this,d); };
/* bouton Monde 3D : à part, côté « gestion » */
function worldCard(){ return `<button class="worldcard" data-a="tab" data-id="hub"><span class="wc-i">🌍</span><span class="wc-t"><b>Monde 3D</b><small>Balade dans ton garage, ta plage, ta rue néon et ton labo</small></span><span class="wc-g">›</span></button>`; }

function worldBtn(){ const t=$('top'); if(!t||t.querySelector('.worldbtn')) return; const b=document.createElement('button'); b.className='worldbtn'; b.dataset.a='tab'; b.dataset.id='hub'; b.setAttribute('aria-label','Monde 3D'); b.textContent='🌍'; const mo=t.querySelector('.money'), sb=mo&&mo.querySelector('[data-a="mute"]'); if(sb) sb.before(b); else (mo||t).appendChild(b); }
const _render2=render; render=function(){ _render2.apply(this,arguments); try{ worldBtn(); }catch(e){} };
/* ===== v0.34 : fiches de stats à la plantation ===== */
const stb=(l,v,max,c,t)=>`<div class="stb"><span>${l}</span><div><i style="width:${Math.round(nz(v/max*100,100))}%;background:${c}"></i></div><b>${t}</b></div>`;
function lampFit(sv,l){ const r=l.lm/sv.lm; if(r<.8) return {c:'#ff6a3d',t:'Trop faible',k:'lo',p:Math.round(r*100)}; if(r>1.35) return {c:'#FCEE0A',t:'Trop forte',k:'hi',p:Math.round(r*100)}; return {c:'#3CFF9E',t:'Idéale',k:'ok',p:Math.round(r*100)}; }
const _rsv0=rSlotView;
rSlotView=function(room,i){
  const F=farm(), sl=F.rooms[room].slots[i];
  const seeds=STR.filter(s=>(F.seeds[s.id]||0)>0);
  if(sl||!seeds.length) return _rsv0(room,i);
  const P=RY.pick||{}, out=ROOMS[room].out, sv=P.sid?SID[P.sid]:null, md=P.med?MED[P.med]:null;
  let h=`<button class="btn alt sm" data-a="rback">← Retour à ${ROOMS[room].nom}</button><div class="rcard haze"><h3>${seedIc(24)} Planter une graine</h3>`;
  h+=`<p class="sm">1 · Variété</p><div class="rpicks">${seeds.map(s=>`<button class="${P.sid===s.id?'on':''}" data-a="rpick" data-id="sid" data-v="${s.id}">${leafIc(PURP[s.id]?'#a85de8':s.ty==='Sativa'?'#8be03c':'#3cc46a',26)}<b>${s.nom}</b><small>${s.ty} · ×${F.seeds[s.id]}</small></button>`).join('')}</div>`;
  if(sv) h+=`<div class="sfiche"><b>${sv.nom}</b> <small>${sv.ty}</small>${stb('THC',sv.thc,30,'#a85de8',sv.thc+' %')}${stb('Rendement',sv.y,50,'#3CFF9E','~'+sv.y+' g')}${stb('Vitesse',10/(sv.veg+sv.fl),1,'#00E5FF',(sv.veg+sv.fl).toFixed(1)+' min')}${stb('Soif',sv.eau,1.3,'#4aa8ff',sv.eau<=.95?'faible':sv.eau<=1.1?'normale':'forte')}${stb('Difficulté',sv.d,5,'#ff6a3d',['','facile','facile','moyenne','difficile','expert'][sv.d||1])}${stb('Lumière',sv.lm,60000,'#FCEE0A',((sv.lm/1000)|0)+' k lm idéal')}<small class="hint">${(sv.px||0)} cr/g de base · pH selon le substrat choisi</small></div>`;
  h+=`<p class="sm">2 · Substrat</p><div class="rpicks">${Object.keys(MED).map(k=>{ const m=MED[k]; return `<button class="${P.med===k?'on':''}" data-a="rpick" data-id="med" data-v="${k}">${soilIc(k,32)}<b>${m.nom}</b><small>${m.px?m.px+' cr':'gratuit'} · pH ${m.ph}</small></button>`; }).join('')}</div>`;
  if(md) h+=`<div class="sfiche"><b>${md.nom}</b> <small>pH idéal ${md.ph}</small>${stb('Rendement',md.y-.8,.4,'#3CFF9E','×'+md.y)}${stb('Vitesse',md.sp-.8,.5,'#00E5FF','×'+md.sp)}${stb('Eau bue',md.eau-.5,1.5,'#4aa8ff','×'+md.eau)}<small class="hint">Plus la plante s’écarte du pH idéal (${md.ph}), plus elle pousse lentement : corrige avec pH− / pH+.</small></div>`;
  let lamp=null;
  if(!out){ const ls=LAMP.filter(l=>(F.lamps[l.id]||0)>0); lamp=P.lamp?LID[P.lamp]:null;
    h+=`<p class="sm">3 · Lampe ${sv?`<small>(idéal pour ${sv.nom} : ${((sv.lm/1000)|0)} k lm)</small>`:'<small>(choisis une variété pour voir le match)</small>'}</p><div class="rpicks">${ls.length?ls.map(l=>{ const ft=sv?lampFit(sv,l):null; return `<button class="${P.lamp===l.id?'on':''}" data-a="rpick" data-id="lamp" data-v="${l.id}"><span class="big">${l.ic}</span><b>${l.nom}</b><small>${(l.lm/1000)|0} k lm · ${l.w} W</small>${ft?`<em class="fit" style="color:${ft.c}">${ft.k==='ok'?'✅':'⚠️'} ${ft.t}</em>`:''}</button>`; }).join(''):'<span class="sm">Aucune lampe : boutique → Lampes</span>'}</div>`;
    if(sv&&lamp){ const ft=lampFit(sv,lamp); h+=`<div class="sfiche">${stb('Match lumière',Math.min(ft.p,100),100,ft.c,ft.p+' % du besoin')}<small class="hint">${ft.k==='lo'?'Lumière insuffisante : croissance ralentie.':ft.k==='hi'?'Trop puissante : gaspillage de courant et plus de chaleur.':'Bon équilibre pour cette variété.'} Chaleur ${lamp.h}×.</small></div>`; } }
  else h+=`<p class="sm">3 · Lumière</p><div class="sfiche"><small class="hint">Plein soleil du ranch : environ ${((sv?36000:36000)/1000)|0} k lm, variable selon les jours. Pas de lampe à choisir.</small></div>`;
  if(sv&&md&&(out||lamp)){ const ft=out?null:lampFit(sv,lamp), spd=md.sp*(ft?(ft.k==='lo'?Math.max(.4,ft.p/100):1):1), tm=(1+sv.veg+sv.fl)/spd, g=Math.round(sv.y*md.y*(out?1.15:1));
    h+=`<div class="sfiche sum"><b>📊 Prévision</b>${stb('Récolte',g,70,'#3CFF9E','~'+g+' g')}${stb('Durée',20/tm,1,'#00E5FF','~'+tm.toFixed(1)+' min')}<small class="hint">Estimation avec soins parfaits (eau, N-P-K, pH, cycle).</small></div>`; }
  const okP=P.sid&&P.med&&(out||P.lamp);
  return h+`<button class="btn wide" data-a="rplant" data-id="${i}" ${okP?'':'disabled'}>🌱 Planter</button></div>`;
};
/* nav : bouton Labo (7e case) */
if(!TABS.some(t=>t[0]==='labo')) TABS.push(['labo','🌿','Labo']);
const _tab20=ACT.tab;
ACT.tab=function(d){ if(d&&d.id==='labo'){ try{ ACT.labopen(); }catch(e){ console.error(e); } return; } return _tab20.apply(this,arguments); };
/* ===== Collection du garage : recherche, filtres, tri ===== */
const GF={q:'',tier:'',cat:'',flag:'',sort:'recent'};
const GSORT={recent:'Ordre d’obtention',tier:'Rareté',ch:'Puissance',kg:'Poids (léger d’abord)',lvl:'Niveau',etat:'État',nom:'Nom A→Z',val:'Valeur'};
function gFiltered(){
  const q=GF.q.trim().toLowerCase(); let a=S.cars.map((c,i)=>({c,i}));
  a=a.filter(({c})=>{ const m=M[c.mid]; if(q&&!(m.nom+' '+m.cat+' '+m.an).toLowerCase().includes(q)) return false; if(GF.tier&&String(m.t)!==GF.tier) return false; if(GF.cat&&m.cat!==GF.cat) return false;
    if(GF.flag==='sh'&&!c.sh) return false; if(GF.flag==='rep'&&!(c.etat<75)) return false; if(GF.flag==='pod'&&!S.pod.slots.includes(c.uid)) return false; return true; });
  const k=GF.sort, g={tier:x=>-M[x.c.mid].t,ch:x=>-st(x.c).ch,kg:x=>st(x.c).kg,lvl:x=>-x.c.lvl,etat:x=>x.c.etat,val:x=>-(M[x.c.mid].val||0)};
  if(k==='nom') a.sort((x,y)=>M[x.c.mid].nom.localeCompare(M[y.c.mid].nom)); else if(g[k]) a.sort((x,y)=>g[k](x)-g[k](y)||x.i-y.i);
  return a.map(x=>x.c);
}
function gGrid(){ const l=gFiltered(); return l.length?l.map(c=>cardHTML(c,{attr:`data-a="car" data-id="${c.uid}"`})).join(''):'<p class="note" style="grid-column:1/-1">Aucune voiture ne correspond. Modifie ou efface les filtres.</p>'; }
function gBar(){
  const cats=[...new Set(S.cars.map(c=>M[c.mid].cat))].sort(), tiers=[...new Set(S.cars.map(c=>M[c.mid].t))].sort((a,b)=>b-a);
  const opt=(v,t,cur)=>`<option value="${v}" ${String(cur)===String(v)?'selected':''}>${t}</option>`;
  return `<div class="gbar"><input id="gq" type="search" placeholder="🔎 Rechercher une voiture…" value="${GF.q.replace(/"/g,'&quot;')}" autocomplete="off">
  <div class="gsel"><select id="gsort" aria-label="Trier">${Object.keys(GSORT).map(k=>opt(k,'↕ '+GSORT[k],GF.sort)).join('')}</select>
  <select id="gtier" aria-label="Catégorie de rareté">${opt('','Toutes raretés',GF.tier)}${tiers.map(t=>opt(t,TIERS[t].n,GF.tier)).join('')}</select>
  <select id="gcat" aria-label="Type">${opt('','Tous types',GF.cat)}${cats.map(c=>opt(c,c,GF.cat)).join('')}</select>
  <select id="gflag" aria-label="Filtre">${opt('','Toutes',GF.flag)}${opt('sh','✨ Shiny',GF.flag)}${opt('rep','🔧 À réparer',GF.flag)}${opt('pod','🏛️ Sur podium',GF.flag)}</select></div>
  <div class="gcount"><span id="gn">${gFiltered().length} / ${S.cars.length} voitures</span>${GF.q||GF.tier||GF.cat||GF.flag||GF.sort!=='recent'?'<button class="btn alt sm" id="greset">Réinitialiser</button>':''}</div></div>`;
}
const _vG20=vGarage;
vGarage=function(){ const h=_vG20(), i=h.indexOf('<div class="sec"><h3>Collection</h3>'); if(i<0) return h;
  return h.slice(0,i)+`<div class="sec"><h3>Collection</h3>${gBar()}<div class="grid" id="ggrid" style="margin-top:10px">${gGrid()}</div><p class="note">Touche une voiture pour la gérer et monter ses modules. Appui long : vue 3D.</p></div>`; };
function gRefresh(){ const g=document.getElementById('ggrid'); if(!g) return; g.innerHTML=gGrid(); const n=document.getElementById('gn'); if(n) n.textContent=gFiltered().length+' / '+S.cars.length+' voitures'; }
document.addEventListener('input',e=>{ if(e.target.id==='gq'){ GF.q=e.target.value; gRefresh(); } });
document.addEventListener('change',e=>{ const m={gsort:'sort',gtier:'tier',gcat:'cat',gflag:'flag'}[e.target.id]; if(m){ GF[m]=e.target.value; render(); } });
document.addEventListener('click',e=>{ if(e.target.id==='greset'){ Object.assign(GF,{q:'',tier:'',cat:'',flag:'',sort:'recent'}); render(); } });
/* ===== v0.39 : conditionnement (sachets, pochons, caisses, valises) + coffre des voitures ===== */
const UN={
 bag:{n:'Sachet',ic:'bag',g:1,px:1.5,buy:10,bonus:.14,vis:.75,d:'Discret, se vend très bien à la pièce'},
 pouch:{n:'Pochon',ic:'pouch',g:10,px:9,buy:5,bonus:.10,vis:.9,d:'Le format classique'},
 crate:{n:'Caisse',ic:'crate',g:100,px:70,buy:2,bonus:.06,vis:1.15,d:'Lourd et voyant'},
 case:{n:'Valise',ic:'case',g:500,px:280,buy:1,bonus:.03,vis:1.3,d:'Gros volume, gros risque'}
};
const UK=Object.keys(UN);
const CAP={'Vélo':5,'Citadine':20,'Sportive':25,'Supercar':20,'Hypercar':10,'Drift':30,'Compacte':40,'Électrique':40,'Muscle car':50,'Rallye':50,'Classique':60,'Luxe':60,'Berline':80,'Break':150,'4x4':200,'Pick-up':400,'Utilitaire':500};
const capOf=c=>CAP[M[c.mid].cat]||60;
function pkI(u,s){ s=s||40; const x={
 bag:`<path d="M9 9h22l2 25a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2z" fill="#e8fff1" fill-opacity=".16" stroke="#bfe9d0" stroke-width="1.5"/><rect x="8.2" y="9" width="23.6" height="4.2" rx="1.2" fill="#3CFF9E"/><circle cx="16" cy="25" r="4.4" fill="#2fbf71"/><circle cx="23.5" cy="26.5" r="4" fill="#3cd987"/><circle cx="20" cy="21.5" r="3.4" fill="#59e79a"/><path d="M12 15h16" stroke="#bfe9d0" stroke-width="1" stroke-dasharray="2 2"/>`,
 pouch:`<path d="M13 7h14l-1.6 5.4c4.6 2.4 7.6 7 7.6 12 0 6-4.4 10.6-13 10.6S7 30.4 7 24.4c0-5 3-9.6 7.6-12z" fill="#5a3b8c" stroke="#a98ae0" stroke-width="1.5"/><rect x="12.4" y="10.6" width="15.2" height="3.4" rx="1.4" fill="#FFD400"/><circle cx="20" cy="25" r="5.6" fill="#3CFF9E" fill-opacity=".9"/><path d="M20 20.6c1 2.4 1 4.8 0 8.8M16.4 24.4c2.4.4 5 .4 7.2 0" stroke="#145a37" stroke-width="1.3" fill="none" stroke-linecap="round"/>`,
 crate:`<rect x="4.5" y="10" width="31" height="23" rx="2" fill="#a8723a" stroke="#6d4521" stroke-width="1.6"/><path d="M4.5 17.6h31M4.5 25.4h31" stroke="#6d4521" stroke-width="1.6"/><path d="M5 10l30 23M35 10 5 33" stroke="#8a5b2c" stroke-width="1.6"/><rect x="13" y="6.4" width="14" height="5" rx="1.2" fill="#d9a25f" stroke="#6d4521" stroke-width="1.2"/><circle cx="20" cy="9" r="1.2" fill="#6d4521"/>`,
 case:`<rect x="14" y="5.5" width="12" height="7" rx="2.5" fill="none" stroke="#9aa3b5" stroke-width="2"/><rect x="4.5" y="11" width="31" height="23" rx="3.2" fill="#1a1d2e" stroke="#6b7390" stroke-width="1.6"/><path d="M4.5 19h31" stroke="#FFD400" stroke-width="2"/><path d="M4.5 21.5h31" stroke="#E0354B" stroke-width="1.6"/><path d="M4.5 24h31" stroke="#3CFF9E" stroke-width="1.6"/><rect x="11" y="16.6" width="4.4" height="5.6" rx="1" fill="#d6b24a"/><rect x="24.6" y="16.6" width="4.4" height="5.6" rx="1" fill="#d6b24a"/>`}[u];
 return `<svg class="pki" viewBox="0 0 40 40" width="${s}" height="${s}" aria-hidden="true">${x}</svg>`; }
function pkState(){ const F=farm(); F.mat=F.mat||{bag:0,pouch:0,crate:0,case:0}; F.lots=F.lots||[]; return F; }
const lotG=l=>l.n*UN[l.u].g;
function pkAvail(F,sid){ let g=(F.stock[sid]&&F.stock[sid].g)||0; F.lots.forEach(l=>{ if(l.sid===sid) g+=lotG(l); }); return g; }
function pkAdd(F,sid,q,u,n){ const l=F.lots.find(x=>x.sid===sid&&x.u===u); if(l){ const a=l.n*UN[u].g, b=n*UN[u].g; l.q=(l.q*a+q*b)/(a+b); l.n+=n; } else F.lots.push({sid,q,u,n}); }
const RPK={sid:null};
function pkCard(){ const F=pkState(), ks=Object.keys(F.stock).filter(k=>F.stock[k].g>=1);
  if(!RPK.sid||!(F.stock[RPK.sid]&&F.stock[RPK.sid].g>=1)) RPK.sid=ks[0]||null;
  const sel=RPK.sid, s=sel&&F.stock[sel];
  let h=`<div class="rcard pkcard"><h3>📦 Conditionnement</h3><p class="sm">Transforme ton stock en sachets, pochons, caisses ou valises : ils se vendent mieux, mais pèsent dans le coffre et se voient plus ou moins.</p>`;
  if(ks.length>1) h+=`<div class="rchips">${ks.map(k=>`<button class="${k===sel?'on':''}" data-a="pksel" data-id="${k}">${SID[k].ic} ${SID[k].nom} · ${Math.floor(F.stock[k].g)} g</button>`).join('')}</div>`;
  else if(sel) h+=`<p class="sm">${SID[sel].ic} <b>${SID[sel].nom}</b> · ${Math.floor(s.g)} g en vrac · qualité ${Math.round(s.q)} %</p>`;
  else h+=`<p class="sm">Aucun stock en vrac à conditionner. Récolte d’abord une plante.</p>`;
  UK.forEach(u=>{ const D=UN[u], can=s?Math.min(Math.floor(s.g/D.g),F.mat[u]):0;
    h+=`<div class="urow"><div class="uic">${pkI(u,40)}</div><div class="ugr"><b>${D.n} <small>${D.g} g</small></b><small>${D.d}</small><small>Emballages : <b>×${F.mat[u]}</b> · prix +${Math.round(D.bonus*100)} % · visibilité ${D.vis<1?'basse':D.vis>1.1?'haute':'moyenne'}</small></div>
    <div class="ubt"><button data-a="pkmake" data-id="${u}" data-v="1" ${can>=1?'':'disabled'}>×1</button><button data-a="pkmake" data-id="${u}" data-v="max" ${can>=1?'':'disabled'}>Max${can>1?' '+can:''}</button><button class="buy" data-a="pkbuy" data-id="${u}">+${D.buy}<small>${fmt(Math.round(D.px*D.buy))} cr</small></button></div></div>`; });
  return h+'</div>'; }
function lotsCard(){ const F=pkState(); if(!F.lots.length) return '';
  const rows=F.lots.map((l,i)=>{ const sv=SID[l.sid]; if(!sv) return ''; const D=UN[l.u], g=lotG(l), p=sellPrice(l.sid,l.q)*(1+D.bonus), m=F.rep>=10?1:.75;
    return `<div class="urow lot"><div class="uic">${pkI(l.u,36)}</div><div class="ugr"><b>${D.n} ×${l.n} <small>${g} g</small></b><small>${sv.ic} ${sv.nom} · qualité ${Math.round(l.q)} %</small><small>≈ ${Math.round(g*p*m)} cr (${F.rep>=10?'contact':'rue −25 %'})</small></div><div class="ubt"><button data-a="lsell" data-id="${i}">Vendre</button></div></div>`; }).join('');
  return `<div class="rcard pkcard"><h3>🧳 Marchandise conditionnée</h3>${rows}<p class="sm">Les livraisons en voiture piochent d’abord ici : bonus de prix du format, mais chaque format a sa visibilité.</p></div>`; }
const _rStock20=rStock; rStock=function(){ pkState(); return pkCard()+lotsCard()+_rStock20(); };
Object.assign(ACT,{
 pksel(d){ RPK.sid=d.id; renderSheet(); },
 pkbuy(d){ const F=pkState(), D=UN[d.id], c=Math.round(D.px*D.buy); if(S.cr<c) return toast('Pas assez de crédits'); S.cr-=c; F.mat[d.id]+=D.buy; toast(`+${D.buy} ${D.n.toLowerCase()}${D.buy>1?'s':''} d’emballage`); save(); renderSheet(); },
 pkmake(d){ const F=pkState(), D=UN[d.id], sid=RPK.sid, s=sid&&F.stock[sid]; if(!s) return; const can=Math.min(Math.floor(s.g/D.g),F.mat[d.id]); const n=d.v==='max'?can:Math.min(1,can); if(n<1) return toast(F.mat[d.id]<1?'Il te faut des emballages':'Pas assez de marchandise');
  s.g-=n*D.g; F.mat[d.id]-=n; pkAdd(F,sid,s.q,d.id,n); F.stats.packed=(F.stats.packed||0)+n*D.g; toast(`${n} ${D.n.toLowerCase()}${n>1?'s':''} prêt${n>1?'s':''}`); save(); renderSheet(); },
 lsell(d){ const F=pkState(), l=F.lots[+d.id]; if(!l) return; const D=UN[l.u], g=lotG(l), m=F.rep>=10?1:.75, gain=Math.round(g*sellPrice(l.sid,l.q)*(1+D.bonus)*m), ht=(F.rep>=10?g*.12:g*.35)*D.vis;
  S.cr+=gain; F.stats.sold+=g; F.rep+=g*.02; karmaAdd(-g*(F.rep>=10?.02:.04)); F.heat.atelier=Math.min(100,F.heat.atelier+ht*.4); F.heat.ranch=Math.min(100,F.heat.ranch+ht*.4); F.lots.splice(+d.id,1); toast(`${g} g vendus, +${fmt(gain)} cr`); save(); renderSheet(); }
});
/* cargaison : lots d'abord, puis vrac */
bestCargo=function(e){ if(e.ill!=='cargo') return null; const F=pkState(); let best=null;
  Object.keys(F.stock).concat(F.lots.map(l=>l.sid)).filter((k,i,a)=>a.indexOf(k)===i).forEach(sid=>{ if(!SID[sid]||pkAvail(F,sid)<e.cargo) return;
    let need=e.cargo, plan=[], bq=0, bsum=0, vis=0, qs=0;
    const mine=F.lots.map((l,i)=>({l,i})).filter(x=>x.l.sid===sid).sort((a,b)=>UN[b.l.u].g-UN[a.l.u].g);
    mine.forEach(({l,i})=>{ const D=UN[l.u]; let n=Math.min(l.n,Math.floor(need/D.g)); if(n>0){ plan.push({i,n}); need-=n*D.g; qs+=l.q*n*D.g; bsum+=D.bonus*n*D.g; vis+=D.vis*n*D.g; } });
    mine.slice().reverse().forEach(({l,i})=>{ if(need<=0||(F.stock[sid]&&F.stock[sid].g>=need)) return; const D=UN[l.u], used=(plan.find(p=>p.i===i)||{n:0}).n, free=l.n-used, n=Math.min(free,Math.ceil(need/D.g)); if(n>0){ const ex=plan.find(p=>p.i===i); if(ex) ex.n+=n; else plan.push({i,n}); need-=n*D.g; qs+=l.q*n*D.g; bsum+=D.bonus*n*D.g; vis+=D.vis*n*D.g; } });
    const lg=plan.reduce((a,p)=>a+p.n*UN[F.lots[p.i].u].g,0); let loose=Math.max(0,e.cargo-lg); const st=F.stock[sid]; if(loose>0){ if(!st||st.g<loose) return; qs+=st.q*loose; vis+=loose; }
    const g=lg+loose, q=qs/g, b={sid,g,q,plan,loose,bonus:bsum/g,vis:vis/g,packed:lg};
    if(!best||sellPrice(sid,q)*(1+b.bonus)>sellPrice(best.sid,best.q)*(1+best.bonus)) best=b; });
  return best; };
ACT.illgo=function(d){ const e=ILL.find(x=>x.id===d.id), F=farm(); if(!e||S.lvl<e.lvl||F.rep<e.rep||S.cars.length<e.manches.length) return;
  let cargo=null; if(e.ill==='cargo'){ cargo=bestCargo(e); if(!cargo) return toast('Pas assez de marchandise'); } else { if(S.cr<e.bet) return toast('Pas assez pour la mise'); }
  closeSheet(); ACT.ev({id:e.id}); if(R&&R.ev&&R.ev.id===e.id){ R.cargo=cargo; render(); } };
const _go20=ACT.go;
ACT.go=function(d){ if(R&&R.cargo&&R.pick&&R.pick[0]){ const c=car(R.pick[0]); if(c&&R.cargo.g>capOf(c)) return toast(`Coffre trop petit : ${capOf(c)} g max, il en faut ${R.cargo.g}`); } return _go20.apply(this,arguments); };
const _vPrep20=vPrep;
vPrep=function(){ let b=''; if(R&&R.cargo){ const k=R.cargo, c=R.pick&&R.pick[0]?car(R.pick[0]):null, cap=c?capOf(c):0, ok=c&&k.g<=cap, load=c?k.g/cap:0;
  b=`<div class="cargob ${c?(ok?'ok':'ko'):''}"><div class="cgi">${pkI(k.packed>=k.g*.5&&k.plan[0]?F_u(k):'crate',44)}</div><div class="cgt"><b>Chargement : ${k.g} g de ${SID[k.sid].nom}</b><small>${k.packed?`${k.packed} g conditionnés (+${Math.round(k.bonus*100)} % de prix)`:'En vrac'}${k.loose?` · ${k.loose} g en vrac`:''}</small>
  <small>${c?`Coffre de ta voiture : <b>${cap} g</b> ${ok?(load>.8?'· presque plein : plus repérable':'· ok'):'· <b>trop petit</b>, choisis un break, un 4x4 ou un utilitaire'}`:'Choisis la voiture qui transporte la marchandise (manche 1).'}</small></div></div>`; }
  return b+_vPrep20(); };
function F_u(k){ const F=farm(), l=F.lots[k.plan[0].i]; return l?l.u:'crate'; }
const _rNet20=rNet;
rNet=function(){ const big=S.cars.reduce((a,c)=>capOf(c)>(a?capOf(a):-1)?c:a,null); return `<div class="rcard"><small>🚗 Ton plus grand coffre : <b>${big?capOf(big)+' g':'—'}</b>${big?` (${M[big.mid].nom})`:''}. Les livraisons demandent la place nécessaire.</small></div>`+_rNet20(); };
illResolve=function(ev,pay,win,pod){
  if(!ev.ill){ if(win) karmaAdd(Math.min(3,1+(ev.lvl>>2))); else if(pod) karmaAdd(.5); return; } const F=pkState(); let msg='';
  if(ev.ill==='cargo'){ const c=R.cargo; if(!c) return;
    const take=()=>{ (c.plan||[]).slice().sort((a,b)=>b.i-a.i).forEach(p=>{ const l=F.lots[p.i]; if(!l) return; l.n-=p.n; if(l.n<=0) F.lots.splice(p.i,1); }); const s=F.stock[c.sid]; if(s&&c.loose) s.g=Math.max(0,s.g-c.loose); }; take();
    const over=(()=>{ const cc=R.pick&&R.pick[0]&&car(R.pick[0]); return cc&&c.g/capOf(cc)>.8?1.2:1; })(), heat=ev.heat*(c.vis||1)*over;
    if(pod){ const v=Math.round(c.g*sellPrice(c.sid,c.q)*(1+(c.bonus||0))*ev.prem*Math.max(.6,pay)); S.cr+=v; F.rep+=ev.rep*.25+1; F.stats.deliv++; const h=heat*.5; F.heat.atelier=Math.min(100,F.heat.atelier+h); F.heat.ranch=Math.min(100,F.heat.ranch+h); karmaAdd(-2); msg=`📦 <b>Livraison réussie</b> : ${c.g} g écoulés, +${fmt(v)} cr${c.bonus?` (dont +${Math.round(c.bonus*100)} % de format)`:''}.`; }
    else{ F.stats.busted++; karmaAdd(-3); const fine=Math.round(S.cr*.08); S.cr-=fine; F.heat.atelier=Math.min(100,F.heat.atelier+heat); F.heat.ranch=Math.min(100,F.heat.ranch+heat); msg=`🚔 <b>Interpellé !</b> Cargaison saisie, amende ${fmt(fine)} cr, chaleur en hausse.`; } }
  else{ if(win){ karmaAdd(-1); S.cr+=ev.bet; F.rep+=1+ev.rep*.1; msg=`🏁 <b>Course gagnée</b> : +${fmt(ev.bet)} cr de mise ramassée.`; }
    else if(pod){ msg='🏁 Tu sauves ta mise, mais sans gloire.'; }
    else { S.cr=Math.max(0,S.cr-ev.bet); msg=`🏁 <b>Perdu</b> : la mise de ${fmt(ev.bet)} cr est partie.`; }
    F.heat.atelier=Math.min(100,F.heat.atelier+ev.heat*.3); }
  save(); setTimeout(()=>banner(msg),400);
};
/* ===== v0.40 : la chaîne plante → récolte → séchoir → conditionnement → livraison, dans le monde 3D ===== */
function packStation(room){
  const sc=HUB.scene, F=pkState(), out=GROW[room].out, BZ=GROW[room].bz+1;
  const L=c=>new THREE.MeshLambertMaterial({color:c}), box=(w,h,d,x,y,z,m)=>{ const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m); o.position.set(x,y,z); sc.add(o); return o; };
  const X=out?12:-14, Z=out?-24:BZ-2.2, wood=out?0x6a4a2a:0x3a4650;
  box(7,.18,2.6,X,1.05,Z,L(wood)); [[-3.2,-1],[3.2,-1],[-3.2,1],[3.2,1]].forEach(a=>box(.18,1,.18,X+a[0],.5,Z+a[1]*1,L(0x2a3438)));
  box(7.2,.06,2.8,X,1.16,Z,new THREE.MeshBasicMaterial({color:0x3cff9e}));
  HUB.obs.push({x0:X-3.6,x1:X+3.6,z0:Z-1.4,z1:Z+1.4});
  /* un objet 3D par lot (limité) */
  let k=0; const put=(u,i)=>{ const x=X-3+(k%8)*.85, row=(k/8|0), z=Z-.5+row*.9; k++;
    if(u==='bag'){ box(.5,.07,.7,x,1.25,z,L(0xe8fff1)); box(.34,.09,.5,x,1.3,z,L(0x2fbf71)); }
    else if(u==='pouch'){ const c=new THREE.Mesh(new THREE.CylinderGeometry(.22,.28,.55,10),L(0x6a3fb0)); c.position.set(x,1.5,z); sc.add(c); box(.3,.08,.3,x,1.82,z,L(0xffd400)); }
    else if(u==='crate'){ box(.8,.7,.8,x,1.6,z,L(0xa8723a)); box(.82,.08,.82,x,1.96,z,L(0x6d4521)); }
    else { box(1,.7,.7,x,1.6,z,L(0x1a1d2e)); box(1.02,.1,.72,x,1.62,z,L(0xffd400)); } };
  F.lots.slice(0,6).forEach(l=>{ for(let i=0;i<Math.min(3,l.n);i++) if(k<16) put(l.u,i); });
  const lb=hubLabel('📦 CONDITIONNEMENT','#FFD400',6,X,Z); lb.position.set(X,4.2,Z); sc.add(lb);
  const tot=()=>{ const f=pkState(); return f.lots.reduce((a,l)=>a+lotG(l),0); }, loose=()=>Object.keys(farm().stock).reduce((a,k)=>a+Math.floor(farm().stock[k].g),0);
  HUB.pois.push({id:'pack',x:X,z:out?Z+3.2:Z-3.2,r:4.2,title:()=>`📦 Table de conditionnement · ${loose()} g en vrac · ${tot()} g prêts`,btns:()=>[{id:'pack',tx:'📦 Conditionner la récolte'},{id:'packnet',tx:'🚗 Charger & livrer',alt:1}]});
  if(!out){ const f=farm(); HUB.pois.push({id:'dry',x:22,z:-BZ+4,r:3.6,title:()=>{ const d=(farm().dry||[]); return d.length?`🧺 Séchoir · ${d.length} lot${d.length>1?'s':''} · ${Math.round(d.reduce((a,b)=>a+b.g,0))} g en séchage`:'🧺 Séchoir vide'; },btns:()=>[{id:'dry',tx:'🫙 Voir le stock'}]}); }
}
const _gb20=growBuild;
growBuild=function(room){ _gb20(room); try{ if(window.THREE) packStation(room); }catch(e){ console.error(e); } };
const _gg20=ACT.growgo;
ACT.growgo=function(d){ if(d.id==='pack'||d.id==='dry'||d.id==='packnet'){ RY.tab=d.id==='packnet'?'net':'stock'; RY.slot=null; return openSheet({t:'ranch'}); } return _gg20.apply(this,arguments); };
/* accès directs depuis les objectifs */
const _tab21=ACT.tab;
ACT.tab=function(d){ if(d&&(d.id==='labstock'||d.id==='labnet')){ try{ ACT.labopen(); }catch(e){ console.error(e); } RY.tab=d.id==='labnet'?'net':'stock'; RY.slot=null; try{ renderSheet(); }catch(e){} return; } return _tab21.apply(this,arguments); };
const _goal3=goalNext;
goalNext=function(){ const r=_goal3(); if(r&&r[2]!=='base') return r; const F=S.farm; if(F&&F.found){ pkState(); const loose=Object.keys(F.stock).reduce((a,k)=>a+F.stock[k].g,0), packed=F.lots.length>0;
  if(!packed&&!(F.stats&&F.stats.packed)&&loose>=5) return ['📦','Conditionne ta récolte en sachets ou pochons : elle se vend mieux','labstock','Conditionner'];
  if(packed&&!(F.stats&&F.stats.deliv)) return ['🚗','Charge ton coffre et fais ta première livraison au volant','labnet','Au réseau']; } return r; };
/* retour d'info quand un lot a fini de sécher */
(()=>{ let prev=null; setInterval(()=>{ try{ const F=S&&S.farm; if(!F||!F.found) return; const n=(F.dry||[]).length; if(prev!==null&&n<prev) toast('🧺 Séchage terminé : ta récolte est au stock, prête à être conditionnée'); prev=n; }catch(_){} },1500); })();
GT.splice(GT.length-1,0,{ic:'📦',t:'Du plant au coffre',x:'<b>Récolte</b> → <b>séchoir</b> (2 min) → <b>stock</b> → <b>conditionnement</b> en sachets, pochons, caisses ou valises → <b>livraison</b> en voiture. À la <b>table de conditionnement</b> du labo (ou dans l’onglet Stock), transforme ton vrac : chaque format a son bonus de prix et sa visibilité. Ton coffre doit être assez grand pour la cargaison.'});
/* ===== v0.41 : Équipe — employés (mécano, jardinier, pilote, vendeur, gardien) ===== */
const ROLES={
 mech:{n:'Mécano',ic:'🔧',base:260,d:'Remet tes voitures en état, même quand tu ne joues pas.',unit:'pts d’état'},
 gard:{n:'Jardinier',ic:'🌱',base:240,d:'Arrose, soigne et récolte tes plantes.',unit:'soins'},
 pil:{n:'Pilote',ic:'🏁',base:300,d:'Court pour toi : crédits et expérience en continu.',unit:'cr rapportés'},
 ven:{n:'Vendeur',ic:'🛍️',base:280,d:'Écoule ton stock en vrac à bon prix.',unit:'cr de ventes'},
 guard:{n:'Gardien',ic:'🛡️',base:270,d:'Veille sur les lieux : la chaleur retombe plus vite.',unit:'pts de chaleur'}
};
const TRAITS={
 des:{n:'Désespéré de survivre',eff:1,drain:1,wage:.85,d:'Se donne à fond quand ton argent est bas'},
 ass:{n:'Assidu',eff:1.1,drain:1,wage:1.05,d:'Travaille un peu plus vite'},
 fai:{n:'Flemmard',eff:.9,drain:.8,wage:.8,d:'Moins cher, moins rapide'},
 per:{n:'Perfectionniste',eff:1.05,drain:1.15,wage:1.1,d:'Soigné mais se fatigue plus vite'},
 fet:{n:'Fêtard',eff:1,drain:1.3,wage:.95,d:'Brillant, mais s’épuise vite'},
 cal:{n:'Calme',eff:1,drain:.75,wage:1.05,d:'Ne se fatigue presque pas'}
};
const NAMES=['Gaspard','Mehdi','Lucie','Bram','Yasmine','Théo','Nadia','Karim','Inès','Wout','Sofia','Pablo','Mona','Elias','Jade','Rémi','Anouk','Idriss','Léa','Sven'];
const SURN=['Dubois','Peeters','Benali','Janssens','Lambert','Diallo','Martens','Rossi','Claes','Mertens','Kowalski','Haddad'];
const QUOTES={
 des:['Chef… la plante, c’est tout ce qui me reste.','Merci de m’avoir pris. Vraiment.','J’ai pas beaucoup dormi, mais elle a bu.','Elle a repris des couleurs. Moi aussi, un peu.','Je ne vous décevrai pas, promis.','C’est la première fois depuis longtemps qu’on me fait confiance.'],
 desHi:['Vous savez… c’est ma famille, ici, maintenant.','Si je peux rester, je ferai tout.','Je me suis remis à cuisiner, grâce à vous.'],
 gen:['Tout roule, chef.','On s’en occupe.','Rien à signaler.','Un petit café et ça repart.','Content de bosser ici.'],
 genHi:['Je me plais vraiment ici.','Vous pouvez compter sur moi.'],
 tired:['Je tiens… un peu de repos ferait du bien.','Je suis cuit, chef.'],
 unpaid:['Le salaire… on attend encore.','C’est compliqué sans la paie, chef.']
};
const TEAM0=()=>({hired:[],cand:[],candT:0,last:Date.now(),seq:0,tot:{}});
function team(){ if(!S.team) S.team=TEAM0(); const T=S.team; if(!T.hired) T.hired=[]; if(!T.cand) T.cand=[]; return T; }
let teamCap=()=>Math.min(6,1+Math.floor(S.lvl/3));
function wageOf(role,sk,trait){ return Math.round(ROLES[role].base*(.6+.12*sk)*TRAITS[trait].wage/5)*5; }
function newCand(role,forceTrait){
  const T=team(); const sk=1+Math.floor(Math.random()*Math.random()*8)+(Math.random()<.25?1:0), tr=forceTrait||Object.keys(TRAITS)[Math.floor(Math.random()*6)], skc=Math.min(10,sk+(S.lvl>8?1:0));
  const nm=NAMES[Math.floor(Math.random()*NAMES.length)]+' '+SURN[Math.floor(Math.random()*SURN.length)];
  return {id:'e'+(++T.seq)+Date.now().toString(36),nom:nm,role,sk:skc,end:2+Math.floor(Math.random()*8),tr,wage:wageOf(role,skc,tr),en:100,lo:30,rest:0,hiredT:0,out:0,col:Math.floor(Math.random()*360),sk2:Math.floor(Math.random()*5),msg:''};
}
function refreshCands(force){
  const T=team(), F=S.farm, can=r=>r!=='gard'||(F&&F.found);
  if(!force&&T.cand.length&&Date.now()-T.candT<15*60000) return;
  const roles=Object.keys(ROLES).filter(can), out=[];
  if(!T.hired.some(e=>e.role==='gard')&&can('gard')&&!T.firstG){ const g=newCand('gard','des'); g.nom='Gaspard Lambert'; g.sk=3; g.end=4; g.wage=wageOf('gard',3,'des'); g.lo=25; out.push(g); }
  while(out.length<3){ const r=roles[Math.floor(Math.random()*roles.length)]; if(out.some(c=>c.role===r)&&roles.length>3) continue; out.push(newCand(r)); }
  T.cand=out; T.candT=Date.now();
}
function empEff(e){ const tr=TRAITS[e.tr]; let m=(.5+.1*e.sk)*tr.eff*(1+.25*e.lo/100); const ef=e.en>25?1:(.5+.02*e.en); m*=ef; if(e.tr==='des'&&S.cr<3000) m*=1.25; return m; }
function empTick(){
  const T=team(); if(!T.hired.length){ T.last=Date.now(); return; }
  const now=Date.now(); let dt=Math.min((now-T.last)/60000,360); T.last=now; if(dt<=0.01){ return; }
  let left=dt;
  while(left>1e-4){ const d=Math.min(left,5); left-=d;
    T.hired.forEach(e=>{
      const wage=e.wage*d/60; 
      if(e.rest>0){ e.rest=Math.max(0,e.rest-d); e.en=Math.min(100,e.en+14*d); e.lo=Math.min(100,e.lo+.5*d); S.cr=Math.max(0,S.cr-wage); return; }
      if(S.cr<wage){ e.lo=Math.max(0,e.lo-.8*d); e.msg='unpaid'; return; }
      S.cr-=wage; e.paid=(e.paid||0)+wage; e.lo=Math.min(100,e.lo+.12*d);
      const tr=TRAITS[e.tr]; e.en=Math.max(0,e.en-(1.3*tr.drain*3/(2+e.end*.6))*d); const eff=empEff(e); let did=0;
      try{
        if(e.role==='mech'){ const lows=S.cars.filter(c=>c.etat<100).sort((a,b)=>a.etat-b.etat); let pts=2.5*eff*d; for(const c of lows){ if(pts<=0) break; const up=Math.min(100-c.etat,pts); c.etat=Math.min(100,Math.round((c.etat+up)*10)/10); pts-=up; did+=up; } }
        else if(e.role==='gard'){ did=empGard(eff,d); }
        else if(e.role==='pil'){ const cr=Math.round(12*eff*d*(1+S.lvl*.03)); S.cr+=cr; addXP(Math.max(0,Math.round(1.4*eff*d))); did=cr; }
        else if(e.role==='ven'){ did=empSell(eff,d,e.sk); }
        else if(e.role==='guard'){ const F=S.farm; if(F&&F.heat){ ['atelier','ranch'].forEach(r=>{ const h=F.heat[r]||0, dn=Math.min(h,.6*eff*d); F.heat[r]=h-dn; did+=dn; }); } }
      }catch(err){ console.error(err); }
      e.out=(e.out||0)+did; T.tot[e.role]=(T.tot[e.role]||0)+did; e.msg=e.en<25?'tired':''; });
  }
  save();
}
function empGard(eff,d){ const F=S.farm; if(!F||!F.found) return 0; ranchSim(); let did=0, cap=Math.max(1,Math.floor(4*eff*d)), harv=Math.max(1,Math.floor(2*eff*d));
  const t0=toast; toast=()=>{}; try{
    for(const room in ROOMS){ const R=F.rooms[room]; if(!R||!R.on) continue; R.slots.forEach((sl,i)=>{ if(!sl) return;
      if(sl.pest&&cap>0){ const k=sl.pest==='mold'?'FONG':'INSEC'; if((F.chem[k]||0)>0){ F.chem[k]--; sl.pest=null; cap--; did++; } }
      if((sl.st==='germ'||sl.st==='veg'||sl.st==='flo')&&sl.w<42&&cap>0&&F.water>=3){ sl.w=Math.min(88,sl.w+30); F.water-=3; cap--; did++; }
      if(sl.st==='ready'&&harv>0){ const keep=RY.tab; RY.tab=room; _rh0({id:String(i)}); RY.tab=keep; harv--; did++; } }); }
  }finally{ toast=t0; } return did; }
function empSell(eff,d,sk){ const F=S.farm; if(!F||!F.found) return 0; let g=3*eff*d, gain=0; for(const k in F.stock){ if(g<=0) break; const s=F.stock[k]; if(!s||s.g<1) continue; const n=Math.floor(Math.min(s.g,g)); if(n<1) continue; const v=Math.round(n*sellPrice(k,s.q)*(1+.02*sk)); s.g-=n; g-=n; S.cr+=v; gain+=v; F.stats.sold+=n; F.rep+=n*.02; karmaAdd(-n*.02); F.heat.atelier=Math.min(100,F.heat.atelier+n*.05); F.heat.ranch=Math.min(100,F.heat.ranch+n*.05); } return gain; }
/* avatar */
function faceSVG(e,s){ s=s||46; const hue=e.col, skin=['#f2c6a0','#d9a273','#b57a4e','#8a5a3a','#e8b890'][e.sk2%5], hair=`hsl(${hue},45%,${e.role==='gard'?30:22}%)`, mood=e.en<25||e.lo<20?-1:e.lo>65?1:0;
  const mouth=mood>0?'M17 29q6 5 12 0':mood<0?'M17 31q6-4 12 0':'M18 30h10';
  return `<svg viewBox="0 0 46 46" width="${s}" height="${s}" class="fav" aria-hidden="true"><circle cx="23" cy="23" r="22" fill="hsl(${hue},40%,22%)"/><path d="M9 46c1-9 7-12 14-12s13 3 14 12z" fill="hsl(${hue},55%,45%)"/><circle cx="23" cy="21" r="10" fill="${skin}"/><path d="M12.5 19c0-8 5-11 10.500-11s10.500 3 10.500 11c-3-4-7-5-10.500-5s-7.500 1-10.500 5z" fill="${hair}"/><circle cx="19.200" cy="22" r="1.200" fill="#222"/><circle cx="26.800" cy="22" r="1.200" fill="#222"/><path d="${mouth}" stroke="#7a3a2a" stroke-width="1.300" fill="none" stroke-linecap="round"/>${e.tr==='des'?'<path d="M16.500 17.500l4-1.200M29.500 17.500l-4-1.200" stroke="#3a2a1a" stroke-width="1.100" stroke-linecap="round"/>':''}${e.en<25?'<path d="M31 13l2 3" stroke="#6ab0ff" stroke-width="1.500" stroke-linecap="round"/>':''}</svg>`; }
function quoteOf(e){ const hi=e.lo>=70; let pool; if(e.msg==='tired') pool=QUOTES.tired; else if(e.msg==='unpaid') pool=QUOTES.unpaid; else if(e.tr==='des') pool=hi?QUOTES.desHi:QUOTES.des; else pool=hi?QUOTES.genHi:QUOTES.gen; let h=0; const s=e.id+Math.floor(Date.now()/90000); for(let i=0;i<s.length;i++) h=(h*31+s.charCodeAt(i))|0; return pool[Math.abs(h)%pool.length]; }
const sb=(l,v,c,t)=>`<div class="stb"><span>${l}</span><div><i style="width:${Math.round(Math.max(0,Math.min(100,v)))}%;background:${c}"></i></div><b>${t}</b></div>`;
function empRow(e,mode){ const R=ROLES[e.role], T=TRAITS[e.tr];
  const stats=sb('Compétence',e.sk*10,'#3CFF9E',e.sk+'/10')+sb('Endurance',e.end*10,'#00E5FF',e.end+'/10')+(mode==='hire'?'':sb('Énergie',e.en,e.en<25?'#ff6a3d':'#FCEE0A',Math.round(e.en)+' %')+sb('Loyauté',e.lo,'#ff2bd6',Math.round(e.lo)+' %'));
  const head=`<div class="eh">${faceSVG(e,48)}<div class="ei"><b>${e.nom}</b><span class="chip">${R.ic} ${R.n}</span><small class="et">${T.n} · ${T.d}</small></div><div class="ew"><b>${fmt(e.wage)}</b><small>cr / h</small></div></div>`;
  if(mode==='hire'){ const T0=team(), full=T0.hired.length>=teamCap(), fee=e.wage*3;
    return `<div class="emp">${head}${stats}<small class="hint">${R.d}</small><button class="btn wide" data-a="ehire" data-id="${e.id}" ${full||S.cr<fee?'disabled':''}>Embaucher · ${fmt(fee)} cr${full?' (équipe pleine)':''}</button></div>`; }
  const raise=Math.round(e.wage*.1/5)*5||5;
  return `<div class="emp">${head}${stats}<p class="eq">« ${quoteOf(e)} »</p><small class="hint">${e.rest>0?`😴 En repos encore ${Math.ceil(e.rest)} min`:R.d} · Total : ${fmt(Math.round(e.out||0))} ${R.unit}</small>
   <div class="eb"><button data-a="erest" data-id="${e.id}" ${e.rest>0?'disabled':''}>😴 Repos 10 min</button><button data-a="eraise" data-id="${e.id}" ${S.cr<raise*10?'disabled':''}>💶 Augmentation +${raise} cr/h</button><button class="bad" data-a="efire" data-id="${e.id}">Licencier</button></div></div>`; }
function equipSheet(X){
  if(!sheet||sheet.t!=='equipe') return false; const T=team(); refreshCands(); empTick();
  const tot=T.hired.reduce((a,e)=>a+e.wage,0);
  $('sheet').innerHTML=`<div class="inv equipe">${X}<h2>👥 Équipe</h2><p class="note">${T.hired.length} / ${teamCap()} employé${T.hired.length>1?'s':''} · salaires ${fmt(tot)} cr / h. Ils travaillent même quand tu ne joues pas (jusqu’à 6 h). Plus tu les traites bien, plus ils s’attachent et rendent.</p>
  ${T.hired.length?T.hired.map(e=>empRow(e,'team')).join(''):'<p class="note">Personne pour l’instant. Recrute ci-dessous.</p>'}
  <h3 class="rh">Candidats <small>(renouvelés toutes les 15 min)</small></h3>${T.cand.map(c=>empRow(c,'hire')).join('')}
  ${T.hired.length<teamCap()?'':`<p class="note">Équipe pleine. Une place de plus tous les 3 niveaux (max 6).</p>`}
  <button class="btn alt wide" data-a="ecand">🔄 Nouveaux candidats · ${fmt(300)} cr</button></div>`;
  return true;
}
Object.assign(ACT,{
 equipe(){ openSheet({t:'equipe'}); },
 ehire(d){ const T=team(), c=T.cand.find(x=>x.id===d.id); if(!c||T.hired.length>=teamCap()) return; const fee=c.wage*3; if(S.cr<fee) return toast('Pas assez de crédits'); S.cr-=fee; T.cand=T.cand.filter(x=>x!==c); c.hiredT=Date.now(); if(c.nom==='Gaspard Lambert') T.firstG=1; T.hired.push(c); T.last=Date.now(); auTry(()=>ui('buy')); toast(`${c.nom} rejoint l’équipe`); save(); renderSheet(); },
 efire(d){ const T=team(), e=T.hired.find(x=>x.id===d.id); if(!e) return; if(!e.cf||Date.now()-e.cf>4000){ e.cf=Date.now(); return toast(`Touche encore pour licencier ${e.nom}`); } T.hired=T.hired.filter(x=>x!==e); save(); renderSheet(); },
 erest(d){ const e=team().hired.find(x=>x.id===d.id); if(!e) return; e.rest=10; auTry(()=>ui('open')); toast(`${e.nom} se repose`); save(); renderSheet(); },
 eraise(d){ const e=team().hired.find(x=>x.id===d.id); if(!e) return; const r=Math.round(e.wage*.1/5)*5||5; if(S.cr<r*10) return toast('Pas assez de crédits'); S.cr-=r*10; e.wage+=r; e.lo=Math.min(100,e.lo+12); auTry(()=>ui('coins')); toast(`${e.nom} : « Merci, chef. »`); save(); renderSheet(); },
 ecand(){ if(S.cr<300) return toast('Pas assez de crédits'); S.cr-=300; refreshCands(true); save(); renderSheet(); }
});
setInterval(()=>{ try{ if(S&&S.team&&S.team.hired&&S.team.hired.length){ empTick(); if(sheet&&sheet.t==='equipe'&&!document.querySelector('#sheet :focus')){ const sc=$('sheet').scrollTop; renderSheet(); $('sheet').scrollTop=sc; } } }catch(_){} },20000);
document.addEventListener('visibilitychange',()=>{ try{ if(!document.hidden) empTick(); }catch(_){} });
/* carte dans la Base + objectif */
function teamCardH(){ const T=team(), n=T.hired.length; return `<button class="row teamcard" data-a="equipe"><span class="ico">👥</span><span class="grow"><span class="ttl">Équipe</span><br><span class="sub">${n?`${n} employé${n>1?'s':''} au travail · ${fmt(T.hired.reduce((a,e)=>a+e.wage,0))} cr/h de salaires`:'Embauche mécano, jardinier, pilote, vendeur ou gardien'}</span></span><span class="gain">${n?'Gérer':'Recruter'} ›</span></button>`; }
const _vBase21=vBase; vBase=function(){ return _vBase21(); };
const _goal4=goalNext;
goalNext=function(){ const r=_goal4(); if(r) return r; if(S.lvl>=3&&!team().hired.length&&(S.stats&&S.stats.races>=2)) return ['👥','Engage ton premier employé : il travaille même quand tu n’es pas là','equipe','Recruter']; return null; };
const _tab22=ACT.tab; 
/* finitions : retour haptique léger sur tous les boutons d'action */
document.addEventListener('pointerdown',e=>{ const b=e.target.closest&&e.target.closest('[data-a]'); if(b&&!b.disabled){ try{ navigator.vibrate&&navigator.vibrate(6); }catch(_){} } },true);
const _eq0=ACT.equipe; ACT.equipe=function(){ try{ auTry(()=>ui('open')); }catch(_){} return _eq0.apply(this,arguments); };
/* ===== son : la sono du monde coupe l'ambiance des menus ===== */
let AMBM=false;
const _aav=auApplyVol;
auApplyVol=function(){ _aav.apply(this,arguments); if(AMBM&&AU&&AU.ok){ const t=AU.ctx.currentTime; try{ AU.mus.gain.setTargetAtTime(.0001,t,.05); AU.b.amb.gain.setTargetAtTime(.0001,t,.05); AU.revIn.gain.setTargetAtTime(.0001,t,.05); }catch(_){} } };
function ambMute(on){ AMBM=on; if(!AU||!AU.ok) return; try{ if(on){ auHum(false); auApplyVol(); } else { auApplyVol(); try{ AU.revIn.gain.setTargetAtTime(.5,AU.ctx.currentTime,.2); }catch(_){} auView(view,true); } }catch(e){ console.error(e); } }
const _ms21=musicStart; musicStart=function(){ _ms21.apply(this,arguments); if(WM.on) ambMute(true); };
const _mst21=musicStop; musicStop=function(){ const was=WM.on; _mst21.apply(this,arguments); if(was||AMBM) ambMute(false); };
/* ===== v0.43 : SALLE D'ARCADE — pinball + mini-jeux, tickets, comptoir de prix, map 3D ===== */
const ARC={
 pin:{n:'Pinball High & Rouillé',ic:'🎰',cost:100,cap:100,col:0xff2bd6,tk:s=>s/600,d:'3 billes. Maintiens LANCER pour armer le plongeur, puis flippers gauche / droite. Allume les 3 cibles pour monter le multiplicateur.'},
 drift:{n:'Reflex Drift',ic:'🚗',cost:40,col:0x00e5ff,tk:s=>s/45,d:'Touche la moitié gauche ou droite de l’écran pour changer de voie. Évite les obstacles, attrape les éclairs.'},
 drag:{n:'Drag Start',ic:'🏁',cost:40,col:0xffd400,tk:s=>s/60,d:'Démarre pile au vert (pas avant !), puis passe 3 vitesses en tapant quand l’aiguille est dans la zone verte.'},
 pit:{n:'Pit Stop Express',ic:'🔧',cost:40,col:0x3cff9e,tk:s=>s/80,d:'Touche vite la roue qui s’allume. Enchaîne sans faute pour un bonus de combo.'},
 nitro:{n:'Pousse-Nitro',ic:'⚡',cost:40,col:0xff9a1a,tk:s=>s/45,d:'Stoppe le curseur dans la zone verte. Elle rétrécit et le curseur accélère à chaque manche.'}
};
const ARCR={pin:[['Nakai',16800],['Vega',10400],['Quill',6900],['Ibarra',3800],['Brandt',1500]],drift:[['Dumas',620],['Okoye',480],['Vega',350],['Brandt',220],['Lindqvist',120]],drag:[['Quill',980],['Nakai',860],['Ibarra',700],['Okoye',540],['Dumas',380]],pit:[['Vega',1500],['Dumas',1200],['Okoye',950],['Nakai',700],['Brandt',450]],nitro:[['Okoye',760],['Quill',640],['Vega',520],['Ibarra',380],['Dumas',240]]};
function arcS(){ return S.arc||(S.arc={tk:0,best:{},plays:0,trophy:0}); }
function arcTone(f,d,type,v){ try{ if(!AU||!AU.ok) return; const c=AU.ctx, t=c.currentTime, o=c.createOscillator(), g=c.createGain(); o.type=type||'square'; o.frequency.setValueAtTime(f,t); g.gain.setValueAtTime(v||.07,t); g.gain.exponentialRampToValueAtTime(.0005,t+d); o.connect(g); g.connect(AU.b.ui); o.start(t); o.stop(t+d+.02); }catch(_){} }
let AOV=null;
function arcRot(on){ try{ if(on){ if(view==='hub'&&document.body.classList.contains('hubmode')&&!HUB.rot){ HUB.rot=true; document.body.classList.add('menuport'); rotNow(false); } } else { if(HUB.rot&&!sheet){ HUB.rot=false; document.body.classList.remove('menuport'); if(view==='hub') rotNow(true); } } }catch(_){} }
const ARC_LV={nitro:3,pit:4,drag:5,drift:6,pin:7};
function arcOpen(id){
  if(AOV||!ARC[id]) return; if(S.lvl<(ARC_LV[id]||0)) return toast('🔒 '+ARC[id].n+' : niveau '+ARC_LV[id]+' requis'); const G=ARC[id]; arcRot(true);
  const o=document.createElement('div'); o.id='arcov'; o.innerHTML=`<div class="arc-top"><div class="arc-t"><b>${G.ic} ${G.n}</b><small>Record : <span id="arcbest">${fmt(arcS().best[id]||0)}</span> · 🎟️ <span id="arctk">${fmt(arcS().tk)}</span></small></div><div class="arc-sc" id="arcsc">0</div><button class="arc-x" data-a="arcquit" aria-label="Quitter">✕</button></div><div class="arc-st" id="arcst"></div><div class="arc-bar" id="arcbar"></div>`;
  document.body.appendChild(o); AOV={id,el:o,stop:null,over:false}; arcIntro(id);
}
function arcIntro(id){ const G=ARC[id], st=document.getElementById('arcst'), bar=document.getElementById('arcbar'); st.innerHTML=''; bar.innerHTML=''; const sc=document.getElementById('arcsc'); sc.textContent='0';
  const c=document.createElement('div'); c.className='arc-card'; c.innerHTML=`<div class="arc-big">${G.ic}</div><h3>${G.n}</h3><p>${G.d}</p><button class="btn wide" data-a="arcstart">▶ Jouer · ${G.cost} cr</button><button class="btn alt wide" data-a="arcquit">Retour</button>`; st.appendChild(c); }
function arcStart(){ if(!AOV) return; const id=AOV.id, G=ARC[id]; if(S.cr<G.cost) return toast('Pas assez de crédits'); S.cr-=G.cost; save(); render&&0;
  const st=document.getElementById('arcst'), bar=document.getElementById('arcbar'); st.innerHTML=''; bar.innerHTML=''; AOV.over=false;
  const api={st,bar,score:(n,t)=>{ const e=document.getElementById('arcsc'); if(e) e.innerHTML=fmt(Math.round(n))+(t?`<small>${t}</small>`:''); },end:(score,note)=>arcEnd(score,note)};
  try{ AOV.stop=GAMES[id](api)||null; }catch(e){ console.error(e); } }
function arcEnd(score,note){ if(!AOV||AOV.over) return; AOV.over=true; const id=AOV.id, G=ARC[id], A=arcS(); score=Math.max(0,Math.round(score)); if(AOV.stop){ try{ AOV.stop(); }catch(_){} AOV.stop=null; }
  const prev=A.best[id]||0, rec=score>prev; if(rec) A.best[id]=score; const tk=Math.max(0,Math.min(G.cap||60,Math.round(G.tk(score)))); A.tk+=tk; A.plays++; if(tk>0) addXP(Math.ceil(tk/4)); save();
  const riv=ARCR[id], rank=1+riv.filter(r=>r[1]>(A.best[id]||0)).length; const st=document.getElementById('arcst'), bar=document.getElementById('arcbar'); bar.innerHTML='';
  const dim=document.createElement('div'); dim.className='arc-dim'; st.appendChild(dim);
  const c=document.createElement('div'); c.className='arc-card res'; c.innerHTML=`<div class="arc-big">${rec&&score>0?'🏆':G.ic}</div><h3>${rec&&score>0?'Nouveau record !':'Partie terminée'}</h3><div class="arc-fin">${fmt(score)}</div>${note?`<p>${note}</p>`:''}<div class="arc-tk">🎟️ +${tk} ticket${tk>1?'s':''} <small>(total ${fmt(A.tk)})</small></div><p class="sm">Classement : <b>#${rank}</b> sur 6 · record ${fmt(A.best[id]||0)}</p><button class="btn wide" data-a="arcstart">↻ Rejouer · ${G.cost} cr</button><button class="btn alt wide" data-a="arcquit">Quitter</button>`;
  st.appendChild(c); const b=document.getElementById('arcbest'); if(b) b.textContent=fmt(A.best[id]||0); const tt=document.getElementById('arctk'); if(tt) tt.textContent=fmt(A.tk); auTry(()=>ui(tk>0?'coins':'close')); if(rec&&score>0) auTry(()=>ui('up')); }
function arcQuit(){ if(!AOV) return; try{ AOV.stop&&AOV.stop(); }catch(_){} AOV.el.remove(); AOV=null; arcRot(false); try{ renderSheet&&sheet&&sheet.t==='arcprix'&&renderSheet(); }catch(_){} }
const GAMES={};
/* ============ PINBALL ============ */
GAMES.pin=function(api){
  const st=api.st, bar=api.bar, W=360,H=600,R=6.5, G=640;
  const cv=document.createElement('canvas'); cv.className='arccv'; st.appendChild(cv); const ctx=cv.getContext('2d'); let K=1;
  const fit=()=>{ const r=st.getBoundingClientRect(), s=Math.min(r.width/W,r.height/H)||1, dpr=Math.min(2,window.devicePixelRatio||1); cv.style.width=(W*s)+'px'; cv.style.height=(H*s)+'px'; cv.width=Math.round(W*s*dpr); cv.height=Math.round(H*s*dpr); K=s*dpr; };
  bar.innerHTML=`<div class="pinctl"><button id="pL" class="arcb">◀</button><button id="pP" class="arcb pl">LANCER<small>maintiens</small></button><button id="pR" class="arcb">▶</button></div>`;
  fit(); const ro=window.ResizeObserver?new ResizeObserver(fit):null; if(ro) ro.observe(st);
  const segs=[]; const sg=(x1,y1,x2,y2,e,k)=>segs.push({x1,y1,x2,y2,e:e||.5,k:k||0});
  { const cx=180,cy=170,ar=168; let px=12,py=170; for(let i=1;i<=18;i++){ const a=Math.PI+i/18*Math.PI, x=cx+ar*Math.cos(a), y=cy+ar*Math.sin(a); sg(px,py,x,y,.4); px=x; py=y; } }
  sg(12,170,12,455); sg(348,170,348,594); sg(318,594,348,594); sg(318,215,318,594); sg(12,455,94,540,.3); sg(318,455,226,540,.3);
  const slL={x1:50,y1:392,x2:98,y2:462}, slR={x1:268,y1:392,x2:222,y2:462}; [slL,slR].forEach(s=>{ s.e=1.05; s.k=360; s.hit=0; segs.push(s); });
  const bumps=[{x:128,y:172,r:17,hit:0},{x:222,y:172,r:17,hit:0},{x:175,y:240,r:17,hit:0}]; const posts=[{x:150,y:330,r:6},{x:208,y:330,r:6},{x:70,y:300,r:6},{x:290,y:300,r:6}];
  const tgt=[{x:46,y:250,r:8,on:0},{x:46,y:290,r:8,on:0},{x:46,y:330,r:8,on:0}]; const lanes=[{x:132,y:64,on:0},{x:180,y:54,on:0},{x:228,y:64,on:0}];
  const FL=[{px:98,py:545,L:56,s:1,th:.6,rest:.6,act:-.52,w:0,on:false},{px:222,py:545,L:56,s:-1,th:.6,rest:.6,act:-.52,w:0,on:false}];
  const tip=f=>[f.px+f.s*f.L*Math.cos(f.th), f.py+f.L*Math.sin(f.th)];
  const B={x:333,y:572,vx:0,vy:0,st:'plunger',trail:[]}; let stuck=0, score=0, ball=1, mult=1, power=0, charging=false, save=0, usedSave=false, msg='', msgT=0, over=false, t=0, tilt=0; const N=3;
  const say=(m)=>{ msg=m; msgT=1.4; };
  const add=n=>{ score+=n*mult; api.score(score,`Bille ${Math.min(ball,N)}/${N} · ×${mult}`); };
  const hud=()=>api.score(score,`Bille ${Math.min(ball,N)}/${N} · ×${mult}`); hud();
  const reset=()=>{ B.x=333; B.y=572; B.vx=B.vy=0; B.st='plunger'; B.trail.length=0; power=0; usedSave=false; };
  const launch=()=>{ if(B.st!=='plunger') return; B.vy=-(660+640*power); B.vx=-6; B.st='play'; save=7; arcTone(220+power*300,.18,'sawtooth',.08); power=0; };
  const closest=(x,y,a,b,c,d)=>{ const dx=c-a, dy=d-b, l2=dx*dx+dy*dy, tt=Math.max(0,Math.min(1,((x-a)*dx+(y-b)*dy)/(l2||1))); return [a+dx*tt,b+dy*tt,tt]; };
  const lose=()=>{ if(over) return; if(save>0&&!usedSave){ usedSave=true; say('BALL SAVE !'); reset(); arcTone(660,.2,'triangle'); return; } ball++; arcTone(120,.35,'sawtooth',.09); if(ball>N){ finish(); } else { reset(); say('BILLE '+ball); hud(); } };
  const finish=()=>{ if(over) return; over=true; setTimeout(()=>api.end(score,''),600); };
  function phys(h){
    if(over) return;
    FL.forEach(f=>{ const tg=f.on?f.act:f.rest, d=tg-f.th, sp=(f.on?22:12)*h, step=Math.abs(d)<sp?d:Math.sign(d)*sp; f.th+=step; f.w=step/h; });
    if(charging&&B.st==='plunger') power=Math.min(1,power+h*1.1);
    if(B.st!=='play') return; if(save>0) save-=h;
    B.vy+=G*h; B.x+=B.vx*h; B.y+=B.vy*h;
    const sp=Math.hypot(B.vx,B.vy); if(sp>1300){ B.vx*=1300/sp; B.vy*=1300/sp; }
    for(const s of segs){ const [cx,cy]=closest(B.x,B.y,s.x1,s.y1,s.x2,s.y2); let dx=B.x-cx, dy=B.y-cy, d=Math.hypot(dx,dy); if(d<R){ if(d<1e-4){ dx=0; dy=-1; d=1; } const nx=dx/d, ny=dy/d; B.x=cx+nx*R; B.y=cy+ny*R; const vn=B.vx*nx+B.vy*ny; if(vn<0){ B.vx-=(1+s.e)*vn*nx; B.vy-=(1+s.e)*vn*ny; if(s.k){ B.vx+=nx*s.k*.55; B.vy+=ny*s.k*.55; if(s.hit!==undefined){ s.hit=1; add(10); arcTone(520,.06,'square',.06); } } } } }
    for(const b of bumps){ const dx=B.x-b.x, dy=B.y-b.y, d=Math.hypot(dx,dy), m=R+b.r; if(d<m){ const nx=d?dx/d:0, ny=d?dy/d:-1; B.x=b.x+nx*m; B.y=b.y+ny*m; const vn=B.vx*nx+B.vy*ny; if(vn<0){ B.vx-=2*vn*nx; B.vy-=2*vn*ny; } const s2=Math.hypot(B.vx,B.vy), k=Math.max(s2,520); B.vx=B.vx/(s2||1)*k+nx*80; B.vy=B.vy/(s2||1)*k+ny*80; b.hit=1; add(100); arcTone(700+Math.random()*300,.09,'square',.08); } }
    for(const p of posts){ const dx=B.x-p.x, dy=B.y-p.y, d=Math.hypot(dx,dy), m=R+p.r; if(d<m){ const nx=d?dx/d:0, ny=d?dy/d:-1; B.x=p.x+nx*m; B.y=p.y+ny*m; const vn=B.vx*nx+B.vy*ny; if(vn<0){ B.vx-=1.7*vn*nx; B.vy-=1.7*vn*ny; add(5); } } }
    for(const g of tgt){ const dx=B.x-g.x, dy=B.y-g.y, d=Math.hypot(dx,dy), m=R+g.r; if(d<m){ const nx=d?dx/d:1, ny=d?dy/d:0; B.x=g.x+nx*m; B.y=g.y+ny*m; const vn=B.vx*nx+B.vy*ny; if(vn<0){ B.vx-=1.5*vn*nx; B.vy-=1.5*vn*ny; } if(!g.on){ g.on=1; add(50); arcTone(880,.07,'triangle',.08); if(tgt.every(q=>q.on)){ tgt.forEach(q=>q.on=0); mult=Math.min(5,mult+1); add(500); say('MULTI ×'+mult+' !'); arcTone(1320,.25,'triangle',.1); } } } }
    for(const l of lanes){ if(!l.on&&Math.hypot(B.x-l.x,B.y-l.y)<11){ l.on=1; add(30); arcTone(990,.05,'sine',.07); if(lanes.every(q=>q.on)){ lanes.forEach(q=>q.on=0); add(300); say('BONUS +300'); arcTone(1480,.2,'triangle',.09); } } }
    for(let i=0;i<2;i++){ const f=FL[i], [tx,ty]=tip(f); const [cx,cy,tt]=closest(B.x,B.y,f.px,f.py,tx,ty); let dx=B.x-cx, dy=B.y-cy, d=Math.hypot(dx,dy); const m=R+6; if(d<m){ if(d<1e-4){ dx=0; dy=-1; d=1; } const nx=dx/d, ny=dy/d, s=tt*f.L; const vx=f.s*s*f.w*(-Math.sin(f.th))*f.s*f.s*(f.s>0?1:-1)*(f.s>0?1:1), cvx=(f.s>0?-Math.sin(f.th):Math.sin(f.th))*s*f.w, cvy=Math.cos(f.th)*s*f.w; B.x=cx+nx*m; B.y=cy+ny*m; const rel=(B.vx-cvx)*nx+(B.vy-cvy)*ny; if(rel<0){ B.vx-=(1.32)*rel*nx; B.vy-=(1.32)*rel*ny; } } }
    if(B.x>319&&B.y>560&&B.vy>=0&&Math.hypot(B.vx,B.vy)<400){ B.x=333; B.y=572; B.vx=B.vy=0; B.st='plunger'; power=0; return; }
    if(B.y>H+24) lose();
    else if(B.x<-20||B.x>W+20||B.y<-30){ reset(); }
    if(Math.hypot(B.vx,B.vy)<14&&B.y<620){ stuck+=h; if(stuck>2.2){ B.vx=(Math.random()<.5?-1:1)*140; B.vy=-180; stuck=0; } } else stuck=0;
    B.trail.push([B.x,B.y]); if(B.trail.length>7) B.trail.shift();
  }
  const draw=()=>{ ctx.setTransform(K,0,0,K,0,0); const gr=ctx.createLinearGradient(0,0,0,H); gr.addColorStop(0,'#0c0620'); gr.addColorStop(1,'#1a0a2e'); ctx.fillStyle=gr; ctx.fillRect(0,0,W,H);
    ctx.strokeStyle='rgba(120,90,255,.12)'; ctx.lineWidth=1; for(let x=0;x<W;x+=30){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); } for(let y=0;y<H;y+=30){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }
    ctx.fillStyle='rgba(255,212,0,.07)'; ctx.font='900 54px system-ui,sans-serif'; ctx.textAlign='center'; ctx.fillText('HIGH',180,330); ctx.fillText('& ROUILLÉ',180,384);
    ctx.lineCap='round'; ctx.lineJoin='round'; ctx.shadowBlur=10; ctx.shadowColor='#00e5ff'; ctx.strokeStyle='#00e5ff'; ctx.lineWidth=4; segs.forEach(s=>{ if(s.k) return; ctx.beginPath(); ctx.moveTo(s.x1,s.y1); ctx.lineTo(s.x2,s.y2); ctx.stroke(); });
    ctx.shadowColor='#ff2bd6'; ctx.strokeStyle='#ff2bd6'; ctx.lineWidth=6; [slL,slR].forEach(s=>{ ctx.globalAlpha=.6+.4*s.hit; ctx.beginPath(); ctx.moveTo(s.x1,s.y1); ctx.lineTo(s.x2,s.y2); ctx.stroke(); s.hit=Math.max(0,s.hit-.12); }); ctx.globalAlpha=1;
    bumps.forEach((b,i)=>{ const c=['#ffd400','#1fe06a','#ff2d2d'][i]; ctx.shadowColor=c; ctx.shadowBlur=14+b.hit*16; ctx.fillStyle='#14082a'; ctx.beginPath(); ctx.arc(b.x,b.y,b.r,0,7); ctx.fill(); ctx.strokeStyle=c; ctx.lineWidth=4; ctx.stroke(); ctx.fillStyle=c; ctx.globalAlpha=.35+.65*b.hit; ctx.beginPath(); ctx.arc(b.x,b.y,b.r-6,0,7); ctx.fill(); ctx.globalAlpha=1; b.hit=Math.max(0,b.hit-.08); });
    ctx.shadowBlur=0; posts.forEach(p=>{ ctx.fillStyle='#cfd6ff'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,7); ctx.fill(); });
    tgt.forEach(g=>{ ctx.shadowColor='#3cff9e'; ctx.shadowBlur=g.on?14:0; ctx.fillStyle=g.on?'#3cff9e':'#1a3a2c'; ctx.beginPath(); ctx.arc(g.x,g.y,g.r,0,7); ctx.fill(); ctx.strokeStyle='#3cff9e'; ctx.lineWidth=2; ctx.stroke(); });
    lanes.forEach(l=>{ ctx.shadowColor='#ffd400'; ctx.shadowBlur=l.on?12:0; ctx.fillStyle=l.on?'#ffd400':'#3a3210'; ctx.beginPath(); ctx.arc(l.x,l.y,7,0,7); ctx.fill(); });
    ctx.shadowBlur=0; ctx.fillStyle='#2a1a4a'; ctx.fillRect(320,596-70*(1-power*.55)+0,26,4); ctx.fillStyle='#ffd400'; ctx.fillRect(330,568+power*22,6,30); ctx.fillStyle=`rgba(255,43,214,${.3+power*.7})`; ctx.fillRect(322,598,22,4);
    FL.forEach(f=>{ const [tx,ty]=tip(f); ctx.shadowColor='#ffd400'; ctx.shadowBlur=f.on?16:6; const g=ctx.createLinearGradient(f.px,f.py,tx,ty); g.addColorStop(0,'#ff2d2d'); g.addColorStop(.5,'#ffd400'); g.addColorStop(1,'#1fe06a'); ctx.strokeStyle=g; ctx.lineWidth=13; ctx.beginPath(); ctx.moveTo(f.px,f.py); ctx.lineTo(tx,ty); ctx.stroke(); ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(f.px,f.py,4,0,7); ctx.fill(); });
    B.trail.forEach((p,i)=>{ ctx.globalAlpha=i/B.trail.length*.35; ctx.fillStyle='#8fe9ff'; ctx.beginPath(); ctx.arc(p[0],p[1],R*(i/B.trail.length),0,7); ctx.fill(); }); ctx.globalAlpha=1;
    ctx.shadowColor='#8fe9ff'; ctx.shadowBlur=14; const rg=ctx.createRadialGradient(B.x-2,B.y-2,1,B.x,B.y,R); rg.addColorStop(0,'#fff'); rg.addColorStop(1,'#6ad6ff'); ctx.fillStyle=rg; ctx.beginPath(); ctx.arc(B.x,B.y,R,0,7); ctx.fill(); ctx.shadowBlur=0;
    if(save>0&&B.st==='play'){ ctx.fillStyle='rgba(255,212,0,.8)'; ctx.font='700 11px system-ui'; ctx.textAlign='center'; ctx.fillText('BALL SAVE',180,590); }
    if(msgT>0){ ctx.globalAlpha=Math.min(1,msgT*2); ctx.fillStyle='#fff'; ctx.shadowColor='#ff2bd6'; ctx.shadowBlur=18; ctx.font='900 26px system-ui,sans-serif'; ctx.textAlign='center'; ctx.fillText(msg,180,430); ctx.globalAlpha=1; ctx.shadowBlur=0; } };
  const sim=(sec)=>{ let left=sec; while(left>1e-6){ const d=Math.min(left,1/240); phys(d); left-=d; } if(msgT>0) msgT-=sec; };
  let raf=0, last=0; const loop=ts=>{ if(!last) last=ts; const dt=Math.min(.033,(ts-last)/1000); last=ts; if(!over) sim(dt); draw(); raf=requestAnimationFrame(loop); }; raf=requestAnimationFrame(loop);
  const hold=(id,fn)=>{ const e=bar.querySelector(id); const dn=ev=>{ ev.preventDefault(); fn(true); }, up=ev=>{ ev.preventDefault(); fn(false); }; e.addEventListener('pointerdown',dn); e.addEventListener('pointerup',up); e.addEventListener('pointerleave',up); e.addEventListener('pointercancel',up); };
  const fl=(i)=>on=>{ FL[i].on=on; if(on) arcTone(180,.05,'square',.05); };
  hold('#pL',fl(0)); hold('#pR',fl(1)); hold('#pP',on=>{ if(on){ charging=true; } else { charging=false; launch(); } });
  const kd=e=>{ if(e.repeat) return; if(e.code==='ArrowLeft'||e.code==='KeyA') fl(0)(true); if(e.code==='ArrowRight'||e.code==='KeyD') fl(1)(true); if(e.code==='Space'){ charging=true; e.preventDefault(); } };
  const ku=e=>{ if(e.code==='ArrowLeft'||e.code==='KeyA') fl(0)(false); if(e.code==='ArrowRight'||e.code==='KeyD') fl(1)(false); if(e.code==='Space'){ charging=false; launch(); } };
  document.addEventListener('keydown',kd); document.addEventListener('keyup',ku);
  window.__pin={sim,B,FL,get score(){return score;},get ball(){return ball;},get over(){return over;},launch:()=>{ power=.9; launch(); },flip:(i,on)=>{ FL[i].on=on; },segs,get st(){return B.st;},get mult(){return mult;}};
  return ()=>{ cancelAnimationFrame(raf); if(ro) ro.disconnect(); document.removeEventListener('keydown',kd); document.removeEventListener('keyup',ku); window.__pin=null; };
};
/* ============ REFLEX DRIFT ============ */
GAMES.drift=function(api){
  const st=api.st, W=360,H=600; const cv=document.createElement('canvas'); cv.className='arccv'; st.appendChild(cv); const ctx=cv.getContext('2d'); let K=1;
  const fit=()=>{ const r=st.getBoundingClientRect(), s=Math.min(r.width/W,r.height/H)||1, dpr=Math.min(2,window.devicePixelRatio||1); cv.style.width=(W*s)+'px'; cv.style.height=(H*s)+'px'; cv.width=Math.round(W*s*dpr); cv.height=Math.round(H*s*dpr); K=s*dpr; }; fit(); const ro=window.ResizeObserver?new ResizeObserver(fit):null; if(ro) ro.observe(st);
  const LX=[90,180,270]; let lane=1, px=180, dist=0, pick=0, sp=260, obs=[], spawn=0, over=false, off=0, flash=0;
  const tap=e=>{ const r=cv.getBoundingClientRect(); const x=e.clientX-r.left; lane=Math.max(0,Math.min(2,lane+(x<r.width/2?-1:1))); arcTone(300+lane*60,.05,'square',.05); };
  st.addEventListener('pointerdown',tap);
  const kd=e=>{ if(e.code==='ArrowLeft') lane=Math.max(0,lane-1); if(e.code==='ArrowRight') lane=Math.min(2,lane+1); }; document.addEventListener('keydown',kd);
  const step=h=>{ if(over) return; sp=260+dist*.04; dist+=sp*h/10; off=(off+sp*h)%60; px+=(LX[lane]-px)*Math.min(1,h*14); spawn-=h; flash=Math.max(0,flash-h*3);
    if(spawn<=0){ spawn=Math.max(.32,.78-dist*.0004)*(.8+Math.random()*.5); const l=Math.floor(Math.random()*3), near=obs.filter(o=>o.y<130&&o.t!=='n').map(o=>o.l); if(!(near.length>=2&&!near.includes(l))){ const r=Math.random(); obs.push({l,y:-40,t:r<.14?'n':r<.5?'c':'k'}); } }
    obs.forEach(o=>o.y+=sp*h); obs=obs.filter(o=>o.y<H+50);
    for(const o of obs){ if(Math.abs(o.y-500)<34&&Math.abs(LX[o.l]-px)<34){ if(o.t==='n'){ pick++; o.y=9999; flash=1; arcTone(1200,.12,'triangle',.08); } else if(!o.done){ over=true; arcTone(110,.4,'sawtooth',.12); setTimeout(()=>api.end(dist+pick*50,`${Math.round(dist)} m · ${pick} éclair${pick>1?'s':''}`),500); } } }
    api.score(dist+pick*50,`${Math.round(dist)} m`); };
  const draw=()=>{ ctx.setTransform(K,0,0,K,0,0); ctx.fillStyle='#0b0b1c'; ctx.fillRect(0,0,W,H); ctx.fillStyle='#161a30'; ctx.fillRect(30,0,300,H); ctx.fillStyle='#ffd400'; ctx.fillRect(28,0,4,H); ctx.fillRect(328,0,4,H);
    ctx.fillStyle='rgba(255,255,255,.5)'; for(let y=-60+off;y<H;y+=60){ [135,225].forEach(x=>ctx.fillRect(x-2,y,4,28)); }
    obs.forEach(o=>{ const x=LX[o.l], y=o.y; if(o.t==='k'){ ctx.fillStyle='#ff6a1a'; ctx.beginPath(); ctx.moveTo(x,y-20); ctx.lineTo(x+16,y+16); ctx.lineTo(x-16,y+16); ctx.closePath(); ctx.fill(); ctx.fillStyle='#fff'; ctx.fillRect(x-9,y+2,18,4); } else if(o.t==='c'){ ctx.fillStyle='#e0354b'; ctx.fillRect(x-20,y-32,40,64); ctx.fillStyle='#10131f'; ctx.fillRect(x-14,y-18,28,16); ctx.fillStyle='#fff'; ctx.fillRect(x-16,y+28,8,4); ctx.fillRect(x+8,y+28,8,4); } else { ctx.shadowColor='#00e5ff'; ctx.shadowBlur=16; ctx.fillStyle='#00e5ff'; ctx.beginPath(); ctx.arc(x,y,15,0,7); ctx.fill(); ctx.shadowBlur=0; ctx.fillStyle='#04202a'; ctx.font='900 20px system-ui'; ctx.textAlign='center'; ctx.fillText('⚡',x,y+7); } });
    ctx.save(); ctx.translate(px,500); ctx.rotate((LX[lane]-px)/120); ctx.fillStyle=flash>0?'#00e5ff':'#ffd400'; ctx.shadowColor='#ffd400'; ctx.shadowBlur=12; ctx.fillRect(-20,-32,40,64); ctx.shadowBlur=0; ctx.fillStyle='#10131f'; ctx.fillRect(-14,-16,28,16); ctx.fillStyle='#e0354b'; ctx.fillRect(-18,-34,10,4); ctx.fillRect(8,-34,10,4); ctx.restore(); };
  let raf=0,last=0; const loop=ts=>{ if(!last) last=ts; const h=Math.min(.033,(ts-last)/1000); last=ts; step(h); draw(); raf=requestAnimationFrame(loop); }; raf=requestAnimationFrame(loop);
  window.__drift={step,get over(){return over;},tap:l=>{lane=l;}};
  return ()=>{ cancelAnimationFrame(raf); if(ro) ro.disconnect(); st.removeEventListener('pointerdown',tap); document.removeEventListener('keydown',kd); window.__drift=null; };
};
/* ============ DRAG START ============ */
GAMES.drag=function(api){
  const st=api.st; st.innerHTML=`<div class="drg"><div class="tree"><i></i><i></i><i></i><i class="g"></i></div><div class="drg-msg" id="dm">Prépare-toi…</div><div class="gau"><div class="zone"></div><div class="nd" id="dn"></div></div><div class="drg-g" id="dg">Vitesse 1</div><button class="arcb big" id="dt">TAP</button></div>`;
  const L=[...st.querySelectorAll('.tree i')], msg=st.querySelector('#dm'), nd=st.querySelector('#dn'), dg=st.querySelector('#dg'), btn=st.querySelector('#dt');
  let ph='wait', tids=[], t0=0, react=0, gear=0, shifts=[], p=0, raf=0, ended=false, tsec=0;
  const later=(f,ms)=>tids.push(setTimeout(f,ms));
  later(()=>{ ph='amber'; L[0].classList.add('on'); arcTone(500,.1,'square'); },700); later(()=>{ L[1].classList.add('on'); arcTone(500,.1,'square'); },1200); later(()=>{ L[2].classList.add('on'); arcTone(500,.1,'square'); },1700);
  later(()=>{ ph='go'; L[3].classList.add('on'); t0=performance.now(); msg.textContent='VERT ! TAPE !'; arcTone(1000,.25,'triangle',.1); },1700+500+Math.random()*900);
  const done=(sc,note)=>{ if(ended) return; ended=true; setTimeout(()=>api.end(sc,note),700); };
  const hit=()=>{
    if(ph==='wait'||ph==='amber'){ ph='dead'; msg.textContent='FAUX DÉPART !'; arcTone(120,.4,'sawtooth',.1); return done(0,'Faux départ : tu as bougé avant le vert.'); }
    if(ph==='go'){ react=Math.round(performance.now()-t0); ph='shift'; gear=1; msg.textContent=`Réaction : ${react} ms`; dg.textContent='Vitesse 1 → tape dans le vert'; arcTone(300,.12,'sawtooth'); tsec=0; return; }
    if(ph==='shift'){ const q=Math.max(0,1-Math.abs(p-.8)/.3), pts=Math.round(q*200); shifts.push(pts); arcTone(400+gear*200,.1,'square',.08); dg.textContent=pts>150?'Parfait !':pts>80?'Bien':'Raté…'; gear++; tsec=0; if(shifts.length>=3){ ph='fin'; const sc=Math.max(0,Math.round(600-react*1.4))+shifts.reduce((a,b)=>a+b,0); msg.textContent=`${react} ms · passages ${shifts.join(' / ')}`; done(sc,`Réaction ${react} ms · passages ${shifts.join(' / ')}`); } }
  };
  btn.addEventListener('pointerdown',e=>{ e.preventDefault(); hit(); }); st.addEventListener('pointerdown',e=>{ if(e.target===btn) return; hit(); });
  const kd=e=>{ if(e.code==='Space') hit(); }; document.addEventListener('keydown',kd);
  let last=0; const loop=ts=>{ if(!last) last=ts; const h=(ts-last)/1000; last=ts; if(ph==='shift'){ tsec+=h; const sp=1.25+gear*.35; p=Math.abs(((tsec*sp)%2)-1); nd.style.left=(p*100)+'%'; if(tsec>2.8){ shifts.push(0); gear++; tsec=0; dg.textContent='Trop tard…'; if(shifts.length>=3){ ph='fin'; const sc=Math.max(0,Math.round(600-react*1.4))+shifts.reduce((a,b)=>a+b,0); done(sc,`Réaction ${react} ms · passages ${shifts.join(' / ')}`); } } } raf=requestAnimationFrame(loop); }; raf=requestAnimationFrame(loop);
  window.__drag={hit,get ph(){return ph;},set p(v){p=v;},get shifts(){return shifts;}};
  return ()=>{ tids.forEach(clearTimeout); cancelAnimationFrame(raf); document.removeEventListener('keydown',kd); window.__drag=null; };
};
/* ============ PIT STOP ============ */
GAMES.pit=function(api){
  const st=api.st; st.innerHTML=`<div class="pit"><div class="pit-m" id="pm">Prépare-toi…</div><div class="pit-car"><div class="body"></div>${[0,1,2,3].map(i=>`<button class="whl w${i}" data-w="${i}" aria-label="Roue ${i+1}"><span></span></button>`).join('')}</div><div class="pit-i" id="pi">0 / 15</div></div>`;
  const W=[...st.querySelectorAll('.whl')], msg=st.querySelector('#pm'), inf=st.querySelector('#pi'); let n=0, cur=-1, score=0, combo=0, tid=0, t0=0, win=1200, ended=false, tids=[]; const TOT=15;
  const next=()=>{ if(n>=TOT){ if(!ended){ ended=true; setTimeout(()=>api.end(score,`${TOT} roues · meilleur combo ${bestC}`),400); } return; } let c; do{ c=Math.floor(Math.random()*4); }while(c===cur); cur=c; W.forEach((w,i)=>w.classList.toggle('on',i===c)); win=Math.max(550,1300-n*50); t0=performance.now(); tid=setTimeout(()=>miss(),win); msg.textContent=['Roue ','Vite : roue ','Allez : roue '][n%3]+(c+1); inf.textContent=`${n} / ${TOT} · combo ${combo}`; };
  let bestC=0; const miss=()=>{ combo=0; n++; W.forEach(w=>w.classList.remove('on')); msg.textContent='Raté !'; arcTone(140,.2,'sawtooth',.08); cur=-1; tids.push(setTimeout(next,260)); };
  const ok=()=>{ clearTimeout(tid); const el=performance.now()-t0, pts=Math.round((30+Math.max(0,1-el/win)*50)*(1+Math.min(.5,combo*.05))); score+=pts; combo++; bestC=Math.max(bestC,combo); n++; W.forEach(w=>w.classList.remove('on')); api.score(score,`combo ${combo}`); arcTone(700+combo*40,.08,'square',.07); msg.textContent=`+${pts}`; cur=-1; tids.push(setTimeout(next,220)); };
  W.forEach((w,i)=>w.addEventListener('pointerdown',e=>{ e.preventDefault(); if(cur<0||ended) return; if(i===cur) ok(); else { clearTimeout(tid); miss(); } }));
  tids.push(setTimeout(next,900)); window.__pit={get cur(){return cur;},hit:i=>{ if(cur<0) return; if(i===cur) ok(); else { clearTimeout(tid); miss(); } },get n(){return n;},get score(){return score;}};
  return ()=>{ clearTimeout(tid); tids.forEach(clearTimeout); ended=true; window.__pit=null; };
};
/* ============ POUSSE-NITRO ============ */
GAMES.nitro=function(api){
  const st=api.st; st.innerHTML=`<div class="nit"><div class="nit-m" id="nm">Manche 1 / 6</div><div class="nbar"><div class="nz" id="nz"></div><div class="nk" id="nk"></div></div><div class="nit-i" id="ni"></div><button class="arcb big" id="nt">STOP</button></div>`;
  const nz=st.querySelector('#nz'), nk=st.querySelector('#nk'), nm=st.querySelector('#nm'), ni=st.querySelector('#ni'), btn=st.querySelector('#nt'); const WD=[.26,.2,.15,.11,.08,.06]; let rd=0, score=0, streak=0, tsec=0, m=0, c=.5, active=true, raf=0, ended=false, tids=[];
  const setup=()=>{ c=.2+Math.random()*.6; nz.style.left=((c-WD[rd]/2)*100)+'%'; nz.style.width=(WD[rd]*100)+'%'; nm.textContent=`Manche ${rd+1} / 6`; tsec=Math.random()*2; active=true; };
  setup();
  const stop=()=>{ if(!active||ended) return; active=false; const d=Math.abs(m-c), half=WD[rd]/2; if(d<=half){ streak++; const pts=Math.round(100*(1-d/half*.6))+Math.min(50,streak*10); score+=pts; ni.textContent=`+${pts}${d<half*.2?' · PARFAIT':''}`; api.score(score,`série ${streak}`); arcTone(900+streak*80,.12,'triangle',.09); } else { streak=0; ni.textContent='Raté'; arcTone(140,.25,'sawtooth',.09); }
    rd++; if(rd>=6){ ended=true; tids.push(setTimeout(()=>api.end(score,'6 manches'),700)); } else tids.push(setTimeout(setup,700)); };
  btn.addEventListener('pointerdown',e=>{ e.preventDefault(); stop(); }); st.addEventListener('pointerdown',e=>{ if(e.target!==btn) stop(); }); const kd=e=>{ if(e.code==='Space') stop(); }; document.addEventListener('keydown',kd);
  let last=0; const loop=ts=>{ if(!last) last=ts; const h=(ts-last)/1000; last=ts; if(active){ tsec+=h; const sp=.9+rd*.38; m=Math.abs(((tsec*sp)%2)-1); nk.style.left=(m*100)+'%'; } raf=requestAnimationFrame(loop); }; raf=requestAnimationFrame(loop);
  window.__nit={stop,set m(v){m=v;},get c(){return c;},get rd(){return rd;},get score(){return score;},freeze:()=>{ tsec=1e9; }};
  return ()=>{ cancelAnimationFrame(raf); tids.forEach(clearTimeout); document.removeEventListener('keydown',kd); window.__nit=null; };
};
Object.assign(ACT,{ arc(d){ arcOpen(d.id); }, arcstart(){ arcStart(); }, arcquit(){ arcQuit(); } });
/* ============ COMPTOIR DE PRIX ============ */
const PRIZES=[
 {id:'nit',ic:'⚡',n:'Nitro ×2',d:'Deux charges de nitro',c:25,f:()=>{ S.nitro=(S.nitro||0)+2; }},
 {id:'cr1',ic:'💰',n:'500 crédits',d:'Un petit coup de pouce',c:30,f:()=>{ S.cr+=500; }},
 {id:'tok',ic:'🪙',n:'Jeton de paquet',d:'Un paquet de cartes à ouvrir',c:40,f:()=>{ S.tok=(S.tok||0)+1; }},
 {id:'cr2',ic:'💎',n:'3 000 crédits',d:'Beaucoup mieux qu’un porte-clés',c:150,f:()=>{ S.cr+=3000; }},
 {id:'tok5',ic:'🎴',n:'5 jetons de paquet',d:'Une pluie de cartes',c:170,f:()=>{ S.tok=(S.tok||0)+5; }},
 {id:'tro',ic:'🏆',n:'Trophée d’arcade',d:'Exemplaire unique, expose-le fièrement (+3 jetons)',c:300,once:1,f:()=>{ arcS().trophy=1; S.tok=(S.tok||0)+3; }}
];
function arcSheet(X){
  if(!sheet||sheet.t!=='arcprix') return false; const A=arcS();
  const lead=Object.keys(ARC).map(id=>{ const G=ARC[id], me=A.best[id]||0, all=ARCR[id].concat([['Toi',me]]).sort((a,b)=>b[1]-a[1]); const rank=all.findIndex(r=>r[0]==='Toi')+1; return `<div class="inv-r"><span class="inv-i">${G.ic}</span><div class="inv-t"><b>${G.n}</b><small>Record : ${fmt(me)} · rang #${rank}/6 · 1er : ${all[0][0]} (${fmt(all[0][1])})</small></div></div>`; }).join('');
  $('sheet').innerHTML=`<div class="inv">${X}<h2>🎟️ Comptoir de prix</h2><p class="note">Tu as <b>${fmt(A.tk)}</b> ticket${A.tk>1?'s':''}. Gagne-en en jouant aux bornes.</p>
   ${PRIZES.map(p=>{ const got=p.once&&A.trophy, can=A.tk>=p.c&&!got; return `<div class="inv-r ${can||got?'':'lock'}"><span class="inv-i">${p.ic}</span><div class="inv-t"><b>${p.n}</b><small>${got?'Déjà obtenu':p.d}</small></div><button class="btn sm" data-a="arcbuy" data-id="${p.id}" ${can?'':'disabled'}>${got?'✔':'🎟️ '+p.c}</button></div>`; }).join('')}
   <h3 class="rh">Classements</h3>${lead}</div>`; return true; }
ACT.arcbuy=d=>{ const p=PRIZES.find(x=>x.id===d.id), A=arcS(); if(!p||A.tk<p.c||(p.once&&A.trophy)) return; A.tk-=p.c; p.f(); save(); auTry(()=>ui('buy')); toast(`${p.ic} ${p.n} !`); renderSheet(); };
/* ============ MAP 3D : la salle d'arcade ============ */
WORLD.arcade={nom:'Salle d’arcade',ic:'🕹️',bx:36,bz:24,spawn:{x:0,z:19,yaw:0},lvl:2};
DEST.push({id:'arcade',ic:'🕹️',nom:'Salle d’arcade',d:'Pousse-nitro au début, puis pit stop, drag, drift et pinball au fil de tes niveaux. Gagne des tickets, échange-les au comptoir.',ok:()=>S.lvl>=3,why:'Niveau 3 requis'});
function buildArcade(W){
  const sc=W.sc, BX=W.bx, BZ=W.bz; sc.background=new THREE.Color(0x07040f); sc.fog=new THREE.Fog(0x07040f,34,120);
  sc.add(new THREE.HemisphereLight(0xa89aff,0x24103a,1.35)); const dl=new THREE.DirectionalLight(0xff9af0,.35); dl.position.set(0,30,10); sc.add(dl);
  const carp=ctex(256,256,(x,Wd,H)=>{ x.fillStyle='#120a24'; x.fillRect(0,0,Wd,H); const cols=['#ff2bd6','#00e5ff','#ffd400','#3cff9e']; for(let i=0;i<46;i++){ x.fillStyle=cols[i%4]+'66'; const s=3+Math.random()*7; x.fillRect(Math.random()*Wd,Math.random()*H,s,s); } x.strokeStyle='rgba(0,229,255,.28)'; x.lineWidth=3; x.strokeRect(2,2,Wd-4,H-4); },[BX/6,BZ/6]);
  const fl=new THREE.Mesh(new THREE.PlaneGeometry(BX*2+4,BZ*2+4),new THREE.MeshLambertMaterial({map:carp})); fl.rotation.x=-Math.PI/2; sc.add(fl);
  const wm=wLamb(0x1a1030), HH=10; W.box(BX*2+1,HH,.6,0,HH/2,-BZ-.3,wm); W.box(BX*2+1,HH,.6,0,HH/2,BZ+.3,wm); W.box(.6,HH,BZ*2,-BX-.3,HH/2,0,wm); W.box(.6,HH,BZ*2,BX+.3,HH/2,0,wm);
  const ce=new THREE.Mesh(new THREE.PlaneGeometry(BX*2,BZ*2),new THREE.MeshBasicMaterial({color:0x05030a,side:THREE.DoubleSide})); ce.rotation.x=Math.PI/2; ce.position.y=HH; sc.add(ce);
  const cols=[0xff2bd6,0x00e5ff,0xffd400,0x3cff9e]; for(let i=-3;i<=3;i++){ W.box(BX*2,.18,.25,0,HH-.2,i*7,wNeon(cols[(i+3)%4])); }
  [[BX*2,.14,.1,0,3,-BZ+.1,0xff2bd6],[BX*2,.14,.1,0,5.6,-BZ+.1,0x00e5ff],[.1,.14,BZ*2,-BX+.1,3,0,0xffd400],[.1,.14,BZ*2,BX-.1,3,0,0x3cff9e],[BX*2,.14,.1,0,3,BZ-.1,0x3cff9e]].forEach(a=>W.box(a[0],a[1],a[2],a[3],a[4],a[5],wNeon(a[6])));
  const sign=hubLabel('🕹️ ARCADE · HIGH & ROUILLÉ','#FFD400',16,0,-BZ+.6); sign.position.set(0,8,-BZ+.7); sc.add(sign);
  const glows=[]; const scr=(ic,col)=>ctex(128,96,(x,Wd,H)=>{ const g=x.createLinearGradient(0,0,0,H); g.addColorStop(0,'#16082e'); g.addColorStop(1,col); x.fillStyle=g; x.fillRect(0,0,Wd,H); x.font='54px serif'; x.textAlign='center'; x.fillText(ic,Wd/2,66); x.fillStyle='rgba(255,255,255,.12)'; for(let y=0;y<H;y+=4) x.fillRect(0,y,Wd,1); });
  const hex=c=>'#'+c.toString(16).padStart(6,'0');
  const cab=(gid,x,z)=>{ const G=ARC[gid], col=G.col, wide=gid==='pin';
    if(wide){ W.box(3,1.5,4.6,x,1.1,z,wLamb(0x241446)); const gl=W.box(2.8,.1,4.4,x,1.95,z+.1,new THREE.MeshBasicMaterial({color:0x3a1a6a,transparent:true,opacity:.8})); gl.rotation.x=-.16; W.box(3,3.4,.5,x,2.9,z-2.2,wLamb(0x241446)); const m=new THREE.Mesh(new THREE.PlaneGeometry(2.4,1.8),new THREE.MeshBasicMaterial({map:scr(G.ic,hex(col))})); m.position.set(x,3.5,z-1.94); sc.add(m); W.box(3.1,.15,4.7,x,.45,z,wNeon(col)); W.obs.push({x0:x-1.7,x1:x+1.7,z0:z-2.6,z1:z+2.6}); }
    else { W.box(2.6,4.4,2.2,x,2.2,z,wLamb(0x1c1430)); W.box(2.7,.14,2.3,x,1.1,z,wNeon(col)); W.box(2.7,.14,2.3,x,3.7,z,wNeon(col)); const m=new THREE.Mesh(new THREE.PlaneGeometry(2.1,1.6),new THREE.MeshBasicMaterial({map:scr(G.ic,hex(col))})); m.position.set(x,2.8,z+1.12); sc.add(m); W.box(2.3,.35,1,x,1.75,z+1.3,wLamb(0x2a1a4a)); const js=new THREE.Mesh(new THREE.CylinderGeometry(.06,.06,.4,6),wLamb(0xdddddd)); js.position.set(x-.5,2.05,z+1.35); sc.add(js); [[.1,0xff2d2d],[.4,0xffd400],[.7,0x1fe06a]].forEach(b=>{ const bt=new THREE.Mesh(new THREE.CylinderGeometry(.12,.12,.08,8),wNeon(b[1])); bt.position.set(x+b[0],1.97,z+1.35); sc.add(bt); }); W.obs.push({x0:x-1.5,x1:x+1.5,z0:z-1.3,z1:z+2}); }
    const lb=hubLabel(G.ic+' '+G.n.split(' ')[0].toUpperCase(),hex(col),6,x,z); lb.position.set(x,5.6,z); sc.add(lb); const gw=wGlow(col,9); gw.position.set(x,3,z+(wide?2.6:2)); sc.add(gw); glows.push(gw);
    W.poi('arc_'+gid,x,z+(wide?4.2:3.4),3.3,()=>S.lvl<ARC_LV[gid]?`🔒 ${G.n} · niveau ${ARC_LV[gid]} requis`:`${G.ic} ${G.n} · record ${fmt(arcS().best[gid]||0)}`,()=>S.lvl<ARC_LV[gid]?[]:[{id:'arc_'+gid,tx:`▶ Jouer · ${G.cost} cr`}]); };
  cab('pin',-24,-18); cab('drift',-11,-19); cab('drag',1,-19); cab('pit',13,-19); cab('nitro',25,-19);
  /* bornes décor */
  [[-30,6],[-30,-2],[30,12]].forEach((p,i)=>{ W.box(2.4,4,2,p[0],2,p[1],wLamb(0x1a1230)); W.box(2.5,.12,2.1,p[0],3.4,p[1],wNeon(cols[i%4])); const m=new THREE.Mesh(new THREE.PlaneGeometry(1.9,1.4),new THREE.MeshBasicMaterial({map:scr(['👾','🎱','🚀'][i],'#2a0a4a')})); m.position.set(p[0]+(p[0]<0?1.02:-1.02),2.6,p[1]); m.rotation.y=p[0]<0?Math.PI/2:-Math.PI/2; sc.add(m); W.obs.push({x0:p[0]-1.4,x1:p[0]+1.4,z0:p[1]-1.3,z1:p[1]+1.3}); });
  /* comptoir de prix */
  const px=BX-4; W.box(3,1.3,10,px,.65,0,wLamb(0x3a2a14)); W.box(3.2,.12,10.2,px,1.35,0,wNeon(0xffd400)); [-3.6,-1.2,1.2,3.6].forEach((z,i)=>{ W.box(.9,.9,.9,px+1.2,2.2,z,wLamb([0xff2bd6,0x00e5ff,0x3cff9e,0xff9a1a][i])); const bl=new THREE.Mesh(new THREE.SphereGeometry(.55,10,8),wLamb(0xffd400)); bl.position.set(px+1.2,3.2,z); sc.add(bl); }); W.box(.4,5,10,px+1.9,2.5,0,wLamb(0x2a1a4a));
  const cl=hubLabel('🎟️ PRIX','#FFD400',9,px,0); cl.position.set(px,6.2,0); sc.add(cl); W.obs.push({x0:px-1.7,x1:px+1.7,z0:-5.2,z1:5.2});
  W.poi('arc_prix',px-4,0,4.2,()=>`🎟️ Comptoir de prix · ${fmt(arcS().tk)} tickets`,()=>[{id:'arc_prix',tx:'Échanger mes tickets'}]);
  /* porte */
  W.box(6,6,.3,0,3,BZ-.1,wNeon(0x3cff9e)); const gl2=hubLabel('↩ RUE NÉON','#3CFF9E',7,0,BZ); gl2.position.set(0,7.2,BZ-.4); sc.add(gl2); W.poi('agate',0,BZ-3.2,3.8,()=>'Sortie',()=>[{id:'agate',tx:'↩ Retour à la rue'}]);
  W.anim=(dt,t)=>{ glows.forEach((g,i)=>{ g.material.opacity=.6+.4*Math.sin(t*3+i*1.3); }); };
}
WBUILD.arcade=buildArcade;
/* porte de l'arcade dans la rue néon */
const _bStreet=WBUILD.street;
WBUILD.street=function(W){ _bStreet(W); const sc=W.sc, x=-18, z=-12.5; W.box(5,4.2,3,x,2.1,z,wLamb(0x1a1230)); W.box(5.4,.3,3.4,x,4.3,z,wNeon(0xff2bd6)); W.box(3.4,3,.1,x,1.5,z+1.55,wNeon(0x2a0a5a)); const l=hubLabel('🕹️ ARCADE','#FF2BD6',8,x,z); l.position.set(x,6.2,z); sc.add(l); const g=wGlow(0xff2bd6,14); g.position.set(x,3,z+2); sc.add(g); W.obs.push({x0:x-2.7,x1:x+2.7,z0:z-1.7,z1:z+1.7});
  W.poi('arcade',x,z+3.6,3.6,()=>'🕹️ Salle d’arcade',()=>[{id:'arcade',tx:'Entrer dans la salle d’arcade'}]); };
const _wgo22=ACT.wgo;
ACT.wgo=function(d){ const id=d.id; if(id==='arcade'){ musicStop(); return growEnter('arcade'); } if(id==='agate'){ return growEnter('street'); } if(id==='arc_prix'){ return openSheet({t:'arcprix'}); } if(id&&id.startsWith('arc_')){ return arcOpen(id.slice(4)); } return _wgo22.apply(this,arguments); };
/* ===== v0.44 : Pinball 2.0 (chasse aux pièces, radar, turbo, multibille, niveaux, paliers) + station Monde ===== */
/* ---------- carte du Monde façon station de métro ---------- */
function worldBtn(){ const t=$('top'); if(!t||t.querySelector('.worldbtn')) return; const b=document.createElement('button'); b.className='worldbtn'; b.dataset.a='wmap'; b.setAttribute('aria-label','Carte du Monde'); b.textContent='🌍'; const mo=t.querySelector('.money'), sb=mo&&mo.querySelector('[data-a="mute"]'); if(sb) sb.before(b); else (mo||t).appendChild(b); }
const LINES=[['Ligne 1 · Chez toi','#ffd400',['garage','atelier','ranch']],['Ligne 2 · Sorties','#ff2bd6',['beach','street','arcade']]];
function wmapSheet(X){
  if(!sheet||sheet.t!=='wmap') return false;
  const here=id=>view==='hub'&&(HUB.map||'garage')===id;
  $('sheet').innerHTML=`<div class="inv metro">${X}<div class="mhead"><span class="mlogo">M</span><div><h2>Station Monde</h2><small>Où veux-tu aller ?</small></div></div>
   ${LINES.map(L=>`<div class="mline" style="--lc:${L[1]}"><div class="mlt">${L[0]}</div>${L[2].map(id=>DEST.find(d=>d.id===id)).filter(Boolean).map(d=>{ const ok=d.ok(), h=here(d.id); return `<button class="mstop ${ok?'':'lock'} ${h?'here':''}" data-a="wtravel" data-id="${d.id}" ${ok&&!h?'':'disabled'}><i class="dot"></i><span class="mic">${d.ic}</span><span class="mtx"><b>${d.nom}</b><small>${h?'Tu es ici':ok?d.d:'🔒 '+d.why}</small></span>${ok&&!h?'<span class="mgo">›</span>':''}</button>`; }).join('')}</div>`).join('')}</div>`; return true; }
ACT.wmap=()=>openSheet({t:'wmap'});
ACT.wtravel=d=>{ const D=DEST.find(x=>x.id===d.id); if(!D||!D.ok()) return; musicStop(); closeSheet();
  if(view!=='hub'){ HUB.map='garage'; ACT.tab({id:'hub'}); if(d.id!=='garage') setTimeout(()=>{ try{ growEnter(d.id); }catch(e){ console.error(e); } },120); return; }
  if(d.id==='garage'){ if((HUB.map||'garage')!=='garage') growExit(); return; } growEnter(d.id); };
/* ---------- pièces exclusives du pinball ---------- */
const PB_UN0=UNIQ.length;
[['Cœur de Flipper','mo1',{ch:1.1,nm:.9},'Un bloc qui cogne comme un bumper'],['Turbo Tilt','tu2',{ch:1,nm:1,fia:-.2},'Se déclenche quand tu secoues la table'],['Pot Multibille','ec2',{ch:.8,sty:.9},'Trois sorties, trois fois plus de bruit'],
 ['Gommes Néon','pn1',{adh:1.5,wet:.4},'Elles brillent dans le noir'],['Freins Flipper','fr3',{fre:1.4,kg:.5},'Ils attrapent la bille au vol'],['Amorti Bumper','su1',{man:1.4,adh:.6},'Rebondit mais ne casse jamais'],
 ['Coque Jackpot','ch2',{kg:1.5,dmg:.8},'Légère comme un ticket gagnant'],['Aileron Ball Save','ae2',{adh:1.1,vmax:.7},'Te rattrape quand tu tombes'],['Nitro Extra Ball','ni3',{nitD:1.1,nitP:1},'Une charge de plus, à chaque fois'],
 ['Jantes Tilt','ja3',{inc:1.5,sty:1.1},'Elles tournent même à l’arrêt'],['Livrée Arcade','pe3',{xp:1.6,sty:1},'Pixels, néons et gros score'],['Culasse Super Jackpot','mo3',{nm:1.5,fia:1,ch:.6},'La pièce que tous les joueurs rêvent d’avoir']]
 .forEach(a=>UNIQ.push({n:a[0],t:a[1],fx:a[2],d:a[3],ar:1}));
const _newMod23=newMod;
newMod=function(r,slot,plain){ const m=_newMod23.apply(this,arguments); if(m.un!=null&&m.un>=PB_UN0){ m.un=rint(0,PB_UN0-1); m.t=UNIQ[m.un].t; S.alb[m.t]=(S.alb[m.t]||0)|(1<<m.r); } return m; };
M.arcgt={id:'arcgt',nom:'Flipper GT Tilt',an:2027,cat:'Édition Arcade',shape:'super',tr:'AWD',t:6,ch:980,nm:1050,kg:1380,vmax:365,adh:93,fre:91,man:93,fia:72,sty:99,val:700000,col:'#ff2bd6',arc:1};
function pbS(){ const A=arcS(); return A.pb||(A.pb={xp:0,lv:1,caps:0,got:{},pal:{},runs:0,bestC:0}); }
const pbNeed=lv=>500*lv, PB_MAXLV=20;
const pbPerk={ save:lv=>8+.6*lv, need:lv=>lv>=9?2:lv>=4?3:4, balls:lv=>lv>=10?4:3, arcP:lv=>Math.min(.5,.1+.02*lv), rar:lv=>1+.07*lv };
const PB_PAL=[{s:12000,t:'part',r:3,n:'Pièce Épique'},{s:40000,t:'arc',r:4,n:'Pièce d’arcade Légendaire'},{s:100000,t:'car',n:'Voiture spéciale : Flipper GT Tilt'}];
const PB_RW=[34,30,20,10,4.5,1.3,.2];
function pbRoll(lv){ const w=PB_RW.map((x,i)=>x*(i>=2?pbPerk.rar(lv):1)), tot=w.reduce((a,b)=>a+b,0); let x=Math.random()*tot; for(let i=0;i<7;i++){ x-=w[i]; if(x<0) return i; } return 0; }
function pbGrant(r,arc){ /* ajoute une pièce à l’inventaire ; renvoie {m,name,dup,full} */
  const P=pbS(); let m, dup=false;
  if(arc){ const ui=PB_UN0+rint(0,UNIQ.length-PB_UN0-1), ex=S.mods.find(x=>x.un===ui);
    if(ex){ ex.q=Math.round((ex.q+.12)*100)/100; ex.st=Math.min(5,(ex.st||0)+1); m=ex; dup=true; }
    else { const base=_newMod23(Math.max(3,r),null,true); m=base; m.un=ui; m.t=UNIQ[ui].t; m.sn=rint(1,999); m.q=Math.round(rnd(1.15,1.4)*100)/100; m.pb=1; S.alb[m.t]=(S.alb[m.t]||0)|(1<<m.r);
      if(S.mods.length+1>invMax()){ S.scrap+=RAR[m.r].sc*2; return {m,name:UNIQ[ui].n,full:1,r:m.r,arc:1}; } S.mods.push(m); }
    P.got[ui]=(P.got[ui]||0)+1; return {m,name:UNIQ[ui].n,dup,r:m.r,arc:1}; }
  m=newMod(r,null,true); if(S.mods.length+1>invMax()){ S.scrap+=RAR[m.r].sc; return {m,name:modName(m),full:1,r:m.r}; } S.mods.push(m); return {m,name:modName(m),r:m.r}; }
/* ---------- le jeu ---------- */
ARC.pin.d='3 billes. Maintiens LANCER puis flippers. Remplis le RADAR (couloirs du haut, cibles, garage, bumpers) pour lancer une CHASSE : frappe la pièce qui flotte avant la fin du temps pour la capturer. 8 tables à débloquer avec ton niveau pinball, avec des PONTS et des RAMPES : lance la bille dedans (flèche à l’entrée) et enchaîne-les pour multiplier les points ; abats les banques de cibles orange. Le TROU bleu te téléporte vers la table suivante (il se ferme tant qu’une pièce est en jeu). Gagne de l’expérience et débloque des paliers.';
ARCR.pin=[['Nakai',90000],['Vega',55000],['Quill',32000],['Ibarra',16000],['Brandt',7000]];
const _pin22=GAMES.pin;
GAMES.pin=function(api){
  const st=api.st, bar=api.bar, W=360,H=600,R=6.5,G=640, P=pbS(), LV=P.lv, N=pbPerk.balls(LV), NEED=pbPerk.need(LV);
  const SK=pmStyleOf(LV), TH=PMS[SK].th; PM.begin(SK,LV);
  const cv=document.createElement('canvas'); cv.className='arccv'; st.appendChild(cv); const ctx=cv.getContext('2d'); let K=1;
  const live=document.createElement('div'); live.className='pinlive'; st.parentNode.insertBefore(live,st);
  const fit=()=>{ const r=st.getBoundingClientRect(), s=Math.min(r.width/W,r.height/H)||1, dpr=Math.min(2,window.devicePixelRatio||1); cv.style.width=(W*s)+'px'; cv.style.height=(H*s)+'px'; cv.width=Math.round(W*s*dpr); cv.height=Math.round(H*s*dpr); K=s*dpr; };
  bar.innerHTML=`<div class="pinctl"><button id="pL" class="arcb">◀</button><button id="pP" class="arcb pl">LANCER<small>maintiens</small></button><button id="pR" class="arcb">▶</button></div>`;
  fit(); const ro=window.ResizeObserver?new ResizeObserver(fit):null; if(ro) ro.observe(st);
  const segs=[]; const sg=(x1,y1,x2,y2,e,k)=>{ const s={x1,y1,x2,y2,e:e||.5,k:k||0}; segs.push(s); return s; };
  { const cx=180,cy=170,ar=168; let px=12,py=170; for(let i=1;i<=18;i++){ const a=Math.PI+i/18*Math.PI, x=cx+ar*Math.cos(a), y=cy+ar*Math.sin(a); sg(px,py,x,y,.4); px=x; py=y; } }
  sg(12,170,12,455); sg(348,170,348,594); sg(318,594,348,594); sg(318,215,318,594); sg(12,455,94,540,.3); sg(318,455,226,540,.3);
  const door=sg(348,196,318,222,.3); door.off=true; door.door=1;
  const slL={x1:50,y1:392,x2:98,y2:462,e:1.05,k:360,hit:0}, slR={x1:268,y1:392,x2:222,y2:462,e:1.05,k:360,hit:0}; segs.push(slL,slR);
  const bumps=[], posts=[], spins=[], boosts=[], portals=[], wells=[], mills=[], ramps=[], dbanks=[]; let rampN=0, rampT=0, rampMax=0; const hole={x:172,y:310,r:15,open:true,sp:0,cool:0};
  const tgt=[], lanes=[];
  const sauc={x:292,y:282,r:10,cool:0,glow:0}; const part={on:false,x:170,y:300,r:24,hp:0,max:0,hit:0,r_:0,arc:false,ui:-1,slot:'moteur',ic:'⚙️',cool:0,vx:0,vy:0,tx:170,ty:250,wt:0,dash:0,tr:[]};
  const FL=[{px:98,py:545,L:56,s:1,th:.6,rest:.6,act:-.52,w:0,on:false},{px:222,py:545,L:56,s:-1,th:.6,rest:.6,act:-.52,w:0,on:false}];
  const tip=f=>[f.px+f.s*f.L*Math.cos(f.th), f.py+f.L*Math.sin(f.th)];
  const mkb=()=>({x:333,y:572,vx:0,vy:0,st:'plunger',trail:[],la:false,ht:0,stuck:0});
  let balls=[mkb()], score=0, ball=1, mult=1, power=0, charging=false, save=pbPerk.save(LV), usedSave=false, msg='', msgT=0, over=false, t=0;
  let combo=0, comboT=0, shake=0, tiltT=0, tiltN=0, nudgeCD=0, ballBumps=0, lastRank=99; const pops=[]; let radar=LV>=6?1:0, turboG=0, turbo=0, bumpN=0, mode=null, chT=0, mbSave=0, jack=0; const caps=[], fx=[];
  const say=m=>{ msg=m; msgT=1.6; };
  const pop=(x,y,t,c)=>pops.push({x,y,t,c:c||'#fff',l:.9});
  const hitC=(x,y,pts)=>{ if(comboT>0) combo++; else combo=1; comboT=1.5; if(pts) pop(x,y-12,'+'+fmt(Math.round(pts*mult*(balls.length>1?2:1))),TH.b); const T={5:[500,'NICE !'],10:[1500,'WOW !'],20:[4000,'INSANE !'],35:[9000,'GODLIKE !']}[combo]; if(T){ add(T[0]); say(T[1]+' COMBO ×'+combo); shake=1; PM.fx('nice'); burst(x,y,TH.a,24); } };
  const add=n=>{ score+=Math.round(n*mult*(balls.length>1?2:1)); };
  const burst=(x,y,c,n)=>{ for(let i=0;i<n;i++){ const a=Math.random()*6.28, v=60+Math.random()*220; fx.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.5+Math.random()*.5,c}); } };
  const resetBall=()=>{ balls=[mkb()]; door.off=true; power=0; usedSave=false; };

  /* ---------- 6 tables + trou de changement ---------- */
  const L3=[[132,62],[180,52],[228,62]], P2=[[120,400],[240,400]], TT=[[110,96],[180,84],[250,96]];
  const TBL=[
   {n:'GARAGE',ic:'🔧',bg:'#ffd400',bumps:[[130,150],[215,150],[172,205]],tgt:TT,lanes:L3,sauc:[100,240],hole:[172,312],posts:P2,
    ramps:[{c:[[54,330],[44,270],[52,200],[88,140],[146,106],[206,98],[262,118],[292,164],[298,226]],col:'#ffd400',nm:'PONT DU GARAGE'}]},
   {n:'NÉON DRIFT',ic:'🌈',bg:'#ff2bd6',bumps:[[95,130],[165,108],[235,130],[130,190],[200,190]],tgt:[[46,235],[46,275],[46,315]],lanes:L3,sauc:[140,290],hole:[178,350],posts:P2,
    spins:[[180,262]],boosts:[[60,300,.3,-.95],[250,345,-.3,-.95]],segs:[[30,215,70,252,.35],[300,215,262,252,.35]],
    ramps:[{c:[[286,330],[296,270],[294,198],[266,120],[204,76],[132,78],[74,122],[54,192],[72,252],[116,286]],col:'#ff2bd6',nm:'BOUCLE NÉON'}]},
   {n:'SPA RUSH',ic:'🏁',bg:'#3cff9e',bumps:[[110,200],[235,200],[172,150,15,[70,0,1.4]]],tgt:TT,lanes:L3,sauc:[140,290],hole:[172,322],posts:P2,
    portals:[[48,200],[272,352]],boosts:[[172,245,0,-1]],
    ramps:[{c:[[54,330],[62,282],[100,238],[160,214],[214,196],[262,168],[292,196],[296,250]],col:'#3cff9e',nm:'EAU ROUGE'},{c:[[290,330],[272,290],[222,256],[164,236],[110,206],[70,196],[50,236],[50,282]],col:'#ffd400',nm:'RAIDILLON'}]},
   {n:'CASSE AUTO',ic:'🚗',bg:'#ff9a1a',bumps:[[130,140],[225,140],[180,95,14]],tgt:[[46,230],[46,270],[46,310]],lanes:L3,sauc:[100,190],hole:[252,336],posts:P2,
    wells:[[180,250,70,520]],mills:[[98,322,36,2.4]],drops:[[[290,150,290,172],[290,178,290,200],[290,206,290,228]]],
    ramps:[{c:[[286,330],[270,284],[224,242],[160,200],[112,160],[104,122],[150,94],[214,102],[262,138]],col:'#ff9a1a',nm:'RAMPE DE CASSE'}]},
   {n:'TURBO TUNNEL',ic:'🚀',bg:'#00e5ff',bumps:[[170,120,17],[170,268,17]],tgt:TT,lanes:L3,sauc:[100,290],hole:[170,342],posts:P2,
    mills:[[88,200,30,2.8],[252,200,30,-2.8]],boosts:[[170,196,0,-1]],spins:[[170,170]],
    ramps:[{c:[[54,330],[50,270],[60,204],[100,140],[170,108],[240,140],[278,196],[284,262]],col:'#00e5ff',nm:'TUNNEL'},{c:[[288,330],[294,274],[276,206]],col:'#3cff9e',nm:'BYPASS',mr:13}]},
   {n:'COSMOS',ic:'🪐',bg:'#8f6bff',bumps:[[170,130,14,[80,30,1.1]],[170,205,14,[-70,0,1.7]]],tgt:TT,lanes:L3,sauc:[140,340],hole:[60,332],posts:P2,
    wells:[[100,262,60,420],[250,200,55,420]],portals:[[52,150],[272,380]],spins:[[180,300]],
    ramps:[{c:[[288,330],[296,270],[290,190],[250,126],[180,92],[110,126],[70,190],[70,262],[110,300]],col:'#8f6bff',nm:'ORBITE'}]},
   {n:'DRAG STRIP',ic:'🚦',bg:'#ff4d4d',bumps:[[120,150],[222,150],[172,120,15]],tgt:TT,lanes:L3,sauc:[140,290],hole:[172,330],posts:P2,
    boosts:[[110,250,0,-1],[236,250,0,-1]],drops:[[[28,150,28,172],[28,178,28,200],[28,206,28,228]]],
    ramps:[{c:[[54,330],[60,270],[84,200],[112,140],[134,80],[160,48]],col:'#ff4d4d',nm:'LIGNE DROITE G',min:380,cs:.93},{c:[[288,330],[282,270],[258,200],[236,140],[216,80],[190,48]],col:'#ff9a1a',nm:'LIGNE DROITE D',min:380,cs:.93}]},
   {n:'ANNEAU NÉON',ic:'💠',bg:'#4aa8ff',bumps:[[172,150,16],[130,210],[214,210]],tgt:TT,lanes:L3,sauc:[280,240],hole:[172,320],posts:P2,
    spins:[[172,262]],portals:[[48,330],[290,150]],drops:[[[300,330,300,352],[300,358,300,380]]],
    ramps:[{c:[[60,300],[50,250],[56,190],[90,124],[150,88],[210,88],[262,122],[290,182],[284,250],[250,300]],col:'#4aa8ff',nm:'GRAND ANNEAU',min:360,cs:.92},{c:[[172,252],[172,214],[172,176],[172,144]],col:'#ff2bd6',nm:'AXE CENTRAL',mr:10,cs:.96}]}];
  const ramSmooth=(c,n)=>{ const out=[]; for(let i=0;i<c.length-1;i++){ const p0=c[Math.max(0,i-1)],p1=c[i],p2=c[i+1],p3=c[Math.min(c.length-1,i+2)]; for(let k=0;k<n;k++){ const u=k/n,u2=u*u,u3=u2*u; out.push([.5*((2*p1[0])+(-p0[0]+p2[0])*u+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*u2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*u3),.5*((2*p1[1])+(-p0[1]+p2[1])*u+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*u2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*u3)]); } } out.push(c[c.length-1].slice()); return out; };
  let tabI=0, T=TBL[0]; const seen={0:1};
  function loadTable(i){
    tabI=i; T=TBL[i];
    for(let k=segs.length-1;k>=0;k--) if(segs[k].tb) segs.splice(k,1);
    bumps.length=posts.length=spins.length=boosts.length=portals.length=wells.length=mills.length=tgt.length=lanes.length=ramps.length=dbanks.length=0;
    T.bumps.forEach(a=>{ const q={x:a[0],y:a[1],r:a[2]||17,hit:0,x0:a[0],y0:a[1]}; if(a[3]) q.mv=a[3]; bumps.push(q); });
    (T.posts||[]).forEach(a=>posts.push({x:a[0],y:a[1],r:6})); T.tgt.forEach(a=>tgt.push({x:a[0],y:a[1],r:8,on:0})); T.lanes.forEach(a=>lanes.push({x:a[0],y:a[1],on:0}));
    (T.spins||[]).forEach(a=>spins.push({x:a[0],y:a[1],r:15,ang:0,cd:0,n:0})); (T.boosts||[]).forEach(a=>{ const m=Math.hypot(a[2],a[3])||1; boosts.push({x:a[0],y:a[1],r:15,dx:a[2]/m,dy:a[3]/m,cd:0,glow:0}); });
    (T.portals||[]).forEach((a,k)=>portals.push({x:a[0],y:a[1],r:13,k,cd:0})); (T.wells||[]).forEach(a=>wells.push({x:a[0],y:a[1],r:a[2],k:a[3]}));
    (T.mills||[]).forEach(a=>{ const sgm=sg(a[0]-a[2],a[1],a[0]+a[2],a[1],.95); sgm.tb=1; sgm.mill=1; mills.push({x:a[0],y:a[1],L:a[2],sp:a[3],s:sgm}); });
    (T.segs||[]).forEach(a=>{ const q=sg(a[0],a[1],a[2],a[3],a[4]||.4); q.tb=1; });
    (T.ramps||[]).forEach((a,k)=>{ const p=ramSmooth(a.c,7), cum=[0]; for(let i=1;i<p.length;i++) cum.push(cum[i-1]+Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1])); const d0=Math.hypot(p[2][0]-p[0][0],p[2][1]-p[0][1])||1;
      ramps.push({k,p,cum,len:cum[cum.length-1],col:a.col||TH.b,pts:a.pts||500,mx:p[0][0],my:p[0][1],mr:a.mr||12,ux:(p[2][0]-p[0][0])/d0,uy:(p[2][1]-p[0][1])/d0,min:a.min||300,cs:a.cs||.88,cd:0,glow:0,n:0,nm:a.nm||'RAMPE'}); });
    (T.drops||[]).forEach(bk=>{ const B={ss:[],rt:0}; bk.forEach(a=>{ const q=sg(a[0],a[1],a[2],a[3],.5); q.tb=1; q.dr=1; q.bk=B; B.ss.push(q); }); dbanks.push(B); });
    sauc.x=T.sauc[0]; sauc.y=T.sauc[1]; sauc.cool=.6; hole.x=T.hole[0]; hole.y=T.hole[1]; hole.cool=1; hole.sp=0;
  }
  loadTable(0);
  const updMovers=h=>{ for(const q of bumps) if(q.mv){ q.x=q.x0+q.mv[0]*Math.sin(t*q.mv[2]); q.y=q.y0+q.mv[1]*Math.sin(t*q.mv[2]); }
    for(const m of mills){ const a=t*m.sp; m.s.x1=m.x-Math.cos(a)*m.L; m.s.y1=m.y-Math.sin(a)*m.L; m.s.x2=m.x+Math.cos(a)*m.L; m.s.y2=m.y+Math.sin(a)*m.L; m.a=a; }
    for(const s of spins){ s.cd-=h; s.ang+=h*(s.cd>0?14:2); } for(const b of boosts){ b.cd-=h; b.glow=Math.max(0,b.glow-h*3); } for(const p of portals) p.cd-=h; for(const r of ramps){ r.cd-=h; r.glow=Math.max(0,r.glow-h*2); } for(const B of dbanks){ if(B.rt>0){ B.rt-=h; if(B.rt<=0){ B.ss.forEach(q=>q.off=false); arcTone(520,.12,'triangle',.07); } } } if(rampT>0){ rampT-=h; if(rampT<=0) rampN=0; } hole.sp+=h*(hole.open?3:.6); hole.cool-=h; hole.open=!part.on&&mode!=='chasse'&&tabsOpen()>1;
    if(part.on){ const p=part; p.wt-=h; p.dash=Math.max(0,p.dash-h);
      if(p.wt<=0||Math.hypot(p.tx-p.x,p.ty-p.y)<14){ p.tx=rnd(50,280); p.ty=rnd(95,400); p.wt=rnd(.9,2.0); if(Math.random()<.35) p.dash=.45; }
      const fr=1-p.hp/p.max, sp=(100+fr*100)*(p.dash>0?2.4:1), dx=p.tx-p.x, dy=p.ty-p.y, d=Math.hypot(dx,dy)||1, k=Math.min(1,h*4); p.vx+=(dx/d*sp-p.vx)*k; p.vy+=(dy/d*sp-p.vy)*k; p.x+=p.vx*h; p.y+=p.vy*h;
      p.x=Math.max(44,Math.min(286,p.x)); p.y=Math.max(90,Math.min(430,p.y)); if(p.y>380&&(p.x<112||p.x>208)) p.y=380; if(Math.floor(t*30)%2===0){ p.tr.push([p.x,p.y]); if(p.tr.length>6) p.tr.shift(); } } };
  const PB_TB_LV=[1,2,4,6,8,10,13,16], tabsOpen=()=>PB_TB_LV.filter(l=>LV>=l).length;
  function switchTable(b){ const n=(tabI+1)%tabsOpen(); loadTable(n); P.tv=(P.tv||1)|(1<<n); if(!seen[n]){ seen[n]=1; add(1500); } say(T.ic+' TABLE : '+T.n); PM.fx('nice'); shake=1; burst(hole.x,hole.y,TH.a,30);
    b.st='play'; b.x=sauc.x; b.y=sauc.y; b.vx=-220; b.vy=-430; b.la=false; b.stuck=0; sauc.cool=1.1; lanes.forEach(q=>q.on=0); arcTone(500,.3,'sine',.1); arcTone(900,.3,'triangle',.08); }
  const launch=()=>{ const b=balls.find(x=>x.st==='plunger'); if(!b) return; if(power>=.8&&power<=.95){ add(2500); say('SKILL SHOT !'); radarAdd(1); PM.fx('skill'); shake=.8; } b.vy=-(660+640*power); b.vx=-6; b.st='play'; b.la=true; door.off=true; arcTone(220+power*300,.18,'sawtooth',.08); power=0; };
  const closest=(x,y,a,b,c,d)=>{ const dx=c-a, dy=d-b, l2=dx*dx+dy*dy, tt=Math.max(0,Math.min(1,((x-a)*dx+(y-b)*dy)/(l2||1))); return [a+dx*tt,b+dy*tt,tt]; };
  const radarAdd=n=>{ radar=Math.min(NEED,radar+n); arcTone(760+radar*120,.08,'triangle',.07); if(radar>=NEED&&!mode) startChasse(); };
  function startChasse(){ radar=0; const arc=Math.random()<pbPerk.arcP(LV); let r=pbRoll(LV); if(arc) r=Math.max(3,r); let ui=-1, slot, ic; if(arc){ ui=PB_UN0+rint(0,UNIQ.length-PB_UN0-1); slot=MODI[UNIQ[ui].t][1]; } else slot=SLOTS[rint(0,SLOTS.length-1)][0]; ic=SLOTS.find(s=>s[0]===slot)[2];
    Object.assign(part,{on:true,hp:2+Math.round(r*1.3),r_:r,arc,ui,slot,ic,hit:0,cool:0,x:rnd(70,260),y:rnd(120,330),vx:0,vy:0,wt:0,dash:0,tr:[]}); part.max=part.hp; mode='chasse'; chT=40; say('🔎 CHASSE !'); arcTone(1100,.2,'triangle',.1); arcTone(1500,.25,'triangle',.08); }
  function endChasse(ok){ part.on=false; mode=null; if(!ok){ say('LA PIÈCE S’ENFUIT…'); arcTone(150,.35,'sawtooth',.08); } }
  function capture(){ const g=pbGrant(part.r_,part.arc); P.caps++; caps.push({name:g.name,r:g.r,arc:!!g.arc,dup:!!g.dup,full:!!g.full,u:(g.m&&!g.full)?g.m.u:null}); add(5000+1000*part.r_); P.bestC=Math.max(P.bestC,caps.length); burst(part.x,part.y,RAR[part.r_].c,50); say((g.dup?'★ AMÉLIORÉE : ':'CAPTURÉ : ')+g.name); PM.fx('capture'); shake=1; endChasse(true); save_(); }
  const save_=()=>{ try{ save(); }catch(_){} };
  const mission=b=>{ const pool=[['jack',30],['radar',25],['save',20],['turbo',15]]; if(balls.length===1) pool.push(['multi',12]); let x=Math.random()*pool.reduce((a,p)=>a+p[1],0), k='jack'; for(const p of pool){ x-=p[1]; if(x<0){ k=p[0]; break; } }
    if(k==='jack'){ add(5000); say('JACKPOT +5 000'); } else if(k==='radar'){ say('RADAR +2'); radarAdd(2); } else if(k==='save'){ save=Math.max(save,12); say('BALL SAVE 12 s'); } else if(k==='turbo'){ turbo=14; turboG=0; say('TURBO !!'); } else { mbSave=22; say('MULTIBILLE !'); for(let i=0;i<2;i++) balls.push({x:sauc.x,y:sauc.y,vx:-120-i*160,vy:-380-i*60,st:'play',trail:[],la:false,ht:0,stuck:0}); }
    arcTone(900,.2,'square',.09); };
  const lose=()=>{ if(over) return; if(save>0&&!usedSave){ usedSave=true; say('BALL SAVE !'); const nb=mkb(); balls=[nb]; door.off=true; arcTone(660,.2,'triangle'); return; } PM.fx('drain'); { const bon=Math.round(ballBumps*20*mult); if(bon){ score+=bon; say('BONUS +'+fmt(bon)); } ballBumps=0; } ball++; mult=1; tgt.forEach(q=>q.on=0); if(ball>N){ finish(); } else { resetBall(); say('BILLE '+ball); } };
  const finish=()=>{ if(over) return; over=true; if(mode) endChasse(false); PM.fx('over'); setTimeout(()=>{ const note=rewards(); api.end(score,note); },700); };
  function rewards(){ const out=[]; const gain=Math.floor(score/25)+caps.reduce((a,c)=>a+(c.r+1)*120,0); P.xp+=gain; P.runs++; let up=0; while(P.lv<PB_MAXLV&&P.xp>=pbNeed(P.lv)){ P.xp-=pbNeed(P.lv); P.lv++; up++; }
    out.push(`<b>+${fmt(gain)} XP</b> · niveau ${P.lv}${P.lv>=PB_MAXLV?' (max)':` · ${fmt(P.xp)}/${fmt(pbNeed(P.lv))}`}`); if(up) out.push(`<span class="pbup">⬆ NIVEAU ${P.lv} !</span>`);
    { const ns=Object.keys(seen).length; if(ns>1) out.push(`<span>🕳 Tables visitées : ${ns}/${TBL.length}</span>`); }
    const palC=[];
    PB_PAL.forEach(p=>{ if(score>=p.s&&!P.pal[p.s]){ P.pal[p.s]=1; if(p.t==='car'){ S.cars.push({uid:S.nuid++,mid:'arcgt',etat:100,xp:0,lvl:1,up:{},inv:0,mods:{},sh:1}); out.push(`<span class="pbpal">🏆 PALIER ${fmt(p.s)} : ${p.n} débloquée !</span>`); } else { const g=pbGrant(p.r,p.t==='arc'); out.push(`<span class="pbpal">🏆 PALIER ${fmt(p.s)} : ${g.name}</span>`); palC.push({name:g.name,r:g.r,arc:!!g.arc,dup:!!g.dup,full:!!g.full,u:(g.m&&!g.full)?g.m.u:null,pal:1}); } } });
    { const all=caps.concat(palC); if(all.length) out.push(pbRecap(all)); }
    save_(); return out.join(''); }
  function rampDone(r){ r.n++; rampN++; rampT=7; rampMax=Math.max(rampMax,rampN); const pts=r.pts*Math.min(5,rampN); add(pts); hitC(r.p[r.p.length-1][0],r.p[r.p.length-1][1],pts); say(rampN>1?'ENCHAÎNEMENT ×'+rampN+' !':r.nm+' +'+fmt(Math.round(pts*mult))); arcTone(800+rampN*120,.18,'triangle',.1); burst(r.p[r.p.length-1][0],r.p[r.p.length-1][1],r.col,12); if(rampN%2===0) radarAdd(1); if(rampN>=3&&rampN%3===0&&!mode){ mission(null); } }
  function stepBall(b,h){
    if(b.st==='hold'){ b.ht-=h; b.x=sauc.x; b.y=sauc.y; if(b.ht<=0){ mission(b); b.st='play'; b.vx=-250; b.vy=-440; sauc.cool=.9; } return; }
    if(b.st==='warp'){ b.wt-=h; b.x+=(hole.x-b.x)*Math.min(1,h*10); b.y+=(hole.y-b.y)*Math.min(1,h*10); if(b.wt<=0) switchTable(b); return; }
    if(b.st==='ramp'){ const r=ramps[b.rp]; if(!r){ b.st='play'; return; } b.rs+=b.rsp*h; const e=b.rs>=r.len; const L=e?r.len:b.rs; let i=1; while(i<r.cum.length-1&&r.cum[i]<L) i++; const a=r.p[i-1], c=r.p[i], sl=(r.cum[i]-r.cum[i-1])||1, u=Math.max(0,Math.min(1,(L-r.cum[i-1])/sl)); b.x=a[0]+(c[0]-a[0])*u; b.y=a[1]+(c[1]-a[1])*u;
      if(e){ const q=r.p[r.p.length-1], q0=r.p[r.p.length-4]||r.p[0], dx=q[0]-q0[0], dy=q[1]-q0[1], dm=Math.hypot(dx,dy)||1, sp=Math.max(380,Math.min(760,b.rsp)); b.vx=dx/dm*sp; b.vy=dy/dm*sp; b.st='play'; b.la=false; r.cd=.5; b.trail.length=0; rampDone(r); }
      else{ b.trail.push([b.x,b.y]); if(b.trail.length>9) b.trail.shift(); } return; }
    if(b.st!=='play') return;
    b.vy+=G*h; b.x+=b.vx*h; b.y+=b.vy*h; const sp=Math.hypot(b.vx,b.vy); if(sp>1300){ b.vx*=1300/sp; b.vy*=1300/sp; }
    if(b.la&&b.y<160){ b.la=false; door.off=false; }
    for(const s of segs){ if(s.off) continue; const [cx,cy]=closest(b.x,b.y,s.x1,s.y1,s.x2,s.y2); let dx=b.x-cx, dy=b.y-cy, d=Math.hypot(dx,dy); if(d<R){ if(d<1e-4){ dx=0; dy=-1; d=1; } const nx=dx/d, ny=dy/d; b.x=cx+nx*R; b.y=cy+ny*R; const vn=b.vx*nx+b.vy*ny; if(vn<0){ b.vx-=(1+s.e)*vn*nx; b.vy-=(1+s.e)*vn*ny; if(s.k){ b.vx+=nx*s.k*.55; b.vy+=ny*s.k*.55; s.hit=1; add(10); arcTone(520,.06,'square',.06); } if(s.dr){ s.off=true; add(150); hitC(cx,cy,150); arcTone(420,.08,'square',.08); const B=s.bk; if(B.ss.every(q=>q.off)){ B.rt=2.2; add(1500); say('BANQUE ABATTUE +1 500'); radarAdd(1); PM.fx('nice'); burst(cx,cy,TH.a,18); } } } } }
    for(const r of ramps){ if(r.cd>0) continue; const dx=b.x-r.mx, dy=b.y-r.my; if(dx*dx+dy*dy<r.mr*r.mr){ const sp0=Math.hypot(b.vx,b.vy)||1, dot=b.vx*r.ux+b.vy*r.uy; if(dot>r.min&&dot/sp0>r.cs){ b.st='ramp'; b.rp=r.k; b.rs=0; b.rsp=Math.max(430,Math.min(780,Math.hypot(b.vx,b.vy)*.8)); b.vx=b.vy=0; r.cd=.6; r.glow=1; arcTone(640,.14,'sawtooth',.08); return; } } }
    for(const q of bumps){ const dx=b.x-q.x, dy=b.y-q.y, d=Math.hypot(dx,dy), m=R+q.r; if(d<m){ const nx=d?dx/d:0, ny=d?dy/d:-1; b.x=q.x+nx*m; b.y=q.y+ny*m; const vn=b.vx*nx+b.vy*ny; if(vn<0){ b.vx-=2*vn*nx; b.vy-=2*vn*ny; } const s2=Math.hypot(b.vx,b.vy), k=Math.max(s2,turbo>0?680:520); b.vx=b.vx/(s2||1)*k+nx*80; b.vy=b.vy/(s2||1)*k+ny*80; q.hit=1; add(100*(turbo>0?3:1)); ballBumps++; hitC(q.x,q.y,100*(turbo>0?3:1)); bumpN++; if(turbo<=0){ turboG++; if(turboG>=25){ turbo=14; turboG=0; say('TURBO !!'); arcTone(1200,.2,'sawtooth',.09); } } if(bumpN%20===0) radarAdd(1); arcTone(700+Math.random()*300,.09,'square',.08); } }
    for(const p of posts){ const dx=b.x-p.x, dy=b.y-p.y, d=Math.hypot(dx,dy), m=R+p.r; if(d<m){ const nx=d?dx/d:0, ny=d?dy/d:-1; b.x=p.x+nx*m; b.y=p.y+ny*m; const vn=b.vx*nx+b.vy*ny; if(vn<0){ b.vx-=1.7*vn*nx; b.vy-=1.7*vn*ny; add(5); } } }
    for(const g of tgt){ const dx=b.x-g.x, dy=b.y-g.y, d=Math.hypot(dx,dy), m=R+g.r; if(d<m){ const nx=d?dx/d:1, ny=d?dy/d:0; b.x=g.x+nx*m; b.y=g.y+ny*m; const vn=b.vx*nx+b.vy*ny; if(vn<0){ b.vx-=1.5*vn*nx; b.vy-=1.5*vn*ny; } hitC(g.x,g.y,0); if(!g.on){ g.on=1; add(50); arcTone(880,.07,'triangle',.08); if(tgt.every(q=>q.on)){ tgt.forEach(q=>q.on=0); mult=Math.min(5,mult+1); add(500); say('MULTI ×'+mult+' !'); arcTone(1320,.25,'triangle',.1); radarAdd(1); } } } }
    for(const l of lanes){ if(!l.on&&Math.hypot(b.x-l.x,b.y-l.y)<11){ l.on=1; add(30); arcTone(990,.05,'sine',.07); if(lanes.every(q=>q.on)){ lanes.forEach(q=>q.on=0); add(300); say('RADAR +1'); radarAdd(1); } } }
    if(sauc.cool<=0&&Math.hypot(b.x-sauc.x,b.y-sauc.y)<sauc.r&&Math.hypot(b.vx,b.vy)<460){ b.st='hold'; b.ht=1.1; b.vx=b.vy=0; sauc.glow=1; add(200); arcTone(300,.15,'square',.08); radarAdd(1); return; }
    if(part.on){ const dx=b.x-part.x, dy=b.y-part.y, d=Math.hypot(dx,dy), m=R+part.r; if(d<m){ const nx=d?dx/d:0, ny=d?dy/d:-1; b.x=part.x+nx*m; b.y=part.y+ny*m; const vn=b.vx*nx+b.vy*ny; if(vn<0){ b.vx-=2*vn*nx; b.vy-=2*vn*ny; } const s2=Math.hypot(b.vx,b.vy), k=Math.max(s2,460); b.vx=b.vx/(s2||1)*k; b.vy=b.vy/(s2||1)*k;
        if(part.cool<=0){ part.cool=.18; part.hp--; part.hit=1; part.tx=Math.max(50,Math.min(280,part.x-nx*170)); part.ty=Math.max(95,Math.min(400,part.y-ny*170)); part.wt=1.4; part.dash=.4; add(300); hitC(part.x,part.y,300); shake=Math.max(shake,.4); arcTone(500+(part.max-part.hp)*90,.1,'square',.09); burst(part.x,part.y,RAR[part.r_].c,8); if(part.hp<=0) capture(); } } }
    for(const w of wells){ const dx=w.x-b.x, dy=w.y-b.y, d=Math.hypot(dx,dy); if(d<w.r&&d>3){ const f=w.k*(1-d/w.r)*h; b.vx+=dx/d*f+(-dy/d)*f*.45; b.vy+=dy/d*f+(dx/d)*f*.45; } }
    for(const s of spins){ if(Math.hypot(b.x-s.x,b.y-s.y)<s.r&&s.cd<=0){ s.cd=.1; s.n++; add(15); if(s.n%3===0) arcTone(1000+s.n%12*60,.04,'square',.04); if(s.n%25===0){ radarAdd(1); hitC(s.x,s.y,0); } } }
    for(const q of boosts){ if(q.cd<=0&&Math.hypot(b.x-q.x,b.y-q.y)<q.r){ q.cd=.4; q.glow=1; const sp=Math.max(Math.hypot(b.vx,b.vy),780); b.vx=q.dx*sp; b.vy=q.dy*sp; add(40); hitC(q.x,q.y,40); arcTone(1100,.1,'sawtooth',.07); } }
    for(const p of portals){ if(p.cd<=0&&Math.hypot(b.x-p.x,b.y-p.y)<p.r){ const o=portals[p.k^1]; if(o){ const sp=Math.hypot(b.vx,b.vy)||1; p.cd=o.cd=.7; b.x=o.x+b.vx/sp*(o.r+R+2); b.y=o.y+b.vy/sp*(o.r+R+2); add(150); hitC(o.x,o.y,150); burst(p.x,p.y,'#4aa8ff',10); burst(o.x,o.y,'#ff9a1a',10); arcTone(1300,.12,'sine',.09); if(Math.random()<.5) radarAdd(1); } } }
    { const dx=b.x-hole.x, dy=b.y-hole.y, d=Math.hypot(dx,dy);
      if(hole.open&&hole.cool<=0){ if(d<hole.r*.62){ b.st='warp'; b.wt=.9; b.vx=b.vy=0; arcTone(200,.5,'sine',.1); return; } }
      }
    for(let i=0;i<2;i++){ const f=FL[i], [tx,ty]=tip(f); const [cx,cy,tt]=closest(b.x,b.y,f.px,f.py,tx,ty); let dx=b.x-cx, dy=b.y-cy, d=Math.hypot(dx,dy); const m=R+6; if(d<m){ if(d<1e-4){ dx=0; dy=-1; d=1; } const nx=dx/d, ny=dy/d, s=tt*f.L, cvx=(f.s>0?-Math.sin(f.th):Math.sin(f.th))*s*f.w, cvy=Math.cos(f.th)*s*f.w; b.x=cx+nx*m; b.y=cy+ny*m; const rel=(b.vx-cvx)*nx+(b.vy-cvy)*ny; if(rel<0){ b.vx-=1.32*rel*nx; b.vy-=1.32*rel*ny; } } }
    if(b.x>319&&b.y>560&&b.vy>=0&&Math.hypot(b.vx,b.vy)<400){ if(balls.length===1||!balls.some(o=>o.st==='plunger')){ b.x=333; b.y=572; b.vx=b.vy=0; b.st='plunger'; power=0; door.off=true; } else b.dead=1; return; }
    if(b.y>H+24){ b.dead=1; return; } if(b.x<-20||b.x>W+20||b.y<-30){ if(balls.length>1) b.dead=1; else { b.x=180; b.y=120; b.vx=0; b.vy=0; } return; }
    if(Math.hypot(b.vx,b.vy)<14&&b.y<620){ b.stuck+=h; if(b.stuck>2.2){ b.vx=(Math.random()<.5?-1:1)*140; b.vy=-180; b.stuck=0; } } else b.stuck=0;
    b.trail.push([b.x,b.y]); if(b.trail.length>7) b.trail.shift(); }
  function phys(h){
    if(over) return;
    if(tiltT>0){ tiltT-=h; FL.forEach(f=>f.on=false); }
    FL.forEach(f=>{ const tg=f.on?f.act:f.rest, d=tg-f.th, sp=(f.on?22:12)*h, step=Math.abs(d)<sp?d:Math.sign(d)*sp; f.th+=step; f.w=step/h; });
    if(charging&&balls.some(b=>b.st==='plunger')) power=Math.min(1,power+h*1.1);
    if(balls.some(b=>b.st==='play'||b.st==='ramp')){ if(save>0) save-=h; if(turbo>0){ turbo-=h; if(turbo<=0) say('Turbo terminé'); } if(mode==='chasse'){ chT-=h; if(chT<=0) endChasse(false); } if(mbSave>0) mbSave-=h; }
    if(sauc.cool>0) sauc.cool-=h; if(part.cool>0) part.cool-=h;
    updMovers(h); for(const b of balls) stepBall(b,h);
    if(balls.some(b=>b.dead)){ const before=balls.length; balls=balls.filter(b=>!b.dead); if(mbSave>0&&balls.length&&balls.length<before&&!balls.some(b=>b.st==='plunger')){ /* multibille : pas de pénalité tant qu’il reste une bille */ } if(!balls.length) lose(); }
  }

  const STARS=Array.from({length:40},(_,i)=>[(i*97%340)+10,(i*61%520)+20,(i%5)+1]);
  const deco=()=>{ ctx.save(); ctx.lineWidth=2; ctx.strokeStyle=T.bg; ctx.fillStyle=T.bg; const i=tabI;
    if(i===1){ ctx.globalAlpha=.12; for(let k=1;k<=5;k++){ ctx.beginPath(); ctx.arc(180,330,k*58+(t*18)%58,Math.PI,0); ctx.stroke(); } }
    else if(i===2){ ctx.globalAlpha=.16; ctx.setLineDash([16,14]); ctx.lineDashOffset=-t*60; ctx.lineWidth=6; ctx.beginPath(); ctx.moveTo(40,130); ctx.bezierCurveTo(300,120,40,260,240,300); ctx.bezierCurveTo(300,320,120,380,150,420); ctx.stroke(); }
    else if(i===3){ ctx.globalAlpha=.1; [[90,430,60,1],[250,470,44,-1]].forEach(g=>{ ctx.save(); ctx.translate(g[0],g[1]); ctx.rotate(t*.4*g[3]); ctx.beginPath(); for(let k=0;k<16;k++){ const a=k/16*6.283, r=k%2?g[2]:g[2]+10; ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r); } ctx.closePath(); ctx.fill(); ctx.restore(); }); }
    else if(i===4){ ctx.globalAlpha=.13; for(let k=0;k<6;k++){ const p=((k+t*.5)%6)/6, w=40+p*150, hh=60+p*210; ctx.strokeRect(180-w,300-hh,w*2,hh*2); } }
    else if(i===5){ STARS.forEach((s,k)=>{ ctx.globalAlpha=.2+.25*Math.abs(Math.sin(t*1.3+k)); ctx.fillRect(s[0],s[1],s[2],s[2]); }); }
    ctx.restore(); };
  const drawNew=()=>{ ctx.save(); ctx.shadowBlur=0;
    wells.forEach(w=>{ const g=ctx.createRadialGradient(w.x,w.y,2,w.x,w.y,w.r); g.addColorStop(0,'rgba(143,107,255,.55)'); g.addColorStop(1,'rgba(143,107,255,0)'); ctx.fillStyle=g; ctx.beginPath(); ctx.arc(w.x,w.y,w.r,0,7); ctx.fill(); ctx.strokeStyle='rgba(200,170,255,.7)'; ctx.lineWidth=2; for(let k=0;k<3;k++){ ctx.beginPath(); ctx.arc(w.x,w.y,10+k*13,t*3+k,t*3+k+3.2); ctx.stroke(); } });
    boosts.forEach(q=>{ ctx.save(); ctx.translate(q.x,q.y); ctx.rotate(Math.atan2(q.dy,q.dx)+Math.PI/2); ctx.strokeStyle=q.glow>0?'#fff':'#3cff9e'; ctx.shadowColor='#3cff9e'; ctx.shadowBlur=8+q.glow*14; ctx.lineWidth=3; for(let k=0;k<3;k++){ ctx.globalAlpha=.4+.6*((Math.floor(t*6)%3)===k?1:.3); ctx.beginPath(); ctx.moveTo(-9,6-k*8); ctx.lineTo(0,-2-k*8); ctx.lineTo(9,6-k*8); ctx.stroke(); } ctx.restore(); });
    portals.forEach(p=>{ const c=p.k?'#ff9a1a':'#4aa8ff'; ctx.strokeStyle=c; ctx.shadowColor=c; ctx.shadowBlur=14; ctx.lineWidth=3; ctx.setLineDash([6,5]); ctx.lineDashOffset=-t*30*(p.k?-1:1); ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,7); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle=c; ctx.globalAlpha=.25; ctx.beginPath(); ctx.arc(p.x,p.y,p.r-3,0,7); ctx.fill(); ctx.globalAlpha=1; });
    spins.forEach(s=>{ ctx.strokeStyle='#ffd400'; ctx.shadowColor='#ffd400'; ctx.shadowBlur=8; ctx.lineWidth=4; ctx.beginPath(); ctx.moveTo(s.x-Math.cos(s.ang)*s.r,s.y-Math.sin(s.ang)*s.r*.35); ctx.lineTo(s.x+Math.cos(s.ang)*s.r,s.y+Math.sin(s.ang)*s.r*.35); ctx.stroke(); });
    mills.forEach(m=>{ ctx.strokeStyle=TH.b; ctx.shadowColor=TH.b; ctx.shadowBlur=12; ctx.lineWidth=6; ctx.beginPath(); ctx.moveTo(m.s.x1,m.s.y1); ctx.lineTo(m.s.x2,m.s.y2); ctx.stroke(); ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(m.x,m.y,5,0,7); ctx.fill(); });
    segs.forEach(s=>{ if(!s.tb||s.mill||s.dr) return; ctx.strokeStyle=TH.a; ctx.shadowColor=TH.a; ctx.shadowBlur=10; ctx.lineWidth=4; ctx.beginPath(); ctx.moveTo(s.x1,s.y1); ctx.lineTo(s.x2,s.y2); ctx.stroke(); });
    segs.forEach(s=>{ if(!s.dr) return; ctx.shadowColor='#ff9a1a'; ctx.shadowBlur=s.off?0:10; ctx.strokeStyle=s.off?'rgba(255,154,26,.25)':'#ff9a1a'; ctx.lineWidth=s.off?2:7; ctx.beginPath(); ctx.moveTo(s.x1,s.y1); ctx.lineTo(s.x2,s.y2); ctx.stroke(); });
    { const o=hole.open, c=o?'#00e5ff':'#ff2d2d'; ctx.shadowColor=c; ctx.shadowBlur=o?18:8; ctx.fillStyle=o?'#02060c':'#240608'; ctx.beginPath(); ctx.arc(hole.x,hole.y,hole.r,0,7); ctx.fill(); ctx.strokeStyle=c; ctx.lineWidth=3; ctx.stroke();
      if(o){ ctx.lineWidth=2; for(let k=0;k<3;k++){ ctx.beginPath(); ctx.arc(hole.x,hole.y,4+k*3.5,hole.sp+k*2,hole.sp+k*2+3.6); ctx.stroke(); } ctx.shadowBlur=0; ctx.fillStyle='#00e5ff'; ctx.font='700 8px system-ui'; ctx.textAlign='center'; ctx.fillText('▶ '+TBL[(tabI+1)%tabsOpen()].n,hole.x,hole.y+hole.r+11); }
      else{ ctx.beginPath(); ctx.moveTo(hole.x-7,hole.y-7); ctx.lineTo(hole.x+7,hole.y+7); ctx.moveTo(hole.x+7,hole.y-7); ctx.lineTo(hole.x-7,hole.y+7); ctx.stroke(); ctx.shadowBlur=0; ctx.fillStyle='#ff6b6b'; ctx.font='700 8px system-ui'; ctx.textAlign='center'; ctx.fillText(tabsOpen()<2?'niv. '+PB_TB_LV[1]:'FERMÉ',hole.x,hole.y+hole.r+11); } }
    ctx.restore(); };
  const draw=()=>{ ctx.setTransform(K,0,0,K,0,0); if(shake>0){ ctx.translate((Math.random()-.5)*shake*7,(Math.random()-.5)*shake*7); shake=Math.max(0,shake-.07); } const gr=ctx.createLinearGradient(0,0,0,H); gr.addColorStop(0,turbo>0?'#2a0a2a':TH.bg[0]); gr.addColorStop(1,TH.bg[1]); ctx.fillStyle=gr; ctx.fillRect(0,0,W,H); ctx.fillStyle='rgba(255,255,255,'+(PM.pulse*.045)+')'; ctx.fillRect(0,0,W,H);
    ctx.strokeStyle=TH.grid; ctx.lineWidth=1; for(let x=0;x<W;x+=30){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); } for(let y=0;y<H;y+=30){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }
    ctx.fillStyle='rgba(255,212,0,.07)'; ctx.font='900 54px system-ui,sans-serif'; ctx.textAlign='center'; ctx.fillStyle=T.bg; ctx.globalAlpha=.07; ctx.fillText(T.ic+' '+T.n.split(' ')[0],180,440); ctx.fillText(T.n.split(' ').slice(1).join(' ')||'',180,494); ctx.globalAlpha=1; deco();
    ctx.lineCap='round'; ctx.lineJoin='round'; ctx.shadowBlur=10+PM.pulse*14; ctx.shadowColor=TH.a; ctx.strokeStyle=TH.a; ctx.lineWidth=4; segs.forEach(s=>{ if(s.k||s.door) return; ctx.beginPath(); ctx.moveTo(s.x1,s.y1); ctx.lineTo(s.x2,s.y2); ctx.stroke(); });
    ctx.shadowColor=door.off?'#3cff9e':'#ff2d2d'; ctx.strokeStyle=door.off?'#3cff9e':'#ff2d2d'; ctx.lineWidth=door.off?2:5; ctx.globalAlpha=door.off?.55:1; ctx.beginPath(); ctx.moveTo(door.x1,door.y1); ctx.lineTo(door.x2,door.y2); ctx.stroke(); ctx.globalAlpha=1;
    ctx.shadowColor=TH.b; ctx.strokeStyle=TH.b; ctx.lineWidth=6; [slL,slR].forEach(s=>{ ctx.globalAlpha=.6+.4*s.hit; ctx.beginPath(); ctx.moveTo(s.x1,s.y1); ctx.lineTo(s.x2,s.y2); ctx.stroke(); s.hit=Math.max(0,s.hit-.12); }); ctx.globalAlpha=1;
    bumps.forEach((b,i)=>{ const c=turbo>0?TH.b:TH.c[i%TH.c.length]; ctx.shadowColor=c; ctx.shadowBlur=14+b.hit*16; ctx.fillStyle='#14082a'; ctx.beginPath(); ctx.arc(b.x,b.y,b.r,0,7); ctx.fill(); ctx.strokeStyle=c; ctx.lineWidth=4; ctx.stroke(); ctx.fillStyle=c; ctx.globalAlpha=.35+.65*b.hit; ctx.beginPath(); ctx.arc(b.x,b.y,b.r-6,0,7); ctx.fill(); ctx.globalAlpha=1; b.hit=Math.max(0,b.hit-.08); });
    drawNew(); ctx.shadowBlur=0; posts.forEach(p=>{ ctx.fillStyle='#cfd6ff'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,7); ctx.fill(); });
    tgt.forEach(g=>{ ctx.shadowColor='#3cff9e'; ctx.shadowBlur=g.on?14:0; ctx.fillStyle=g.on?'#3cff9e':'#1a3a2c'; ctx.beginPath(); ctx.arc(g.x,g.y,g.r,0,7); ctx.fill(); ctx.strokeStyle='#3cff9e'; ctx.lineWidth=2; ctx.stroke(); });
    lanes.forEach(l=>{ ctx.shadowColor='#ffd400'; ctx.shadowBlur=l.on?12:0; ctx.fillStyle=l.on?'#ffd400':'#3a3210'; ctx.beginPath(); ctx.arc(l.x,l.y,7,0,7); ctx.fill(); });
    ctx.shadowColor='#00e5ff'; ctx.shadowBlur=10+sauc.glow*14; ctx.fillStyle='#04121a'; ctx.beginPath(); ctx.arc(sauc.x,sauc.y,sauc.r+2,0,7); ctx.fill(); ctx.strokeStyle='#00e5ff'; ctx.lineWidth=3; ctx.stroke(); ctx.shadowBlur=0; ctx.fillStyle='#00e5ff'; ctx.font='700 8px system-ui'; ctx.fillText('GARAGE',sauc.x,sauc.y+25); sauc.glow=Math.max(0,sauc.glow-.03);
    if(part.on){ part.tr.forEach((q,i)=>{ ctx.globalAlpha=(i+1)/part.tr.length*.18; ctx.fillStyle=RAR[part.r_].c; ctx.beginPath(); ctx.arc(q[0],q[1],part.r*.8,0,7); ctx.fill(); }); ctx.globalAlpha=1; const c=RAR[part.r_].c, pulse=.6+.4*Math.sin(t*6); ctx.shadowColor=c; ctx.shadowBlur=18+part.hit*18; ctx.fillStyle='#10081f'; ctx.beginPath(); ctx.arc(part.x,part.y,part.r,0,7); ctx.fill(); ctx.strokeStyle=c; ctx.lineWidth=3; ctx.globalAlpha=pulse; ctx.stroke(); ctx.globalAlpha=1;
      ctx.lineWidth=4; ctx.strokeStyle='#fff'; ctx.beginPath(); ctx.arc(part.x,part.y,part.r+5,-Math.PI/2,-Math.PI/2+6.283*part.hp/part.max); ctx.stroke();
      ctx.shadowBlur=0; ctx.fillStyle=c; ctx.globalAlpha=.22; ctx.beginPath(); ctx.arc(part.x,part.y,part.r-3,0,7); ctx.fill(); ctx.globalAlpha=1; ctx.font='26px serif'; ctx.textBaseline='middle'; try{ ctx.filter='brightness(0) invert(1)'; }catch(_){} ctx.fillText(part.ic,part.x,part.y+1); try{ ctx.filter='none'; }catch(_){} ctx.textBaseline='alphabetic'; part.hit=Math.max(0,part.hit-.07); }
    ctx.shadowBlur=0; if(balls.some(b=>b.st==='plunger')){ ctx.fillStyle='rgba(255,255,255,.14)'; ctx.fillRect(341,500,5,95); ctx.fillStyle='rgba(60,255,158,.75)'; ctx.fillRect(341,500+95*.05,5,95*.15); ctx.fillStyle=power>=.8&&power<=.95?'#3cff9e':TH.b; ctx.fillRect(341,595-95*power,5,95*power); } ctx.fillStyle='#2a1a4a'; ctx.fillRect(320,596-70*(1-power*.55)+0,26,4); ctx.fillStyle='#ffd400'; ctx.fillRect(330,568+power*22,6,30); ctx.fillStyle=`rgba(255,43,214,${.3+power*.7})`; ctx.fillRect(322,598,22,4);
    FL.forEach(f=>{ const [tx,ty]=tip(f); ctx.shadowColor='#ffd400'; ctx.shadowBlur=f.on?16:6; const g=ctx.createLinearGradient(f.px,f.py,tx,ty); g.addColorStop(0,'#ff2d2d'); g.addColorStop(.5,'#ffd400'); g.addColorStop(1,'#1fe06a'); ctx.strokeStyle=g; ctx.lineWidth=13; ctx.beginPath(); ctx.moveTo(f.px,f.py); ctx.lineTo(tx,ty); ctx.stroke(); ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(f.px,f.py,4,0,7); ctx.fill(); });
    const drawRamps=()=>{ ctx.save(); ctx.lineCap='round'; ctx.lineJoin='round'; ramps.forEach(r=>{ const P=r.p, path=()=>{ ctx.beginPath(); ctx.moveTo(P[0][0],P[0][1]); for(let i=1;i<P.length;i++) ctx.lineTo(P[i][0],P[i][1]); };
        ctx.shadowBlur=0; ctx.save(); ctx.translate(3,7); path(); ctx.strokeStyle='rgba(0,0,0,.38)'; ctx.lineWidth=18; ctx.stroke(); ctx.restore();
        ctx.shadowColor=r.col; ctx.shadowBlur=8+r.glow*16; path(); ctx.strokeStyle=r.col; ctx.lineWidth=18; ctx.stroke(); ctx.shadowBlur=0; path(); ctx.strokeStyle='#080b20'; ctx.lineWidth=13; ctx.stroke();
        ctx.setLineDash([7,11]); ctx.lineDashOffset=-t*46; path(); ctx.strokeStyle=r.col; ctx.globalAlpha=.4; ctx.lineWidth=2.5; ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha=1;
        ctx.save(); ctx.translate(r.mx,r.my); ctx.rotate(Math.atan2(r.uy,r.ux)); ctx.fillStyle=r.col; ctx.globalAlpha=.5+.5*r.glow; ctx.beginPath(); ctx.moveTo(10,0); ctx.lineTo(-5,-8); ctx.lineTo(-2,0); ctx.lineTo(-5,8); ctx.closePath(); ctx.fill(); ctx.restore(); }); ctx.restore(); };
    const drawBall=b=>{ if(b.st==='hold') return; b.trail.forEach((p,i)=>{ ctx.globalAlpha=i/b.trail.length*.35; ctx.fillStyle='#8fe9ff'; ctx.beginPath(); ctx.arc(p[0],p[1],R*(i/b.trail.length),0,7); ctx.fill(); }); ctx.globalAlpha=1;
      ctx.shadowColor='#8fe9ff'; ctx.shadowBlur=14; const rg=ctx.createRadialGradient(b.x-2,b.y-2,1,b.x,b.y,R); rg.addColorStop(0,'#fff'); rg.addColorStop(1,'#6ad6ff'); ctx.fillStyle=rg; ctx.beginPath(); ctx.arc(b.x,b.y,b.st==='warp'?R*Math.max(.1,b.wt/.9):b.st==='ramp'?R*1.2:R,0,7); ctx.fill(); ctx.shadowBlur=0; };
    balls.forEach(b=>{ if(b.st!=='ramp') drawBall(b); }); drawRamps(); balls.forEach(b=>{ if(b.st==='ramp') drawBall(b); });
    fx.forEach(p=>{ ctx.globalAlpha=Math.max(0,p.l*2); ctx.fillStyle=p.c; ctx.fillRect(p.x-2,p.y-2,4,4); }); ctx.globalAlpha=1;
    ctx.font='800 13px system-ui'; ctx.textAlign='center'; pops.forEach(p=>{ ctx.globalAlpha=Math.max(0,Math.min(1,p.l*1.6)); ctx.fillStyle=p.c; ctx.fillText(p.t,p.x,p.y); }); ctx.globalAlpha=1;
    if(combo>=3&&comboT>0){ ctx.globalAlpha=Math.min(1,comboT*1.5); ctx.fillStyle=TH.b; ctx.font='900 20px system-ui'; ctx.textAlign='right'; ctx.fillText('COMBO ×'+combo,306,40); ctx.globalAlpha=1; }
    if(save>0&&balls.some(b=>b.st==='play')){ ctx.fillStyle='rgba(255,212,0,.8)'; ctx.font='700 11px system-ui'; ctx.textAlign='center'; ctx.fillText('BALL SAVE '+Math.ceil(save),180,590); }
    if(msgT>0){ ctx.globalAlpha=Math.min(1,msgT*2); ctx.fillStyle='#fff'; ctx.shadowColor='#ff2bd6'; ctx.shadowBlur=18; ctx.font='900 24px system-ui,sans-serif'; ctx.textAlign='center'; ctx.fillText(msg,180,400); ctx.globalAlpha=1; ctx.shadowBlur=0; } };
  const rivals=ARCR.pin; let lastL='';
  const hud=()=>{ api.score(score,`Bille ${Math.min(ball,N)}/${N} · ×${mult}`);
    const all=rivals.map(r=>({n:r[0],s:r[1]})).concat([{n:'TOI',s:score,me:1}]).sort((a,b)=>b.s-a.s), i=all.findIndex(x=>x.me), up=all[i-1], dn=all[i+1];
    const cell=(x,k)=>x?`<div class="pl ${x.me?'me':''}"><b>#${all.indexOf(x)+1}</b><span>${x.n}</span><em>${fmt(x.s)}</em></div>`:`<div class="pl none">${k}</div>`;
    const pips=(n,m,c)=>Array.from({length:m},(_,k)=>`<i class="${k<n?'on':''}" style="--c:${c}"></i>`).join('');
    const modeH=mode==='chasse'?`<div class="pmode ch">🔎 CHASSE ${Math.ceil(chT)} s · ${'♥'.repeat(Math.max(0,part.hp))}<small>${'♡'.repeat(part.max-part.hp)}</small></div>`:turbo>0?`<div class="pmode tb">🔥 TURBO ${Math.ceil(turbo)} s · bumpers ×3</div>`:balls.length>1?`<div class="pmode mb">🎱 MULTIBILLE · points ×2</div>`:`<div class="pmode">${T.ic} ${T.n} · 🕳 ${hole.open?'ouvert':'fermé'} · NIV ${P.lv}</div>`;
    if(i<lastRank&&lastRank<99&&dn){ say('DÉPASSÉ '+dn.n.toUpperCase()+' !'); PM.fx('nice'); } lastRank=i;
    const musH=`<span class="plg mus">♪ ${PMS[SK].n} ${Math.round(PM.bpm())}<button class="pmm" data-a="pmmute">${PM.muted?'🔇':'🔊'}</button></span>`;
    const h=`<div class="plr">${cell(up,'🥇 Tu es 1er !')}${cell(all[i],'')}${cell(dn,'—')}</div><div class="plm">${musH}<div class="plg">RADAR <span class="pp">${pips(radar,NEED,'#00e5ff')}</span></div><div class="plg">TURBO <span class="pp">${pips(turbo>0?5:Math.min(5,Math.floor(turboG/5)),5,'#ff2bd6')}</span></div>${modeH}</div>`;
    if(h!==lastL){ live.innerHTML=h; lastL=h; } };
  const sim=sec=>{ let left=sec; while(left>1e-6){ const d=Math.min(left,1/240); t+=d; phys(d); left-=d; } if(msgT>0) msgT-=sec; if(comboT>0){ comboT-=sec; if(comboT<=0) combo=0; } if(nudgeCD>0) nudgeCD-=sec; tiltN=Math.max(0,tiltN-sec/5); for(const q of pops){ q.y-=30*sec; q.l-=sec; } for(let i=pops.length-1;i>=0;i--) if(pops[i].l<=0) pops.splice(i,1); for(const p of fx){ p.x+=p.vx*sec; p.y+=p.vy*sec; p.vy+=300*sec; p.l-=sec; } for(let i=fx.length-1;i>=0;i--) if(fx[i].l<=0) fx.splice(i,1); };
  let raf=0, last=0, hacc=0; const loop=ts=>{ if(!last) last=ts; const dt=Math.min(.033,(ts-last)/1000); last=ts; if(!over) sim(dt); PM.pulse*=.88; { let sp=0; for(const b of balls) if(b.st==='play') sp=Math.max(sp,Math.hypot(b.vx,b.vy)); const tI=Math.min(1,.12+sp/950+(mode?.25:0)+(turbo>0?.25:0)+(balls.length>1?.15:0)); PM.I+=(tI-PM.I)*.07; PM.mode=mode; PM.turbo=turbo>0; PM.multi=balls.length>1; } draw(); hacc+=dt; if(hacc>.1){ hacc=0; hud(); } raf=requestAnimationFrame(loop); }; hud(); raf=requestAnimationFrame(loop);
  const hold=(id,fn)=>{ const e=bar.querySelector(id); const dn=ev=>{ ev.preventDefault(); fn(true); }, up=ev=>{ ev.preventDefault(); fn(false); }; e.addEventListener('pointerdown',dn); e.addEventListener('pointerup',up); e.addEventListener('pointerleave',up); e.addEventListener('pointercancel',up); };
  const fl=i=>on=>{ if(tiltT>0) on=false; FL[i].on=on; if(on) arcTone(180,.05,'square',.05); };
  hold('#pL',fl(0)); hold('#pR',fl(1)); hold('#pP',on=>{ if(on){ charging=true; } else { charging=false; launch(); } });
  const kd=e=>{ if(e.repeat) return; if(e.code==='ArrowLeft'||e.code==='KeyA') fl(0)(true); if(e.code==='ArrowRight'||e.code==='KeyD') fl(1)(true); if(e.code==='Space'){ charging=true; e.preventDefault(); } };
  const ku=e=>{ if(e.code==='ArrowLeft'||e.code==='KeyA') fl(0)(false); if(e.code==='ArrowRight'||e.code==='KeyD') fl(1)(false); if(e.code==='Space'){ charging=false; launch(); } };
  document.addEventListener('keydown',kd); document.addEventListener('keyup',ku);
  const nudge=()=>{ if(over||nudgeCD>0||!balls.some(b=>b.st==='play')) return; nudgeCD=.9; tiltN++; balls.forEach(b=>{ if(b.st==='play'){ b.vy-=150; b.vx+=(Math.random()-.5)*180; } }); shake=.7; arcTone(90,.12,'square',.08); if(tiltN>=3.2){ tiltT=2.6; tiltN=0; say('TILT !'); arcTone(70,.5,'sawtooth',.1); } };
  cv.addEventListener('pointerdown',nudge);
  window.__pin={sim,get balls(){return balls;},get B(){return balls[0]||{x:0,y:0,vx:0,vy:0};},FL,segs,part,get score(){return score;},get ball(){return ball;},get over(){return over;},get st(){return balls[0]?balls[0].st:'none';},get mult(){return mult;},get mode(){return mode;},get radar(){return radar;},get caps(){return caps;},get turbo(){return turbo;},get nballs(){return balls.length;},get tab(){return tabI;},get hole(){return hole;},ramps,dbanks,get rampMax(){return rampMax;},loadTable,switchTable,TBL,bumps,mills,wells,portals,spins,boosts,tgt,
    launch:()=>{ power=.9; launch(); },launchP:p=>{ power=p; launch(); },nudge,get combo(){return combo;},hitC,get tilt(){return tiltT;},flip:(i,on)=>{ FL[i].on=on; },radarAdd,startChasse,capture,mission:k=>mission(balls[0]),setScore:v=>{ score=v; },lose,door,hud,N,NEED};
  return ()=>{ cancelAnimationFrame(raf); if(ro) ro.disconnect(); live.remove(); PM.end(); document.removeEventListener('keydown',kd); document.removeEventListener('keyup',ku); window.__pin=null; };
};
/* ---------- comptoir : onglets Pinball (niveau, paliers, collection) ---------- */
const _arcSheet23=arcSheet;
arcSheet=function(X){
  if(!sheet||sheet.t!=='arcprix') return false; _arcSheet23(X); const P=pbS(), LV=P.lv, el=$('sheet').querySelector('.inv'); if(!el) return true;
  const dex=UNIQ.slice(PB_UN0).map((u,i)=>{ const n=P.got[PB_UN0+i]||0, sl=SLOTS.find(s=>s[0]===MODI[u.t][1]); return `<div class="dx ${n?'ok':''}"><span class="dxi">${n?sl[2]:'❔'}</span><b>${n?u.n:'???'}</b><small>${n?u.d+(n>1?` · ★${Math.min(5,n-1)}`:''):sl[1]}</small></div>`; }).join('');
  const html=`<h3 class="rh">🎰 Pinball · niveau ${LV}${LV>=PB_MAXLV?' (max)':''}</h3><div class="pbxp"><i style="width:${LV>=PB_MAXLV?100:Math.round(P.xp/pbNeed(LV)*100)}%"></i></div>
   <p class="note">Radar : ${pbPerk.need(LV)} charges · Ball save ${pbPerk.save(LV).toFixed(1).replace('.',',')} s · ${pbPerk.balls(LV)} billes · pièces d’arcade ${Math.round(pbPerk.arcP(LV)*100)} % · captures : ${P.caps}</p>
   <h3 class="rh">🏆 Paliers (score en une partie)</h3>${PB_PAL.map(p=>`<div class="inv-r ${P.pal[p.s]?'':'lock'}"><span class="inv-i">${P.pal[p.s]?'✅':'🎯'}</span><div class="inv-t"><b>${fmt(p.s)} points</b><small>${p.n}</small></div></div>`).join('')}
   <h3 class="rh">📖 Pièces d’arcade (${Object.keys(P.got).length}/${UNIQ.length-PB_UN0})</h3><div class="dxg">${dex}</div>`;
  const h3=[...el.querySelectorAll('h3.rh')].find(x=>/Classements/.test(x.textContent)); if(h3) h3.insertAdjacentHTML('beforebegin',html); else el.insertAdjacentHTML('beforeend',html); return true; };
/* ===== v0.46 : monde 3D en portrait uniquement (le mode paysage est supprimé) ===== */
const _rot24=rotNow;
rotNow=function(on){ return _rot24(false); };
const _hubMode24=hubMode;
hubMode=function(){ _hubMode24.apply(this,arguments); try{ document.body.classList.remove('hubland'); if(S.hubLand) S.hubLand=false; }catch(_){} };
const _glSize24=glSize;
glSize=function(){ _glSize24.apply(this,arguments);
  try{ if(view==='hub'&&GL.cam&&GL.cam.isPerspectiveCamera&&GL.cam.aspect){ const a=GL.cam.aspect, f=a<1?Math.min(108,2*Math.atan(Math.tan(41*Math.PI/180)/a)*180/Math.PI):100; if(Math.abs(GL.cam.fov-f)>.5){ GL.cam.fov=f; GL.cam.updateProjectionMatrix(); } } }catch(_){} };
ACT.hubrot=()=>{};
/* ===== v0.45 : moteur de musique du pinball (techno / drum & bass / dubstep / hard), suit la vitesse ===== */
const PMS={
 techno:{n:'TECHNO',bpm:128,th:{a:'#00e5ff',b:'#ff2bd6',c:['#ffd400','#1fe06a','#ff2d2d'],bg:['#0c0620','#1a0a2e'],grid:'rgba(120,90,255,.12)'}},
 dnb:{n:'DRUM & BASS',bpm:172,th:{a:'#3cff9e',b:'#ffd400',c:['#00e5ff','#ff2bd6','#ff9a1a'],bg:['#03140c','#0b2a1c'],grid:'rgba(60,255,158,.12)'}},
 dub:{n:'DUBSTEP',bpm:140,th:{a:'#b05cff',b:'#ff7a1a',c:['#ff2bd6','#00e5ff','#ffd400'],bg:['#14041f','#2a0838'],grid:'rgba(176,92,255,.14)'}},
 hard:{n:'HARD TECHNO',bpm:150,th:{a:'#ff3b3b',b:'#ffffff',c:['#ffd400','#ff7a1a','#ff2bd6'],bg:['#1a0404','#2e0a0a'],grid:'rgba(255,60,60,.14)'}}
};
const pmStyleOf=lv=>lv>=15?'hard':lv>=10?'dub':lv>=5?'dnb':'techno';
const PM={ctx:null,on:false,timer:0,next:0,step:0,key:'techno',I:0,mode:null,turbo:false,multi:false,pulse:0,muted:false,master:null,nbuf:null,dist:null,lv:1,vol:0};
PM.volTarget=()=>{ let v=.5; try{ const a=S.audio||{}; if(a.mute) return 0; v=.5*(a.master==null?.9:a.master)*(a.music==null?.7:a.music)/.63; }catch(_){} return PM.muted?0:v; };
PM.setVol=()=>{ if(PM.master&&PM.ctx) PM.master.gain.setTargetAtTime(PM.volTarget(),PM.ctx.currentTime,.15); };
PM.begin=function(key,lv){
  if(PM.on) PM.end(true); const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
  try{ PM.ctx=PM.ctx||new AC(); const c=PM.ctx; if(c.state==='suspended') c.resume();
    PM.master=c.createGain(); PM.master.gain.value=0; const cp=c.createDynamicsCompressor(); cp.threshold.value=-14; cp.ratio.value=5; PM.master.connect(cp); cp.connect(c.destination);
    if(!PM.nbuf){ const len=c.sampleRate, b=c.createBuffer(1,len,c.sampleRate), d=b.getChannelData(0); for(let i=0;i<len;i++) d[i]=Math.random()*2-1; PM.nbuf=b; }
    const cv=new Float32Array(1024); for(let i=0;i<1024;i++){ const x=i/512-1; cv[i]=Math.tanh(x*4); } PM.dist=c.createWaveShaper(); PM.dist.curve=cv; PM.dist.connect(PM.master);
    PM.on=true; PM.key=key; PM.lv=lv; PM.step=0; PM.I=0; PM.mode=null; PM.turbo=false; PM.multi=false; PM.next=c.currentTime+.12; PM.timer=setInterval(PM.sched,50); PM.setVol(); try{ ambMute(true); }catch(_){} }catch(e){ PM.on=false; console.error(e); } };
PM.end=function(quick){
  if(!PM.on) return; PM.on=false; clearInterval(PM.timer); const m=PM.master, c=PM.ctx; try{ m.gain.setTargetAtTime(0,c.currentTime,quick?.02:.25); setTimeout(()=>{ try{ m.disconnect(); }catch(_){} },quick?200:1200); }catch(_){}
  if(!quick){ try{ if(!WM.on) ambMute(false); }catch(_){} } };
PM.bpm=()=>PMS[PM.key].bpm*(.95+.1*PM.I)*(PM.turbo?1.05:1);
PM.sched=function(){ const c=PM.ctx; if(!PM.on||!c) return; let g=0; while(PM.next<c.currentTime+.28&&g++<16){ try{ PM.stepAt(PM.step,PM.next); }catch(e){ console.error(e); } PM.next+=60/PM.bpm()/4; PM.step=(PM.step+1)%64; } };
const hzm=m=>440*Math.pow(2,(m-69)/12);
PM._env=(t,g,v,a,d)=>{ g.gain.setValueAtTime(0.0001,t); g.gain.linearRampToValueAtTime(v,t+a); g.gain.exponentialRampToValueAtTime(.0003,t+a+d); };
PM.kick=(t,v,hard)=>{ const c=PM.ctx, o=c.createOscillator(), g=c.createGain(); o.type='sine'; o.frequency.setValueAtTime(hard?190:150,t); o.frequency.exponentialRampToValueAtTime(42,t+.13); g.gain.setValueAtTime(v,t); g.gain.exponentialRampToValueAtTime(.001,t+(hard?.34:.26)); o.connect(g); g.connect(hard?PM.dist:PM.master); o.start(t); o.stop(t+.4);
  const d=(t-c.currentTime)*1000; setTimeout(()=>{ PM.pulse=1; },Math.max(0,d)); };
PM.noise=(t,dur,v,type,f,q)=>{ const c=PM.ctx, s=c.createBufferSource(), fl=c.createBiquadFilter(), g=c.createGain(); s.buffer=PM.nbuf; fl.type=type; fl.frequency.value=f; if(q) fl.Q.value=q; g.gain.setValueAtTime(v,t); g.gain.exponentialRampToValueAtTime(.0005,t+dur); s.connect(fl); fl.connect(g); g.connect(PM.master); s.start(t,Math.random()*.5); s.stop(t+dur+.02); };
PM.snare=(t,v)=>{ PM.noise(t,.2,v,'bandpass',1900,.8); const c=PM.ctx, o=c.createOscillator(), g=c.createGain(); o.type='triangle'; o.frequency.setValueAtTime(220,t); o.frequency.exponentialRampToValueAtTime(150,t+.08); g.gain.setValueAtTime(v*.7,t); g.gain.exponentialRampToValueAtTime(.001,t+.14); o.connect(g); g.connect(PM.master); o.start(t); o.stop(t+.18); };
PM.clap=(t,v)=>{ [0,.012,.024].forEach(d=>PM.noise(t+d,.1,v,'bandpass',1500,1)); PM.noise(t+.03,.16,v*.7,'bandpass',1200,.6); };
PM.hat=(t,v,open)=>PM.noise(t,open?.2:.045,v,'highpass',7500);
PM.bassv=(t,m,dur,v,type,cut,q,sweep)=>{ const c=PM.ctx, o=c.createOscillator(), f=c.createBiquadFilter(), g=c.createGain(); o.type=type||'sawtooth'; o.frequency.value=hzm(m); f.type='lowpass'; f.Q.value=q||4; f.frequency.setValueAtTime(sweep?cut*3.2:cut,t); if(sweep) f.frequency.exponentialRampToValueAtTime(cut,t+dur*.8); g.gain.setValueAtTime(v,t); g.gain.setValueAtTime(v,t+dur*.8); g.gain.exponentialRampToValueAtTime(.0005,t+dur); o.connect(f); f.connect(g); g.connect(PM.master); o.start(t); o.stop(t+dur+.03); };
PM.reese=(t,m,dur,v,cut)=>{ const c=PM.ctx, f=c.createBiquadFilter(), g=c.createGain(); f.type='lowpass'; f.Q.value=6; f.frequency.setValueAtTime(cut,t); f.frequency.linearRampToValueAtTime(cut*1.8,t+dur*.5); f.frequency.linearRampToValueAtTime(cut,t+dur); g.gain.setValueAtTime(v,t); g.gain.setValueAtTime(v,t+dur*.85); g.gain.exponentialRampToValueAtTime(.0005,t+dur); f.connect(g); g.connect(PM.master); [-9,9].forEach(dt=>{ const o=c.createOscillator(); o.type='sawtooth'; o.frequency.value=hzm(m); o.detune.value=dt; o.connect(f); o.start(t); o.stop(t+dur+.03); }); };
PM.wob=(t,m,dur,v,rate)=>{ const c=PM.ctx, f=c.createBiquadFilter(), g=c.createGain(), l=c.createOscillator(), lg=c.createGain(); f.type='lowpass'; f.Q.value=9; f.frequency.value=700; l.frequency.value=rate; lg.gain.value=650; l.connect(lg); lg.connect(f.frequency); g.gain.setValueAtTime(v,t); g.gain.setValueAtTime(v,t+dur*.9); g.gain.exponentialRampToValueAtTime(.0005,t+dur); f.connect(g); g.connect(PM.master); [0,7].forEach(dt=>{ const o=c.createOscillator(); o.type=dt?'square':'sawtooth'; o.frequency.value=hzm(m); o.detune.value=dt; o.connect(f); o.start(t); o.stop(t+dur+.03); }); l.start(t); l.stop(t+dur+.03);
  const s=c.createOscillator(), sg=c.createGain(); s.type='sine'; s.frequency.value=hzm(m-12); sg.gain.setValueAtTime(v*.8,t); sg.gain.exponentialRampToValueAtTime(.0005,t+dur); s.connect(sg); sg.connect(PM.master); s.start(t); s.stop(t+dur+.03); };
PM.lead=(t,m,dur,v,type,cut)=>{ const c=PM.ctx, o=c.createOscillator(), f=c.createBiquadFilter(), g=c.createGain(); o.type=type||'square'; o.frequency.value=hzm(m); f.type='lowpass'; f.frequency.value=cut||3200; g.gain.setValueAtTime(v,t); g.gain.exponentialRampToValueAtTime(.0005,t+dur); o.connect(f); f.connect(g); g.connect(PM.master); o.start(t); o.stop(t+dur+.03); };
PM.pad=(t,m,dur,v)=>{ [0,3,7].forEach((iv,k)=>[-8,8].forEach(dt=>{ const c=PM.ctx, o=c.createOscillator(), f=c.createBiquadFilter(), g=c.createGain(); o.type='sawtooth'; o.frequency.value=hzm(m+12+iv); o.detune.value=dt; f.type='lowpass'; f.frequency.value=1100; g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(v/6,t+dur*.2); g.gain.exponentialRampToValueAtTime(.0004,t+dur); o.connect(f); f.connect(g); g.connect(PM.master); o.start(t); o.stop(t+dur+.05); })); };
PM.riser=(t,dur,v)=>{ const c=PM.ctx, s=c.createBufferSource(), f=c.createBiquadFilter(), g=c.createGain(); s.buffer=PM.nbuf; s.loop=true; f.type='bandpass'; f.Q.value=2; f.frequency.setValueAtTime(300,t); f.frequency.exponentialRampToValueAtTime(7000,t+dur); g.gain.setValueAtTime(.0001,t); g.gain.linearRampToValueAtTime(v,t+dur); g.gain.linearRampToValueAtTime(0,t+dur+.05); s.connect(f); f.connect(g); g.connect(PM.master); s.start(t); s.stop(t+dur+.1); };
const PM_ROOT=[33,33,29,31], PENT=[0,3,5,7,10,12,15,17];
PM.stepAt=function(s,t){
  const bar=s>>4, st=s&15, root=PM_ROOT[bar], I=PM.I, k=PM.key, tens=PM.mode==='chasse', turbo=PM.turbo, multi=PM.multi, bt=60/PM.bpm()/4;
  const arp=(every,base,oct)=>{ if(st%every===0){ const n=PENT[(s*3+bar)%PENT.length]; PM.lead(t,base+n+(oct||0),bt*every*.8,.05+.03*I,'square',2400+I*2500); } };
  const x=(pat)=>pat[st]==='x';
  if(k==='techno'){
    if(st%4===0) PM.kick(t,.9);
    if(st%4===2) PM.hat(t,.16+.06*I); if(I>.35&&st%2===1) PM.hat(t,.06+.04*I); if(bar===3&&st===14) PM.hat(t,.18,true);
    if(st===4||st===12){ PM.clap(t,.2+.1*I); }
    if(st%4===2) PM.bassv(t,root+(bar%2?12:0),bt*1.6,.3,'sawtooth',280+I*1100,5);
    if(I>.5&&x('x.xxx.xx.x.xxx.x')) PM.bassv(t,root+24+[0,3,0,7,0,12,3,0][(s>>1)&7],bt*.9,.1,'sawtooth',500+I*900,12,true);
    if(st===0&&I>.2) PM.pad(t,root+12,bt*16,.16);
  } else if(k==='dnb'){
    if(st===0||st===10) PM.kick(t,.85); if(st===4||st===12) PM.snare(t,.42+.12*I); if(st===7||(I>.5&&st===15)) PM.snare(t,.12);
    if(st%2===0) PM.hat(t,.1+.05*I,st===14); else if(I>.3) PM.hat(t,.05);
    if(st===0||st===8) PM.reese(t,root+12,bt*8,.2+.06*I,380+I*900);
    if(I>.55) arp(2,root+36);
  } else if(k==='dub'){
    if(st===0||st===10) PM.kick(t,.9); if(st===8){ PM.snare(t,.55); PM.clap(t,.3); }
    if(st%2===0) PM.hat(t,.09+.04*I); if(I>.5&&st%2===1) PM.hat(t,.04);
    if(st===0||st===8){ const rate=PM.bpm()/60*([1,1.5,2,3][bar]); PM.wob(t,root+(st===8&&bar%2?3:0),bt*8,.22+.06*I,rate*1.5); }
    if(bar===3&&st>=12&&I>.3) PM.snare(t,.2+(st-12)*.06);
    if(st===0&&bar===3&&I>.4) PM.riser(t,bt*16,.12);
  } else {
    if(st%4===0) PM.kick(t,.95,true);
    if(st%4!==0&&x('.xxx.xxx.xxx.xxx')) PM.bassv(t,root+((s>>2)&1?12:0),bt*.8,.22,'sawtooth',420+I*800,3);
    if(st%2===1) PM.hat(t,.12,true); if(st===4||st===12) PM.clap(t,.28);
    if(I>.55&&(st===0||st===6||st===10)) PM.lead(t,root+36+[0,7,3,10][bar],bt*2.2,.08,'sawtooth',3800);
  }
  if(tens){ if(st%2===0) arp(2,root+36+7); PM.hat(t,.07); if(st===0&&bar%2===0) PM.riser(t,bt*8,.07); }
  if(turbo&&st%4===0) PM.lead(t,root+48,bt*1.4,.06,'sawtooth',4500);
  if(multi&&st%2===0) arp(2,root+24+5);
};
PM.fx=function(kind){ if(!PM.on||PM.muted) return; const c=PM.ctx, t=c.currentTime+.01;
  if(kind==='capture'){ [0,4,7,12,16].forEach((n,i)=>PM.lead(t+i*.07,72+n,.35,.12,'triangle',6000)); PM.noise(t,.5,.12,'highpass',5000); }
  else if(kind==='drain'){ const o=c.createOscillator(), g=c.createGain(); o.type='sawtooth'; o.frequency.setValueAtTime(420,t); o.frequency.exponentialRampToValueAtTime(40,t+.6); g.gain.setValueAtTime(.15,t); g.gain.exponentialRampToValueAtTime(.0005,t+.65); o.connect(g); g.connect(PM.master); o.start(t); o.stop(t+.7); }
  else if(kind==='nice'){ [0,7].forEach((n,i)=>PM.lead(t+i*.06,76+n,.25,.1,'square',5000)); }
  else if(kind==='skill'){ [0,5,9,14].forEach((n,i)=>PM.lead(t+i*.05,69+n,.3,.1,'sawtooth',5000)); }
  else if(kind==='over'){ [12,7,3,0].forEach((n,i)=>PM.lead(t+i*.14,60+n,.5,.12,'sawtooth',1800)); } };
ACT.pmmute=()=>{ PM.muted=!PM.muted; PM.setVol(); const b=document.querySelector('.pmm'); if(b) b.textContent=PM.muted?'🔇':'🔊'; };
/* ===== v0.47 : PISTE D'ESSAI — tout le circuit de Spa-Francorchamps, chrono par secteur, records ===== */
const PT_SEC=[{n:'S1',nom:'La Source → Les Combes',a:0,b:2650},{n:'S2',nom:'Malmedy → Pouhon → Campus',a:2650,b:5200},{n:'S3',nom:'Stavelot → Blanchimont → Bus Stop',a:5200,b:null}];
const PT_REFV=1, PT_BENCH=['piccola','riva','touge','gts','rossa','aurion'];
function ptS(){ return S.ptest||(S.ptest={rec:{},best:{},hist:[],ref:{},refv:PT_REFV,laps:0}); }
const ptT=(t)=>{ if(t==null||!isFinite(t)) return '—'; const m=Math.floor(t/60), s=t-m*60; return (m?m+':':'')+(m&&s<10?'0':'')+s.toFixed(3).replace('.',','); };
const ptMark=(L,j)=>Math.floor(j/3)*L+[0,2650,5200][j%3];
function ptNew(s0){ const L=TRK.L; let u=s0; if(u>L/2) u-=L; return {L,u,prev:s0,next:0,mk:[],lapV:0,secV:[0,0,0],offT:0,valid:true,laps:[],ev:[],nit:0,secN:[],t0:0}; }
/* avance le chrono : s = abscisse sur la piste, t = temps de la séance, v en m/s */
function ptStep(T,s,t,h,v,onPave){
  const L=T.L, d=dS(s,T.prev); T.prev=s; if(Math.abs(d)>60){ T.valid=false; return; }
  const u0=T.u; T.u+=d; if(T.next>0){ const sec=(T.next-1)%3; if(v>T.secV[sec]) T.secV[sec]=v; if(v>T.lapV) T.lapV=v; if(!onPave) T.offT+=h; }
  while(T.u>=ptMark(L,T.next)){
    const j=T.next, m=ptMark(L,j), fr=T.u>u0?Math.max(0,Math.min(1,(m-u0)/(T.u-u0))):1, tc=t-h+h*fr; T.mk[j]=tc; T.next++;
    if(j%3===0){
      if(j>0){ const n=j/3, t0=T.mk[j-3], lap=tc-t0, sc=[T.mk[j-2]-T.mk[j-3],T.mk[j-1]-T.mk[j-2],tc-T.mk[j-1]], len=[2650,2550,L-5200];
        const rec={n,t:lap,s:sc,vmax:T.lapV*3.6,secV:T.secV.map(x=>x*3.6),secA:sc.map((x,k)=>len[k]/x*3.6),vavg:L/lap*3.6,valid:T.valid&&T.offT<=3&&n>1,off:T.offT,nit:T.nit,out:n===1};
        T.laps.push(rec); T.ev.push({k:'lap',rec}); }
      T.lapV=0; T.secV=[0,0,0]; T.offT=0; T.valid=true; T.nit=0;
    } else { const k=(j%3)-1, st=tc-T.mk[j-1]; T.ev.push({k:'sec',i:k,t:st,vmax:T.secV[k]*3.6}); }
  }
  while(T.next>0&&T.u<ptMark(L,T.next-1)){ T.next--; T.valid=false; }
}
/* enregistre un tour terminé ; renvoie {pb,rec,sec:[...]} */
function ptRecord(card,m,r){
  const P=ptS(), key=card.uid+'|'+m, old=P.rec[key], B=P.best[m]||(P.best[m]={s:[null,null,null],lap:null}); const out={pb:false,secPb:[false,false,false],secRec:[false,false,false]};
  P.laps++; P.hist.unshift({uid:card.uid,mid:card.mid,m,t:r.t,s:r.s,vmax:r.vmax,valid:r.valid,ts:Date.now()}); P.hist.length=Math.min(P.hist.length,40);
  if(!r.valid) return out;
  const o=old||(P.rec[key]={uid:card.uid,mid:card.mid,nom:M[card.mid].nom,m,lap:null,s:[null,null,null],sv:[0,0,0],vmax:0,vavg:0,ts:0});
  o.mid=card.mid; o.nom=M[card.mid].nom; o.up=ptPow(card);
  if(o.lap==null||r.t<o.lap){ o.lap=r.t; o.vmax=r.vmax; o.vavg=r.vavg; o.ts=Date.now(); o.ls=r.s.slice(); out.pb=true; }
  r.s.forEach((x,k)=>{ if(o.s[k]==null||x<o.s[k]){ o.s[k]=x; out.secPb[k]=true; } if(r.secV[k]>(o.sv[k]||0)) o.sv[k]=r.secV[k]; if(B.s[k]==null||x<B.s[k]){ B.s[k]=x; out.secRec[k]=true; } });
  if(B.lap==null||r.t<B.lap){ B.lap=r.t; out.rec=true; }
  return out;
}
function ptPow(c){ try{ const s=st(c); return {ch:Math.round(s.ch||s.pui||0),kg:Math.round(s.kg||0),vm:Math.round(s.vmax||0)}; }catch(_){ return null; } }
/* ---------- séance en direct ---------- */
const PTUI={m:'sec'};
const isPT=()=>!!(RC&&R&&R.test&&RC.kind==='spa');
function ptStart(uid,m){
  if(!TRK.ready||!glEnsure()||!window.THREE) return toast('Le circuit se charge ou la 3D est indisponible');
  const c=car(uid); if(!c) return; closeSheet();
  const mn={d:'circuit',m:m||PTUI.m||'sec',sp:'tour',test:1};
  R={ev:{id:'test',nom:'Piste d’essai',manches:[mn],opp:{},lvl:0,gain:0},pick:[uid],opps:[[]],auto:false,rows:[],i:0,test:1};
  try{ startSpa(0); }catch(e){ console.error(e); } if(!RC) return; RC.test=true; RC.O={pil:'',prog:0}; RC.len=TRK.L; RC.pos=1; RC.T=ptNew(RC.P.s); RC.tm=m||PTUI.m||'sec'; RC.cardU=uid; RC.sess=[]; RC.pbMsg=null;
}
function tickTest(h){
  const P=RC.P, T=RC.T; RC.clock+=h; const t=RC.clock;
  if(t<0){ if(inThr()>.05&&P.penSet==null){ P.penSet=1; P.pen=.8; flash('Faux départ, moteur coupé 0,8 s','#FF4D6D',1.6); } T.prev=P.s; return; }
  if(!P.go){ P.go=true; if(inThr()>.05&&!P.penSet) flash(t<.3?'Départ parfait':'Parti','#3CFF9E',.9); }
  const inp={steer:inSteer(),thr:inThr(),brake:RC.inp.b||RC.inp.kb,hand:RC.inp.hand};
  const nit0=P.nit||0;
  carStep(P,inp,h); carWorld(P,h); P.thrNow=inp.thr; P.braking=!!inp.brake; driftTick(P,h);
  if((P.nit||0)>nit0) T.nit++;
  const fr=frameAt(P.s), al=P.vx*Math.cos(fr.th)+P.vz*Math.sin(fr.th);
  P.wrongT=(al<-4)?P.wrongT+h:0; P.stuckT=(P.v<1.2)?P.stuckT+h:0;
  ptStep(T,P.s,t,h,P.v,P.onPave);
  while(T.ev.length){ const e=T.ev.shift(); ptEvent(e); }
  if(P.msgHit==null&&P.hitFlash>.6){ P.msgHit=1; flash('Choc !','#FF4D6D',.8); } if(P.hitFlash<.1) P.msgHit=null;
}
function ptEvent(e){
  const c=car(RC.cardU), m=RC.tm, P=ptS(), o=P.rec[c.uid+'|'+m], B=P.best[m]||{s:[null,null,null]};
  if(e.k==='sec'){ const pb=o&&o.s[e.i], gb=B.s[e.i], d=pb!=null?e.t-pb:null; const col=gb!=null&&e.t<gb?'#B05CFF':pb!=null&&e.t<pb?'#3CFF9E':'#FCEE0A';
    RC.secShow=RC.secShow||{}; RC.secShow[e.i]={t:e.t,col,d,v:e.vmax}; flash(`S${e.i+1}  ${ptT(e.t)}${d!=null?`  (${d>=0?'+':''}${d.toFixed(3).replace('.',',')})`:''}`,col,2.4); }
  else { const r=e.rec, res=ptRecord(c,m,r); r.res=res; RC.sess.push(r); RC.last=r; RC.secShow={};
    const col=!r.valid?'#FF4D6D':res.rec?'#B05CFF':res.pb?'#3CFF9E':'#FCEE0A';
    flash(r.out?`Tour de lancement ${ptT(r.t)}`:r.valid?`${res.rec?'RECORD ':res.pb?'MEILLEUR PERSO ':''}TOUR ${ptT(r.t)}`:`Tour invalide (${r.off>3?'hors piste':'remise en piste'}) ${ptT(r.t)}`,col,3.2); save(); if(r.valid&&!r.out) auTry(()=>ui(res.rec?'up':'coins')); }
}
const _tickSpa26=tickSpa; tickSpa=function(h){ if(isPT()){ if(RC.T) tickTest(h); return; } return _tickSpa26.apply(this,arguments); };
const _vSpa26=vSpa;
vSpa=function(){ let h=_vSpa26.apply(this,arguments); if(!isPT()) return h.replace('<button class="btn alt sm" id="bResp"',`<button class="btn alt sm" id="bCam" data-a="ptcam">${ptCamTx()}</button><button class="btn alt sm" id="bResp"`);
  h=h.replace('<div class="race">','<div class="race ptest">').replace(/<span>Manche [^<]*<\/span>/,'<span>🏁 Piste d’essai · Spa</span>').replace('<div class="prog2"><i id="hProg"></i></div>','').replace('<button class="btn alt sm" id="bResp"',`<button class="btn alt sm" id="bCam" data-a="ptcam">${ptCamTx()}</button><button class="btn alt sm" id="bResp"`).replace('Remettre en piste (+5 s)','Remettre en piste').replace('>Abandonner<','>Terminer la séance<'); const i=h.lastIndexOf('</div>'); return h.slice(0,i)+'<div class="ptp" id="ptp"></div>'+h.slice(i); };
const _hud26=hudSpa; hudSpa=function(){ _hud26.apply(this,arguments); if(isPT()&&RC.T){ try{ ptHud(); }catch(e){ console.error(e); } } };
let ptHudT=0;
function ptHud(){
  const e=document.getElementById('ptp'); if(!e) return; const now=performance.now(); if(now-ptHudT<120) return; ptHudT=now;
  const T=RC.T, t=RC.clock, c=car(RC.cardU), P=ptS(), o=P.rec[c.uid+'|'+RC.tm], B=P.best[RC.tm]||{s:[null,null,null],lap:null};
  const lapNo=T.next>0?Math.floor((T.next-1)/3)+1:0, j0=lapNo?3*(lapNo-1):0, tl=lapNo?t-T.mk[j0]:0, cur=T.next>0?(T.next-1)%3:-1;
  const sh=RC.secShow||{}, chips=[0,1,2].map(k=>{ let tx='—', cl=''; if(sh[k]){ tx=ptT(sh[k].t); cl='d '+(sh[k].col==='#B05CFF'?'pur':sh[k].col==='#3CFF9E'?'grn':'yel'); } else if(k===cur){ tx=ptT(t-T.mk[T.next-1]); cl='cur'; } return `<i class="${cl}"><em>S${k+1}</em>${tx}</i>`; }).join('');
  const last=RC.last, bad=lapNo&&(!T.valid||T.offT>3);
  const h=`<div class="ptl"><b>${lapNo?(lapNo===1?'TOUR DE LANCEMENT':'TOUR '+lapNo):'DÉPART'}</b><span class="ptt">${lapNo?ptT(tl):'—'}</span></div><div class="pts">${chips}</div><div class="ptb"><span>Dernier <b>${last?ptT(last.t):'—'}</b></span><span>Record <b>${o&&o.lap!=null?ptT(o.lap):'—'}</b></span><span>Vmax <b>${Math.round(Math.max(T.lapV*3.6,0))}</b></span></div>${bad?'<div class="ptw">⚠ Tour invalide : '+(T.offT>3?'trop de temps hors piste':'remise en piste')+'</div>':''}`;
  if(e._h!==h){ e._h=h; e.innerHTML=h; }
}
const _resp26=respawnPlayer;
respawnPlayer=function(){ if(isPT()){ if(RC.done||RC.clock<0||!RC.T) return; respawn(RC.P); RC.T.valid=false; flash('Remise en piste : tour invalidé','#FCEE0A',1.6); ui('respawn'); return; } return _resp26.apply(this,arguments); };
const _fn26=fireNitro;
fireNitro=function(){ if(isPT()){ const had=S.nitro; S.nitro=Math.max(1,S.nitro); try{ _fn26(); }finally{ S.nitro=had; } const b=$('pNit'); if(b){ const sm=b.querySelector('small'); if(sm) sm.textContent='∞'; } return; } return _fn26.apply(this,arguments); };
function ptExit(){ const um=RC&&RC.sess?RC.sess.slice():[]; leaveRace(); R=null; view='hub'; PTUI.last=um; render(); openSheet({t:'ptest'}); }
const _quit26=ACT.quit; ACT.quit=function(){ if(isPT()) return ptExit(); return _quit26.apply(this,arguments); };
/* ---------- références : un pilote IA fait un tour lancé avec la voiture de série ---------- */
function ptRefJob(mid,m){ const card={uid:-1,mid,etat:100,xp:0,lvl:1,up:{},inv:0,mods:{}}, mn={d:'circuit',m:m||'sec'}, r=mkRacer(card,mn,{skill:.93,err:0,react:0}), c=mkSpaCar(r,r.m,TRK.L-8,0,100);
  c.mass=Math.max(80,st(card).kg); c.go=true; c.dr={pts:0,chain:0,t:0,grace:0,mult:1,best:0,n:0,live:false}; const prof=aiProfile(r,.93), v0=Math.min(prof[c.i]||20,r.VM*.9); c.vx=Math.cos(c.psi)*v0; c.vz=Math.sin(c.psi)*v0;
  return {mid,m,r,c,prof,T:ptNew(c.s),t:0,done:false,res:null}; }
function ptRefRun(J,steps){ for(let k=0;k<steps&&!J.done;k++){ const h=1/120; const inp=aiControl(J.c,J.prof,0,.93); carStep(J.c,inp,h); carWorld(J.c,h); J.t+=h; ptStep(J.T,J.c.s,J.t,h,J.c.v,J.c.onPave);
    if(J.T.laps.length){ const l=J.T.laps[0]; J.done=true; J.res={t:l.t,s:l.s,vmax:l.vmax,vavg:l.vavg,valid:l.valid}; } else if(J.t>480){ J.done=true; J.res=null; } } }
let PTR=null;
function ptRefAll(){
  if(PTR||!TRK.ready) return; const P=ptS(); if(P.refv!==PT_REFV){ P.ref={}; P.refv=PT_REFV; }
  const m=PTUI.m, mids=[...new Set(PT_BENCH.concat(S.cars.map(c=>c.mid)))].filter(id=>M[id]&&!(M[id].noAI)&&!P.ref[id+'|'+m]); if(!mids.length) return;
  PTR={q:mids,n:0,tot:mids.length,m,J:null};
  const pump=()=>{ if(!PTR) return; try{ if(!PTR.J){ const id=PTR.q.shift(); if(!id){ PTR=null; save(); if(sheet&&sheet.t==='ptrank') renderSheet(); return; } PTR.J=ptRefJob(id,PTR.m); }
      ptRefRun(PTR.J,2500); if(PTR.J.done){ ptS().ref[PTR.J.mid+'|'+PTR.m]=PTR.J.res||{t:null}; PTR.J=null; PTR.n++; save(); if(sheet&&sheet.t==='ptrank') renderSheet(); } }catch(e){ console.error(e); PTR=null; return; } setTimeout(pump,8); };
  setTimeout(pump,20); if(sheet&&sheet.t==='ptrank') renderSheet(); }
/* ---------- feuilles ---------- */
const WNAME={sec:'☀️ Sec',pluie:'🌧️ Pluie',neige:'❄️ Neige'};
function ptSheet(X){
  if(!sheet||(sheet.t!=='ptest'&&sheet.t!=='ptrank')) return false; const P=ptS(), m=PTUI.m;
  const chips=Object.keys(WNAME).map(k=>`<button class="chip ${k===m?'on':''}" data-a="ptw" data-id="${k}">${WNAME[k]}</button>`).join('');
  if(sheet.t==='ptest'){
    const rows=S.cars.map(c=>{ const o=P.rec[c.uid+'|'+m], mm=M[c.mid]; return `<div class="inv-r"><span class="inv-i">🏎️</span><div class="inv-t"><b>${mm.nom}${c.sh?' ✨':''}</b><small>${o&&o.lap!=null?`Record ${ptT(o.lap)} · Vmax ${Math.round(o.vmax)} km/h`:'Pas encore de chrono'} · état ${c.etat} %</small></div><button class="btn sm" data-a="ptgo" data-id="${c.uid}">Rouler</button></div>`; }).join('');
    const um=PTUI.last&&PTUI.last.length?`<h3 class="rh">Dernière séance</h3>${PTUI.last.map(r=>`<div class="inv-r ${r.valid?'':'lock'}"><span class="inv-i">${r.out?'🚦':r.valid?(r.res&&r.res.rec?'🟣':r.res&&r.res.pb?'🟢':'⏱️'):'⚠️'}</span><div class="inv-t"><b>Tour ${r.n} · ${ptT(r.t)}</b><small>${r.s.map((x,k)=>'S'+(k+1)+' '+ptT(x)).join(' · ')} · Vmax ${Math.round(r.vmax)}</small></div></div>`).join('')}`:'';
    $('sheet').innerHTML=`<div class="inv">${X}<h2>🏁 Piste d’essai</h2><p class="note">Tout le circuit de Spa-Francorchamps (7,05 km) rien que pour toi : pas d’adversaires, vraies barrières, vibreurs, herbe, gravier et sable. Le chrono découpe chaque tour en 3 secteurs. Le premier tour est un tour de lancement, il ne compte pas pour les records. Remise en piste ou plus de 3 s hors piste : tour invalide. Nitro illimitée.</p>
     <div class="chips" style="margin:8px 0">${chips}</div>${TRK.ready?'':'<p class="note">⏳ Le circuit se charge…</p>'}${rows}${um}
     <div class="brow" style="margin-top:10px"><button class="btn alt" data-a="ptrank">📊 Records & comparaison</button></div></div>`; return true; }
  /* classement / comparaison */
  const B=P.best[m]||{s:[null,null,null],lap:null}, mine=Object.values(P.rec).filter(o=>o.m===m&&o.lap!=null).sort((a,b)=>a.lap-b.lap), lead=mine[0];
  const col=(x,k,o)=>x==null?'':(B.s[k]!=null&&x<=B.s[k]+1e-6?'pur':x<=o.s[k]+1e-6?'grn':'');
  const tab=mine.length?`<div class="ptab"><div class="ptr hd"><b>#</b><b>Voiture</b><b>Tour</b><b>S1</b><b>S2</b><b>S3</b><b>Vmax</b></div>${mine.map((o,i)=>`<div class="ptr"><span>${i+1}</span><span class="nm">${o.nom}${car(o.uid)?'':' (vendue)'}${o.up?`<small>${o.up.ch} ch · ${o.up.kg} kg</small>`:''}</span><span class="tl">${ptT(o.lap)}${i?`<small>+${(o.lap-lead.lap).toFixed(3).replace('.',',')}</small>`:''}</span>${o.s.map((x,k)=>`<span class="${col(x,k,o)}">${ptT(x)}</span>`).join('')}<span>${Math.round(o.vmax)}</span></div>`).join('')}</div>`:'<p class="note">Aucun tour valide pour l’instant dans ces conditions. Roule au moins 2 tours.</p>';
  const refs=PT_BENCH.concat(S.cars.map(c=>c.mid)).filter((x,i,a)=>a.indexOf(x)===i).map(id=>({id,r:P.ref[id+'|'+m]})).filter(x=>x.r&&x.r.t!=null);
  const all=refs.map(x=>({n:M[x.id].nom,t:x.r.t,v:x.r.vmax,kind:'ref'})).concat(mine.map(o=>({n:o.nom+' · ta voiture',t:o.lap,v:o.vmax,kind:'me'}))).sort((a,b)=>a.t-b.t);
  const cmp=all.length?`<div class="ptab cmp">${all.map((x,i)=>`<div class="ptr ${x.kind}"><span>${i+1}</span><span class="nm">${x.n}</span><span class="tl">${ptT(x.t)}</span><span>${Math.round(x.v)} km/h</span></div>`).join('')}</div>`:'';
  const busy=PTR?`<p class="note">⏳ Calcul des références… ${PTR.n}/${PTR.tot}</p>`:`<button class="btn alt" data-a="ptref">${refs.length?'Mettre à jour les références':'Calculer les références'}</button>`;
  const dv=S.cars.map(c=>{ const o=P.rec[c.uid+'|'+m], r=P.ref[c.mid+'|'+m]; return o&&o.lap!=null&&r&&r.t!=null?`<div class="inv-r"><span class="inv-i">${o.lap<r.t?'🚀':'📉'}</span><div class="inv-t"><b>${M[c.mid].nom}</b><small>${o.lap<r.t?'Plus rapide':'Plus lent'} que la série (pilote IA) de ${Math.abs(o.lap-r.t).toFixed(3).replace('.',',')} s</small></div></div>`:''; }).join('');
  $('sheet').innerHTML=`<div class="inv">${X}<h2>📊 Records & comparaison</h2><div class="chips" style="margin:8px 0">${chips}</div><h3 class="rh">Mes voitures</h3>${tab}<h3 class="rh">Face aux références</h3><p class="note">Un pilote IA (niveau constant) fait un tour lancé avec chaque voiture de série. Compare tes chronos à ces repères.</p>${busy}${cmp}${dv?'<h3 class="rh">Effet de tes améliorations</h3>'+dv:''}<div class="brow" style="margin-top:10px"><button class="btn alt" data-a="ptest">← Piste d’essai</button></div></div>`; return true; }
Object.assign(ACT,{ ptest(){ openSheet({t:'ptest'}); }, ptrank(){ openSheet({t:'ptrank'}); }, ptw(d){ PTUI.m=d.id; renderSheet(); }, ptgo(d){ ptStart(+d.id,PTUI.m); }, ptref(){ ptRefAll(); } });
const _vEp26=vEpreuves;
vEpreuves=function(){ return _vEp26.apply(this,arguments);
  /* carte retirée : l’accès se fait par la grande porte du garage 3D */ const rec=Object.values(ptS().rec).filter(o=>o.lap!=null).sort((a,b)=>a.lap-b.lap)[0];
  return `<button class="row ptcard" data-a="ptest"><span class="ico">🏁</span><span class="grow"><span class="ttl">Piste d’essai · Spa-Francorchamps</span><br><span class="sub">Tour libre, chrono par secteur, records${rec?' · meilleur '+ptT(rec.lap):''}</span></span><span class="gain">Libre</span></button>`+_vEp26.apply(this,arguments); };

/* ---- caméras de la piste d'essai : 0 poursuite d'origine, 1 vue proche ~30°, 2 cockpit avec volant ---- */
const PTCAMN=['Poursuite','Proche 30°','Cockpit'];
function ptCamI(){ const v=S.camv!=null?S.camv:(S.ptest&&S.ptest.cam); return v>=0&&v<3?v|0:0; }
function ptCamTx(){ return '📷 '+PTCAMN[ptCamI()]; }
ACT.ptcam=function(){ S.camv=(ptCamI()+1)%3; RS&&(RS.camP2=null); save(); const b=$('bCam'); if(b) b.textContent=ptCamTx(); try{ flash('Vue : '+PTCAMN[S.camv],'#00E5FF',1.1); }catch(_){} };
function ptWheel(on,st){
  const el=$('rslot'); if(!el||!el.parentNode) return; const w=el.parentNode; let d=w.querySelector('#ptwh');
  if(!on){ if(d) d.remove(); return; }
  if(!d){ d=document.createElement('div'); d.id='ptwh'; d.innerHTML='<svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="86" fill="none" stroke="#10131f" stroke-width="22"/><circle cx="100" cy="100" r="86" fill="none" stroke="#2b3150" stroke-width="14"/><path d="M14 104 Q100 120 186 104" stroke="#10131f" stroke-width="16" fill="none"/><rect x="92" y="108" width="16" height="78" fill="#10131f"/><rect x="92" y="6" width="16" height="22" fill="#ffd400"/><circle cx="100" cy="104" r="20" fill="#1a1e33" stroke="#00e5ff" stroke-width="4"/></svg>'; w.appendChild(d); }
  d.firstChild.style.transform='rotate('+(st*110).toFixed(1)+'deg)';
}
const _draw26=drawSpa;
drawSpa=function(dt,time){
  _draw26.apply(this,arguments);
  if(!RS||!RC||!RC.P||RC.kind!=='spa'){ return; }
  if(typeof orbitOn==='function'&&orbitOn()) return;
  const m=ptCamI(), P=RC.P, cam=RS.cam; try{ RS.pc.g.visible=(m!==2); }catch(_){}
  if(m===0){ ptWheel(false); return; }
  const fx=Math.cos(P.psi), fz=Math.sin(P.psi); let px,py,pz,lx,ly,lz,fov;
  if(m===1){
    const vang=P.v>6?Math.atan2(P.vz,P.vx):P.psi, a=P.psi+wrapA(vang-P.psi)*.3, ax=Math.cos(a), az=Math.sin(a), d=6.6+Math.min(P.v,90)*.012, h=Math.tan(30*Math.PI/180)*d;
    const tx=P.x-ax*d, tz=P.z-az*d, ty=P.y+1.0+h; if(!RS.camP2) RS.camP2={x:tx,y:ty,z:tz}; const k=1-Math.exp(-dt*9), c=RS.camP2;
    c.x+=(tx-c.x)*k; c.y+=(ty-c.y)*k; c.z+=(tz-c.z)*k; px=c.x;py=c.y;pz=c.z; lx=P.x+ax*9; ly=P.y+.9; lz=P.z+az*9; fov=68+Math.min(P.v,95)*.1;
    ptWheel(false);
  }else{
    const H=RS.pc.H||1.4; px=P.x+fx*.15; py=P.y+Math.max(.95,H*.72); pz=P.z+fz*.15; lx=P.x+fx*30; ly=py-.25; lz=P.z+fz*30; fov=78+Math.min(P.v,95)*.12+(P.nitroT>0?10:0);
    ptWheel(true,RC.inp.st||0);
  }
  cam.position.set(px,py,pz); cam.lookAt(lx,ly,lz);
  if(Math.abs(cam.fov-fov)>.05){ cam.fov=fov; cam.updateProjectionMatrix(); }
  try{ RS.sky.position.copy(cam.position); }catch(_){}
};
const _leave26=leaveRace; leaveRace=function(){ try{ ptWheel(false); if(RS&&RS.pc) RS.pc.g.visible=true; }catch(_){} return _leave26.apply(this,arguments); };

/* ---- mêmes 3 vues pour les courses classiques (parcours sur rail) ---- */
const _vRace27=vRace;
vRace=function(){ return _vRace27.apply(this,arguments).replace('<button class="btn danger sm" id="bQuit"',`<button class="btn alt sm" id="bCam" data-a="ptcam">${ptCamTx()}</button><button class="btn danger sm" id="bQuit"`); };
const _drawRace27=drawRace;
drawRace=function(dt,time){
  _drawRace27.apply(this,arguments);
  if(!RS||!RC||!RC.P||!RS.path||RC.kind!=='race') return;
  const m=ptCamI(); try{ RS.pc.g.visible=(m!==2); }catch(_){}
  if(m===0){ ptWheel(false); return; }
  if(typeof orbitOn==='function'&&orbitOn()) return;
  const P=RC.P, Pa=RS.path, tk=RC.tk, cam=RS.cam, s=clamp(P.x,-Pa.PRE+4,tk.L+Pa.POST-6), p=pathAt(Pa,s,P.lane), fx=Math.cos(p.th), fz=Math.sin(p.th);
  let px,py,pz,lx,ly,lz,fov;
  if(m===1){ const d=6.6+Math.min(P.v,90)*.012, h=Math.tan(30*Math.PI/180)*d, tx=p.x-fx*d, tz=p.z-fz*d, ty=1.0+h;
    if(!RS.camP2) RS.camP2={x:tx,y:ty,z:tz}; const k=1-Math.exp(-dt*9), c=RS.camP2; c.x+=(tx-c.x)*k; c.y+=(ty-c.y)*k; c.z+=(tz-c.z)*k;
    px=c.x;py=c.y;pz=c.z; lx=p.x+fx*9; ly=.9; lz=p.z+fz*9; fov=68+Math.min(P.v,95)*.1; ptWheel(false); }
  else{ const H=RS.pc.H||1.4; px=p.x+fx*.15; py=Math.max(.95,H*.72); pz=p.z+fz*.15; lx=p.x+fx*30; ly=py-.25; lz=p.z+fz*30; fov=78+Math.min(P.v,95)*.12+(P.nitroT>0?10:0); ptWheel(true,(RC.inp&&RC.inp.st)||0); }
  cam.position.set(px,py,pz); cam.lookAt(lx,ly,lz);
  if(Math.abs(cam.fov-fov)>.05){ cam.fov=fov; cam.updateProjectionMatrix(); }
  try{ RS.sky.position.copy(cam.position); RS.ground.position.x=Math.round(cam.position.x/30)*30; RS.ground.position.z=Math.round(cam.position.z/30)*30; }catch(_){}
};
/* ===== v0.50 : labo ×1/×5/×10, rouvrir un paquet avec un jeton ===== */
RY.qty=RY.qty||1;
const _rShop27=rShop;
rShop=function(){
  let h=_rShop27.apply(this,arguments); if(RY.shop==='gear') return h;
  const q=RY.qty||1, bar=`<div class="qtybar"><span>Quantité</span>${[1,5,10].map(n=>`<button class="${q===n?'on':''}" data-a="rqty" data-id="${n}">×${n}</button>`).join('')}</div>`;
  const i=h.indexOf('</div>')+6; h=h.slice(0,i)+bar+h.slice(i);
  if(q>1) h=h.replace(/data-id="(seed|chem|lamp):([^"]+)">([^<]*)<br>/g,(m,t,id,px)=>{ let u=t==='seed'?SID[id].sd:t==='chem'?CHEM[id].px:LID[id].px; return `data-id="${t}:${id}">×${q} · ${fmt(u*q)}<br>`; });
  return h;
};
ACT.rqty=d=>{ RY.qty=+d.id||1; renderSheet(); };
const _rbuy27=ACT.rbuy;
ACT.rbuy=function(d){
  const [t,a]=String(d.id).split(':'), q=RY.qty||1;
  if(q<=1||!(t==='seed'||t==='chem'||t==='lamp')) return _rbuy27.apply(this,arguments);
  const F=farm(); let u; if(t==='seed'){ const s=SID[a]; if(!s||F.rep<s.rep) return; u=s.sd; } else if(t==='chem') u=CHEM[a].px; else u=LID[a].px;
  const n=Math.min(q,Math.floor(S.cr/u)); if(n<1) return toast('Pas assez de crédits');
  S.cr-=n*u; const box=t==='seed'?F.seeds:t==='chem'?F.chem:F.lamps; box[a]=(box[a]||0)+n;
  toast(n<q?`Crédits justes : ${n} acheté${n>1?'s':''} sur ${q}`:`+${n} acheté${n>1?'s':''}`); save(); renderSheet();
};
/* paquets : « Encore un » aussi avec un jeton */
function pkTok27(){
  document.querySelectorAll('#sheet button[data-a="pack"][data-k="cr"]').forEach(b=>{
    if(!/Encore/i.test(b.textContent)) return; const nx=b.nextElementSibling; if(nx&&nx.dataset&&nx.dataset.k==='tok') return;
    const pk=PACKS.find(p=>p.id===b.dataset.id); if(!pk||!pk.tok) return;
    const c=document.createElement('button'); c.className='btn'; c.dataset.a='pack'; c.dataset.id=pk.id; c.dataset.k='tok'; c.style.gridColumn='1 / -1'; if(S.tok<pk.tok) c.disabled=true;
    c.innerHTML=`🎟 Encore un, ${pk.tok} jeton${pk.tok>1?'s':''} <small>(tu en as ${S.tok})</small>`; b.parentNode.appendChild(c);
  });
}
const _rs27=renderSheet; renderSheet=function(){ const r=_rs27.apply(this,arguments); try{ pkTok27(); }catch(e){ console.error(e); } return r; };

/* ---- récap des pièces gagnées au pinball : fiche détail + équiper ---- */
function pbRecap(list){
  return `<div class="pbrec"><b>🎁 Pièces gagnées (${list.length})</b><small>Touche une pièce pour voir sa fiche et l’équiper</small><div class="pbcap">${list.map(c=>{ const m=c.u!=null?modOf(c.u):null, sl=m?SLOTS.find(x=>x[0]===MODI[m.t][1]):null;
    return `<button class="pbc ${c.u==null?'off':''}" ${c.u!=null?`data-a="pbdet" data-id="${c.u}"`:'disabled'} style="--rc:${RAR[c.r].c}"><i>${sl?sl[2]:'📦'}</i><span>${c.arc?'⭐ ':''}${c.name}</span><em>${RAR[c.r].n}${c.dup?' · ★+':''}${c.full?' · ferraille':''}${c.pal?' · palier':''}</em></button>`; }).join('')}</div></div>`;
}
function pbDetRender(u){
  const ov=document.getElementById('arcov')||document.body; let d=document.getElementById('pbdet'); if(!d){ d=document.createElement('div'); d.id='pbdet'; ov.appendChild(d); }
  const m=modOf(u); if(!m){ d.remove(); return; } const sl=MODI[m.t][1], slN=SLOTS.find(x=>x[0]===sl), on=eqCar(u);
  d.innerHTML=`<div class="pbd-in"><button class="pbd-x" data-a="pbdetx">✕</button><h3>${slN[2]} ${slN[1]}</h3><div class="pbd-card">${modHTML(m)}</div>
    <p class="note">${on?`Monté sur <b>${M[on.mid].nom}</b>. Tu peux le déplacer sur une autre voiture.`:'Pas encore monté. Choisis une voiture pour l’équiper tout de suite.'}</p>
    <div class="pbd-cars">${S.cars.map(c=>{ const cu=c.mods&&modOf(c.mods[sl]), here=on&&on.uid===c.uid, up=cu&&modPow(m)>modPow(cu), nw=!cu;
      return `<button class="pbd-car ${here?'on':''}" ${here?'disabled':''} data-a="pbeq" data-id="${c.uid}:${u}"><span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span><span class="grow"><b>${M[c.mid].nom}</b><small>${here?'Déjà monté ici':cu?'Remplace : '+modName(cu)+' ('+RAR[cu.r].n+')':'Emplacement vide'}</small></span><em>${here?'✔':nw?'＋':up?'⬆':'⬇'}</em></button>`; }).join('')}</div>
    <button class="btn alt wide" data-a="pbdetx">Fermer</button></div>`;
}
Object.assign(ACT,{ pbdet(d){ pbDetRender(+d.id); }, pbdetx(){ const d=document.getElementById('pbdet'); if(d) d.remove(); },
  pbeq(d){ const [cu,u]=String(d.id).split(':').map(Number), c=car(cu), m=modOf(u); if(!c||!m) return; equipMod(c,u,MODI[m.t][1]); save(); toast(modName(m)+' monté sur '+M[c.mid].nom); try{ ui('coins'); }catch(_){} pbDetRender(u); } });
/* ===== v0.52 : progression par niveaux, labo au niveau 8 + tuto, drag étendu ===== */
const LAB_LVL=8;
const labLv=()=>S&&S.age18===true?S.lvl:0;
function tabOk(id){ return id!=='labo'||labLv()>=LAB_LVL; }
function evDi(ev){ return ev&&ev.di!=null?ev.di:EVENTS.indexOf(ev); }
/* ---- nouvelles épreuves (di = difficulté équivalente dans l'ancienne échelle) ---- */
[
 {id:'d2',nom:'Quart de mile du port',lvl:2,gain:1000,xp:45,di:2,opp:{t:[1,1],up:0,etat:[35,60]},manches:[{d:'drag',m:'sec'}]},
 {id:'d3',nom:'Drag sous les néons',lvl:4,gain:2400,xp:100,di:4,opp:{t:[1,2],up:1,etat:[55,85]},manches:[{d:'drag',m:'sec'}]},
 {id:'a1',nom:'Drag Arcade I · boules de boost',lvl:5,gain:3600,xp:140,di:5,opp:{t:[2,3],up:1,etat:[65,95]},manches:[{d:'drag',m:'sec',bon:1}]},
 {id:'d4',nom:'Duel des pistards',lvl:6,gain:5200,xp:180,di:5.5,opp:{t:[2,3],up:1,etat:[75,100]},manches:[{d:'drag',m:'sec'},{d:'drag',m:'pluie'}]},
 {id:'a2',nom:'Drag Arcade II · piste piégée',lvl:8,gain:9000,xp:290,di:6.5,opp:{t:[3,4],up:2,etat:[85,100]},manches:[{d:'drag',m:'sec',bon:2}]},
 {id:'d5',nom:'Légende du quart de mile',lvl:9,gain:16000,xp:380,di:7,opp:{t:[4,5],up:2,etat:[90,100]},manches:[{d:'drag',m:'sec'},{d:'drag',m:'sec'},{d:'drag',m:'pluie'}]},
 {id:'a3',nom:'Drag Arcade III · portes nitro',lvl:10,gain:26000,xp:480,di:7.5,opp:{t:[4,5],up:3,etat:[95,100]},manches:[{d:'drag',m:'sec',bon:3},{d:'drag',m:'pluie',bon:3}]}
].forEach(e=>{ if(!EVENTS.some(x=>x.id===e.id)) EVENTS.push(e); });
EVENTS.forEach(e=>{ if(e.di==null) e.di=EVENTS.indexOf(e); }); EVENTS.sort((a,b)=>a.lvl-b.lvl);
if(typeof ILL!=='undefined') ILL.forEach(e=>{ if(!e._l8){ e._l8=1; e.lvl=Math.max(LAB_LVL,LAB_LVL+Math.floor((e.lvl-2)/3)); } });
{ const a=DEST.find(d=>d.id==='atelier'), r=DEST.find(d=>d.id==='ranch');
  if(a){ a.ok=()=>labLv()>=LAB_LVL&&!!farm().found; Object.defineProperty(a,'why',{get(){ return labLv()<LAB_LVL?'Niveau '+LAB_LVL+' requis':'Trouve la cloison dans le garage'; }}); }
  if(r){ r.ok=()=>labLv()>=LAB_LVL&&!!farm().rooms.ranch.on; } }
const _ranch28=ACT.ranch; ACT.ranch=function(){ if(labLv()<LAB_LVL) return toast('🔒 Le labo s’ouvre au niveau '+LAB_LVL); return _ranch28.apply(this,arguments); };
const _lo28=ACT.labopen; ACT.labopen=function(){ if(labLv()<LAB_LVL) return toast('🔒 Le labo s’ouvre au niveau '+LAB_LVL); return _lo28.apply(this,arguments); };
const _wgo28=ACT.wgo; ACT.wgo=function(d){ const id=d&&d.id; if(id&&id.startsWith('arc_')&&ARC_LV[id.slice(4)]&&S.lvl<ARC_LV[id.slice(4)]) return toast('🔒 Niveau '+ARC_LV[id.slice(4)]+' requis'); return _wgo28.apply(this,arguments); };
/* ---- déblocages : liste par niveau ---- */
const UNL=[
 [2,'🏝️','Plage Irie','Bar tiki, feu de camp, tes voitures sur le sable : un lieu pour souffler.'],
 [3,'🌃','Rue Néon','Ruelle sous la pluie, vitrines et départ de course.'],
 [3,'🕹️','Salle d’arcade','Elle ouvre avec un premier jeu : le Pousse-Nitro. Les autres arrivent avec tes niveaux.'],
 [4,'🔧','Pit Stop (arcade)','Change les roues le plus vite possible.'],
 [5,'🚦','Drag Start (arcade)','Le départ parfait et les rapports, en mini-jeu.'],
 [6,'🌀','Reflex Drift (arcade)','Dérape au bon moment pour enchaîner les points.'],
 [7,'🎰','Pinball (arcade)','Tables, radar, capture de pièces. Plus ton niveau pinball monte, plus de tables s’ouvrent.'],
 [8,'🌿','Labo clandestin','Une cloison s’ouvre dans ton garage : culture, séchage, vente… et les courses clandestines, le karma et la police. Un tuto complet t’y attend.'],
 [8,'🌾','Ranch & Réseau','Grâce à la réputation, un grand champ extérieur et des livraisons.']
];
function unlFor(l){
  const out=UNL.filter(u=>u[0]===l).map(u=>[u[1],u[2],u[3]]);
  EVENTS.filter(e=>e.lvl===l&&l>1&&!e.ill).forEach(e=>out.push(['🏁',e.nom,'Nouvelle épreuve : '+e.manches.map(m=>DISC[m.d].nom+(m.bon?' (bonus arcade)':'')).join(', ')+'.']));
  POD_LVL.forEach((p,i)=>{ if(p===l&&l>1) out.push(['🏛️','Podium n°'+(i+1),'Un emplacement de plus pour exposer une voiture dans ton garage.']); });
  return out;
}
const _addXP28=addXP;
addXP=function(n){ const l0=S.lvl; _addXP28.apply(this,arguments); if(S.lvl>l0){ S.unlQ=S.unlQ||[]; for(let l=l0+1;l<=S.lvl;l++){ const it=unlFor(l); if(it.length) S.unlQ.push({l,it}); } try{ save(); }catch(_){} } };
setInterval(()=>{ try{
  if(!S||!S.cars) return;
  if(labLv()>=LAB_LVL&&!S.labSeen){ S.labSeen=1; if(!(S.unlQ||[]).some(q=>q.l===8)){ S.unlQ=S.unlQ||[]; S.unlQ.push({l:8,it:unlFor(8)}); } }
  if(!(S.unlQ&&S.unlQ.length)||sheet||(typeof AOV!=='undefined'&&AOV)||document.body.classList.contains('racing')||view==='race') return;
  const q=S.unlQ.shift(); save(); openSheet({t:'unl',l:q.l,it:q.it});
}catch(_){} },1800);
function ulSheet(X){
  if(!sheet||sheet.t!=='unl') return false;
  const lab=sheet.it.some(x=>x[1]==='Labo clandestin');
  $('sheet').innerHTML=`<div class="tuto gtu">${X}<div class="tu-ic">🔓</div><h2>Niveau ${sheet.l} : du nouveau !</h2>
   <div class="ulist">${sheet.it.map(x=>`<div class="ul-r"><i>${x[0]}</i><div><b>${x[1]}</b><small>${x[2]}</small></div></div>`).join('')}</div>
   <div class="tu-btns"><button class="btn alt" data-a="close">Plus tard</button>${lab?'<button class="btn" data-a="ulgo" data-id="hub">🌿 Aller au garage</button>':'<button class="btn" data-a="close">Super !</button>'}</div></div>`;
  return true;
}
ACT.ulgo=d=>{ closeSheet(); try{ ACT.tab({id:d.id}); }catch(_){} };
/* ---- tuto du labo : pas à pas, pour des joueurs qui ne connaissent pas ---- */
GT.length=0;
GT.push(
 {ic:'🌿',t:'Bienvenue dans ton labo',x:'Tu viens de débloquer le <b>labo clandestin</b>. Ici, tu <b>cultives des plantes</b>, tu les <b>sèches</b>, puis tu les <b>vends</b> pour gagner beaucoup de crédits. Ces crédits servent à acheter des voitures, des pièces, et à jouer des <b>courses illégales</b> mieux payées. <b>Attention :</b> c’est risqué. La <b>police</b> peut s’en mêler et ton <b>karma</b> baisse. Ce tuto explique tout, étape par étape. Tu peux le relancer avec le bouton ❓. <b>Kit de départ offert</b> : 2 graines, 2 lampes et un peu d’engrais.'},
 {ic:'🕹️',t:'Se déplacer et agir',x:'Joystick à gauche pour marcher, glisse le doigt sur l’écran pour regarder autour. <b>Approche-toi</b> d’un plot (bac), du robinet, du séchoir ou du bureau : des <b>boutons apparaissent en haut de l’écran</b>. Tout se fait avec ces boutons. Le <b>🎒</b> ouvre ton sac à dos.'},
 {ic:'🪴',t:'Étape 1 · Planter',x:'Un <b>plot</b> est un bac où pousse <b>une</b> plante. Va sur un plot vide et appuie <b>🌱 Planter</b>. Tu choisis 3 choses : la <b>graine</b> (la variété), le <b>support</b> (terreau = simple, coco = plus rapide, hydro = très rapide mais exigeant) et la <b>lampe</b> (la lumière fait grandir). Pour ta première fois : <b>terreau + une lampe néon</b>.'},
 {ic:'💧',t:'Étape 2 · L’eau',x:'Une plante a soif. Va au <b>point d’eau</b> (coin bleu) et prends <b>🪣 Remplir l’arrosoir</b> (6 charges). Puis, devant la plante, appuie <b>💧 Arroser</b>. Garde l’eau entre <b>30 % et 90 %</b> : trop sèche, elle s’abîme ; trop mouillée, elle pourrit. La citerne se remplit contre quelques crédits.'},
 {ic:'🌱',t:'Étape 3 · Les 4 phases',x:'Chaque plante passe par : <b>Germination</b> (courte) → <b>Croissance</b> (elle fait des feuilles) → <b>Floraison</b> (elle fait la récolte) → <b>Prête ✨</b>. Le cercle au sol devient vert quand elle est prête. Le temps passe même quand le jeu est fermé : tu peux revenir plus tard. Une plante morte doit être évacuée.'},
 {ic:'🟩',t:'Pourquoi l’azote (N) ?',x:'Dans la <b>📋 Fiche</b> d’un plot, tu vois 3 barres : <b>N, P, K</b>. Ce sont les « repas » de la plante, comme pour un humain : <b>N = azote</b> → les <b>feuilles et la croissance</b> (surtout pendant la croissance). Pas assez d’azote : feuilles jaunes et plante qui stagne. La barre doit rester entre <b>35 et 80</b>. Trop d’engrais, c’est pire que pas assez : la plante « brûle ».'},
 {ic:'🟧',t:'Pourquoi P et K ?',x:'<b>P = phosphore</b> → les <b>racines</b> et le <b>démarrage des fleurs</b>. <b>K = potassium</b> → la <b>qualité</b> et le poids de la récolte (et la résistance). En <b>croissance</b>, pense surtout <b>azote</b>. En <b>floraison</b>, pense <b>P et K</b>. Quand une barre baisse (la plante consomme), ajoute un engrais de la même couleur depuis la Fiche. Le <b>🚀 Booster de floraison</b> donne un coup de pouce final.'},
 {ic:'🔻',t:'Le pH, pourquoi − et + ?',x:'Le <b>pH</b> mesure si l’eau/le sol est <b>acide</b> ou <b>basique</b>. Si le pH est mauvais, la plante <b>n’arrive plus à absorber</b> ses engrais, même s’il y en a beaucoup. Chaque support a son pH idéal (indiqué dans la Fiche : environ <b>6</b>). Le pH dérive tout seul avec le temps. <b>pH trop haut</b> → utilise <b>🔻 pH −</b>. <b>pH trop bas</b> → utilise <b>🔺 pH +</b>. Un seul produit à la fois, et regarde le chiffre.'},
 {ic:'⚪',t:'Cal-Mag, lampes et soins',x:'<b>Cal-Mag ⚪</b> évite les carences (feuilles tachetées) surtout avec la lumière forte. Plus une <b>lampe</b> est puissante, plus elle fait pousser vite, mais plus elle crée de <b>chaleur</b> (la police remarque). Si tu vois <b>⚪ moisissure</b> ou <b>🔴 acariens</b>, soigne avec <b>fongicide</b> ou <b>insecticide</b> avant que la santé tombe.'},
 {ic:'✂️',t:'Étape 4 · Récolter et sécher',x:'Plante prête → <b>✂️ Récolter</b>. La récolte va au <b>séchoir</b> (coin orange) pendant quelques minutes. Ensuite elle entre dans ton <b>stock</b>. Plus la <b>santé</b>, la <b>qualité</b> et l’équilibre N-P-K-pH ont été bons, plus le <b>prix</b> sera élevé.'},
 {ic:'💰',t:'Étape 5 · Vendre',x:'Au <b>bureau 🚗 Réseau</b>, onglet <b>Stock &amp; vente</b>, tu choisis où vendre : la <b>rue</b> (rapide, mais risqué et mauvais pour le karma), le <b>dealer</b> (correct), ou en <b>gros</b> (mieux payé, demande de la réputation). Tu peux aussi <b>conditionner</b> ta récolte en lots à la table de conditionnement.'},
 {ic:'🚨',t:'Chaleur, police et karma',x:'Plus tu produis et vends, plus la <b>chaleur 🚨</b> monte. À 100 %, <b>descente de police</b> : saisie et amende. Baisse-la avec <b>ventilation, filtres</b> ou <b>pot-de-vin</b>. Le <b>karma</b> reflète tes choix : <b>courses légales et dons = positif</b>, <b>ventes de rue et deals = négatif</b>. Un karma négatif attire la police, même pendant tes courses normales. Les dons te permettent de le remonter.'},
 {ic:'🏁',t:'Le lien avec les courses',x:'Dans <b>Missions</b> : les <b>go-fast</b> (tu livres ta marchandise pendant une course, la police peut te poursuivre) et les <b>courses à mise</b> (tu paries des crédits). Elles paient plus, mais font monter la <b>chaleur</b> et baisser le <b>karma</b>. Ta <b>réputation</b> grimpe avec les livraisons réussies et ouvre le <b>Ranch 🌾</b> (24 plots en plein air).'},
 {ic:'🎒',t:'Ta première culture : la check-list',x:'<b>1.</b> Plante 1 graine (terreau + lampe néon). <b>2.</b> Remplis l’arrosoir et arrose. <b>3.</b> Ouvre la Fiche : garde N, P, K entre 35 et 80 et le pH près de l’idéal. <b>4.</b> Attends le cercle vert, puis <b>récolte</b>. <b>5.</b> Laisse sécher, puis <b>vends</b> au bureau. Le <b>🎒</b> te rappelle où utiliser chaque objet. Bonne pousse !'}
);
/* ---- drag arcade : boules de boost, flaques d'huile, portes nitro, changement de voie ---- */
const _bind28=bindRace;
bindRace=function(){ _bind28.apply(this,arguments); try{ if(RC&&RC.kind==='race'&&RC.mn&&RC.mn.bon&&RS&&!RS.dbon) dragBonInit(); }catch(e){ console.error(e); } };
function dragBonInit(){
  const tk=RC.tk, Pa=RS.path, tier=RC.mn.bon, P=RC.P, items=[]; RS.dbon=true; RC.dbon={tier,items,n:0,hit:0};
  const lanes=[-2.2,2.2]; RC.laneT=P.lane<0?-2.2:2.2; P.lane=RC.laneT;
  let s=55; while(s<tk.L-45){ items.push({t:'orb',s,lane:lanes[rint(0,1)]}); s+=rnd(32,50); }
  if(tier>=2){ s=95; while(s<tk.L-60){ const it={t:'oil',s,lane:lanes[rint(0,1)]}; if(!items.some(o=>Math.abs(o.s-it.s)<14&&o.lane===it.lane)) items.push(it); s+=rnd(80,115); } }
  if(tier>=3){ s=130; while(s<tk.L-70){ items.push({t:'gate',s,lane:lanes[rint(0,1)]}); s+=rnd(105,140); } }
  const sc=RS.scene, gO=new THREE.SphereGeometry(.62,14,10), mO=new THREE.MeshBasicMaterial({color:0x3cff9e}), gG=new THREE.BoxGeometry(.28,3.4,.28), gB=new THREE.BoxGeometry(.3,.3,3.6), mG=new THREE.MeshBasicMaterial({color:0xffd400});
  const gOil=new THREE.CircleGeometry(1.7,20), mOil=new THREE.MeshBasicMaterial({color:0x3a1060,transparent:true,opacity:.9});
  items.forEach(it=>{ const p=pathAt(Pa,it.s,it.lane); let m;
    if(it.t==='orb'){ m=new THREE.Mesh(gO,mO); m.position.set(p.x,1.15,p.z); }
    else if(it.t==='oil'){ m=new THREE.Mesh(gOil,mOil); m.rotation.x=-Math.PI/2; m.position.set(p.x,.07,p.z); }
    else { m=new THREE.Group(); const l=new THREE.Mesh(gG,mG), r=new THREE.Mesh(gG,mG), b=new THREE.Mesh(gB,mG); l.position.set(0,1.7,-1.8); r.position.set(0,1.7,1.8); b.position.set(0,3.3,0); m.add(l); m.add(r); m.add(b); m.position.set(p.x,0,p.z); m.rotation.y=-p.th; }
    sc.add(m); it.m=m; });
  const w=$('rslot')&&$('rslot').parentNode; if(w&&!w.querySelector('#laneBtn')) w.insertAdjacentHTML('beforeend','<button id="laneBtn" class="lanebtn" data-a="lane">⇄ VOIE</button>');
  if(!RC.keyL){ RC.keyL=e=>{ if(!RC||!RC.dbon) return; if(['ArrowLeft','ArrowRight','KeyQ','KeyE'].includes(e.code)) ACT.lane(); }; document.addEventListener('keydown',RC.keyL); }
}
ACT.lane=function(){ if(!RC||!RC.dbon||RC.done) return; RC.laneT=-RC.laneT; try{ navigator.vibrate&&navigator.vibrate(15); }catch(_){} };
const _tick28=tick;
tick=function(dt){
  _tick28.apply(this,arguments);
  const D=RC&&RC.dbon; if(!D||RC.kind!=='race'||RC.clock<0) return; const P=RC.P;
  P.lane+=(RC.laneT-P.lane)*Math.min(1,dt*7);
  for(const it of D.items){ if(it.got||Math.abs(P.x-it.s)>2.3||Math.abs(P.lane-it.lane)>1.35) continue; it.got=1; if(it.m) it.m.visible=(it.t==='oil');
    if(it.t==='orb'){ P.boostT=Math.max(P.boostT,1.15); D.n++; S.cr+=25; flash('BOOST ! +25 cr','#3CFF9E',.8); try{ ui('coins'); }catch(_){} }
    else if(it.t==='oil'){ P.v*=.82; P.boostT=0; D.hit++; flash('FLAQUE D’HUILE !','#FF4D6D',1); try{ navigator.vibrate&&navigator.vibrate([60,40,60]); }catch(_){} }
    else{ P.nitroT=Math.max(P.nitroT,1.5); P.nit=(P.nit||0); D.n++; S.cr+=60; flash('PORTE NITRO ! +60 cr','#FFD400',1); try{ ui('up'); }catch(_){} } }
  for(const it of D.items){ if(it.t==='orb'&&!it.got&&it.m) it.m.position.y=1.15+.22*Math.sin(RC.clock*4+it.s); }
};
const _leave28=leaveRace; leaveRace=function(){ try{ if(RC&&RC.keyL){ document.removeEventListener('keydown',RC.keyL); RC.keyL=null; } }catch(_){} return _leave28.apply(this,arguments); };
/* ===== v0.53 : 8 voitures 3D réelles (stats d'après les fiches constructeur) ===== */
MODEL_IDS.push('epave','golf','tt','r8','alfa','p1','solus','concept');
CAP['Course']=50; CAP['Prototype']=20;
(function(){
  const set=(id,o)=>{ const m=M[id]; Object.assign(m,o); return m; };
  /* Golf GTI Mk8.5 : 265 ch, 370 Nm, 5,9 s, 250 km/h limitée, traction */
  set('touge',{nom:'Wolfen Sprint GTI',an:2025,cat:'Compacte',shape:'hatch',tr:'FWD',t:3,ch:265,nm:370,kg:1450,vmax:250,adh:68,fre:66,man:74,fia:80,sty:58,val:18000,col:'#B81D1D',glb:'golf'});
  /* Audi TT RS : 400 ch, 480 Nm, 1 440 kg, 3,7 s, 250 km/h bridée, quattro */
  set('gts',{nom:'Ostwald TR-S Coupé',an:2022,cat:'Sportive',shape:'coupe',tr:'AWD',t:4,ch:400,nm:480,kg:1440,vmax:250,adh:80,fre:74,man:74,fia:76,sty:70,val:48000,col:'#C8141C',glb:'tt'});
  /* Alfa 155 V6 TI DTM 1993 : V6 2,5 l atmo, 400 ch à 11 500 tr/min, transmission 4x4 Q4, ≈1 040 kg */
  set('rx4',{nom:'Alvaro 155 V6 DTM',an:1993,cat:'Course',shape:'sedan',tr:'AWD',t:4,ch:400,nm:300,kg:1040,vmax:270,adh:80,fre:82,man:84,fia:45,sty:80,val:52000,col:'#7A1E22',glb:'alfa'});
  /* Concept 050 : voiture-concept fictive (modèle libre CC0), électrique de prototype */
  set('volta',{nom:'Aero Concept 050',an:2030,cat:'Prototype',shape:'super',tr:'AWD',t:5,ch:780,nm:1050,kg:1750,vmax:320,adh:84,fre:82,man:80,fia:55,sty:96,val:170000,col:'#14E5E0',glb:'concept'});
  /* Audi R8 V10 performance : 620 ch, 580 Nm, 1 595 kg, 2,9 s, 331 km/h, quattro */
  set('rossa',{nom:'Ostwald V10 Quattro',an:2023,cat:'Supercar',shape:'super',tr:'AWD',t:5,ch:620,nm:580,kg:1595,vmax:331,adh:88,fre:86,man:82,fia:74,sty:90,val:210000,col:'#C58A3E',glb:'r8'});
  /* McLaren P1 : V8 biturbo + électrique, 916 ch, 900 Nm, 1 450 kg, 2,8 s, 350 km/h bridée */
  set('aurion',{nom:'Murrow P1 Hybride',an:2014,cat:'Hypercar',shape:'super',tr:'RWD',t:6,ch:916,nm:900,kg:1450,vmax:350,adh:92,fre:94,man:90,fia:55,sty:97,val:700000,col:'#4B2A6B',glb:'p1'});
  const add=o=>{ CARS.push(o); M[o.id]=o; };
  /* McLaren Solus GT : V10 5,2 l atmo, 829 ch, ≈650 Nm, ≈1 000 kg, 2,5 s (0-100 mph), 320 km/h, 25 exemplaires */
  add({id:'solus',nom:'Murrow Solus GT',an:2023,cat:'Hypercar',shape:'super',tr:'RWD',t:6,ch:829,nm:650,kg:1000,vmax:320,adh:92,fre:93,man:95,fia:40,sty:99,val:1400000,col:'#E8590C',glb:'solus'});
  /* Épave de départ : berline américaine des années 60, rouillée */
  add({id:'epave',nom:'Épave rouillée 1962',an:1962,cat:'Classique',shape:'sedan',tr:'RWD',t:1,ch:105,nm:200,kg:1400,vmax:150,adh:32,fre:22,man:30,fia:25,sty:45,val:700,col:'#7FA7A6',glb:'epave'});
  Object.assign(ENG_OF,{epave:'v8big',touge:'i4t',gts:'i6',rx4:'v6',volta:'ev',rossa:'v8flat',aurion:'v8',solus:'v8flat'});
})();
/* ===== v0.54 : circuits arcade (objets façon kart) + police belge & karma ===== */
const MKI={turbo:['🚀','Turbo'],shield:['🛡️','Bouclier'],missile:['🎯','Missile'],oil:['🛢️','Huile'],storm:['⚡','Éclair']};
[{id:'k1',nom:'🎮 Coupe Arcade : La Source',lvl:10,gain:26000,xp:520,opp:{t:[4,5],up:2,etat:[90,100]},manches:[{d:'circuit',m:'sec',sp:'s1',mk:1},{d:'circuit',m:'pluie',sp:'s2',mk:1}],di:9},
 {id:'k2',nom:'🎮 Grand Prix Arcade : Kemmel',lvl:13,gain:48000,xp:760,opp:{t:[5,5],up:3,etat:[95,100]},manches:[{d:'circuit',m:'sec',sp:'s2',mk:1},{d:'circuit',m:'sec',sp:'s3',mk:1},{d:'circuit',m:'pluie',sp:'s4',mk:1}],di:11},
 {id:'k3',nom:'🎮 Super Coupe Arcade : Spa complet',lvl:16,gain:90000,xp:1100,opp:{t:[5,6],up:3,etat:[100,100]},manches:[{d:'circuit',m:'sec',sp:'s1',mk:1},{d:'circuit',m:'sec',sp:'s3',mk:1},{d:'circuit',m:'sec',sp:'s4',mk:1}],di:12}
].forEach(e=>{ if(!EVENTS.some(x=>x.id===e.id)) EVENTS.push(e); });
EVENTS.sort((a,b)=>a.lvl-b.lvl);
const _ss30=startSpa;
startSpa=function(i){
  _ss30.apply(this,arguments);
  try{
    const mn=R.ev.manches[i];
    if(mn.mk) mkInit();
    if(R.polChase||(karma()<=-25&&Math.random()<.35)) polInit();
  }catch(e){ try{console.warn(e);}catch(_){} }
};
function mkInit(){
  const st=RC.stage, M30={bx:[],oil:[],t:0}; RC.mk=M30;
  for(let s=st.a+170;s<st.b-120;s+=250){
    const f=frameAt(s), g=new THREE.Group();
    const bar=new THREE.Mesh(new THREE.BoxGeometry(.35,.9,13),new THREE.MeshBasicMaterial({color:0xffcc00,transparent:true,opacity:.55,depthWrite:false}));
    bar.position.y=3; g.add(bar);
    [-6.6,6.6].forEach(z=>{ const p=new THREE.Mesh(new THREE.BoxGeometry(.4,3.4,.4),new THREE.MeshBasicMaterial({color:0xff7a00})); p.position.set(0,1.7,z); g.add(p); });
    g.position.set(f.x,f.y,f.z); g.rotation.y=-f.th; RS.scene.add(g);
    M30.bx.push({s:wrapS(s),cd:{},g,bar});
  }
  RC.P.mkItem=null; flash('🎮 Mode arcade : traverse les portiques jaunes pour piocher un objet','#FFD400',2.6);
}
function mkRoll(rank,n){
  const w=rank===0?{oil:3,shield:3,turbo:1,missile:1}:rank>=n-2?{turbo:3,storm:2,missile:2,shield:1}:{turbo:2,missile:3,shield:2,oil:2,storm:1};
  const ks=Object.keys(w); let t=ks.reduce((a,k)=>a+w[k],0)*Math.random();
  for(const k of ks){ t-=w[k]; if(t<=0) return k; } return ks[0];
}
function mkUse(c){
  const it=c.mkItem; if(!it) return; c.mkItem=null; const M30=RC.mk, P=RC.P;
  const order=RC.all.slice().sort((a,b)=>b.prog-a.prog), idx=order.indexOf(c);
  const hit=(t,txt)=>{ if(!t) return; if(t.mkSh>0){ t.mkSh=0; if(t===P) flash('🛡️ Bouclier utilisé !','#46e08a',1.2); return; } t.mkSlow=1.8; if(t===P) flash(txt,'#ff4d6d',1.4); };
  if(it==='turbo'){ c.nitroT=Math.max(c.nitroT,2.4); if(c===P) flash('🚀 Turbo !','#00E5FF',1); }
  else if(it==='shield'){ c.mkSh=8; if(c===P) flash('🛡️ Bouclier actif 8 s','#46e08a',1.2); }
  else if(it==='missile'){ const t=order[idx-1]; if(c===P) flash(t?'🎯 Missile lancé !':'🎯 Personne devant…','#FFD400',1); hit(t,'🎯 Touché par un missile !'); }
  else if(it==='oil'){
    const s=wrapS(c.s-14), f=frameAt(s), m=new THREE.Mesh(new THREE.CircleGeometry(2.4,18),new THREE.MeshBasicMaterial({color:0x07070a,transparent:true,opacity:.85,depthWrite:false}));
    m.rotation.x=-Math.PI/2; m.position.set(f.x,f.y+.06,f.z); RS.scene.add(m); M30.oil.push({s,t:30,by:c,m}); if(c===P) flash('🛢️ Huile lâchée derrière toi','#c084fc',1);
  } else if(it==='storm'){ RC.all.forEach(o=>{ if(o!==c) hit(o,'⚡ Éclair ! Tu es ralenti'); }); if(c===P) flash('⚡ Éclair sur tout le monde !','#FFD400',1.2); }
}
ACT.mkuse=()=>{ if(RC&&RC.mk&&RC.P.mkItem&&!RC.done) mkUse(RC.P); };
function mkTick(h){
  const M30=RC.mk, P=RC.P, all=RC.all; M30.t+=h;
  const order=all.slice().sort((a,b)=>b.prog-a.prog);
  all.forEach(c=>{
    if(c.fin!=null) return;
    if(c.mkSlow>0){ c.mkSlow-=h; const f=Math.exp(-.9*h); c.vx*=f; c.vz*=f; }
    if(c.mkSh>0) c.mkSh-=h;
    if(!c.mkItem) M30.bx.forEach(b=>{ if((b.cd[c.s>-1?all.indexOf(c):0]||0)>M30.t) return; if(Math.abs(dS(b.s,c.s))<7){ b.cd[all.indexOf(c)]=M30.t+12; c.mkItem=mkRoll(order.indexOf(c),all.length); c.mkT=rnd(1.2,4);
      if(c===P){ flash(MKI[c.mkItem][0]+' '+MKI[c.mkItem][1]+' : touche le bouton','#FFD400',1.4); try{ ui('up'); }catch(_){} } } });
    else if(c!==P&&(c.mkT-=h)<=0) mkUse(c);
    M30.oil.forEach(o=>{ if(o.by!==c&&o.t>0&&Math.abs(dS(o.s,c.s))<4&&!((c.mkHit||0)>M30.t)){ c.mkHit=M30.t+3; if(c.mkSh>0){ c.mkSh=0; } else{ c.mkSlow=1.4; if(c===P) flash('🛢️ Dérapage sur l’huile !','#c084fc',1.2); } } });
  });
  M30.oil.forEach(o=>{ o.t-=h; if(o.t<=0&&o.m){ o.m.visible=false; } });
  M30.bx.forEach(b=>{ b.bar.rotation.x+=h*1.5; });
}
/* ---- police belge ---- */
function polInit(){
  if(!MODELS.patrouille) return;
  const cr=buildCar(M.patrouille,'#2f6bff',{}); RS.scene.add(cr.g); RC.pc2={cr,gap:42,close:0}; R.polSpa=1;
  flash('🚨 Une patrouille belge te colle derrière !','#2f6bff',2.4);
}
function polTick(h){
  const p=RC.pc2, P=RC.P; if(P.fin!=null){ p.cr.g.visible=false; return; }
  if(P.prog>120) p.gap=clamp(p.gap-(52-P.v)*h*.12,4,80);
  p.close=p.gap<7?p.close+h:Math.max(0,p.close-h*.5);
  if(p.close>2.5){ p.close=0; p.gap=60; P.timePen=(P.timePen||0)+8; const fine=Math.max(200,Math.round(S.cr*.03)); S.cr=Math.max(0,S.cr-fine); karmaAdd(-1); R.polCaught=1; flash('🚨 Interpellé ! +8 s et '+fmt(fine)+' cr d’amende','#ff4d6d',2.4); }
  const s=wrapS(P.s-p.gap), f=frameAt(s), w=Math.sin(RC.clock*.7)*1.6;
  p.cr.g.position.set(f.x-f.nx*w,f.y,f.z-f.nz*w); p.cr.g.rotation.y=-f.th; p.cr.g.visible=true;
}
const _ts30=tickSpa;
tickSpa=function(h){ _ts30.apply(this,arguments); try{ if(RC&&RC.kind==='spa'&&!RC.done&&RC.clock>0){ if(RC.mk) mkTick(h); if(RC.pc2) polTick(h); } }catch(e){} };
const _ds30=drawSpa;
drawSpa=function(dt,time){ _ds30.apply(this,arguments); try{ if(RC&&RC.pc2) pulseSirens(RC.pc2.cr,time||0); }catch(e){} };
const _hs30=hudSpa;
hudSpa=function(){
  _hs30.apply(this,arguments);
  try{ const root=document.querySelector('.race'); if(!root||!RC) return;
    if(RC.mk){ let b=$('mkIt'); if(!b){ b=document.createElement('button'); b.id='mkIt'; b.className='mkit'; b.setAttribute('data-a','mkuse'); root.appendChild(b); }
      const it=RC.P.mkItem, k=it?MKI[it]:null, html=k?k[0]+'<small>'+k[1]+'</small>':'<small>Objet</small>';
      if(b.dataset.h!==html){ b.dataset.h=html; b.innerHTML=html; } b.classList.toggle('has',!!it); }
    if(RC.pc2){ let g=$('polg'); if(!g){ g=document.createElement('div'); g.id='polg'; g.className='polg'; root.appendChild(g); } g.textContent='🚨 '+Math.round(RC.pc2.gap)+' m'+(RC.pc2.close>0?' !':''); g.classList.toggle('hot',RC.pc2.gap<14); }
  }catch(e){}
};
/* ---- scène de contrôle avant une épreuve légale quand le karma est négatif ---- */
const polFine=()=>Math.max(300,Math.round(S.cr*.05));
const _go30=ACT.go;
ACT.go=function(d){
  const ev=R&&R.ev;
  if(ev&&!ev.ill&&!R.polDone){
    if((S.polUntil||0)>Date.now()) return toast('🚔 Immobilisé par la police encore '+Math.ceil((S.polUntil-Date.now())/1000)+' s');
    const k=karma();
    if(k<=-10&&Math.random()<Math.min(.55,-k/160+.1)){ R.polDone=1; R.polD=d; openSheet({t:'pol'}); return; }
  }
  return _go30.apply(this,arguments);
};
function polSheet(X){
  if(!sheet||sheet.t!=='pol') return false;
  const f=polFine();
  $('sheet').innerHTML=`<div class="tuto gtu">${X}<div class="tu-ic">🚔</div><h2>Contrôle de police</h2>
   <p>Un gyrophare bleu dans ton rétro. Un agent de la police belge te fait signe de te ranger : « Bonjour. Votre réputation vous précède… Papiers, s’il vous plaît. »</p>
   <p class="note">Karma actuel : ${Math.round(karma())}. Payer ou patienter le fait remonter.</p>
   <div class="tu-btns col"><button class="btn" data-a="polpay">💶 Payer l’amende (${fmt(f)} cr, karma +3)</button>
   <button class="btn alt" data-a="polwait">⏳ Attendre 90 s (karma +3, épreuves bloquées)</button>
   <button class="btn alt" data-a="poldon">🤝 Faire un don de 1 500 cr (karma +3, tu repars)</button>
   <button class="btn bad" data-a="polrun">🏎️ Foncer et courir quand même</button></div></div>`;
  return true;
}
ACT.polpay=()=>{ const f=polFine(); if(S.cr<f) return toast('Pas assez de crédits'); S.cr-=f; karmaAdd(3); S.stats.polPay=(S.stats.polPay||0)+1; closeSheet(); toast('🚔 Amende payée, bonne route'); save(); ACT.go(R.polD); };
ACT.polwait=()=>{ S.polUntil=Date.now()+90000; karmaAdd(3); S.stats.polPay=(S.stats.polPay||0)+1; closeSheet(); toast('⏳ Tu patientes 90 s sur le bas-côté…'); save(); };
ACT.poldon=()=>{ if(S.cr<1500) return toast('Pas assez de crédits'); S.cr-=1500; karmaAdd(3); S.stats.don=(S.stats.don||0)+1; closeSheet(); toast('🤝 Merci pour ton geste'); save(); ACT.go(R.polD); };
ACT.polrun=()=>{ R.polChase=1; closeSheet(); ACT.go(R.polD); };
const _don30=ACT.rdon; if(_don30) ACT.rdon=function(){ const c0=S.cr; const r=_don30.apply(this,arguments); if(S.cr<c0) S.stats.don=(S.stats.don||0)+1; return r; };
const _fin30=finalize;
finalize=function(forfeit){
  try{ if(R&&R.polChase&&!R.polSpa&&!R.polAcct){ R.polAcct=1; const fine=Math.round(S.cr*.06); S.cr-=fine; karmaAdd(-2); toast('🚨 Poursuivi par la police : '+fmt(fine)+' cr d’amende'); }
       if(R&&R.ev&&R.ev.manches.some(m=>m.mk)&&!forfeit) S.stats.mkN=(S.stats.mkN||0)+1; }catch(e){}
  return _fin30.apply(this,arguments);
};
/* ---- interception de la police pendant les livraisons clandestines ---- */
const _ir30=illResolve;
illResolve=function(ev,pay,win,pod){
  try{ if(ev&&ev.ill&&(pod||win)){ const F=farm(), heat=Math.max(F.heat.atelier,F.heat.ranch), p=clamp(.07+heat/260+Math.max(0,-karma())/320,0,.5);
    if(Math.random()<p){ toast('🚔 La police belge t’intercepte en route : livraison ratée !'); pod=false; win=false; } } }catch(e){}
  return _ir30.call(this,ev,pay,win,pod);
};
/* ---- succès côté légal ---- */
[['l1','Légal','Citoyen modèle : atteins +25 de karma',s=>[Math.max(0,Math.round(karma())),25],{cr:5000}],
 ['l2','Légal','Saint de la route : atteins +60 de karma',s=>[Math.max(0,Math.round(karma())),60],{cr:20000,tok:5}],
 ['l3','Légal','Donateur : fais 3 dons',s=>[s.stats.don||0,3],{cr:3000}],
 ['l4','Légal','Respect de la loi : règle 3 contrôles de police',s=>[s.stats.polPay||0,3],{cr:2500}],
 ['l5','Légal','Pilote arcade : termine une coupe arcade',s=>[s.stats.mkN||0,1],{cr:6000,tok:3}]
].forEach(m=>{ if(!MISSIONS.some(x=>x.id===m[0])){ MISSIONS.push({id:m[0],t:m[2],p:m[3],g:m[4]}); MCAT[m[0]]=m[1]; } });
/* ===== v0.55 : charte +18 ans du labo + cinématique d'intro ===== */
/* ---- charte de prévention et confirmation d'âge ---- */
function ageSheet(X){
  if(!sheet||sheet.t!=='age') return false;
  const st=sheet.st||0;
  if(st===2) $('sheet').innerHTML=`<div class="tuto gtu"><div class="tu-ic">🔞</div><h2>Avant de jouer</h2>
   <p><b>High &amp; Rouillé</b> contient des contenus <b>destinés à un public majeur</b> : une partie du jeu met en scène, <b>uniquement dans un univers de fiction</b>, la culture du cannabis, des activités et des courses clandestines, et la police.</p>
   <p>Un mineur peut jouer au jeu : <b>tout ce qui touche à l’illégal lui est entièrement masqué</b> (labo, courses clandestines, missions illégales, équipe clandestine).</p>
   <p class="note">Réponds honnêtement. Aucune pièce d’identité n’est demandée.</p>
   <div class="tu-btns col"><button class="btn" data-a="age1yes">✅ J’ai 18 ans ou plus</button><button class="btn alt" data-a="age1no">🙋 J’ai moins de 18 ans</button></div></div>`;
  else if(st===0) $('sheet').innerHTML=`<div class="tuto gtu">${X}<div class="tu-ic">⚠️</div><h2>Charte de prévention</h2>
   <p>La suite du jeu (le <b>labo clandestin</b> et les activités illégales) met en scène la <b>culture du cannabis</b>, <b>uniquement dans un univers de fiction</b>.</p>
   <ul class="agel"><li>Le cannabis est <b>interdit aux mineurs</b>. Cette partie du jeu l’est aussi.</li><li>Ce jeu ne montre pas comment cultiver, et ne doit pas être imité : la culture, la détention et la vente sont encadrées par la loi.</li><li>Le cannabis a des risques réels : dépendance, troubles de l’attention et de la mémoire, effets sur la santé mentale, <b>surtout avant 25 ans</b>. Au volant, il est dangereux.</li><li>Besoin d’en parler, anonymement ? En Belgique : Infor-Drogues, 02 227 52 52.</li></ul>
   <div class="tu-btns"><button class="btn alt" data-a="agenope">Je ne veux pas de cette partie</button><button class="btn" data-a="agecharte">J’ai lu la charte</button></div></div>`;
  else $('sheet').innerHTML=`<div class="tuto gtu">${X}<div class="tu-ic">🔞</div><h2>Confirme ton âge</h2>
   <p>Pour débloquer le labo et la partie illégale, tu dois avoir <b>18 ans ou plus</b>.</p><p class="note">Réponds honnêtement : cette partie n’est pas destinée aux mineurs.</p>
   <div class="tu-btns col"><button class="btn" data-a="ageyes">✅ J’ai 18 ans ou plus, et je le confirme</button><button class="btn alt" data-a="agenope">❌ J’ai moins de 18 ans</button></div></div>`;
  return true;
}
ACT.agenext=()=>{ sheet.st=1; renderSheet(); };
ACT.ageyes=()=>{ S.age18=true; S.charte=1; save(); closeSheet(); toast('🔓 Labo débloqué'); try{ S.labSeen=0; render(); }catch(_){} };
ACT.agenope=()=>{ S.age18=false; save(); closeSheet(); toast('🔒 Cette partie du jeu est masquée. Le reste est accessible.'); try{ render(); }catch(_){} };
const afterAge=()=>{ const f=window.__afterAge; window.__afterAge=null; try{ if(f) f(); }catch(e){} };
ACT.age1yes=()=>{ S.age18=true; S.charte=0; save(); closeSheet(); try{ render(); }catch(_){} afterAge(); };
ACT.age1no=()=>{ S.age18=false; save(); closeSheet(); try{ render(); }catch(_){} afterAge(); };
ACT.agecharte=()=>{ S.charte=1; save(); closeSheet(); toast('🔓 Labo débloqué'); try{ S.labSeen=0; render(); }catch(_){} };
setInterval(()=>{ try{ if(!S||!S.intro||sheet||view==='race'||document.getElementById('cine')||document.getElementById('upd')) return;
  if(S.age18==null) openSheet({t:'age',st:2});
  else if(S.age18===true&&S.charte==null) S.charte=1;                                    /* anciennes sauvegardes : charte déjà lue */
  else if(S.age18===true&&!S.charte&&S.lvl>=LAB_LVL) openSheet({t:'age',st:0}); }catch(e){} },2500);

/* ===== cinématique d'intro (≈ 50 s) : moteur 3D du jeu + synthèse audio ===== */
function startCine(done){
  if(navigator.webdriver||!glEnsure()||document.getElementById('cine')){ done(); return; }
  const ov=document.createElement('div'); ov.id='cine';
  ov.innerHTML='<div class="cn-bar t"></div><div class="cn-bar b"></div><div class="cn-cap" id="cnCap"></div><div class="cn-spd" id="cnSpd"></div><div class="cn-fade" id="cnFade"></div><button class="cn-skip" id="cnSkip">Passer ▸▸</button><div class="cn-start" id="cnGo"><b>HIGH &amp; ROUILLÉ</b><span>Touche l’écran pour lancer l’intro<br>🔊 son recommandé</span></div>';
  document.body.appendChild(ov);
  let ended=false, T=null, sc=null;
  const finish=()=>{ if(ended) return; ended=true; try{ cineAudioStop(); }catch(_){} try{ glStop(); if(sc) disposeScene(sc); }catch(_){} ov.remove(); done(); };
  document.getElementById('cnSkip').onclick=e=>{ e.stopPropagation(); finish(); };
  document.getElementById('cnGo').onclick=async()=>{
    document.getElementById('cnGo').remove();
    try{ auUnlock(); }catch(_){}
    try{ await ensureModels(); }catch(_){}
    try{ T=cineBuild(finish); sc=T.sc; glAttach('cine'); glRun(sc,T.cam,T.tick,'race'); cineAudioStart(T); }
    catch(e){ try{console.warn('cine',e);}catch(_){} finish(); }
  };
}
const CS=[[1.5,5,'Un soir ordinaire…'],[26.3,29.5,'Ils ne s’arrêtent pas.'],[40,43,'Trop rapides.']];
const cnE=x=>{x=Math.max(0,Math.min(1,x)); return x*x*(3-2*x);};
const cnTS=t=>t<13.3?1:t<14.8?1-.88*cnE((t-13.3)/1.5):t<26?.12:t<27.2?.12+.88*cnE((t-26)/1.2):1;
function cineBuild(finish){
  const sc=new THREE.Scene(), col=0x1b1030; sc.background=new THREE.Color(col); sc.fog=new THREE.Fog(col,45,430);
  sc.add(new THREE.AmbientLight(0x9a8fd0,.8)); const dl=new THREE.DirectionalLight(0xffb27a,.95); dl.position.set(-60,40,30); sc.add(dl);
  const cam=new THREE.PerspectiveCamera(70,1,.1,900); sc.add(cam);
  /* guidon (vue première personne) */
  const hb=new THREE.Group(), dk=new THREE.MeshLambertMaterial({color:0x15161c}), gl=new THREE.MeshLambertMaterial({color:0x8a6a48}), mt=new THREE.MeshLambertMaterial({color:0x9aa0aa});
  const bar=new THREE.Mesh(new THREE.CylinderGeometry(.014,.014,.66,8),mt); bar.rotation.z=Math.PI/2; hb.add(bar);
  [-.33,.33].forEach(x=>{ const g=new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,.14,8),dk); g.rotation.z=Math.PI/2; g.position.x=x; hb.add(g); const lv=new THREE.Mesh(new THREE.BoxGeometry(.012,.012,.1),mt); lv.position.set(x*.86,-.01,-.06); hb.add(lv); const h=new THREE.Mesh(new THREE.SphereGeometry(.05,8,6),gl); h.position.set(x*.98,-.02,.05); hb.add(h); });
  const st=new THREE.Mesh(new THREE.CylinderGeometry(.016,.016,.2,8),mt); st.rotation.x=Math.PI/2+.5; st.position.set(0,-.05,-.1); hb.add(st);
  const tyre=new THREE.Mesh(new THREE.CylinderGeometry(.34,.34,.045,20),dk); tyre.rotation.z=Math.PI/2; tyre.position.set(0,-.62,-.35); hb.add(tyre);
  [-.03,.03].forEach(x=>{ const f=new THREE.Mesh(new THREE.CylinderGeometry(.008,.008,.62,6),mt); f.position.set(x,-.3,-.18); f.rotation.x=-.5; hb.add(f); });
  hb.position.set(0,-.34,-.62); cam.add(hb);
  /* textures */
  const cv=(w,h,f)=>{ const c=document.createElement('canvas'); c.width=w; c.height=h; f(c.getContext('2d'),w,h); const t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; return t; };
  const road=cv(256,256,(x,w,h)=>{ x.fillStyle='#26262e'; x.fillRect(0,0,w,h); for(let i=0;i<900;i++){ x.fillStyle=`rgba(${60+Math.random()*40|0},${60+Math.random()*40|0},${70+Math.random()*40|0},.35)`; x.fillRect(Math.random()*w,Math.random()*h,2,2); }
    x.fillStyle='#e0b43c'; x.fillRect(0,h/2-3,w*.5,6); x.fillStyle='#cfd2dc'; x.fillRect(0,4,w,4); x.fillRect(0,h-8,w,4); });
  road.repeat.set(1,1);
  const facs=[0,1,2,3].map(k=>cv(128,256,(x,w,h)=>{ const base=['#2a1f3d','#3a2430','#1f2d3d','#33291f'][k]; x.fillStyle=base; x.fillRect(0,0,w,h);
    for(let r=0;r<12;r++) for(let c=0;c<5;c++){ const on=Math.random()<.4; x.fillStyle=on?(Math.random()<.2?'#7fe8ff':'#ffd27a'):'#10101a'; x.fillRect(8+c*24,10+r*20,14,11); } }));
  const fm=facs.map(t=>new THREE.MeshLambertMaterial({map:t,emissive:0x2a2418,emissiveMap:t}));
  const LEN=1200, rd=new THREE.Mesh(new THREE.PlaneGeometry(LEN,14),new THREE.MeshLambertMaterial({map:road})); rd.rotation.x=-Math.PI/2; road.repeat.set(LEN/16,1); sc.add(rd);
  const wk=new THREE.MeshLambertMaterial({color:0x4a4658}); [-9,9].forEach(z=>{ const m=new THREE.Mesh(new THREE.BoxGeometry(LEN,.25,4),wk); m.position.set(0,.12,z); sc.add(m); }); const sw=sc.children.slice(-2);
  /* bâtiments recyclés autour de la caméra */
  const NB=46, SB=14, LB=NB*SB, bl=[];
  [-1,1].forEach(sd=>{ for(let k=0;k<NB;k++){ const hh=9+((k*37+sd*11)%19)+(k%5===0?9:0), w=12.5, d=14;
    const m=new THREE.Mesh(new THREE.BoxGeometry(w,hh,d),fm[(k+(sd>0?2:0))%4]); m.position.y=hh/2; sc.add(m); bl.push({m,k,sd,d}); } });
  /* lampadaires */
  const NL=24, SL=26, LL=NL*SL, lp=[], bulb=new THREE.MeshBasicMaterial({color:0xffe2a0}), pole=new THREE.MeshLambertMaterial({color:0x22232b});
  [-1,1].forEach(sd=>{ for(let k=0;k<NL;k++){ const g=new THREE.Group(); const p=new THREE.Mesh(new THREE.CylinderGeometry(.08,.1,6.2,6),pole); p.position.y=3.1; g.add(p); const b=new THREE.Mesh(new THREE.SphereGeometry(.34,8,6),bulb); b.position.set(0,6.3,-sd*.7); g.add(b); sc.add(g); lp.push({g,k,sd}); } });
  /* ruelle + épave */
  let XA=0; const alley=new THREE.Group(); sc.add(alley);
  const am=new THREE.MeshLambertMaterial({color:0x2b2233}), af=new THREE.Mesh(new THREE.PlaneGeometry(11,76),new THREE.MeshLambertMaterial({color:0x1c1a22})); af.rotation.x=-Math.PI/2; af.position.set(0,.02,-38); alley.add(af);
  [-6,6].forEach(x=>{ const w=new THREE.Mesh(new THREE.BoxGeometry(1.2,16,76),fm[x<0?1:3]); w.position.set(x,8,-38); alley.add(w); });
  const endw=new THREE.Mesh(new THREE.BoxGeometry(14,16,1),am); endw.position.set(0,8,-77); alley.add(endw);
  const warm=new THREE.PointLight(0xffa860,1.6,26); warm.position.set(0,3.6,-26); alley.add(warm);
  const cold=new THREE.PointLight(0x6fa8ff,.9,30); cold.position.set(0,5,-12); alley.add(cold);
  const bulb2=new THREE.Mesh(new THREE.SphereGeometry(.25,8,6),bulb); bulb2.position.set(0,3.6,-26); alley.add(bulb2);
  const ep=buildCar(M.epave,'#fff',{}); ep.g.position.set(.3,0,-34); ep.g.rotation.y=-1.15; alley.add(ep.g);
  /* voitures */
  const mk=id=>buildCar(M[id],'#fff',{});
  const spec=[['rossa',-3.2,16.0],['aurion',.6,16.4],['solus',2.9,17.3],['gts',-2.9,17.8],['touge',.2,18.7],['rx4',2.6,19.1],['volta',-3.0,20.2]].map(a=>({c:mk(a[0]),lane:a[1],tr:a[2],pol:0}));
  [['patrouille',.4,22.2],['patrouille',-2.4,23.0]].forEach(a=>spec.push({c:mk(a[0]),lane:a[1],tr:a[2],pol:1}));
  spec.forEach(s=>{ sc.add(s.c.g); });
  /* tables déterministes : temps de film -> temps monde -> position du vélo */
  const DT=.02, NT=2600, TW=new Float32Array(NT+1), XB=new Float32Array(NT+1); let tw=0, xb=0;
  for(let i=0;i<=NT;i++){ const t=i*DT; TW[i]=tw; XB[i]=xb; const ts=cnTS(t), vb=t<28?3.6:3.6+(11-3.6)*cnE((t-28)/5); tw+=ts*DT; xb+=vb*ts*DT; }
  const at=(A,t)=>{ const f=Math.max(0,Math.min(NT-1,t/DT)), i=Math.floor(f); return A[i]+(A[i+1]-A[i])*(f-i); };
  const twAt=t=>at(TW,t), xbAt=t=>at(XB,t);
  XA=xbAt(44.6); alley.position.set(XA,0,-7); ep.g.position.set(.3,0,-27);   /* ruelle dans l'axe -z, au bord du trottoir */
  spec.forEach(s=>{ s.tp=twAt(s.tr); s.xp=xbAt(s.tr); });
  const carX=(s,t)=>{ const u=twAt(t)-s.tp; return s.xp+(u<0?55*u:55*u+5*u*u); };
  const carV=(s,t)=>{ const u=twAt(t)-s.tp; return u<0?55:55+10*u; };
  const P=spec.map(()=>new THREE.Vector3()), LT=new THREE.Vector3(), tmp=new THREE.Vector3(); let lookInit=false, prevT=0, fovC=70;
  const T={sc,cam,spec,P,t:0,ts:1,xb:0,carX,carV,twAt,xbAt,done:false};
  T.tick=(dt,time)=>{
    if(!T.t0) T.t0=time; const t=Math.min(50.2,time-T.t0); const ts=cnTS(t), dtw=ts*(t-prevT); prevT=t; T.t=t; T.ts=ts;
    const xbn=xbAt(t), zb=-5.8; T.xb=xbn;
    /* voitures */
    spec.forEach((s,i)=>{ const x=carX(s,t), v=carV(s,t); s.x=x; s.z=s.lane+.35*Math.sin(twAt(t)*1.3+i); s.v=v; const g=s.c.g;
      g.position.set(x,0,s.z); g.rotation.y=-.03*Math.cos(twAt(t)*1.3+i); g.visible=Math.abs(x-(T.cx==null?xbn:T.cx))<430; P[i].set(x,.7,s.z);
      s.c.wheels.forEach(w=>{ w.rotation.z-=v*dtw/(s.c.wr||.34); }); if(s.pol) pulseSirens(s.c,t*1.0); });
    /* caméra */
    let pos=new THREE.Vector3(xbn,1.55+Math.sin(t*(t>39?14:5))*(t>39?.05:.02),zb), look=null, fov=70, roll=0;
    const bobShake=t>39&&t<44?.03:.006;
    if(t<26||t>=39){
      if(t<9.5){ look=new THREE.Vector3(xbn+50,1.2,zb+Math.sin(t*.8)*.8); }
      else if(t<12.3){ const a=cnE((t-9.5)/2.8)*Math.PI; look=new THREE.Vector3(xbn+Math.cos(a)*50,1.3,zb+Math.sin(a)*50); roll=Math.sin(a)*.06; }
      else if(t>=17.6&&t<20.4){ let bi=0,bd=1e9; spec.forEach((s,i)=>{ const d=Math.abs(s.x-xbn-6); if(d<bd){bd=d;bi=i;} }); pos.set(xbn+2,.45,zb+.2); look=P[bi].clone(); look.y=.7; fov=58; roll=-.08; }
      else if(t>=22&&t<24.8){ pos.set(xbn+16,1.0,zb+.8); look=P[0].clone(); look.y=.8; fov=50; }
      else if(t<26){ let bi=0,bd=1e9; spec.forEach((s,i)=>{ const d=Math.hypot(s.x-xbn,s.z-zb); if(d<bd){bd=d;bi=i;} }); look=P[bi].clone(); look.y=.9; fov=70-18*cnE((t-13)/2)*(t<26?1:0); roll=.05; }
      else if(t<43.6){ look=new THREE.Vector3(xbn+50,.9,zb); fov=74; }
      else if(t<44.9){ const a=-cnE((t-43.6)/1.3)*Math.PI/2; look=new THREE.Vector3(xbn+Math.cos(a)*50,1.2,zb+Math.sin(a)*50); fov=70; }
      else{ const e=cnE((t-44.9)/3.8); pos.set(XA,1.55-.55*e,zb-e*20); look=new THREE.Vector3(XA+.3,.7+.2*e,-34); fov=68-12*e; }
    } else {
      const L=spec[0];
      if(t<31){ pos.set(L.x-11,1.35,L.z-5.5); look=new THREE.Vector3(L.x+4,.8,L.z); fov=80; }
      else if(t<35){ if(!T.sx) T.sx=carX(L,31)+150; pos.set(T.sx,.65,-2.2); look=P[0].clone(); fov=62; }
      else { pos.set(L.x+2,1.25,Math.max(-9.3,L.z-6.5)); look=new THREE.Vector3(L.x-7,.9,L.z); fov=52; }
    }
    if(!lookInit||t<9.5||(t>=26&&t<26.1)||(t>=17.6&&t<17.7)||(t>=20.4&&t<20.5)||(t>=22&&t<22.1)||(t>=24.8&&t<24.9)||t>=43.6&&t<43.7||t>=39&&t<39.1){ LT.copy(look); lookInit=true; }
    else{ const k=1-Math.exp(-(t>=12.3&&t<26?3.2:t>=44.9?6:14)*Math.max(.001,dt)); LT.lerp(look,t<12.3?1:k); }
    cam.position.copy(pos); cam.position.x+=(Math.random()-.5)*bobShake; cam.position.y+=(Math.random()-.5)*bobShake;
    T.cx=pos.x; { const cxr=pos.x;
    rd.position.x=Math.floor(cxr/16)*16; sw.forEach(m=>m.position.x=Math.floor(cxr/16)*16);
    bl.forEach(o=>{ const x=cxr-250+(((o.k*SB-cxr+250)%LB)+LB)%LB; o.m.position.set(x,o.m.position.y,o.sd*(11+o.d/2)); o.m.visible=!(o.sd<0&&Math.abs(x-XA)<10.5); });
    lp.forEach(o=>{ const x=cxr-250+(((o.k*SL-cxr+250)%LL)+LL)%LL; o.g.position.set(x,0,o.sd*8.4); });
    }
    cam.lookAt(LT); if(roll) cam.rotateZ(roll);
    if(t>=26&&t<28.5) fov+=14*(1-(t-26)/2.5); if(t>=39&&t<41) fov+=12*(1-(t-39)/2); if(t>=12.3&&t<26) fov-=3*Math.min(1,(t-12.3)/6);
    if(Math.abs(cam.fov-fov)>.05){ cam.fov+=(fov-cam.fov)*Math.min(1,dt*6); cam.updateProjectionMatrix(); }
    hb.visible=((t<17.6||(t>=20.4&&t<26))||(t>=39&&t<45)); hb.position.y=-.34+Math.sin(t*(t>39?14:5))*.01;
    ep.g.visible=t>40;
    /* légendes, fondu */
    const cap=document.getElementById('cnCap'); if(cap){ const c=CS.find(a=>t>=a[0]&&t<a[1]); if(c){ cap.textContent=c[2]; cap.style.opacity=1; cap.classList.remove('big'); } else if(t>=46.4){ cap.innerHTML='HIGH &amp; ROUILLÉ'; cap.classList.add('big'); cap.style.opacity=1; } else cap.style.opacity=0; }
    const sp=document.getElementById('cnSpd'); if(sp){ const o=t>=26&&t<39?.75:t>=39&&t<44?.6:t>=12.3&&t<26?.25:t>=3&&t<9.5?.12:0; sp.style.opacity=o; sp.style.animationDuration=(ts<.5?1.6:.35)+'s'; }
    const fd=document.getElementById('cnFade'); if(fd) fd.style.opacity=t<1.2?1-t/1.2:t>49?Math.min(1,(t-49)/1):0;
    try{ cineAudioTick(T,dt); }catch(e){}
    if(t>=50&&!T.done){ T.done=true; finish(); }
  };
  return T;
}
/* ---- audio : musique épique qui suit le ralenti, moteurs avec Doppler, sirènes ---- */
const CA={on:false};
function cineAudioStart(T){
  const A=AU.ctx; if(!A||!AU.master) return; const o=A.createGain(); o.gain.value=0; o.gain.linearRampToValueAtTime(1,A.currentTime+1.5); o.connect(AU.master);
  CA.o=o; CA.A=A; CA.nodes=[]; CA.beat=0; CA.hb=0;
  const keep=n=>{CA.nodes.push(n); return n;};
  const lp=A.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=1200; lp.connect(o); CA.lp=lp;
  /* nappe Ré mineur + sub */
  CA.pad=[73.4,110,146.8,174.6].map((f,i)=>{ const s=keep(A.createOscillator()); s.type='sawtooth'; s.detune.value=(i%2?7:-7); s.frequency.value=f; const g=A.createGain(); g.gain.value=.08; s.connect(g); g.connect(lp); s.start(); return {s,f}; });
  const sub=keep(A.createOscillator()); sub.type='sine'; sub.frequency.value=36.7; const sg=A.createGain(); sg.gain.value=.26; sub.connect(sg); sg.connect(o); sub.start(); CA.sub={s:sub,f:36.7};
  /* écho spacieux + nappe épique (accord Ré mineur / Sib) */
  const dly=A.createDelay(1.5); dly.delayTime.value=.42; const fb=A.createGain(); fb.gain.value=.38; const dlp=A.createBiquadFilter(); dlp.type='lowpass'; dlp.frequency.value=1800; lp.connect(dly); dly.connect(dlp); dlp.connect(fb); fb.connect(dly); dlp.connect(o);
  const epg=A.createGain(); epg.gain.value=0; epg.connect(lp); epg.connect(dly); CA.ep=epg;
  CA.epo=[146.8,174.6,220,293.7,349.2,440].map((f,i)=>{ const s=keep(A.createOscillator()); s.type=i<3?'sawtooth':'triangle'; s.detune.value=(i%2?9:-9); s.frequency.value=f; const g=A.createGain(); g.gain.value=i<3?.05:.07; s.connect(g); g.connect(epg); s.start(); return {s,f}; });
  /* vent */
  const ns=keep(A.createBufferSource()); ns.buffer=AU.noise; ns.loop=true; const bp=A.createBiquadFilter(); bp.type='bandpass'; bp.frequency.value=500; bp.Q.value=.6; const wg=A.createGain(); wg.gain.value=.05; ns.connect(bp); bp.connect(wg); wg.connect(o); ns.start(); CA.wind={g:wg,bp};
  /* voix de moteurs et sirènes */
  CA.v=T.spec.map(s=>{ const a=keep(A.createOscillator()), b=keep(A.createOscillator()); a.type='sawtooth'; b.type='square'; const f=A.createBiquadFilter(); f.type='lowpass'; f.frequency.value=s.pol?700:1100; const g=A.createGain(); g.gain.value=0;
    a.connect(f); b.connect(f); f.connect(g); let pn=null; if(A.createStereoPanner){ pn=A.createStereoPanner(); g.connect(pn); pn.connect(o); } else g.connect(o); a.start(); b.start();
    let sir=null; if(s.pol){ const q=keep(A.createOscillator()); q.type='square'; const qg=A.createGain(); qg.gain.value=0; const qf=A.createBiquadFilter(); qf.type='bandpass'; qf.frequency.value=900; qf.Q.value=1.2; q.connect(qf); qf.connect(qg); qg.connect(pn||o); q.start(); sir={q,qg}; }
    return {a,b,g,pn,sir,pass:null}; });
  CA.on=true;
}
function cineKick(vol,pitch){ const A=CA.A,t=A.currentTime,s=A.createOscillator(),g=A.createGain(); s.frequency.setValueAtTime(150*pitch,t); s.frequency.exponentialRampToValueAtTime(40*pitch,t+.16); g.gain.setValueAtTime(vol,t); g.gain.exponentialRampToValueAtTime(.001,t+.3); s.connect(g); g.connect(CA.o); s.start(t); s.stop(t+.35); }
function cineNote(f,len,vol,type){ const A=CA.A,t=A.currentTime,s=A.createOscillator(),g=A.createGain(),fl=A.createBiquadFilter(); s.type=type||'sawtooth'; s.frequency.value=f; fl.type='lowpass'; fl.frequency.setValueAtTime(2600,t); fl.frequency.exponentialRampToValueAtTime(500,t+len); g.gain.setValueAtTime(vol,t); g.gain.exponentialRampToValueAtTime(.001,t+len); s.connect(fl); fl.connect(g); g.connect(CA.o); s.start(t); s.stop(t+len+.05); }
function cineNoise(len,f0,f1,vol){ const A=CA.A,t=A.currentTime,s=A.createBufferSource(),b=A.createBiquadFilter(),g=A.createGain(); s.buffer=AU.noise; b.type='bandpass'; b.Q.value=1.2; b.frequency.setValueAtTime(f0,t); b.frequency.exponentialRampToValueAtTime(f1,t+len); g.gain.setValueAtTime(.001,t); g.gain.linearRampToValueAtTime(vol,t+len*.7); g.gain.exponentialRampToValueAtTime(.001,t+len); s.connect(b); b.connect(g); g.connect(CA.o); s.start(t); s.stop(t+len+.05); }
function cineAudioTick(T,dt){
  if(!CA.on) return; const A=CA.A, t=T.t, ts=T.ts, m=.55+.45*ts, now=A.currentTime;
  /* ralenti : tout descend en hauteur et s'assourdit */
  CA.lp.frequency.setTargetAtTime(ts<.5?520:t>26?3600:1500,now,.15);
  CA.pad.forEach(p=>p.s.frequency.setTargetAtTime(p.f*m,now,.08)); CA.sub.s.frequency.setTargetAtTime(CA.sub.f*m,now,.08);
  CA.ep.gain.setTargetAtTime(t<12?0:t<26?(ts<.5?.9:.5):t<39?.35:t<44?.2:t>=46?.5:0,now,.5); CA.epo.forEach(p=>p.s.frequency.setTargetAtTime(p.f*(t>=17&&t<26?1.122:1)*m,now,.25));
  CA.wind.g.gain.setTargetAtTime(t<9?.05:t>39?.09:.03,now,.3);
  /* événements */
  const ev=(k,a)=>{ if(!CA['e'+k]&&t>=a){ CA['e'+k]=1; return true; } return false; };
  if(ev(1,13.3)){ cineKick(.9,.5); cineNoise(1.6,300,90,.25); }                    /* entrée du ralenti */
  if(ev(2,24.3)) cineNoise(2.2,200,6000,.3);
  if(ev(5,17.4)) cineNoise(2.4,300,7000,.22);  if(ev(6,21.8)){ cineNoise(2.6,300,8000,.25); cineKick(.9,.4); }
  if(ev(7,13.4)){ [146.8,220,293.7,440].forEach(f=>cineNote(f,4,.14,'triangle')); }  if(ev(8,19)){ [116.5,174.6,233,349].forEach(f=>cineNote(f,4,.14,'triangle')); }                                      /* montée */
  if(ev(3,26)){ cineKick(1,1); cineKick(.8,.6); cineNote(73.4,1.6,.35); cineNote(146.8,1.6,.3); cineNoise(1.2,6000,300,.35); } /* explosion de reprise */
  if(ev(4,46.4)){ cineKick(1,.7); [146.8,174.6,220,293.7].forEach(f=>cineNote(f,3,.16)); }  /* titre */
  /* rythme dépendant du ralenti */
  const mr=.35+.65*ts, tempo=t<9?70:t<26?60:t<39?150:t<44?90:120; CA.beat+=dt*(tempo/60)*mr*(t<13.3?1:1);
  const b=Math.floor(CA.beat), h=Math.floor(CA.beat*2);
  if(b!==CA.lb){ CA.lb=b; if(t>=6&&t<9.5) cineKick(.35,1); else if(t>=13.3&&t<26) cineKick(.95,.5+.3*ts); else if(t>=26&&t<39) cineKick(.8,1); else if(t>=44&&t<46.4) cineKick(.5,.9); }
  if(h!==CA.lh){ CA.lh=h; const arp=[146.8,174.6,220,261.6,220,174.6,196,233]; if(t>=26&&t<39) cineNote(arp[h%8]*(h%16<8?1:1.125),.22,.13); else if(t>=44&&t<46.4) cineNote([293.7,349.2,440][h%3],.5,.07,'triangle'); else if(t>=15&&t<26&&h%4===0) cineNote(220*m,1.2,.05,'sine'); if(t>=26&&t<39&&h%2) cineNoise(.07,8000,9000,.07); }
  /* moteurs, Doppler et sirènes */
  const cx=T.cam.position.x, cz=T.cam.position.z, f=new THREE.Vector3(); T.cam.getWorldDirection(f);
  T.spec.forEach((s,i)=>{ const v=CA.v[i], dx=s.x-cx, dz=s.z-cz, d=Math.max(1,Math.hypot(dx,dz)), vr=s.v*dx/d, u=T.twAt(t)-s.tp, dop=340/(340+vr);
    const rev=1+Math.max(0,Math.min(3,u))*.3, f0=(s.pol?62:50+i*6)*rev*dop*m, g=Math.min(1,1/(1+Math.pow(d/(ts<.5?14:18),1.5)))*(s.pol?.04:.075)*(Math.abs(s.x-cx)<440?1:0);
    v.a.frequency.setTargetAtTime(f0,now,.04); v.b.frequency.setTargetAtTime(f0*1.5,now,.04); v.g.gain.setTargetAtTime(g,now,.05); if(v.pn) v.pn.pan.setTargetAtTime(Math.max(-1,Math.min(1,(-dx*f.z+dz*f.x)/d)),now,.05);
    if(v.sir){ v.sir.q.frequency.setTargetAtTime(((Math.floor(t*(ts<.5?1:2))%2)?960:720)*m,now,.02); v.sir.qg.gain.setTargetAtTime(Math.min(.5,1/(1+d/40))*.09*(t>14?1:0),now,.05); }
    const side=Math.sign(dx); if(v.pass!=null&&side!==v.pass&&d<40&&T.ts>0){ cineNoise(ts<.5?1.3:.5,1800*m,300,.28*Math.min(1,12/d)); } v.pass=side; });
}
function cineAudioStop(){ if(!CA.on) return; CA.on=false; try{ const A=CA.A; CA.o.gain.setTargetAtTime(0,A.currentTime,.2); setTimeout(()=>{ CA.nodes.forEach(n=>{ try{n.stop();}catch(_){} try{n.disconnect();}catch(_){} }); try{CA.o.disconnect();}catch(_){} },900); }catch(_){} }
ACT.cine=()=>{ closeSheet&&closeSheet(); startCine(()=>{}); };
/* ===== v0.56 : doublons caméra, capot cockpit, voie en accélérant, intro dans les réglages ===== */
setInterval(()=>{ try{ const l=document.querySelectorAll('#bCam'); for(let i=1;i<l.length;i++) l[i].remove(); }catch(e){} },400);
ptWheel=function(on){
  const el=$('rslot'); if(!el||!el.parentNode) return; const w=el.parentNode; let d=w.querySelector('#ptwh');
  if(!on){ if(d) d.remove(); return; }
  if(d) return;
  const m=(RC&&RC.P&&(RC.P.m||(RC.P.r&&RC.P.r.m)))||{}, c=m.col||'#555';
  d=document.createElement('div'); d.id='ptwh';
  d.innerHTML=`<svg viewBox="0 0 100 12" preserveAspectRatio="none"><defs><linearGradient id="hdg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c}" stop-opacity=".95"/><stop offset="1" stop-color="#05060a"/></linearGradient></defs><path d="M0 12V8.6Q50 3.2 100 8.6V12Z" fill="url(#hdg)"/><path d="M0 8.6Q50 3.2 100 8.6" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width=".4"/></svg>`;
  w.appendChild(d);
};
/* changer de voie en gardant le doigt sur l'accélérateur : on réagit au toucher (pas au clic, que le multi-touch supprime) */
document.addEventListener('pointerdown',e=>{
  const b=e.target&&e.target.closest&&e.target.closest('#laneBtn,#mkIt'); if(!b) return;
  e.preventDefault(); b.dataset.pd=String(Date.now());
  try{ if(b.id==='laneBtn') ACT.lane(); else ACT.mkuse(); }catch(_){}
},true);
document.addEventListener('click',e=>{
  const b=e.target&&e.target.closest&&e.target.closest('#laneBtn,#mkIt'); if(b&&Date.now()-(+b.dataset.pd||0)<900){ e.stopPropagation(); e.preventDefault(); }
},true);
/* ---- v0.57 : collisions drag, swipe paquets ---- */
const _tick33=tick;
tick=function(dt){
  _tick33.apply(this,arguments);
  try{ const D=RC&&RC.dbon; if(!D||RC.kind!=='race'||RC.clock<0||RC.done) return; const P=RC.P; RC.cbT=(RC.cbT||0)-dt;
    RC.Os.forEach(o=>{ if(o.fin!=null||P.fin!=null) return; const dl=Math.abs(P.lane-o.lane); if(dl>1.7) return; const g=o.x-P.x;
      if(g>0&&g<4.4){ if(P.v>o.v*.97){ P.v=o.v*.95; P.x=Math.min(P.x,o.x-4.4); if(RC.cbT<=0){ RC.cbT=.9; flash('Collision ! change de voie','#FF4D6D',.9); try{navigator.vibrate&&navigator.vibrate([40,30,40]);}catch(e){} } } }
      else if(g<0&&g>-4.4){ if(o.v>P.v*.97){ o.v=P.v*.95; o.x=Math.min(o.x,P.x-4.4); } } });
  }catch(e){ console.error(e); }
};
let SW=null;
document.addEventListener('pointerdown',e=>{ const st=e.target.closest&&e.target.closest('.ostage'); SW=st&&sheet&&sheet.t==='open'?{x:e.clientX,y:e.clientY,t:Date.now()}:null; },true);
document.addEventListener('pointerup',e=>{ if(!SW) return; const dx=e.clientX-SW.x, dy=e.clientY-SW.y, s=SW; SW=null;
  if(Math.abs(dx)>40&&Math.abs(dx)>Math.abs(dy)*1.3&&Date.now()-s.t<900){ window.__swT=Date.now(); const st=document.querySelector('.ostage'); if(st){ st.style.transition='transform .18s,opacity .18s'; st.style.transform='translateX('+(dx<0?-60:60)+'px)'; st.style.opacity='.2'; } ACT.reveal(); } },true);
document.addEventListener('click',e=>{ if(window.__swT&&Date.now()-window.__swT<400&&e.target.closest&&e.target.closest('.ostage')){ e.stopPropagation(); e.preventDefault(); } },true);
/* ---- v0.58b : podiums plus simples ---- */
const podOpen=i=>S.lvl>=POD_LVL[i];
const podVal=c=>M[c.mid].t*(.5+.5*c.etat/100)*(1+(st(c).sp.inc||0))*(c.sh?1.5:1);
Object.assign(ACT,{
  podcar(){ if(!sheet||sheet.t!=='car') return; const u=sheet.uid, c=car(u); if(!c) return; const at=S.pod.slots.indexOf(u);
    if(at>=0){ S.pod.slots[at]=null; toast('Retirée du podium'); }
    else{ let i=S.pod.slots.findIndex((x,k)=>podOpen(k)&&!x);
      if(i<0){ let w=-1,wv=1e9; S.pod.slots.forEach((x,k)=>{ if(!podOpen(k)) return; const cc=x&&car(x); const v=cc?podVal(cc):0; if(v<wv){wv=v;w=k;} }); i=w; }
      if(i<0) return toast('Aucun podium ouvert');
      S.pod.slots[i]=u; toast('Placée sur le podium '+(i+1)); }
    save(); render(); renderSheet(); },
  podauto(){ const open=POD_LVL.map((l,i)=>podOpen(i)?i:-1).filter(i=>i>=0); const best=S.cars.slice().sort((a,b)=>podVal(b)-podVal(a)).slice(0,open.length);
    S.pod.slots=S.pod.slots.map(()=>null); best.forEach((c,k)=>{ S.pod.slots[open[k]]=c.uid; }); toast(best.length+' voiture'+(best.length>1?'s':'')+' placée'+(best.length>1?'s':'')+' sur tes podiums'); save(); render(); }
});
const _rs34=renderSheet;
renderSheet=function(){ const r=_rs34.apply(this,arguments);
  try{ if(sheet&&sheet.t==='car'){ const c=car(sheet.uid), h=document.querySelector('#sheet .thhero'); if(c&&h&&!document.getElementById('podBtn')){ const on=S.pod.slots.includes(c.uid); h.insertAdjacentHTML('afterend','<button id="podBtn" class="btn wide" style="margin-top:8px" data-a="podcar">'+(on?'🏛️ Retirer du podium':'🏛️ Placer sur un podium')+'</button>'); } } }catch(e){}
  return r; };
const _rd34=render;
render=function(){ const r=_rd34.apply(this,arguments);
  try{ const b=document.getElementById('pCollect'); if(b&&!document.getElementById('podAuto')){ const row=b.closest('.row'); if(row) row.insertAdjacentHTML('afterend','<div class="row" id="podAuto"><span class="ico">⭐</span><span class="grow"><span class="ttl">Placement auto</span><br><span class="sub">Place tes meilleures voitures sur les podiums ouverts.</span></span><button class="btn sm" data-a="podauto">Meilleures</button></div><div class="rchips" id="podChips">'+POD_LVL.map((l,i)=>{const u=S.pod.slots[i], c=u&&podOpen(i)&&car(u); return '<button data-a="slot3" data-id="'+i+'" class="'+(c?'on':'')+'">'+(podOpen(i)?'🏛️ '+(i+1)+(c?' · '+M[c.mid].nom:' · libre'):'🔒 niv. '+l)+'</button>';}).join('')+'</div>'); } }catch(e){}
  return r; };
/* sélection 3D plus tolérante : podium le plus proche du doigt à l'écran */
garagePick=function(e,c){
  const r=c.getBoundingClientRect(); const nx=(e.clientX-r.left)/r.width*2-1, ny=-((e.clientY-r.top)/r.height*2-1);
  GG.ray.setFromCamera({x:nx,y:ny},GG.cam); const h=GG.ray.intersectObjects(GG.hit,false);
  if(h.length){ openSheet({t:'slot',i:h[0].object.userData.slot}); return; }
  let bi=-1,bd=.28; GG.hit.forEach(m=>{ const v=new THREE.Vector3(); m.getWorldPosition(v); v.y=1; v.project(GG.cam); const d=Math.hypot((v.x-nx)*r.width/r.height*.6,v.y-ny); if(d<bd){bd=d;bi=m.userData.slot;} });
  if(bi>=0) openSheet({t:'slot',i:bi});
};
/* ---- v0.61 : thèmes musicaux de course, tempo lissé, anti-chevauchement, notes de mise à jour ---- */
const GAME_VER='1.3';
const PATCH={'1.3':{t:'Pinball retravaillé, boutons de course',l:['Pinball : ponts écartés et plus durs à atteindre, GARAGE bien moins gourmand','Pinball : les trous de changement de table fermés laissent passer la bille','Paquet Voiture aussi achetable avec 50 jetons','Course : DRIFT remplace le gros NITRO, GAZ agrandi pour mieux doser, NITRO plus compact']},'1.2':{t:'Pinball à ponts, paquets Voiture',l:['Pinball : 8 tables avec ponts, rampes et banques de cibles','Paquets : un seul carrousel (aléatoires, ciblés, Voiture), achat ×1, ×5 ou ×10','Nouveau Paquet Voiture : 1 voiture au hasard, 50 000 cr','Âge demandé au 1er lancement : l’illégal est masqué aux mineurs','Missions clandestines pour les majeurs (après le labo)','Rue Néon : enseignes retirées, zone de marche corrigée']},'1.1':{t:'Menus regroup\u00e9s',l:['5 onglets : Garage, \u00c9preuves, Atelier, March\u00e9, Missions','Cartes dans March\u00e9 ; Labo, Base et \u00c9quipe dans Atelier','Labo ouvert comme une page, avec Croiser et Tout planter','Atelier : Tout fusionner, par raret\u00e9 ou d\u2019un coup','Paquets cibl\u00e9s en vrais paquets de cartes','\u00c9preuves tri\u00e9es par niveau','Drag arcade : plus de d\u00e9part dans la voiture adverse']},'1.0':{t:'Version 1.0',l:['5 nouveaux circuits et 3 circuits de drift (voir \u00c9preuves)','Atelier et \u00c9quipe r\u00e9unis : 7 onglets au lieu de 8','Sauvegarde : export, import et copie de secours (Base > R\u00e9glages)','Qualit\u00e9 graphique Auto / Basse / Haute','Interface arrondie et centr\u00e9e partout','Objectifs de d\u00e9but de partie plus guid\u00e9s']},'0.66':{t:'March\u00e9 plus lisible',l:['Casse et concession : affichage x1 ou x3','Recherche, filtre de raret\u00e9 et tri (prix, raret\u00e9, puissance)']},'0.65':{t:'Labo plus clair',l:['Base : labo et \u00e9quipe retir\u00e9s (boutons du bas)','Labo : swipe entre les plantes, menu arrondi','Chrono min:sec sur chaque plante + alerte \u00ab pr\u00eate pour la floraison \u00bb','Bouton Floraison direct dans le labo','Jardinier plus progressif','Tuto : chaleur et police expliqu\u00e9es','Labo : musique reggae seule, plus de message r\u00e9p\u00e9t\u00e9, boutons centr\u00e9s','Labo : ambiance reggae / dub / chill et d\u00e9cor cannabis']},'0.64':{t:'Garage & barre d\u2019XP',l:['Collection : affichage x1 ou x3','Fiche v\u00e9hicule : swipe gauche/droite pour changer de voiture (fl\u00e8ches retir\u00e9es)','Modules : affichage x1, x3 ou x5','Cartes : paquets al\u00e9atoires en haut, paquets cibl\u00e9s en dessous','Barre d\u2019XP du haut simplifi\u00e9e : progression + XP restant']},'0.63':{t:'Atelier, équipe & paquets',l:[
 '🛠️ Onglets Atelier et Équipe dans la barre du bas, avec tuto à la première visite',
 '♻️ Atelier refait : Fabriquer, Recycler, Fusionner en 3 onglets clairs',
 '👥 Équipe refaite : cartes lisibles, énergie, loyauté, recrutement',
 '◀ ▶ Flèches sur la fiche d’une voiture pour passer à la suivante',
 '🎯 6 paquets ciblés (puissance, adhérence, freinage, robuste, style, nitro) + les paquets aléatoires',
 '🎟 Paiement des paquets explicite : crédits ou jetons, tu choisis',
 '❓ Un tuto pour chaque menu, rejouable avec le bouton ?']}};
/* --- thèmes musicaux --- */
const MTH=[
 {n:'Néon',bpm:174,orig:true},
 {n:'Asphalte',bpm:168,root:73.42,q:[[0,'m'],[8,'M'],[3,'M'],[10,'M']],lead:[[0,2],[3,3],[6,4],[10,3],[12,5]],w:'sawtooth'},
 {n:'Désert',bpm:164,root:82.41,q:[[0,'m'],[1,'M'],[3,'M'],[1,'M']],lead:[[0,3],[2,4],[4,3],[8,2],[10,3],[14,4]],w:'square'},
 {n:'Nuit',bpm:170,root:65.41,q:[[0,'m'],[8,'M'],[3,'M'],[10,'M']],lead:[[0,4],[4,5],[8,4],[12,3]],w:'triangle'},
 {n:'Acier',bpm:176,root:98,q:[[0,'m'],[8,'M'],[3,'M'],[10,'M']],lead:[[0,5],[3,4],[6,5],[9,3],[12,4],[14,5]],w:'sawtooth'},
 {n:'Orage',bpm:178,root:61.74,q:[[0,'m'],[8,'M'],[3,'M'],[10,'M']].map(a=>a).slice(0,4),lead:[[0,3],[1,4],[4,5],[8,3],[9,4],[12,2]],w:'square'}];
MTH[5].q=[[0,'m'],[8,'M'],[3,'M'],[10,'M']];
const CH0=CHORDS.map(c=>({sub:c.sub,bass:c.bass,pad:c.pad.slice(),arp:c.arp.slice()}));
let CUR_TH=0;
function mkChord(r,k,qual){ const f=r*Math.pow(2,k/12), t3=qual==='m'?3:4, tri=[1,Math.pow(2,t3/12),Math.pow(2,7/12)].map(x=>f*2*x); return {sub:f/2,bass:f,pad:tri,arp:tri.concat(tri.map(x=>x*2))}; }
function applyTheme(i){ if(i===CUR_TH) return; CUR_TH=i; const T=MTH[i];
  for(let k=0;k<4;k++){ const c=T.orig?CH0[k]:mkChord(T.root,T.q[k][0],T.q[k][1]); CHORDS[k].sub=c.sub; CHORDS[k].bass=c.bass; CHORDS[k].pad=c.pad; CHORDS[k].arp=c.arp; }
  BPM=T.bpm; STEP=60/BPM/4; BAR=STEP*16; }
function themeFor(){ let id=''; try{ id=(R&&R.ev&&R.ev.id)||''; }catch(e){} let i=-1; try{ i=EVENTS.findIndex(e=>e.id===id); }catch(e){} if(i<0) i=Math.floor(Math.random()*6); return i%MTH.length; }
const _arS35=auRaceStart;
auRaceStart=function(o){ try{ if(AU.ok){ AU.seq.bpmL=null; applyTheme(o&&o.drag?0:themeFor()); } }catch(e){ console.error(e); } AU.theme=CUR_TH; return _arS35.apply(this,arguments); };
const _am35=auMood;
auMood=function(m){ try{ if(!['race','tense','silent','stinger','drag'].includes(m)) applyTheme(0); }catch(e){} return _am35.apply(this,arguments); };
/* mélodie propre à chaque thème (niveaux 1 à 3, mode course) */
const _ss35=schedStep;
schedStep=function(step,t){ _ss35.apply(this,arguments);
  try{ const q=AU.seq; if(q.mood!=='race'||!q.level||CUR_TH===0||q.dropFrom!=null) return; const T=MTH[CUR_TH], s=step%16, bar=Math.floor(step/16), ch=CHORDS[Math.floor(bar/2)%4];
    T.lead.forEach(([st,ix])=>{ if(st===s) pluck(t,ch.arp[ix%6]*(q.level>=3?2:1),.09,T.w,STEP*2.2); }); }catch(e){} };
/* tempo du drag : changement uniquement à chaque mesure, par petits paliers */
dragSD=function(){ const q=AU.seq, f=clamp(AU.speedFrac||0,0,1); AU.dsm=(AU.dsm||0)+(f-(AU.dsm||0))*.07; const tgt=120+68*Math.pow(AU.dsm,.85);
  if(q.bpmL==null) q.bpmL=tgt; else if(q.step%16===0&&q.bpmS!==q.step){ q.bpmS=q.step; q.bpmL+=Math.max(-3,Math.min(3,tgt-q.bpmL)); } return 15/q.bpmL; };
/* une seule musique : l'intro coupe les autres */
const _cas35=cineAudioStart, _cae35=cineAudioStop;
cineAudioStart=function(T){ try{ ambMute(true); }catch(e){} return _cas35.apply(this,arguments); };
cineAudioStop=function(){ const r=_cae35.apply(this,arguments); try{ if(!WM.on&&!(PM&&PM.on)) ambMute(false); }catch(e){} return r; };
/* écran de mise à jour */
function showPatch(force){ if(document.getElementById('upd')) return; const P=PATCH[GAME_VER]; if(!P) return;
  const d=document.createElement('div'); d.id='upd'; d.innerHTML='<div class="upd-c"><small>MISE À JOUR</small><h2>v'+GAME_VER+' · '+P.t+'</h2><ul>'+P.l.map(x=>'<li>'+x+'</li>').join('')+'</ul><button class="btn wide" id="updGo">C’est parti</button></div>';
  document.body.appendChild(d); document.getElementById('updGo').onclick=()=>{ d.remove(); try{ S.seenVer=GAME_VER; save(); }catch(e){} }; }
ACT.patch=()=>{ closeSheet&&closeSheet(); showPatch(true); };
setInterval(()=>{ try{ if(!S||!S.intro||S.seenVer===GAME_VER||sheet||view==='race'||document.getElementById('cine')||document.getElementById('upd')||document.getElementById('arcov')) return;
  if(S.seenVer==null&&(S.stats&&!S.stats.races)&&S.lvl<=1){ S.seenVer=GAME_VER; return; } showPatch(); }catch(e){} },2000);
/* ---- v0.62 : niveaux du labo, équipe clandestine, équipe sur l'accueil ---- */
const LAB_TIERS=['','Atelier caché · Néon T5 · Northern Lights · White Widow','LED blanche · AK-47 · Critical Mass · enzymes · anti-fongiques · ventilation · Arroseur','LED spectre complet · Blue Dream · Booster · coco · citerne · Nutritionniste','Ranch · OG Kush · Granddaddy Purple · filtre à charbon · pot-de-vin','Iodure céramique · Jack Herer · Purple Haze · irrigation auto · Chimiste','Girl Scout · Sour Diesel · hydroponie · Dealer','Durban Poison · Zkittlez · lampe HPS · Avocat','Gorilla Glue · Wedding Cake · Chauffeur','Amnesia Haze · LED Pro','Gelato · maître cultivateur'];
const labNeed=l=>Math.round(100*Math.pow(l,1.7));
const strLL=s=>{ const r=s.rep||0; return r>=64?10:r>=56?9:r>=40?8:r>=28?7:r>=20?6:r>=14?5:r>=10?4:r>=6?3:r>=2?2:1; };
STR.forEach(s=>{ s.ll=strLL(s); });
const LAMP_LL={t5:1,led:2,led2:3,cmh:5,hps:7,ledp:9}, CHEM_LL={ENZ:2,FONG:2,INSEC:2,BOOST:3}, GEAR_LL={fan:2,filter:4,irri:5}, MED_LL={terreau:1,coco:3,hydro:6};
function labF(){ const F=farm(); if(F.ll==null){ const st=F.stats||{}; let x=(st.harv||0)*20+(st.sold||0)*.5+(st.deliv||0)*60, l=1; while(l<10&&x>=labNeed(l)){ l++; } F.ll=l; F.lx=Math.max(0,Math.round(x)); F.sx={h:st.harv||0,s:st.sold||0,d:st.deliv||0}; } return F; }
const labL=()=>{ try{ const F=S&&S.farm; if(!F||!F.found) return 0; return labF().ll||1; }catch(e){ return 1; } };
function labGain(x){ const F=labF(); if(F.ll>=10){ F.lx=labNeed(10); return; } F.lx+=x; while(F.ll<10&&F.lx>=labNeed(F.ll)){ F.ll++; try{ banner('🧪 <b>Labo niveau '+F.ll+' !</b><br>Débloqué : '+LAB_TIERS[F.ll]); auTry(()=>ui('buy')); }catch(e){} } }
setInterval(()=>{ try{ if(!(S&&S.farm&&S.farm.found)) return; const F=labF(), st=F.stats, sx=F.sx||(F.sx={h:st.harv||0,s:st.sold||0,d:st.deliv||0});
  const dh=(st.harv||0)-sx.h, ds=(st.sold||0)-sx.s, dd=(st.deliv||0)-sx.d; if(dh<=0&&ds<=0&&dd<=0){ sx.h=st.harv||0; sx.s=st.sold||0; sx.d=st.deliv||0; return; }
  sx.h=st.harv||0; sx.s=st.sold||0; sx.d=st.deliv||0; labGain(Math.max(0,dh)*20+Math.max(0,ds)*.5+Math.max(0,dd)*60); save(); }catch(e){} },1500);
function labReq(t,a,b){ if(t==='seed') return (SID[a]&&SID[a].ll)||1; if(t==='chem') return CHEM_LL[a]||1; if(t==='lamp') return LAMP_LL[a]||1; if(t==='gear') return GEAR_LL[b]||1; if(t==='tank') return 3; if(t==='bribe') return 4; return 1; }
const _rb36=ACT.rbuy; ACT.rbuy=function(d){ const [t,a,b]=String(d.id).split(':'), n=labReq(t,a,b); if(labL()<n){ toast('🔒 Labo niveau '+n+' requis'); return; } return _rb36.apply(this,arguments); };
const _rp36=ACT.rplant; ACT.rplant=function(d){ try{ const P=RY.pick||{}, n=MED_LL[P.med]||1; if(labL()<n){ toast('🔒 '+MED[P.med].nom+' : labo niveau '+n); return; } }catch(e){} return _rp36.apply(this,arguments); };
const _rs36=ACT.rbuyslot; ACT.rbuyslot=function(d){ const F=farm(), R=F.rooms[d.id], RM=ROOMS[d.id]; const base=d.id==='ranch'?8:6, allow=base+2*(labL()-1); if(R&&R.slots.length>=allow&&R.slots.length<RM.max){ toast('🔒 Parcelle suivante : labo niveau '+Math.min(10,labL()+1)); return; } return _rs36.apply(this,arguments); };
const _rr36=ACT.rbuyranch; ACT.rbuyranch=function(){ if(labL()<4){ toast('🔒 Le ranch demande le labo niveau 4'); return; } return _rr36.apply(this,arguments); };
/* ----- équipe : rôles clandestins ----- */
Object.assign(ROLES,{
 irri:{n:'Arroseur',ic:'💧',base:210,d:'Arrose seul les plantes qui ont soif (utilise ta citerne).',unit:'arrosages',ll:2,ill:1},
 nut:{n:'Nutritionniste',ic:'🧪',base:330,d:'Nourrit les plantes avec tes engrais N-P-K et Ca-Mg.',unit:'soins',ll:3,ill:1},
 chim:{n:'Chimiste',ic:'⚗️',base:430,d:'Corrige le pH, soigne les nuisibles, pose enzymes et boosters.',unit:'traitements',ll:5,ill:1},
 dealer:{n:'Dealer',ic:'🕶️',base:380,d:'Écoule ton stock dans la rue, un peu mieux payé mais plus risqué.',unit:'cr de ventes',ll:6,ill:1},
 avo:{n:'Avocat',ic:'⚖️',base:470,d:'Fait retomber la chaleur bien plus vite qu’un gardien.',unit:'pts de chaleur',ll:7,ill:1},
 chauf:{n:'Chauffeur',ic:'🚐',base:540,d:'Livre ton stock en gros à prix premium. Beaucoup de chaleur.',unit:'cr de livraisons',ll:8,ill:1}});
const isIll=r=>!!(ROLES[r]&&ROLES[r].ill);
const illOpen=()=>{ try{ return labLv()>=LAB_LVL&&S.farm&&S.farm.found; }catch(e){ return false; } };
const legalCap=()=>Math.min(6,1+Math.floor(S.lvl/3));
const illCap=()=>illOpen()?Math.floor((labL()+1)/2):0;
let CAPR=null;
teamCap=function(){ const T=team(); if(!CAPR) return legalCap()+illCap(); const cls=isIll(CAPR), n=T.hired.filter(e=>isIll(e.role)===cls).length; return T.hired.length-n+(cls?illCap():legalCap()); };
const _er36=empRow; empRow=function(e,mode){ CAPR=e.role; try{ return _er36(e,mode); } finally{ CAPR=null; } };
const _eh36=ACT.ehire; ACT.ehire=function(d){ const c=team().cand.find(x=>x.id===d.id); CAPR=c?c.role:null; try{ return _eh36.apply(this,arguments); } finally{ CAPR=null; } };
refreshCands=function(force){
  const T=team(), F=S.farm, can=r=>{ const R=ROLES[r]; if(R.ill) return illOpen()&&labL()>=R.ll; return r!=='gard'||(F&&F.found); };
  if(!force&&T.cand.length&&Date.now()-T.candT<15*60000&&!T.cand.some(c=>ROLES[c.role].ill&&!can(c.role))&&(!illOpen()||T.cand.some(c=>ROLES[c.role].ill)||T.illT===labL())) return;
  const roles=Object.keys(ROLES).filter(can), out=[];
  if(!T.hired.some(e=>e.role==='gard')&&can('gard')&&!T.firstG){ const g=newCand('gard','des'); g.nom='Gaspard Lambert'; g.sk=3; g.end=4; g.wage=wageOf('gard',3,'des'); g.lo=25; out.push(g); }
  const ill=roles.filter(r=>ROLES[r].ill), leg=roles.filter(r=>!ROLES[r].ill);
  if(ill.length){ const r=ill[Math.floor(Math.random()*ill.length)]; out.push(newCand(r)); if(ill.length>2){ const r2=ill[Math.floor(Math.random()*ill.length)]; if(r2!==r) out.push(newCand(r2)); } }
  while(out.length<4){ const r=leg[Math.floor(Math.random()*leg.length)]; if(out.some(c=>c.role===r)&&leg.length>3) continue; out.push(newCand(r)); }
  T.cand=out; T.candT=Date.now(); T.illT=labL(); };
function empSellX(eff,d,sk,mult,heat,rate){ const F=S.farm; if(!F||!F.found) return 0; let g=rate*eff*d, gain=0; for(const k in F.stock){ if(g<=0) break; const s=F.stock[k]; if(!s||s.g<1) continue; const n=Math.floor(Math.min(s.g,g)); if(n<1) continue; const v=Math.round(n*sellPrice(k,s.q)*mult*(1+.02*sk)); s.g-=n; g-=n; S.cr+=v; gain+=v; F.stats.sold+=n; F.rep+=n*.02; karmaAdd(-n*.03); F.heat.atelier=Math.min(100,F.heat.atelier+n*heat); F.heat.ranch=Math.min(100,F.heat.ranch+n*heat); } return gain; }
function empIll(e,eff,d){ const F=S.farm; if(!F||!F.found) return 0; let did=0; const r=e.role, plants=[];
  if(['irri','nut','chim'].includes(r)){ ranchSim(); for(const room in ROOMS){ const R=F.rooms[room]; if(R&&R.on) R.slots.forEach(sl=>{ if(sl&&sl.st!=='dead'&&sl.st!=='ready') plants.push(sl); }); } }
  if(r==='irri'){ let cap=Math.max(1,Math.floor(5*eff*d)); for(const sl of plants){ if(cap<=0) break; if(sl.w<50){ if((F.can||0)>0) F.can--; else if(F.water>=3) F.water-=3; else break; sl.w=Math.min(100,sl.w+36); cap--; did++; } } }
  else if(r==='nut'){ let cap=Math.max(1,Math.floor(4*eff*d)); for(const sl of plants){ for(const k of ['N','P','K']){ if(cap>0&&sl[k]<40&&(F.chem[k]||0)>0){ F.chem[k]--; sl[k]=Math.min(100,sl[k]+22); cap--; did++; } } if(cap>0&&sl.hp<60&&(F.chem.CM||0)>0){ F.chem.CM--; sl.hp=Math.min(100,sl.hp+10); cap--; did++; } } }
  else if(r==='chim'){ let cap=Math.max(1,Math.floor(3*eff*d)); const use=k=>{ if((F.chem[k]||0)<1||cap<1) return false; F.chem[k]--; cap--; did++; return true; };
    for(const sl of plants){ const ideal=(MED[sl.med]&&MED[sl.med].ph)||6.3;
      if(sl.pest){ if(use(sl.pest==='mold'?'FONG':'INSEC')){ sl.pest=null; sl.prot=4; } }
      else if(sl.ph>ideal+.6){ if(use('PHm')) sl.ph-=.45; } else if(sl.ph<ideal-.6){ if(use('PHp')) sl.ph+=.45; }
      else if(sl.st==='veg'&&!sl.enz){ if(use('ENZ')) sl.enz=4; } else if(sl.st==='flo'&&!sl.boost){ if(use('BOOST')){ sl.boost=4; sl.q=Math.min(100,sl.q+6); } } } }
  else if(r==='dealer') did=empSellX(eff,d,e.sk,1.12,.06,2.2);
  else if(r==='chauf') did=empSellX(eff,d,e.sk,1.42,.11,3.5);
  else if(r==='avo'){ ['atelier','ranch'].forEach(room=>{ const h=F.heat[room]||0, dn=Math.min(h,1.5*eff*d); F.heat[room]=h-dn; did+=dn; }); }
  if(did>0&&['irri','nut','chim'].includes(r)) labGain(did*.15);
  return did; }
const _et36=empTick;
empTick=function(){ const T=team(), now=Date.now(); let dt=Math.min((now-T.last)/60000,360); const ills=T.hired.filter(e=>isIll(e.role)&&e.rest<=0&&e.en>0);
  _et36.apply(this,arguments); if(dt<=.01||!ills.length||!illOpen()) return;
  try{ let left=dt; while(left>1e-4){ const d=Math.min(left,5); left-=d; ills.forEach(e=>{ if(S.cr<=0||e.en<=0) return; const did=empIll(e,empEff(e),d); e.out=(e.out||0)+did; T.tot[e.role]=(T.tot[e.role]||0)+did; }); } save(); }catch(err){ console.error(err); } };
/* ----- décors : niveau du labo et équipe sur l'accueil ----- */
function labBar(){ const F=labF(), l=F.ll, nx=l<10?labNeed(l):1, pr=l>=10?100:Math.min(100,Math.round(F.lx/nx*100)), nt=l<10?LAB_TIERS[l+1]:'Niveau maximum';
  return '<div class="lab-lv" id="labLv"><b>🧪 Labo niveau '+l+'</b><div class="lb"><i style="width:'+pr+'%"></i></div><small>'+(l<10?F.lx+' / '+nx+' XP · prochain : '+nt:'Maître cultivateur')+'</small></div>'; }
function decor36(){ try{
  if(S&&S.farm&&S.farm.found&&labLv()>=LAB_LVL){ const old=document.getElementById('labLv'), a=document.querySelector('#sheet .rstats, #sheet .rhd'); if(a){ if(old) old.remove(); a.insertAdjacentHTML('afterend',labBar()); }
    document.querySelectorAll('[data-a="rbuy"],[data-a="rbuyslot"],[data-a="rbuyranch"]').forEach(b=>{ let n=1; if(b.dataset.a==='rbuy'){ const [t,a,g]=String(b.dataset.id).split(':'); n=labReq(t,a,g); } else if(b.dataset.a==='rbuyranch') n=4; else { const R=S.farm.rooms[b.dataset.id]; if(R){ const base=b.dataset.id==='ranch'?8:6; n=Math.max(1,Math.ceil((R.slots.length+1-base)/2)+1); } }
      if(labL()<n){ const it=b.closest('.rit'); if(it) it.classList.add('lock'); b.disabled=true; b.innerHTML='🔒<br><i>Niv. '+n+'</i>'; } }); }
  const eq=document.getElementById('sheet'); if(sheet&&sheet.t==='equipe'&&!document.getElementById('teamCls')){ const nt=eq.querySelector('.note'); const T=team(); const L=T.hired.filter(e=>!isIll(e.role)).length, I=T.hired.length-L; if(nt) nt.insertAdjacentHTML('afterend','<div class="team-cls" id="teamCls"><span>🏢 Légal : <b>'+L+' / '+legalCap()+'</b></span>'+(illOpen()?'<span>🕶️ Clandestin : <b>'+I+' / '+illCap()+'</b> <small>(+1 place tous les 2 niveaux du labo)</small></span>':'')+'</div>'); }
 }catch(e){} }
const _rd36=render; render=function(){ const r=_rd36.apply(this,arguments); decor36(); return r; };
const _rsh36=renderSheet; renderSheet=function(){ const r=_rsh36.apply(this,arguments); decor36(); return r; };
/* ---- v0.63 : onglets Atelier et Équipe, flèches de fiche, tutos de menus ---- */
if(!TABS.some(t=>t[0]==='atelier')){ const i=TABS.findIndex(t=>t[0]==='epreuves'); TABS.splice(i+1,0,['atelier','🛠️','Atelier'],['equipe','👥','Équipe']); }
const TUTX={
 atelier:{t:'🛠️ L’Atelier',p:[
  ['♻️ Recycler','Un module dont tu n’as plus besoin devient de la <b>ferraille</b>. Plus il est rare, plus il en donne.'],
  ['🔨 Fabriquer','Avec la ferraille, tu choisis la <b>rareté</b> puis l’<b>emplacement</b> (moteur, turbo, pneus…). Le modèle exact reste aléatoire.'],
  ['✨ Fusionner','5 modules de même rareté, non montés, donnent <b>1 module de la rareté au-dessus</b>. Les brillants, uniques et modules montés sont protégés.']]},
 equipe:{t:'👥 Ton équipe',p:[
  ['Des employés qui bossent pour toi','Mécano, jardinier, pilote, vendeur, gardien : ils travaillent même quand tu ne joues pas (jusqu’à 6 h) et touchent un salaire par heure.'],
  ['Énergie et loyauté','Un employé fatigué rend moins. Offre-lui du <b>repos</b>, une <b>augmentation</b>, et il s’attachera à toi.'],
  ['Les places','Une place légale de plus tous les 3 niveaux. Avec le labo et la majorité, des places <b>clandestines</b> s’ajoutent.']]},
 garage:{t:'🚗 Ton garage',p:[['Voitures et podiums','Touche une voiture pour la réparer, l’équiper ou l’améliorer. Les <b>podiums</b> exposent tes plus belles voitures et rapportent des crédits : utilise « Meilleures » pour les placer d’un coup.']]},
 epreuves:{t:'🏁 Épreuves',p:[['Courses et gains','Choisis une épreuve, une voiture adaptée à la discipline, puis pilote. Gagner rapporte crédits, expérience et parfois des jetons.']]},
 cartes:{t:'🃏 Cartes',p:[['Paquets et modules','Ouvre des paquets (crédits ou jetons) pour obtenir des <b>modules</b> à monter sur tes voitures. Swipe pour passer d’une carte à l’autre. Recyclage, fabrication et fusion sont dans l’<b>Atelier</b>.']]},
 marche:{t:'🛒 Marché',p:[['Acheter et vendre','Voitures, pièces du jour et services. Le stock change chaque jour.']]},
 base:{t:'🏗️ Base',p:[['Tes bâtiments','Améliore tes bâtiments pour de meilleurs bonus : entrepôt, atelier, showroom et plus.']]},
 missions:{t:'📜 Missions',p:[['Objectifs et récompenses','Complète des missions pour gagner crédits, nitro et jetons. Touche une mission terminée pour récupérer sa récompense.']]}};
function showTutx(key,force){ const T=TUTX[key]; if(!T||document.getElementById('tx')) return; let i=0; const d=document.createElement('div'); d.id='tx';
  const draw=()=>{ const p=T.p[i], last=i===T.p.length-1; d.innerHTML='<div class="upd-c"><small>TUTO'+(T.p.length>1?' · '+(i+1)+' / '+T.p.length:'')+'</small><h2>'+T.t+'</h2><h3 class="tx-h">'+p[0]+'</h3><p class="tx-p">'+p[1]+'</p><div class="tx-b">'+(last?'':'<button class="btn alt" id="txSk">Passer</button>')+'<button class="btn" id="txGo">'+(last?'Compris':'Suivant')+'</button></div></div>';
    d.querySelector('#txGo').onclick=()=>{ if(last){ d.remove(); try{ (S.tx=S.tx||{})[key]=1; save(); }catch(e){} } else { i++; draw(); } };
    const sk=d.querySelector('#txSk'); if(sk) sk.onclick=()=>{ d.remove(); try{ (S.tx=S.tx||{})[key]=1; save(); }catch(e){} }; };
  draw(); document.body.appendChild(d); }
ACT.tutx=d=>{ showTutx(d.id==='view'?view:d.id,true); };
setInterval(()=>{ try{ if(!S||!S.intro||sheet||!TUTX[view]||(S.tx&&S.tx[view])) return; if(['tx','upd','cine','arcov'].some(i=>document.getElementById(i))) return;
  if(!['atelier','equipe'].includes(view)&&S.lvl>4){ (S.tx=S.tx||{})[view]=1; return; } showTutx(view); }catch(e){} },1200);
/* ---------- Atelier ---------- */
let AT={tab:'fab',r:0,s:null,cf:null};
const atFree=()=>S.mods.filter(m=>!eqCar(m.u)&&!m.sh&&m.un==null);
function vAtelier(){
  const free=atFree(), tabs=`<div class="subtabs">${[['fab','🔨 Fabriquer'],['rec','♻️ Recycler'],['fus','✨ Fusionner']].map(([id,n])=>`<button data-a="attab" data-id="${id}" ${AT.tab===id?'aria-current="true"':''}>${n}</button>`).join('')}</div>`;
  const head=`<div class="head"><h2>🛠️ Atelier</h2><p><button class="hq" data-a="tutx" data-id="atelier">?</button></p></div>
   <div class="x-stats"><div><small>Ferraille</small><b>♻️ ${fmt(S.scrap)}</b></div><div><small>Modules</small><b>📦 ${S.mods.length} / ${invMax()}</b></div><div><small>Libres</small><b>${free.length}</b></div></div>`;
  let body='';
  if(AT.tab==='fab'){
    const r=AT.r, cost=craftCost(r), ok=S.scrap>=cost, sl=AT.s&&SLOTS.find(s=>s[0]===AT.s);
    body=`<p class="x-h">① Choisis la rareté</p><div class="x-rar">${RAR.slice(0,5).map((x,i)=>`<button class="${i===r?'on':''} ${S.scrap<craftCost(i)?'dim':''}" data-a="atr" data-id="${i}" style="--c:${x.c}"><b>${x.n}</b><small>${craftCost(i)} ♻️</small></button>`).join('')}</div>
      <p class="x-h">② Choisis l’emplacement</p><div class="x-slots">${SLOTS.map(s=>`<button class="${AT.s===s[0]?'on':''}" data-a="atslot" data-id="${s[0]}"><b>${s[2]}</b><span>${s[1]}</span></button>`).join('')}</div>
      <div class="x-go"><div><b>${sl?RAR[r].n+' · '+sl[1]:'Choisis un emplacement'}</b><small>Coût ${cost} ♻️ · il t’en reste ${fmt(Math.max(0,S.scrap-cost))}${ok?'':' (il t’en manque '+(cost-S.scrap)+')'}</small></div><button class="btn" data-a="atcraft" ${sl&&ok&&S.mods.length<invMax()?'':'disabled'}>Fabriquer</button></div>
      ${ok?'':'<p class="note">Pas assez de ferraille : recycle des modules dans l’onglet Recycler.</p>'}`;
  } else if(AT.tab==='rec'){
    const rows=RAR.slice(0,6).map((x,i)=>{ const k=free.filter(m=>m.r===i), y=Math.round(k.length*x.sc*scrapK()); return `<div class="x-row" style="--c:${x.c}"><i></i><div class="grow"><b>${x.n}</b><small>${k.length} module${k.length>1?'s':''} libre${k.length>1?'s':''} · +${y} ♻️</small></div><button class="btn sm ${AT.cf===i?'':'alt'}" data-a="atrec" data-id="${i}" ${k.length?'':'disabled'}>${AT.cf===i?'Confirmer ?':'Tout recycler'}</button></div>`; }).join('');
    body=`<p class="note">Seuls les modules <b>non montés</b>, non brillants et non uniques sont recyclables. Les Rares et au-dessus demandent une confirmation.</p>${rows}<button class="btn alt wide" style="margin-top:10px" data-a="atinv">Voir mes modules un par un</button>`;
  } else {
    const rows=RAR.slice(0,6).map((x,i)=>{ const n=free.filter(m=>m.r===i).length, nx=RAR[i+1]; return `<div class="x-row fu" style="--c:${nx.c}"><div class="grow"><b>5 ${x.n} → 1 <span style="color:${nx.c}">${nx.n}</span></b><div class="x-bar"><i style="width:${Math.min(100,n/5*100)}%;background:${x.c}"></i></div><small>${n} / 5 modules libres</small></div><button class="btn sm" data-a="fuse" data-id="${i}" ${n>=5?'':'disabled'}>${n>=5?'Fusionner':'Encore '+(5-n)}</button></div>`; }).join('');
    body=`<p class="note">Les 5 modules de plus faible qualité sont utilisés. Brillants, uniques et modules montés sont protégés.</p>${rows}`; }
  return head+tabs+body;
}
Object.assign(ACT,{
  attab(d){ AT.tab=d.id; AT.cf=null; render(); }, atr(d){ AT.r=+d.id; render(); }, atslot(d){ AT.s=d.id; render(); },
  atcraft(){ const r=AT.r, cost=craftCost(r); if(!AT.s||S.scrap<cost) return; if(S.mods.length>=invMax()) return toast('Inventaire plein : recycle ou fusionne'); S.scrap-=cost; const m=newMod(r,AT.s,true); S.mods.push(m); save(); render(); openSheet({t:'open',cards:[m.u],i:0,pk:'p1'}); },
  atrec(d){ const r=+d.id, k=atFree().filter(m=>m.r===r); if(!k.length) return; if(r>=2&&AT.cf!==r){ AT.cf=r; toast('Touche encore pour confirmer'); render(); return; }
    const y=Math.round(k.length*RAR[r].sc*scrapK()); S.scrap+=y; try{ bump('recyN',k.length); }catch(e){} S.mods=S.mods.filter(m=>!k.includes(m)); AT.cf=null; toast(k.length+' modules recyclés · +'+y+' ♻️'); save(); render(); },
  atinv(){ cTab='inv'; ACT.tab({id:'cartes'}); } });
/* ---------- Équipe ---------- */
let EQ={tab:'team'};
function empCard(e){ const R=ROLES[e.role], T=TRAITS[e.tr]; const bars=(l,v,c)=>`<div class="x-mb"><span>${l}</span><div><i style="width:${Math.round(Math.max(0,Math.min(100,v)))}%;background:${c}"></i></div><b>${Math.round(v)}</b></div>`;
  const raise=Math.round(e.wage*.1/5)*5||5;
  return `<div class="x-emp ${R.ill?'ill':''}"><div class="x-eh">${faceSVG(e,46)}<div class="grow"><b>${e.nom}</b><span class="chip">${R.ic} ${R.n}</span>${R.ill?'<span class="chip ill">clandestin</span>':''}<small>${T.n}</small></div><div class="x-w"><b>${fmt(e.wage)}</b><small>cr/h</small></div></div>
   <div class="x-bars">${bars('⚡',e.en,e.en<25?'#ff6a3d':'#FCEE0A')}${bars('❤️',e.lo,'#ff2bd6')}</div>
   <small class="x-st">${e.rest>0?'😴 Repos encore '+Math.ceil(e.rest)+' min':R.d} · Total ${fmt(Math.round(e.out||0))} ${R.unit}</small><p class="x-q">« ${quoteOf(e)} »</p>
   <div class="x-ac"><button data-a="erest" data-id="${e.id}" ${e.rest>0?'disabled':''}>😴 Repos</button><button data-a="eraise" data-id="${e.id}" ${S.cr<raise*10?'disabled':''}>💶 +${raise}</button><button class="bad" data-a="efire" data-id="${e.id}">Licencier</button></div></div>`; }
function candCard(c){ const R=ROLES[c.role], T=TRAITS[c.tr], fee=c.wage*3; CAPR=c.role; const full=team().hired.length>=teamCap(); CAPR=null;
  return `<div class="x-emp ${R.ill?'ill':''}"><div class="x-eh">${faceSVG(c,46)}<div class="grow"><b>${c.nom}</b><span class="chip">${R.ic} ${R.n}</span>${R.ill?'<span class="chip ill">clandestin</span>':''}<small>${T.n} · ${T.d}</small></div><div class="x-w"><b>${fmt(c.wage)}</b><small>cr/h</small></div></div>
   <small class="x-st">${R.d}</small><div class="x-bars">${sb('Compétence',c.sk*10,'#3CFF9E',c.sk+'/10')}${sb('Endurance',c.end*10,'#00E5FF',c.end+'/10')}</div>
   <button class="btn wide" data-a="ehire" data-id="${c.id}" ${full||S.cr<fee?'disabled':''}>${full?'Plus de place':'Embaucher · '+fmt(fee)+' cr'}</button></div>`; }
function vEquipe(){ const T=team(); refreshCands(); try{ empTick(); }catch(e){}
  const L=T.hired.filter(e=>!isIll(e.role)), I=T.hired.filter(e=>isIll(e.role)), wages=T.hired.reduce((a,e)=>a+e.wage,0), en=T.hired.length?Math.round(T.hired.reduce((a,e)=>a+e.en,0)/T.hired.length):0;
  const head=`<div class="head"><h2>👥 Équipe</h2><p><button class="hq" data-a="tutx" data-id="equipe">?</button></p></div>
   <div class="x-stats"><div><small>Légal</small><b>${L.length} / ${legalCap()}</b></div>${illOpen()?`<div><small>Clandestin</small><b>🕶️ ${I.length} / ${illCap()}</b></div>`:''}<div><small>Salaires</small><b>${fmt(wages)} /h</b></div><div><small>Énergie</small><b>⚡ ${en} %</b></div></div>
   <div class="subtabs">${[['team','Mon équipe ('+T.hired.length+')'],['rec','Recruter']].map(([id,n])=>`<button data-a="eqtab" data-id="${id}" ${EQ.tab===id?'aria-current="true"':''}>${n}</button>`).join('')}</div>`;
  let body='';
  if(EQ.tab==='team'){
    body=T.hired.length?(L.length?`<p class="x-h">🏢 Équipe légale</p>${L.map(empCard).join('')}`:'')+(I.length?`<p class="x-h">🕶️ Équipe clandestine</p>${I.map(empCard).join('')}`:''):`<div class="x-empty"><b>Personne ne travaille pour toi.</b><small>Un employé gagne des crédits et du temps même quand tu es absent.</small><button class="btn" data-a="eqtab" data-id="rec">Recruter</button></div>`;
    if(!illOpen()&&S.lvl>=6&&S.age18===true) body+=`<p class="note">🕶️ Équipe clandestine : s’ouvre avec le labo (niveau ${LAB_LVL}, majeur).</p>`;
  } else {
    const mins=Math.max(0,15-Math.floor((Date.now()-T.candT)/60000));
    body=`<p class="note">Candidats renouvelés dans ${mins} min.${illOpen()?' Des profils clandestins apparaissent avec le niveau de ton labo.':''}</p>${T.cand.map(candCard).join('')}<button class="btn alt wide" data-a="ecand">🔄 Nouveaux candidats · 300 cr</button>`; }
  return head+body; }
Object.assign(ACT,{ eqtab(d){ EQ.tab=d.id; render(); }, equipe(){ ACT.tab({id:'equipe'}); } });
['ehire','efire','erest','eraise','ecand'].forEach(k=>{ const o=ACT[k]; ACT[k]=function(){ const r=o.apply(this,arguments); try{ if(view==='equipe') render(); }catch(e){} return r; }; });
setInterval(()=>{ try{ if(view==='equipe'&&!sheet&&!document.getElementById('tx')&&!document.querySelector('#view :focus')) render(); }catch(e){} },30000);
/* ---------- flèches de la fiche véhicule ---------- */
function carNav(dir){ if(!sheet||sheet.t!=='car') return; const L=S.cars, i=L.findIndex(c=>c.uid===sheet.uid); if(i<0||L.length<2) return; sheet.uid=L[(i+dir+L.length)%L.length].uid; renderSheet(); const sh=$('sheet'); if(sh) sh.scrollTop=0; auTry(()=>ui('open')); }
Object.assign(ACT,{ carprev(){ carNav(-1); }, carnext(){ carNav(1); } });
document.addEventListener('keydown',e=>{ if(sheet&&sheet.t==='car'){ if(e.key==='ArrowLeft') carNav(-1); else if(e.key==='ArrowRight') carNav(1); } });
function decor37(){ try{
  const on=sheet&&sheet.t==='car'&&S.cars.length>1, n=document.getElementById('carnav');
  if(n) n.remove();
  if(!document.querySelector('#view .head .hq')&&TUTX[view]&&!['atelier','equipe'].includes(view)){ const h=document.querySelector('#view .head p, #view .head'); if(h) h.insertAdjacentHTML('beforeend',' <button class="hq" data-a="tutx" data-id="view">?</button>'); }
 }catch(e){} }
const _rd37=render; render=function(){ const r=_rd37.apply(this,arguments); decor37(); return r; };
const _rsh37=renderSheet; renderSheet=function(){ const r=_rsh37.apply(this,arguments); decor37(); return r; };
/* ---- v0.63 : paquets ciblés par statistique, paiement explicite ---- */
Object.assign(PKT,{
 f1:{c1:'#ff8a5c',c2:'#c2381a',c3:'#3a0d05',emb:'🔥',tag:'PUISSANCE'},
 f2:{c1:'#7dd3ff',c2:'#1d6fb8',c3:'#06213d',emb:'⭕',tag:'ADHÉRENCE'},
 f3:{c1:'#ff6a8a',c2:'#a3203f',c3:'#2e0610',emb:'🛑',tag:'FREINAGE'},
 f4:{c1:'#8be03c',c2:'#3f8a14',c3:'#122b05',emb:'🛡️',tag:'ROBUSTE'},
 f5:{c1:'#e69bff',c2:'#9a3fd0',c3:'#2d0a45',emb:'🎨',tag:'STYLE'},
 f6:{c1:'#ffe14d',c2:'#d98a14',c3:'#4d2a00',emb:'⚡',tag:'NITRO'}});
[
 {id:'f1',nom:'Paquet Puissance',n:4,cr:3200,tok:5,boost:1.2,min:1,slots:['moteur','turbo','echap'],d:'4 modules de moteur, turbo ou échappement : puissance et couple'},
 {id:'f2',nom:'Paquet Adhérence',n:4,cr:3200,tok:5,boost:1.2,min:1,slots:['pneus','aero','jantes'],d:'4 modules de pneus, aéro ou jantes : adhérence et tenue'},
 {id:'f3',nom:'Paquet Freinage',n:4,cr:3000,tok:5,boost:1.2,min:1,slots:['freins','susp'],d:'4 modules de freins ou de suspension : freinage et maniabilité'},
 {id:'f4',nom:'Paquet Robuste',n:4,cr:3000,tok:5,boost:1.2,min:1,slots:['chassis'],d:'4 modules de châssis : fiabilité, solidité, poids'},
 {id:'f5',nom:'Paquet Style',n:4,cr:2800,tok:4,boost:1.2,min:1,slots:['peinture','jantes','aero'],d:'4 modules de peinture, jantes ou aéro : style et revenus du showroom'},
 {id:'f6',nom:'Paquet Nitro',n:4,cr:3400,tok:6,boost:1.2,min:1,slots:['nitro'],d:'4 modules de nitro : durée et puissance'}
].forEach(p=>{ if(!PACKS.some(x=>x.id===p.id)) PACKS.push(p); });
PACKS.forEach(p=>{ if(!p.slots) p.rand=1; });
const PKF={slots:null};
const _nm38=newMod; newMod=function(r,slot,plain){ if(!slot&&PKF.slots) slot=PKF.slots[rint(0,PKF.slots.length-1)]; return _nm38(r,slot,plain); };
const _op38=openPack; openPack=function(id,cur){ const p=PACKS.find(x=>x.id===id); PKF.slots=p&&p.slots||null; try{ return _op38.apply(this,arguments); } finally{ PKF.slots=null; } };
CAR_P.f1=CAR_P.f2=CAR_P.f3=CAR_P.f4=CAR_P.f5=CAR_P.f6=.0008;
/* paiement explicite : un tap sur le paquet ouvre le choix crédits ou jetons */
function payChoice(id){ const p=PACKS.find(x=>x.id===id); if(!p||document.getElementById('pkpay')) return;
  const d=document.createElement('div'); d.id='pkpay'; const okC=S.cr>=p.cr, okT=S.tok>=p.tok;
  d.innerHTML='<div class="upd-c"><small>OUVRIR</small><h2>'+p.nom+'</h2><p class="tx-p">Choisis comment payer. Tu as <b>'+fmt(S.cr)+' cr</b> et <b>'+S.tok+' jeton'+(S.tok>1?'s':'')+'</b>.</p>'+
   '<div class="tx-b"><button class="btn'+(okC?'':' alt')+'" id="ppC" '+(okC?'':'disabled')+'>💰 '+fmt(p.cr)+' cr</button><button class="btn'+(okT?'':' alt')+'" id="ppT" '+(okT?'':'disabled')+'>🎟 '+p.tok+' jeton'+(p.tok>1?'s':'')+'</button></div><button class="btn alt wide" id="ppX" style="margin-top:8px">Annuler</button></div>';
  document.body.appendChild(d); const go=k=>{ d.remove(); ACT.pack({id,k}); };
  d.querySelector('#ppC').onclick=()=>go('cr'); d.querySelector('#ppT').onclick=()=>go('tok'); d.querySelector('#ppX').onclick=()=>d.remove(); }
document.addEventListener('pointerup',()=>{},true);
const _pk38=ACT.pack; ACT.pack=function(d){ if(d&&d.k==='auto'){ const p=PACKS.find(x=>x.id===d.id); if(S.cr>=p.cr&&S.tok>=p.tok) return payChoice(d.id); return _pk38.call(this,{id:d.id,k:S.tok>=p.tok&&S.cr<p.cr?'tok':'cr'}); } return _pk38.apply(this,arguments); };
/* le tap sur le paquet central passe par le choix quand les deux paiements sont possibles */
(function(){ const o=ACT.pack; ACT.pack=function(d){ if(d&&d.id&&d.k&&!d.explicit&&new Error().stack.indexOf('pointerup')>=0){ const p=PACKS.find(x=>x.id===d.id); if(p&&S.cr>=p.cr&&S.tok>=p.tok&&!document.getElementById('pkov')&&!sheet) return payChoice(d.id); } return o.apply(this,arguments); }; })();
/* libellés clairs sur les boutons de paquet */
function decor38(){ try{ document.querySelectorAll('#pkInfo button[data-a="pack"][data-k="tok"]').forEach(b=>{ const p=PACKS.find(x=>x.id===b.dataset.id); if(p&&!b.dataset.d38){ b.dataset.d38=1; b.innerHTML='🎟 '+p.tok+' jeton'+(p.tok>1?'s':'')+' <small>(tu en as '+S.tok+')</small>'; } });
  document.querySelectorAll('#pkInfo button[data-a="pack"][data-k="cr"]').forEach(b=>{ const p=PACKS.find(x=>x.id===b.dataset.id); if(p&&!b.dataset.d38){ b.dataset.d38=1; b.innerHTML='💰 '+fmt(p.cr)+' cr'; } });
  const pi=document.getElementById('pkInfo'); if(pi&&!pi.querySelector('.pk-kind')){ const p=PACKS[clamp(Math.round(PK.drag?PK.pos:PK.tgt),0,PACKS.length-1)], t=pi.querySelector('.t'); if(t&&p) t.insertAdjacentHTML('afterend','<small class="pk-kind">'+(p.car?'🚗 Voiture : 1 au hasard, tous tiers':p.slots?'🎯 Ciblé : '+p.slots.map(s=>(SLOTS.find(x=>x[0]===s)||[0,s])[1]).join(', '):'🎲 Aléatoire : tous les emplacements')+'</small>'); } }catch(e){} }
setInterval(decor38,300);
/* ---- v0.63b : affichage de la collection 1 / 3 / 5 colonnes ---- */
const gCols=()=>(S&&S.gcols)||0;
const _gGrid39=gGrid;
gGrid=function(){ const n=gCols(); if(n<3) return _gGrid39(); const l=gFiltered(); return l.length?l.map(c=>cardHTML(c,{cls:'cmini',attr:'data-a="car" data-id="'+c.uid+'"'})).join(''):'<p class="note" style="grid-column:1/-1">Aucune voiture ne correspond. Modifie ou efface les filtres.</p>'; };
const _gBar39=gBar;
gBar=function(){ let h=_gBar39(); const n=gCols(); const b='<div class="gview" role="group" aria-label="Affichage">'+[[0,'▭','Auto'],[1,'▬','1 par ligne'],[3,'▦','3 colonnes'],[5,'▩','5 colonnes']].map(([v,i,t])=>'<button data-a="gcols" data-id="'+v+'" class="'+(n===v?'on':'')+'" title="'+t+'" aria-label="'+t+'">'+i+(v?'<small>'+v+'</small>':'')+'</button>').join('')+'</div>';
  return h.replace('<div class="gcount">',b+'<div class="gcount">'); };
ACT.gcols=d=>{ S.gcols=+d.id; try{ save(); }catch(e){} render(); };
function decor39(){ try{ const g=document.getElementById('ggrid'); if(!g) return; const n=gCols(); g.style.gridTemplateColumns=n?'repeat('+n+',minmax(0,1fr))':''; g.className='grid'+(n?' gc'+n:''); }catch(e){} }
const _rd39=render; render=function(){ const r=_rd39.apply(this,arguments); decor39(); return r; };
/* ---- v0.64b : vues x1/x3 (garage), x1/x3/x5 (modules), boutiques aléatoire / ciblée ---- */
gBar=function(){ let h=_gBar39(); const n=gCols()>=3?3:1;
  const b='<div class="gview" role="group" aria-label="Affichage">'+[1,3].map(v=>'<button data-a="gcols" data-id="'+v+'" class="'+(n===v?'on':'')+'" aria-label="'+v+' par ligne">'+(v===1?'▬':'▦')+' x'+v+'</button>').join('')+'</div>';
  return h.replace('<div class="gcount">',b+'<div class="gcount">'); };
const _gGrid40=gGrid; gGrid=function(){ if(gCols()>=3) return _gGrid40(); const l=gFiltered(); return _gGrid39.apply(this,arguments); };
function decor39(){ try{ const g=document.getElementById('ggrid'); if(g){ const n=gCols()>=3?3:1; g.style.gridTemplateColumns='repeat('+n+',minmax(0,1fr))'; g.className='grid gc'+n; }
  const m=document.querySelector('#view .mods:not(.open)'); if(m&&cTab==='inv'){ const k=S.mcols||1; m.style.gridTemplateColumns='repeat('+k+',minmax(0,1fr))'; m.classList.remove('mc1','mc3','mc5'); m.classList.add('mc'+k); } }catch(e){} }
/* modules : sélecteur x1 / x3 / x5 */
ACT.mcols=d=>{ S.mcols=+d.id; try{ save(); }catch(e){} render(); };
const _vC40=vCartes; vCartes=function(){ let h=_vC40.apply(this,arguments);
  if(cTab==='inv'){ const k=S.mcols||1; const b='<div class="gview" role="group" aria-label="Affichage des modules">'+[1,3,5].map(v=>'<button data-a="mcols" data-id="'+v+'" class="'+(k===v?'on':'')+'">'+(v===1?'▬':v===3?'▦':'▩')+' x'+v+'</button>').join('')+'</div>';
    h=h.replace('<div class="mods">',b+'<div class="mods">'); }
  return h; };
/* boutiques : aléatoire en haut (carrousel), ciblée en dessous */
const FPACKS=PACKS.filter(p=>p.slots); FPACKS.forEach(p=>{ const i=PACKS.indexOf(p); if(i>=0) PACKS.splice(i,1); });
['find','findIndex'].forEach(fn=>{ PACKS[fn]=function(f){ const r=Array.prototype[fn].call(this,f); if(fn==='find') return r||FPACKS.find(f); return r; }; });
const _pk40=packsHTML; packsHTML=function(){ const rows=FPACKS.map(p=>{ const t=PKT[p.id]||{}; const okC=S.cr>=p.cr, okT=S.tok>=p.tok;
  return '<div class="fpk" style="--c1:'+t.c1+';--c2:'+t.c2+'"><span class="fe">'+(t.emb||'🎯')+'</span><span class="fi"><b>'+p.nom+'</b><small>'+p.d+'</small></span><span class="fb"><button class="btn sm" data-a="pack" data-id="'+p.id+'" data-k="cr" '+(okC?'':'disabled')+'>💰 '+fmt(p.cr)+'</button><button class="btn alt sm" data-a="pack" data-id="'+p.id+'" data-k="tok" '+(okT?'':'disabled')+'>🎟 '+p.tok+'</button></span></div>'; }).join('');
  return '<h3 class="pkh">🎲 Paquets aléatoires</h3><p class="note" style="margin-top:0">Tous les emplacements, tu prends ce qui tombe.</p>'+_pk40.apply(this,arguments)+'<h3 class="pkh">🎯 Paquets ciblés</h3><p class="note" style="margin-top:0">Tu choisis la catégorie de pièces à chasser.</p><div class="fpks">'+rows+'</div>'; };
/* ---- v0.64c : swipe gauche/droite entre fiches véhicule, avec animation ---- */
(function(){ let st=null;
  const sh=()=>document.getElementById('sheet');
  document.addEventListener('touchstart',e=>{ st=null; if(!sheet||sheet.t!=='car'||S.cars.length<2) return; const el=sh(); if(!el||!el.contains(e.target)||e.target.closest('canvas,input,select,textarea,.chips')) return; const t=e.touches[0]; st={x:t.clientX,y:t.clientY,t:Date.now()}; },{passive:true});
  document.addEventListener('touchend',e=>{ if(!st) return; const t=e.changedTouches[0], dx=t.clientX-st.x, dy=t.clientY-st.y, s0=st; st=null;
    if(Math.abs(dx)<60||Math.abs(dx)<Math.abs(dy)*1.5||Date.now()-s0.t>900) return; swipeCar(dx<0?1:-1); },{passive:true});
  window.swipeCar=function(dir){ const el=sh(); if(!el||!sheet||sheet.t!=='car') return;
    el.style.transition='transform .14s ease-in,opacity .14s'; el.style.transform='translateX('+(-dir*60)+'px)'; el.style.opacity='0';
    setTimeout(()=>{ carNav(dir); const e2=sh(); if(!e2) return; e2.style.transition='none'; e2.style.transform='translateX('+(dir*60)+'px)'; e2.style.opacity='0'; void e2.offsetWidth; e2.style.transition='transform .2s ease-out,opacity .2s'; e2.style.transform=''; e2.style.opacity=''; setTimeout(()=>{ e2.style.transition=''; },240); },140); };
})();
/* ---- v0.65 : labo — swipe entre plantes, chrono, floraison directe, jardinier progressif, tuto chaleur/police ---- */
/* temps restant réel (minutes) pour la phase en cours */
function slotSp(room,sl){ const md=MED[sl.med]||{sp:1}, f=plantFit(room,sl), g=x=>isFinite(x)?x:1; const r=(.3+.7*g(f.lf))*(.5+.5*g(f.nf))*(.55+.45*g(f.wf))*(.7+.3*g(f.pf))*g(f.cf)*g(md.sp)*(sl.enz>0?1.2:1)*(sl.boost>0?1.1:1); return isFinite(r)?r:1; }
function slotPc(sl){ if(sl.st==='ready') return 100; if(sl.st==='dead') return 0; const sv=SID[sl.sid], need=({germ:1,veg:sv.veg,flo:sv.fl}[sl.st])||1; return Math.round(nz((sl.stAge||0)/need*100,100)); }
function slotLeftMin(room,sl){ if(!sl||sl.st==='ready'||sl.st==='dead') return 0; const sv=SID[sl.sid], need=({germ:1,veg:sv.veg,flo:sv.fl}[sl.st])||1; return Math.max(0,(need-(sl.stAge||0))/Math.max(.05,slotSp(room,sl))); }
function fmtMS(m){ const s=Math.max(0,Math.round(m*60)); return Math.floor(s/60)+' min '+String(s%60).padStart(2,'0')+' s'; }
function canFlower(sl){ return sl&&sl.st==='veg'&&slotPc(sl)>=50; }
/* floraison directe depuis le labo 3D */
const _pp42=plotPoi; plotPoi=function(room,pl){ const q=_pp42.apply(this,arguments); if(!q||!q.btns) return q; const F=farm(), sl=F.rooms[room].slots[pl.i]; const ob=q.btns, ot=q.title;
  q.btns=function(){ const b=ob.apply(this,arguments); if(sl&&canFlower(sl)) b.unshift({id:'flower',tx:'🌸 Floraison'}); return b; };
  q.title=function(){ let t=ot.apply(this,arguments); if(sl&&sl.st!=='ready'&&sl.st!=='dead'){ try{ t+=' · ⏱ '+fmtMS(slotLeftMin(room,sl)); }catch(e){} } return t; }; return q; };
const _gg42=ACT.growgo; ACT.growgo=function(d){ if(d&&d.id&&d.id.startsWith('plot')&&d.v==='flower'){ return flowerSlot(HUB.map,+d.id.slice(4)); } return _gg42.apply(this,arguments); };
function flowerSlot(room,i){ const sl=farm().rooms[room].slots[i]; if(!canFlower(sl)) return false; sl.st='flo'; sl.stAge=0; sl.cyc=12; sl.nf=0; save(); toast('🌸 '+SID[sl.sid].nom+' passe en floraison'); try{ if(sheet&&sheet.t==='ranch') renderSheet(); }catch(e){} return true; }
ACT.floall=function(){ const room=RY.tab, R=farm().rooms[room]; if(!R) return; let n=0; R.slots.forEach((sl,i)=>{ if(canFlower(sl)&&flowerSlot(room,i)) n++; }); if(!n) toast('Aucune plante prête pour la floraison'); };
const _rf42=ACT.rflower; ACT.rflower=function(d){ const r=_rf42.apply(this,arguments); toast('🌸 Floraison lancée'); return r; };
/* notification : plante prête pour la floraison / à récolter */
setInterval(()=>{ try{ const F=S&&S.farm; if(!F||!F.found||document.body.classList.contains('racing')) return; ranchSim(); let fl=0, rd=0;
  for(const room in ROOMS){ const R=F.rooms[room]; if(!R||!R.on) continue; R.slots.forEach(sl=>{ if(!sl) return; if(canFlower(sl)&&!sl.nf){ sl.nf=1; fl++; } if(sl.st==='ready'&&!sl.nr){ sl.nr=1; rd++; } }); }
  if(fl) toast('🌸 '+(fl>1?fl+' plantes sont prêtes':'Une plante est prête')+' pour la floraison ! Ouvre le labo.');
  if(rd) toast('✂️ '+(rd>1?rd+' plantes sont prêtes':'Une plante est prête')+' à récolter !'); }catch(e){} },6000);
/* swipe entre fiches de plantes */
(function(){ let st=null; const sh=()=>document.getElementById('sheet');
  document.addEventListener('touchstart',e=>{ st=null; if(!sheet||sheet.t!=='ranch'||RY.slot==null) return; const el=sh(); if(!el||!el.contains(e.target)||e.target.closest('input,select,textarea,.rtabs,.chips,.rchips')) return; const t=e.touches[0]; st={x:t.clientX,y:t.clientY,t:Date.now()}; },{passive:true});
  document.addEventListener('touchend',e=>{ if(!st) return; const t=e.changedTouches[0], dx=t.clientX-st.x, dy=t.clientY-st.y, s0=st; st=null; if(Math.abs(dx)<60||Math.abs(dx)<Math.abs(dy)*1.5||Date.now()-s0.t>900) return; swipePlant(dx<0?1:-1); },{passive:true});
  window.swipePlant=function(dir){ const el=sh(); if(!el||!sheet||sheet.t!=='ranch'||RY.slot==null) return; S.swd=1; const R=farm().rooms[RY.tab]; if(!R) return; const idx=[]; R.slots.forEach((s,i)=>{ if(s) idx.push(i); }); if(idx.length<2) return; const p=idx.indexOf(RY.slot); const nx=idx[(p<0?0:(p+dir+idx.length)%idx.length)];
    el.style.transition='transform .14s ease-in,opacity .14s'; el.style.transform='translateX('+(-dir*60)+'px)'; el.style.opacity='0';
    setTimeout(()=>{ RY.slot=nx; RY.pick=null; renderSheet(); const e2=sh(); if(!e2) return; e2.scrollTop=0; e2.style.transition='none'; e2.style.transform='translateX('+(dir*60)+'px)'; e2.style.opacity='0'; void e2.offsetWidth; e2.style.transition='transform .2s ease-out,opacity .2s'; e2.style.transform=''; e2.style.opacity=''; setTimeout(()=>{ e2.style.transition=''; },240); },140); }; })();
/* décor : chrono, boutons floraison, classe arrondie */
function decor42(){ try{ const el=document.getElementById('sheet'); if(!el) return; const on=sheet&&sheet.t==='ranch'; el.classList.toggle('lab',!!on); if(!on) return; const room=RY.tab, R=farm().rooms[room]; if(!R) return;
  if(RY.slot!=null){ const sl=R.slots[RY.slot]; if(!sl) return;
    const rb=[...el.querySelectorAll('.rcard .rb span')].find(s=>s.textContent==='Avancement');
    if(rb&&sl.st!=='ready'&&sl.st!=='dead'){ let t=rb.parentNode.querySelector('.tmr'); if(!t){ t=document.createElement('em'); t.className='tmr'; rb.parentNode.appendChild(t); } t.textContent='⏱ '+fmtMS(slotLeftMin(room,sl)); }
    const hero=el.querySelector('.rhero2'); if(hero&&canFlower(sl)&&!el.querySelector('#flBtn')) hero.insertAdjacentHTML('afterend','<button class="btn wide good" id="flBtn" data-a="rflower" data-id="'+RY.slot+'">🌸 Passer en floraison</button>');
    if(hero&&!S.swd&&!el.querySelector('.plnav')){ const idx=R.slots.filter(Boolean).length; if(idx>1) hero.insertAdjacentHTML('beforebegin','<p class="plnav">↔ Glisse à gauche ou à droite pour passer à une autre plante</p>'); }
  } else { el.querySelectorAll('.rslot[data-a="rslot"]').forEach(b=>{ const sl=R.slots[+b.dataset.id]; if(!sl||sl.st==='ready'||sl.st==='dead') return; let t=b.querySelector('.tmr'); if(!t){ t=document.createElement('small'); t.className='tmr'; b.querySelector('small').after(t); } t.textContent='⏱ '+fmtMS(slotLeftMin(room,sl)); if(canFlower(sl)&&!b.querySelector('.rfl')) b.insertAdjacentHTML('beforeend','<span class="rfl">🌸 prête pour la floraison</span>'); });
    const n=R.slots.filter(canFlower).length, g=el.querySelector('#flAll'); if(n&&!g){ const grid=el.querySelector('.rgrid'); if(grid) grid.insertAdjacentHTML('beforebegin','<button class="btn wide good" id="flAll" data-a="floall">🌸 Floraison : '+n+' plante'+(n>1?'s':'')+' prête'+(n>1?'s':'')+'</button>'); } else if(g&&!n) g.remove(); }
 }catch(e){} }
setInterval(decor42,1000);
const _rsh42=renderSheet; renderSheet=function(){ const r=_rsh42.apply(this,arguments); decor42(); return r; };
/* jardinier progressif : peu au début, plus avec le niveau du labo et sa compétence */
empGard=function(eff,d){ const F=S.farm; if(!F||!F.found) return 0; ranchSim(); const L=Math.min(1,.3+.08*(typeof labL==='function'?labL():1)); F.gacc=F.gacc||{w:0,h:0,c:0};
  F.gacc.w+=.5*eff*d*L; F.gacc.h+=.25*eff*d*L; F.gacc.c+=.3*eff*d*L; let did=0; const t0=toast; toast=()=>{}; try{
    for(const room in ROOMS){ const R=F.rooms[room]; if(!R||!R.on) continue; const order=R.slots.map((sl,i)=>[sl,i]).filter(x=>x[0]).sort((a,b)=>a[0].w-b[0].w);
      for(const [sl,i] of order){
        if(sl.pest&&F.gacc.c>=1){ const k=sl.pest==='mold'?'FONG':'INSEC'; if((F.chem[k]||0)>0){ F.chem[k]--; sl.pest=null; F.gacc.c--; did++; } }
        if((sl.st==='germ'||sl.st==='veg'||sl.st==='flo')&&sl.w<35&&F.gacc.w>=1&&F.water>=3){ sl.w=Math.min(85,sl.w+30); F.water-=3; F.gacc.w--; did++; }
        if(sl.st==='ready'&&F.gacc.h>=1){ const keep=RY.tab; RY.tab=room; _rh0({id:String(i)}); RY.tab=keep; F.gacc.h--; did++; } } }
  }finally{ toast=t0; } for(const k in F.gacc) F.gacc[k]=Math.min(F.gacc[k],3); return did; };
/* tuto : chaleur et police, expliqué clairement */
(function(){ const i=GT.findIndex(g=>g.t&&g.t.indexOf('Chaleur, police')>=0); const A={ic:'🌡️',t:'La chaleur 🚨, c’est quoi ?',x:'La <b>chaleur</b> mesure l’<b>attention de la police</b> sur chaque pièce (Atelier, Ranch). Elle <b>monte toute seule</b> quand tu as des plantes : un peu en <b>croissance</b>, beaucoup en <b>floraison</b>, et <b>le plus</b> quand une plante est <b>prête mais pas récoltée</b>. Les lampes puissantes en ajoutent aussi. Plus tu as de plantes, plus elle monte. Tu la vois en haut à droite et dans « Mon labo ».'};
  const B={ic:'🚓',t:'Police, descente et karma',x:'<b>Sous 60 %</b> : aucun risque. <b>Au-dessus de 60 %</b> : une <b>descente de police</b> peut tomber à tout moment, de plus en plus probable jusqu’à 100 %. Elle <b>saisit la plupart de tes plantes en floraison</b>, <b>40 % du stock</b> et une <b>amende de 12 %</b> de tes crédits. <br><br><b>Comment la baisser</b> : récolte vite, installe des <b>filtres à charbon</b> (jusqu’à 3 par pièce), engage un <b>gardien</b> ou un <b>avocat</b>, garde un <b>karma positif</b>. Le <b>karma</b> monte avec les courses légales et les dons, descend avec les ventes de rue et les deals.'};
  if(i>=0) GT.splice(i,1,A,B); else GT.push(A,B); })();
/* ---- v0.65b : ambiance « weed » du labo : musique reggae / dub / chill + décor ---- */
const LM={ctx:null,on:false,timer:0,next:0,step:0,master:null,dly:null,nbuf:null,bar:0,pad:null};
const labActive=()=>{ try{ return view==='hub'&&HUB&&HUB.map&&GROW[HUB.map]&&!document.hidden&&!document.body.classList.contains('racing'); }catch(e){ return false; } };
const labVol=()=>{ try{ const a=S.audio||{}; if(a.mute) return 0; return .5*(a.master==null?.9:a.master)*(a.music==null?.7:a.music)/.63; }catch(e){ return .5; } };
function labMusicStart(){ if(LM.on) return; const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
  try{ LM.ctx=LM.ctx||new AC(); const c=LM.ctx; if(c.state==='suspended') c.resume(); if(c.state==='suspended') return;
    LM.master=c.createGain(); LM.master.gain.value=0; LM.master.connect(c.destination); LM.master.gain.setTargetAtTime(labVol(),c.currentTime,.8);
    /* écho dub */
    const dl=c.createDelay(2); dl.delayTime.value=60/72*.75; const fb=c.createGain(); fb.gain.value=.5; const lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=1800; const wet=c.createGain(); wet.gain.value=.6;
    dl.connect(lp); lp.connect(fb); fb.connect(dl); lp.connect(wet); wet.connect(LM.master); LM.dly=dl;
    const len=c.sampleRate*2, buf=c.createBuffer(1,len,c.sampleRate), d=buf.getChannelData(0); for(let i=0;i<len;i++) d[i]=Math.random()*2-1; LM.nbuf=buf;
    LM.on=true; LM.step=0; LM.bar=0; LM.next=c.currentTime+.15; LM.timer=setInterval(labSched,100);
  }catch(e){ LM.on=false; } }
function labMusicStop(){ if(!LM.on) return; LM.on=false; clearInterval(LM.timer); const m=LM.master, c=LM.ctx; try{ m.gain.cancelScheduledValues(c.currentTime); m.gain.setTargetAtTime(0,c.currentTime,.25); setTimeout(()=>{ try{ m.disconnect(); }catch(_){} },1500); }catch(_){} }
function labSched(){ const c=LM.ctx; if(!c||!LM.on) return; while(LM.next<c.currentTime+.4){ try{ labStep(LM.step,LM.next); }catch(e){} LM.next+=60/72/2; LM.step++; if(LM.step%8===0) LM.bar=(LM.step/8)|0; } }
function labStep(n,t){ const c=LM.ctx, M=LM.master, st=n%8, bar=((n/8)|0)%16, ph=(bar>=12?2:bar>=8?1:0), hz=m=>440*Math.pow(2,(m-69)/12), roots=[33,38,33,40], r=roots[bar%4];
  const drop=bar>=12;
  const tone=(type,f,t0,dur,vol,lpf,send,att)=>{ const o=c.createOscillator(), g=c.createGain(); o.type=type; o.frequency.value=f; const a=att||.008; g.gain.setValueAtTime(0,t0); g.gain.linearRampToValueAtTime(vol,t0+a); g.gain.exponentialRampToValueAtTime(.001,t0+dur); let n2=o; if(lpf){ const f2=c.createBiquadFilter(); f2.type='lowpass'; f2.frequency.value=lpf; o.connect(f2); n2=f2; } n2.connect(g); g.connect(M); if(send){ const s=c.createGain(); s.gain.value=send; g.connect(s); s.connect(LM.dly); } o.start(t0); o.stop(t0+dur+.05); };
  const noise=(t0,dur,vol,f,type,send)=>{ const ns=c.createBufferSource(); ns.buffer=LM.nbuf; const fl=c.createBiquadFilter(); fl.type=type||'highpass'; fl.frequency.value=f; const g=c.createGain(); g.gain.setValueAtTime(vol,t0); g.gain.exponentialRampToValueAtTime(.001,t0+dur); ns.connect(fl); fl.connect(g); g.connect(M); if(send){ const s=c.createGain(); s.gain.value=send; g.connect(s); s.connect(LM.dly); } ns.start(t0,Math.random()*1.5); ns.stop(t0+dur+.05); };
  const kick=(t0,v)=>{ const k=c.createOscillator(), g=c.createGain(); k.frequency.setValueAtTime(110,t0); k.frequency.exponentialRampToValueAtTime(38,t0+.22); g.gain.setValueAtTime(v,t0); g.gain.exponentialRampToValueAtTime(.001,t0+.32); k.connect(g); g.connect(M); k.start(t0); k.stop(t0+.36); };
  /* batterie « one drop » : kick + cross-stick sur le temps 3 */
  if(!drop){ if(st===4){ kick(t,.62); noise(t,.07,.22,1800,'bandpass',.45); tone('triangle',420,t,.07,.12,null,.3); } if(st===0&&bar%2===0) kick(t,.34); }
  else { /* drop dubstep : demi-temps */ if(st===0){ kick(t,.7); } if(st===4){ kick(t,.5); noise(t,.18,.3,1400,'bandpass',.5); } }
  /* charley sur les contretemps */
  noise(t,.035,st%2?.06:.025,8000); if(st%2===1&&ph>0) noise(t+.02,.05,.03,9500);
  /* basse : ronde, profonde */
  if(!drop){ if([0,3,4,6].includes(st)){ const note=r+(st===4?7:st===6?10:0); tone('sine',hz(note),t,st===0?.7:.3,.5,260); tone('triangle',hz(note+12),t,.22,.07,500); } }
  else { if(st===0||st===4){ /* wobble */
      const o=c.createOscillator(), g=c.createGain(), f=c.createBiquadFilter(), lfo=c.createOscillator(), lg=c.createGain(); o.type='sawtooth'; o.frequency.value=hz(r); f.type='lowpass'; f.Q.value=7; f.frequency.value=400; lfo.frequency.value=3.4; lg.gain.value=340; lfo.connect(lg); lg.connect(f.frequency);
      g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.26,t+.03); g.gain.setTargetAtTime(0,t+.75,.08); o.connect(f); f.connect(g); g.connect(M); o.start(t); lfo.start(t); o.stop(t+1.05); lfo.stop(t+1.05); } }
  /* skank : accords sur les contretemps, envoyés dans l'écho */
  if(st%2===1&&!(drop&&bar%2)){ [0,3,7].forEach(i=>tone('square',hz(r+24+i),t,.1,.028,1500,.5)); tone('triangle',hz(r+31),t,.12,.03,1800,.5); }
  /* nappe chill : une note longue tous les 2 temps forts */
  if(st===0&&bar%2===0){ [0,3,7,10].forEach((i,k)=>tone('sine',hz(r+24+i),t,3.2,.05,1200,.25,.9)); }
  /* mélodica / flûte pentatonique */
  if(ph>=1&&!drop&&(st===2||st===5)&&Math.random()<.55){ const pent=[0,3,5,7,10,12,15], nt=r+36+pent[(Math.random()*pent.length)|0]; const o=c.createOscillator(), v=c.createOscillator(), vg=c.createGain(), g=c.createGain(); o.type='triangle'; o.frequency.value=hz(nt); v.frequency.value=5.2; vg.gain.value=hz(nt)*.012; v.connect(vg); vg.connect(o.frequency); g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.06,t+.05); g.gain.exponentialRampToValueAtTime(.001,t+.7); o.connect(g); g.connect(M); const s=c.createGain(); s.gain.value=.55; g.connect(s); s.connect(LM.dly); o.start(t); v.start(t); o.stop(t+.8); v.stop(t+.8); }
  /* gargouillis de bang, discret, de temps en temps */
  if(st===6&&bar%8===5){ for(let k=0;k<5;k++){ const o=c.createOscillator(), g=c.createGain(), tt=t+k*.09; o.frequency.setValueAtTime(260+k*40,tt); o.frequency.exponentialRampToValueAtTime(620+k*60,tt+.07); g.gain.setValueAtTime(.05,tt); g.gain.exponentialRampToValueAtTime(.001,tt+.08); o.connect(g); g.connect(M); o.start(tt); o.stop(tt+.1); } }
}
/* bouton musique dans le labo */
function labBtn(){ let b=document.getElementById('lmBtn'); const on=labActive()&&!sheet; if(!on){ if(b) b.remove(); return; } if(!b){ b=document.createElement('button'); b.id='lmBtn'; b.dataset.a='lmtoggle'; document.body.appendChild(b); } const off=!!(S&&S.labMusicOff); const t=off?'🔇':'🎵'; if(b.textContent!==t) b.textContent=t; b.setAttribute('aria-label',off?'Activer la musique du labo':'Couper la musique du labo'); }
ACT.lmtoggle=()=>{ S.labMusicOff=!S.labMusicOff; try{ save(); }catch(e){} toast(S.labMusicOff?'Musique du labo coupée':'🎵 Ambiance reggae / dub'); labWatch(); };
let labAmb=false;
function labWatch(){ try{ const act=labActive(); if(act&&!labAmb){ labAmb=true; ambMute(true); } else if(!act&&labAmb){ labAmb=false; if(!WM.on) ambMute(false); } const want=labActive()&&!S.labMusicOff&&labVol()>0; if(want&&!LM.on) labMusicStart(); else if(!want&&LM.on) labMusicStop(); if(LM.on&&LM.master) LM.master.gain.setTargetAtTime(labVol(),LM.ctx.currentTime,.3); labBtn(); }catch(e){} }
setInterval(labWatch,500);
document.addEventListener('visibilitychange',()=>{ if(document.hidden) labMusicStop(); });
/* décor cannabis : feuilles néon, bandes rasta, brume verte, feuilles qui flottent */
function leafTex(col){ const cv=document.createElement('canvas'); cv.width=cv.height=128; const x=cv.getContext('2d'); x.translate(64,118); const lobes=[[0,100,11],[28,86,10],[-28,86,10],[58,64,9],[-58,64,9],[88,42,7],[-88,42,7]];
  lobes.forEach(([a,len,w])=>{ x.save(); x.rotate(a*Math.PI/180); const g=x.createLinearGradient(0,0,0,-len); g.addColorStop(0,'#0f5a2c'); g.addColorStop(1,col); x.fillStyle=g; x.beginPath(); x.moveTo(0,0); x.quadraticCurveTo(w*1.4,-len*.5,0,-len); x.quadraticCurveTo(-w*1.4,-len*.5,0,0); x.fill(); x.strokeStyle='rgba(255,255,255,.35)'; x.lineWidth=1.2; x.beginPath(); x.moveTo(0,-4); x.lineTo(0,-len*.85); x.stroke(); x.restore(); });
  x.strokeStyle='#0f5a2c'; x.lineWidth=4; x.beginPath(); x.moveTo(0,0); x.lineTo(0,10); x.stroke(); const t=new THREE.CanvasTexture(cv); return t; }
function weedDecor(room){ const H=HUB, sc=H.scene; if(!sc||!window.THREE) return; const G=GROW[room], out=G.out, BX=G.bx, BZ=G.bz; const wz={haze:[],leaves:[]}; H.wz=wz;
  const T1=leafTex('#3cff9e'), T2=leafTex('#b6ff4d'), T3=leafTex('#7dffd0');
  const plane=(tex,w,h,x,y,z,ry)=>{ const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex,transparent:true,side:THREE.DoubleSide,depthWrite:false})); m.position.set(x,y,z); if(ry) m.rotation.y=ry; sc.add(m); return m; };
  const box=(w,h,d,x,y,z,c)=>{ const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshBasicMaterial({color:c})); m.position.set(x,y,z); sc.add(m); return m; };
  if(!out){
    [-17,1,15].forEach((x,i)=>{ plane([T1,T2,T3][i],4.6,4.6,x,7.6,-BZ+.2); }); plane(T1,3.4,3.4,BX-.3,7.4,-6,-Math.PI/2); plane(T2,3.4,3.4,-BX+.3,7.4,-6,Math.PI/2);
    [[0xe8202a,9.55],[0xfcd116,9.3],[0x13a538,9.05]].forEach(([c,y])=>box(BX*2-2,.14,.1,0,y,-BZ+.12,c));
    [[0xe8202a,9.55],[0xfcd116,9.3],[0x13a538,9.05]].forEach(([c,y])=>{ box(.1,.14,BZ*2-2,BX-.12,y,0,c); box(.1,.14,BZ*2-2,-BX+.12,y,0,c); });
    const sg=labelSprite('🍃 IRIE · 420 🍃','#3CFF9E',22); sg.position.set(-8,10.6,-BZ+.6); sg.material.depthTest=false; sg.renderOrder=20; sc.add(sg);
    for(let i=0;i<(window.__lq?4:12);i++){ const s=new THREE.Sprite(new THREE.SpriteMaterial({map:growCache().glowM.map,color:i%3?0x6dffb0:0xc9ff7a,transparent:true,opacity:.1,depthWrite:false,fog:false})); s.scale.set(16,10,1); s.position.set((Math.random()*2-1)*BX*.9,2+Math.random()*5,(Math.random()*2-1)*BZ*.9); wz.haze.push({s,x:s.position.x,z:s.position.z,p:Math.random()*6,sp:.15+Math.random()*.2}); sc.add(s); }
    const l1=new THREE.PointLight(0x3cff9e,.9,60); l1.position.set(-14,7,-6); sc.add(l1); const l2=new THREE.PointLight(0xfcd116,.5,50); l2.position.set(14,7,-8); sc.add(l2);
  } else {
    plane(T1,6,6,-BX+2,6,-BZ+.2); plane(T2,6,6,BX-2,6,-BZ+.2); const sg=labelSprite('🍃 IRIE · 420 🍃','#B6FF4D',22); sg.position.set(0,12,-BZ-2); sg.material.depthTest=false; sg.renderOrder=20; sc.add(sg);
    for(let i=0;i<(window.__lq?3:8);i++){ const s=new THREE.Sprite(new THREE.SpriteMaterial({map:growCache().glowM.map,color:0xc9ff7a,transparent:true,opacity:.08,depthWrite:false,fog:false})); s.scale.set(22,12,1); s.position.set((Math.random()*2-1)*BX,3+Math.random()*5,(Math.random()*2-1)*BZ); wz.haze.push({s,x:s.position.x,z:s.position.z,p:Math.random()*6,sp:.12+Math.random()*.15}); sc.add(s); }
  }
  for(let i=0;i<(window.__lq?(out?5:8):(out?14:22));i++){ const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:[T1,T2,T3][i%3],transparent:true,opacity:.8,depthWrite:false})); const sz=.7+Math.random()*.8; sp.scale.set(sz,sz,1); const x=(Math.random()*2-1)*BX*.9, z=(Math.random()*2-1)*BZ*.9, y=1+Math.random()*7; sp.position.set(x,y,z); wz.leaves.push({s:sp,x,z,y,p:Math.random()*6,sp:.25+Math.random()*.4}); sc.add(sp); }
}
const _gb43=growBuild; growBuild=function(room){ _gb43(room); try{ weedDecor(room); }catch(e){ console.error(e); } };
const _gt43=growTick; growTick=function(dt){ _gt43(dt); try{ const w=HUB.wz, t=HUB.t||0; if(!w) return; w.haze.forEach(h=>{ h.s.position.x=h.x+Math.sin(t*h.sp+h.p)*3; h.s.position.z=h.z+Math.cos(t*h.sp*.8+h.p)*2.5; h.s.material.opacity=.07+.04*Math.sin(t*.5+h.p); }); w.leaves.forEach(l=>{ l.s.position.y=l.y+Math.sin(t*l.sp+l.p)*.6; l.s.position.x=l.x+Math.sin(t*l.sp*.7+l.p)*.8; l.s.material.rotation=Math.sin(t*l.sp+l.p)*.6; }); }catch(e){} };
/* ---- v0.66 : marché des voitures (casse + concession) : vues x1/x3, recherche, filtres, tri ---- */
const MKF={q:'',tier:'',sort:'prix'};
const mkCols=()=>(S&&S.mkcols>=3)?3:1;
function mkCard(c,btn){ const n=mkCols(); return '<div class="mkc">'+cardHTML(c,{tag:'div',cls:n===3?'cmini':''})+btn+'</div>'; }
function mkList(){ const q=MKF.q.trim().toLowerCase(), ok=m=>(!q||(m.nom+' '+(m.cat||'')).toLowerCase().includes(q))&&(!MKF.tier||String(m.t)===MKF.tier);
  const sort=a=>MKF.sort==='tier'?a.sort((x,y)=>M[x.mid].t-M[y.mid].t||x.p-y.p):MKF.sort==='puiss'?a.sort((x,y)=>(M[y.mid].ch||0)-(M[x.mid].ch||0)):a.sort((x,y)=>x.p-y.p);
  const cl=S.bat.concession, neuves=cl?CARS.filter(m=>m.t<=cl+1):[];
  const wr=sort(S.offres.map((o,i)=>({o,i,mid:o.mid,p:o.prix})).filter(x=>ok(M[x.mid])));
  const nw=sort(neuves.map(m=>({m,mid:m.id,p:m.val})).filter(x=>ok(x.m)));
  return {wr,nw,cl,tot:S.offres.length+neuves.length}; }
function mkGrids(){ const {wr,nw,cl}=mkList(), n=mkCols(), cr_=v=>cr(v);
  const btn=(a,id,p)=>`<button class="btn wide sm" data-a="${a}" data-id="${id}" ${S.cr<p?'disabled':''}>${n===3?'Acheter<br><small>'+cr_(p)+'</small>':'Acheter '+cr_(p)}</button>`;
  const g1=wr.length?wr.map(x=>mkCard({mid:x.mid,etat:x.o.etat,lvl:1,up:{}},btn('buy',x.i,x.p))).join(''):'<p class="note" style="grid-column:1/-1;text-align:center">Aucune épave ne correspond.</p>';
  const g2=cl?(nw.length?nw.map(x=>mkCard({mid:x.mid,etat:100,lvl:1,up:{}},btn('buynew',x.mid,x.p))).join(''):'<p class="note" style="grid-column:1/-1;text-align:center">Aucune voiture ne correspond.</p>'):'';
  return {g1,g2,nw:nw.length,wr:wr.length}; }
function mkBar(){ const n=mkCols(); const opt=(v,l,c)=>`<option value="${v}" ${c===v?'selected':''}>${l}</option>`;
  return `<div class="mkbar"><input id="mq" type="search" placeholder="🔎 Rechercher une voiture…" value="${MKF.q.replace(/"/g,'&quot;')}">
   <div class="mkrow"><select id="mkt">${opt('','Toutes raretés',MKF.tier)}${TIERS.map((t,i)=>t?opt(String(i),t.n,MKF.tier):'').join('')}</select><select id="mks">${opt('prix','↕ Prix croissant',MKF.sort)}${opt('tier','↕ Rareté',MKF.sort)}${opt('puiss','↕ Puissance',MKF.sort)}</select></div>
   <div class="gview"><button data-a="mkcols" data-id="1" class="${n===1?'on':''}">▬ x1</button><button data-a="mkcols" data-id="3" class="${n===3?'on':''}">▦ x3</button></div></div>`; }
const _vM44=vMarche; vMarche=function(){ let h=_vM44.apply(this,arguments); if(mTab!=='cars') return h;
  const g=mkGrids(), cl=S.bat.concession, refresh=100*S.bat.casse, n=mkCols();
  const body=`${mkBar()}<h3>🏚️ Casse automobile <small class="mkn">${g.wr} épave${g.wr>1?'s':''}</small></h3><p class="note">Des épaves à retaper. Les offres changent toutes les 3 épreuves.</p>
   <div class="grid mkgrid gc${n}" id="mkg1">${g.g1}</div>
   <button class="btn alt sm wide" style="margin-top:12px" data-a="refresh" ${S.cr<refresh?'disabled':''}>Voir d’autres épaves, ${cr(refresh)}</button>
   <div class="sec"><h3>🏢 Concession <small class="mkn">${cl?g.nw+' voiture'+(g.nw>1?'s':''):''}</small></h3>${cl?`<p class="note">Voitures neuves, 100 % d’état.</p><div class="grid mkgrid gc${n}" id="mkg2">${g.g2}</div>`:`<p class="note">Construis la concession dans Atelier › Base pour acheter des voitures neuves.</p>`}</div>`;
  const a=h.indexOf('<h3>Casse automobile</h3>'); if(a<0) return h; const b=h.indexOf('</div></div>',h.lastIndexOf('Concession</h3>')); 
  /* remplace tout le bloc voitures par le nouveau, en gardant les onglets */
  const head=h.slice(0,a); return head+body+(b>0&&h.slice(b+12).trim()?h.slice(b+12):''); };
ACT.mkcols=d=>{ S.mkcols=+d.id; try{ save(); }catch(e){} render(); };
function mkRefresh(){ try{ const g=mkGrids(), a=document.getElementById('mkg1'), b=document.getElementById('mkg2'); if(a) a.innerHTML=g.g1; if(b) b.innerHTML=g.g2; }catch(e){} }
document.addEventListener('input',e=>{ if(e.target.id==='mq'){ MKF.q=e.target.value; mkRefresh(); } });
document.addEventListener('change',e=>{ if(e.target.id==='mkt'){ MKF.tier=e.target.value; render(); } else if(e.target.id==='mks'){ MKF.sort=e.target.value; render(); } });
/* ---- v1.0 : navigation resserrée, parcours de début, sauvegarde, qualité graphique ---- */
/* 1. Équipe rejoint l'Atelier : 7 onglets au lieu de 8 */
(()=>{ const i=TABS.findIndex(t=>t[0]==='equipe'); if(i>=0) TABS.splice(i,1); const a=TABS.find(t=>t[0]==='atelier'); if(a){ a[1]='🛠️'; a[2]='Atelier'; } })();
const _rn45=render; render=function(){ const r=_rn45.apply(this,arguments); try{ decor45(); }catch(e){} return r; };
function decor45(){ if(view==='atelier'||view==='equipe'){ const v=document.getElementById('view'); if(v&&!v.querySelector('.topsw')) v.insertAdjacentHTML('afterbegin','<div class="subtabs topsw">'+[['atelier','🔨 Fabrication'],['equipe','👥 Équipe']].map(([id,n])=>'<button data-a="tab" data-id="'+id+'" '+(view===id?'aria-current="true"':'')+'>'+n+'</button>').join('')+'</div>'); }
  const nav=document.getElementById('nav'); if(nav&&view==='equipe'){ const b=nav.querySelector('[data-id="atelier"]'); if(b) b.setAttribute('aria-current','page'); }
  const pb=document.querySelector('#view [data-a="patch"]'); if(pb&&!document.getElementById('svbtn')) pb.insertAdjacentHTML('afterend',' <button class="btn alt" id="svbtn" data-a="svopen">💾 Sauvegarde</button> <button class="btn alt" id="qlbtn" data-a="qlset">🎞️ Qualité : '+(({auto:'Auto',low:'Basse',high:'Haute'})[(S.q||'auto')])+'</button>'); }
/* 2. parcours de début : étapes supplémentaires après celles qui existent */
const _gn45=goalNext; goalNext=function(){ const r=_gn45.apply(this,arguments); if(r) return r; const st=S.stats||{};
  if(S.cars.length<2&&S.cr>=600) return ['🛒','Achète une deuxième voiture au marché (casse ou concession) pour varier tes épreuves','marche','Au marché'];
  if(!(S.bat&&S.bat.bureau)&&S.cr>=1200) return ['🏗️','Construis le Bureau des contrats : +10 % de gains sur toutes les épreuves','base','À la base'];
  try{ if(typeof questsEnsure==='function'){ questsEnsure(); const q=S.quests; if(q&&q.d&&q.d.some&&false) return null; } }catch(e){}
  if(S.daily!==dayKey()) return ['🎁','Ta récompense quotidienne est prête, ainsi que les défis du jour','missions','Aux missions'];
  return null; };
/* 3. sauvegarde : export / import / copie de secours */
const encS=()=>btoa(unescape(encodeURIComponent(JSON.stringify(S))));
const decS=t=>JSON.parse(decodeURIComponent(escape(atob(t.trim()))));
setInterval(()=>{ try{ if(S&&S.cars&&S.cars.length) localStorage.setItem(KEY+'_bak',JSON.stringify(S)); }catch(e){} },120000);
ACT.svopen=()=>{ let m=document.getElementById('svm'); if(m) m.remove(); const hasBak=(()=>{ try{ return !!localStorage.getItem(KEY+'_bak'); }catch(e){ return false; } })();
  document.body.insertAdjacentHTML('beforeend','<div id="svm"><div class="svc"><h2>💾 Sauvegarde</h2><p class="note">Ta progression est gardée dans ce navigateur. Copie le code ci-dessous et garde-le : il te permet de tout restaurer, même sur un autre appareil.</p><textarea id="svt" readonly rows="4"></textarea><div class="svb"><button class="btn" data-a="svcopy">📋 Copier le code</button><button class="btn alt" data-a="svdl">⬇️ Télécharger</button></div><h3>Restaurer</h3><textarea id="svi" rows="3" placeholder="Colle ici un code de sauvegarde"></textarea><div class="svb"><button class="btn" data-a="svimp">⬆️ Importer</button>'+(hasBak?'<button class="btn alt" data-a="svbak">🕑 Copie de secours</button>':'')+'</div><p class="note" id="svmsg"></p><button class="btn alt wide" data-a="svclose">Fermer</button></div></div>');
  try{ document.getElementById('svt').value=encS(); }catch(e){} };
ACT.svclose=()=>{ const m=document.getElementById('svm'); if(m) m.remove(); };
ACT.svcopy=async()=>{ const t=document.getElementById('svt'); const msg=document.getElementById('svmsg'); try{ await navigator.clipboard.writeText(t.value); msg.textContent='Code copié.'; }catch(e){ t.select(); try{ document.execCommand('copy'); msg.textContent='Code copié.'; }catch(_){ msg.textContent='Sélectionne le code et copie-le à la main.'; } } };
ACT.svdl=()=>{ const msg=document.getElementById('svmsg'); try{ const b=new Blob([JSON.stringify(S)],{type:'application/json'}), a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='high-et-rouille-sauvegarde.json'; document.body.appendChild(a); a.click(); a.remove(); msg.textContent='Fichier demandé. S’il ne part pas, utilise « Copier le code ».'; }catch(e){ msg.textContent='Téléchargement impossible ici : utilise « Copier le code ».'; } };
ACT.svimp=()=>{ const msg=document.getElementById('svmsg'), v=document.getElementById('svi').value.trim(); if(!v){ msg.textContent='Colle d’abord un code.'; return; } try{ const o=v[0]==='{'?JSON.parse(v):decS(v); if(!o||!Array.isArray(o.cars)) throw new Error('bad'); localStorage.setItem(KEY+'_bak',JSON.stringify(S)); localStorage.setItem(KEY,JSON.stringify(o)); msg.textContent='Sauvegarde importée, rechargement…'; setTimeout(()=>location.reload(),600); }catch(e){ msg.textContent='Code invalide : rien n’a été modifié.'; } };
ACT.svbak=()=>{ const msg=document.getElementById('svmsg'); try{ const b=localStorage.getItem(KEY+'_bak'); if(!b) throw 0; JSON.parse(b); localStorage.setItem(KEY,b); msg.textContent='Copie de secours restaurée, rechargement…'; setTimeout(()=>location.reload(),600); }catch(e){ msg.textContent='Aucune copie de secours valide.'; } };
/* 4. qualité graphique */
const labLQ=()=>{ const q=(S&&S.q)||'auto'; if(q==='low') return true; if(q==='high') return false; try{ return (navigator.hardwareConcurrency||8)<=4||(navigator.deviceMemory||8)<=3; }catch(e){ return false; } };
window.__lq=labLQ();
ACT.qlset=()=>{ const o=['auto','low','high']; S.q=o[(o.indexOf(S.q||'auto')+1)%3]; window.__lq=labLQ(); try{ save(); }catch(e){} toast('Qualité : '+({auto:'Auto',low:'Basse',high:'Haute'})[S.q]+(S.q==='auto'?(window.__lq?' (basse détectée)':' (haute détectée)'):'')+' — appliquée au prochain chargement de scène'); render(); };
/* ---- v1.0 : nouveaux circuits générés (5 circuits + 3 circuits de drift) ---- */
const NTRK={
 c1:{nom:'Circuit des Docks',k:'c',pl:7,lim:12.5,p:[[0,0],[220,0],[300,20],[330,80],[300,140],[220,160],[160,150],[120,190],[130,260],[200,300],[260,350],[220,400],[100,400],[20,360],[-40,300],[-30,230],[-80,180],[-70,100],[-30,40]]},
 c2:{nom:'Boucle du Lac',k:'c',pl:7.5,lim:13,p:[[0,0],[250,-30],[420,10],[500,120],[470,260],[350,320],[250,260],[150,300],[40,340],[-90,290],[-130,170],[-90,60]]},
 c3:{nom:'Zone Industrielle',k:'c',pl:7,lim:12.5,p:[[0,0],[300,0],[340,60],[300,120],[200,120],[170,180],[230,240],[340,240],[390,300],[340,370],[120,370],[60,310],[100,250],[40,190],[-40,200],[-80,120],[-50,40]]},
 c4:{nom:'La Corniche',k:'c',pl:8,lim:14,p:[[0,0],[300,-60],[600,-40],[780,60],[820,200],[720,300],[560,260],[430,320],[300,420],[120,430],[-60,370],[-130,240],[-90,100]]},
 c5:{nom:'Grand Anneau Néon',k:'c',pl:8.5,lim:14.5,p:[[0,0],[400,0],[560,40],[640,140],[600,240],[480,280],[400,250],[330,300],[250,250],[160,270],[60,300],[-60,270],[-120,170],[-90,60]]},
 f1:{nom:'Drift : Parking Cargo',k:'d',pl:8,lim:15,p:[[0,0],[120,0],[180,30],[170,90],[100,110],[40,100],[30,160],[100,190],[180,180],[200,240],[130,280],[40,270],[-30,240],[-50,160],[-40,80]]},
 f2:{nom:'Drift : Spirale du Col',k:'d',pl:8,lim:15,p:[[0,0],[200,0],[260,50],[230,110],[120,120],[60,170],[100,230],[220,240],[290,300],[250,360],[120,370],[10,340],[-50,270],[-40,180],[-60,100]]},
 f3:{nom:'Drift : Arène Néon',k:'d',pl:9,lim:16,p:[[0,0],[180,-20],[300,30],[330,130],[270,210],[160,190],[110,250],[170,320],[290,350],[260,430],[130,450],[10,400],[-60,310],[-70,200],[-50,100]]}
};
const _wA=a=>{ a=(a+Math.PI)%(2*Math.PI); return (a<0?a+2*Math.PI:a)-Math.PI; };
function trkGen(spec){
  const P=spec.p, n0=P.length, dense=[];
  for(let i=0;i<n0;i++){ const p0=P[(i-1+n0)%n0], p1=P[i], p2=P[(i+1)%n0], p3=P[(i+2)%n0];
    for(let k=0;k<24;k++){ const t=k/24, t2=t*t, t3=t2*t; const f=(a,b,c,d)=>.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t2+(-a+3*b-3*c+d)*t3); dense.push([f(p0[0],p1[0],p2[0],p3[0]),f(p0[1],p1[1],p2[1],p3[1])]); } }
  const resample=(pts,N)=>{ const m=pts.length, cum=[0]; for(let i=0;i<m;i++){ const a=pts[i], b=pts[(i+1)%m]; cum.push(cum[i]+Math.hypot(b[0]-a[0],b[1]-a[1])); } const Lt=cum[m], out=[]; let j=0; for(let k=0;k<N;k++){ const s=k*Lt/N; while(cum[j+1]<s) j++; const a=pts[j%m], b=pts[(j+1)%m], u=(s-cum[j])/Math.max(1e-9,cum[j+1]-cum[j]); out.push([a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u]); } return {out,Lt}; };
  let r=resample(dense,Math.max(60,Math.round(dense.length*3/3))); const Lt0=r.Lt; const N=Math.round(Lt0/3); r=resample(dense,N); let pts=r.out;
  for(let it=0;it<6;it++){ pts=pts.map((p,i)=>{ const a=pts[(i-1+N)%N], b=pts[(i+1)%N]; return [(a[0]+2*p[0]+b[0])/4,(a[1]+2*p[1]+b[1])/4]; }); }
  let L=0; for(let i=0;i<N;i++){ const a=pts[i], b=pts[(i+1)%N]; L+=Math.hypot(b[0]-a[0],b[1]-a[1]); } const DS=L/N;
  const cx=new Float32Array(N), cz=new Float32Array(N), cy=new Float32Array(N), th=new Float32Array(N), kap=new Float32Array(N), limL=new Float32Array(N), limR=new Float32Array(N), pl=new Float32Array(N), pr=new Float32Array(N), wallL=new Float32Array(N), wallR=new Float32Array(N);
  for(let i=0;i<N;i++){ cx[i]=pts[i][0]; cz[i]=pts[i][1]; }
  for(let i=0;i<N;i++){ const a=(i-1+N)%N, b=(i+1)%N; th[i]=Math.atan2(cz[b]-cz[a],cx[b]-cx[a]); }
  for(let i=0;i<N;i++){ const a=(i-2+N)%N, b=(i+2)%N; kap[i]=_wA(th[b]-th[a])/(4*DS); }
  for(let i=0;i<N;i++){ pl[i]=pr[i]=spec.pl; limL[i]=limR[i]=spec.lim; wallL[i]=wallR[i]=spec.lim; }
  /* grille de surfaces */
  let x0=1e9,x1=-1e9,z0=1e9,z1=-1e9; for(let i=0;i<N;i++){ x0=Math.min(x0,cx[i]); x1=Math.max(x1,cx[i]); z0=Math.min(z0,cz[i]); z1=Math.max(z1,cz[i]); }
  const X0=Math.floor(x0-90), Z0=Math.floor(z0-90), GW=Math.ceil(x1-X0+90), GH=Math.ceil(z1-Z0+90), grid=new Uint8Array(GW*GH);
  const nx=i=>Math.sin(th[i]), nz=i=>-Math.cos(th[i]), corner=i=>Math.abs(kap[i])>1/170;
  const paint=(code,fromF,toF)=>{ for(let i=0;i<N;i++){ const j=(i+1)%N; for(let sub=0;sub<3;sub++){ const u=sub/3, px=cx[i]+(cx[j]-cx[i])*u, pz=cz[i]+(cz[j]-cz[i])*u, ax=nx(i), az=nz(i); for(let sd=-1;sd<=1;sd+=2){ const a=fromF(i,sd), b=toF(i,sd); for(let o=a;o<=b;o+=.5){ const gx=Math.floor(px+ax*sd*o-X0), gz=Math.floor(pz+az*sd*o-Z0); if(gx>=0&&gz>=0&&gx<GW&&gz<GH) grid[gz*GW+gx]=code; } } } } };
  const lim=(i,sd)=>sd>0?limL[i]:limR[i], pw=(i,sd)=>sd>0?pl[i]:pr[i];
  paint(2,()=>0,(i,sd)=>lim(i,sd)+.4);
  paint(5,(i,sd)=>pw(i,sd)+1.2,(i,sd)=>{ const outer=(kap[i]>0)===(sd>0); return pw(i,sd)+1.2+(corner(i)&&outer?Math.min(3.8,lim(i,sd)-pw(i,sd)-1.4):-1); });
  paint(8,(i,sd)=>pw(i,sd),(i,sd)=>pw(i,sd)+(corner(i)?1.2:-1));
  paint(7,()=>0,(i,sd)=>pw(i,sd));
  /* maillage */
  const tile=256, TX0=Math.floor((x0-120)/tile)*tile, TZ0=Math.floor((z0-120)/tile)*tile, bins={};
  const bin=(g,x,z)=>{ const tx=Math.floor((x-TX0)/tile), tz=Math.floor((z-TZ0)/tile), k=g+'|'+tx+'|'+tz; return bins[k]||(bins[k]={g,t:[tx,tz],pos:[],idx:[],col:[],uv:[]}); };
  const quad=(g,A,B,C,D,col,uv)=>{ const b=bin(g,(A[0]+C[0])/2,(A[2]+C[2])/2), v=b.pos.length/3; b.pos.push(...A,...B,...C,...D); b.idx.push(v,v+1,v+2,v,v+2,v+3); if(col) for(let k=0;k<4;k++) b.col.push(...col); if(uv) b.uv.push(...uv); };
  const pt=(i,sd,o,y)=>[cx[i]+nx(i)*sd*o,y,cz[i]+nz(i)*sd*o];
  for(let i=0;i<N;i++){ const j=(i+1)%N, lo=lim(i,1), ro=lim(i,-1);
    quad('grass',pt(i,1,lo,0),pt(j,1,limL[j],0),pt(j,-1,limR[j],0),pt(i,-1,ro,0),null,null);
    quad('asph',pt(i,1,pl[i],.02),pt(j,1,pl[j],.02),pt(j,-1,pr[j],.02),pt(i,-1,pr[i],.02),null,null);
    for(const sd of [1,-1]){ if(corner(i)&&corner(j)){ const a=pw(i,sd), b=pw(j,sd); quad('kerb',pt(i,sd,a,.04),pt(j,sd,b,.04),pt(j,sd,b+1.2,.04),pt(i,sd,a+1.2,.04),null,[i/2,0,(i+1)/2,0,(i+1)/2,1,i/2,1]); }
      quad('lines',pt(i,sd,pw(i,sd)-.7,.06),pt(j,sd,pw(j,sd)-.7,.06),pt(j,sd,pw(j,sd)-.35,.06),pt(i,sd,pw(i,sd)-.35,.06),null,null);
      const w0=lim(i,sd), w1=lim(j,sd), cc=sd>0?[0,229,255]:[255,43,214];
      quad('wall_solid',pt(i,sd,w0,0),pt(j,sd,w1,0),pt(j,sd,w1,1.1),pt(i,sd,w0,1.1),[42,47,102],null);
      quad('wall_energy',pt(i,sd,w0,1.1),pt(j,sd,w1,1.1),pt(j,sd,w1,2.4),pt(i,sd,w0,2.4),cc,null); }
    if(i%4<2) quad('lines',pt(i,1,.12,.06),pt(j,1,.12,.06),pt(j,-1,.12,.06),pt(i,-1,.12,.06),null,null); }
  const sx=Math.ceil((x1+120-TX0)/tile), sz=Math.ceil((z1+120-TZ0)/tile);
  for(let a=0;a<sx;a++) for(let b=0;b<sz;b++){ const k='terrain|'+a+'|'+b, X=TX0+a*tile, Z=TZ0+b*tile; bins[k]={g:'terrain',t:[a,b],pos:[X,-.12,Z,X+tile,-.12,Z,X+tile,-.12,Z+tile,X,-.12,Z+tile],idx:[0,1,2,0,2,3],col:[],uv:[]}; }
  /* immeubles néon et arbres hors piste */
  let seed=spec.p.length*977+3; const rn=()=>{ seed=(seed*16807)%2147483647; return seed/2147483647; };
  const far=(x,z,m)=>{ for(let i=0;i<N;i+=2){ if(Math.hypot(cx[i]-x,cz[i]-z)<m) return false; } return true; };
  const trees=[]; let nb=0, tries=0; while(nb<(spec.k==='c'?46:30)&&tries<900){ tries++; const x=x0-80+rn()*(x1-x0+160), z=z0-80+rn()*(z1-z0+160); if(!far(x,z,spec.lim+34)) continue; const w=10+rn()*16, d=10+rn()*16, h=12+rn()*40;
    const y0=0, v=[[x-w/2,y0,z-d/2],[x+w/2,y0,z-d/2],[x+w/2,y0,z+d/2],[x-w/2,y0,z+d/2],[x-w/2,h,z-d/2],[x+w/2,h,z-d/2],[x+w/2,h,z+d/2],[x-w/2,h,z+d/2]];
    [[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7]].forEach(f=>quad('bldg',v[f[0]],v[f[1]],v[f[2]],v[f[3]],null,null)); nb++; }
  const tl={}; for(let k=0;k<70;k++){ const x=x0-60+rn()*(x1-x0+120), z=z0-60+rn()*(z1-z0+120); if(!far(x,z,spec.lim+8)) continue; const tx=Math.floor((x-TX0)/tile), tz=Math.floor((z-TZ0)/tile), kk=tx+'|'+tz; (tl[kk]=tl[kk]||{t:[tx,tz],a:[]}).a.push(x,0,z,5+rn()*5); }
  /* empaquetage binaire */
  const parts=[]; let off=0; const items=[]; const align=n=>{ off=(off+n-1)&~(n-1); };
  const put=(arr,Type)=>{ align(4); const o=off; items.push([o,new Type(arr)]); off+=arr.length*Type.BYTES_PER_ELEMENT; return o; };
  const F=Float32Array;
  const phys={}; ['cx','cz','cy','th','kap','limL','limR','pl','pr','wallL','wallR'].forEach(k=>{ const a={cx,cz,cy,th,kap,limL,limR,pl,pr,wallL,wallR}[k]; phys[k]=put(a,F); });
  const segs=new Float32Array([X0+1,Z0+1,X0+1.01,Z0+1]), styp=new Uint8Array([0]); phys.segs=put(segs,F); phys.nseg=1; align(4); phys.styp=off; items.push([off,styp]); off+=4;
  const nh=31, hrel=new Int16Array(N*nh); align(4); phys.hrel=off; items.push([off,hrel]); off+=hrel.byteLength;
  Object.values(bins).forEach(b=>{ const p={g:b.g,nv:b.pos.length/3,ni:b.idx.length,t:b.t,o:{}}; p.o.p=put(b.pos,F); if(b.pos.length/3>65000) throw new Error('part trop grande'); align(2); p.o.i=off; items.push([off,new Uint16Array(b.idx)]); off+=b.idx.length*2; if(b.col.length) p.o.c=(()=>{ const a=new Uint8Array(b.col); align(4); const o=off; items.push([o,a]); off+=a.length; return o; })(); if(b.uv.length) p.o.u=put(b.uv,F); parts.push(p); });
  const tmeta=Object.values(tl).map(q=>({t:q.t,n:q.a.length/4,o:put(q.a,F)}));
  const buf=new ArrayBuffer((off+7)&~7); items.forEach(([o,a])=>{ new Uint8Array(buf,o,a.byteLength).set(new Uint8Array(a.buffer,a.byteOffset,a.byteLength)); });
  const meta={N,DS,L,X0,Z0,CELL:1,GW,GH,dh0:-60,dhs:4,nh,phys,parts,trees:tmeta,tile,TX0,TZ0};
  return {meta,buf,N,DS,L,cx:new F(buf,phys.cx,N),cz:new F(buf,phys.cz,N),cy:new F(buf,phys.cy,N),th:new F(buf,phys.th,N),kap:new F(buf,phys.kap,N),limL:new F(buf,phys.limL,N),limR:new F(buf,phys.limR,N),pl:new F(buf,phys.pl,N),pr:new F(buf,phys.pr,N),wallL:new F(buf,phys.wallL,N),wallR:new F(buf,phys.wallR,N),nseg:1,segs:new F(buf,phys.segs,4),styp:new Uint8Array(buf,phys.styp,1),hrel:new Int16Array(buf,phys.hrel,N*nh),nh,dh0:-60,dhs:4,X0,Z0,GW,GH,grid};
}
/* branchement : les manches qui demandent un circuit « cX » / « fX » chargent leur tracé, sinon Spa */
let SPA0=null; const NTD={};
function trkUse(id){ try{ if(!SPA0&&TRK.ready) SPA0=Object.assign({},TRK); if(NTRK[id]){ const td=NTD[id]||(NTD[id]=trkGen(NTRK[id])); Object.assign(TRK,td); const st=SPA_STAGES.find(s=>s.id===id); if(st) st.b=td.L; TRK.cur=id; buildSegGrid(); return true; } if(SPA0&&TRK.cur){ Object.assign(TRK,SPA0); TRK.cur=null; buildSegGrid(); } }catch(e){ console.error('circuit',e); try{ if(SPA0){ Object.assign(TRK,SPA0); TRK.cur=null; buildSegGrid(); } }catch(_){} return false; } return false; }
Object.keys(NTRK).forEach(id=>{ if(!SPA_STAGES.some(s=>s.id===id)) SPA_STAGES.push({id,nom:NTRK[id].nom,a:0,b:2000}); });
const _ss46=startSpa; startSpa=function(i){ const mn=R&&R.ev&&R.ev.manches[i]; const id=mn&&mn.sp; const ok=trkUse(id); if(id&&NTRK[id]&&!ok){ mn.sp='s1'; trkUse('s1'); }
  try{ return _ss46.apply(this,arguments); }catch(e){ console.error('startSpa',e); if(mn&&NTRK[mn.sp]){ mn.sp='s1'; trkUse('s1'); return _ss46.apply(this,arguments); } throw e; } };
/* épreuves */
(()=>{ const add=[
 {id:'c1',nom:'Circuit des Docks',lvl:2,gain:1300,xp:55,di:2,opp:{t:[1,1],up:0,etat:[35,60]},manches:[{d:'circuit',m:'sec',sp:'c1'}]},
 {id:'c2',nom:'Boucle du Lac',lvl:4,gain:2800,xp:110,di:4,opp:{t:[1,2],up:1,etat:[55,85]},manches:[{d:'circuit',m:'sec',sp:'c2'},{d:'circuit',m:'pluie',sp:'c1'}]},
 {id:'c3',nom:'Zone Industrielle',lvl:6,gain:6500,xp:210,di:6,opp:{t:[2,3],up:1,etat:[70,100]},manches:[{d:'circuit',m:'pluie',sp:'c3'}]},
 {id:'c4',nom:'La Corniche',lvl:8,gain:13000,xp:340,di:8,opp:{t:[3,4],up:2,etat:[80,100]},manches:[{d:'circuit',m:'sec',sp:'c4'},{d:'circuit',m:'sec',sp:'c3'}]},
 {id:'c5',nom:'Grand Anneau Néon',lvl:10,gain:26000,xp:520,di:10,opp:{t:[4,5],up:2,etat:[90,100]},manches:[{d:'circuit',m:'sec',sp:'c5'},{d:'circuit',m:'pluie',sp:'c4'}]},
 {id:'f1',nom:'Drift : Parking Cargo',lvl:3,gain:1600,xp:65,di:3,opp:{t:[1,2],up:0,etat:[45,70]},manches:[{d:'drift',m:'sec',sp:'f1'}]},
 {id:'f2',nom:'Drift : Spirale du Col',lvl:7,gain:7500,xp:230,di:7,opp:{t:[3,4],up:2,etat:[80,100]},manches:[{d:'drift',m:'sec',sp:'f2'},{d:'drift',m:'pluie',sp:'f1'}]},
 {id:'f3',nom:'Drift : Arène Néon',lvl:11,gain:22000,xp:450,di:11,opp:{t:[5,6],up:3,etat:[95,100]},manches:[{d:'drift',m:'sec',sp:'f3'},{d:'drift',m:'sec',sp:'f2'}]}];
 add.forEach(e=>{ if(!EVENTS.some(x=>x.id===e.id)) EVENTS.push(e); }); })();
/* ---- v1.1 : navigation à 5 onglets, labo en page, croisement guidé, tout planter, fusion en masse, paquets ciblés, tri des épreuves, drag arcade ---- */

/* 1. barre du bas : Garage, Épreuves, Atelier, Marché, Missions (Cartes dans Marché ; Labo, Base, Équipe dans Atelier) */
(()=>{ TABS.length=0; [['garage', '🚗', 'Garage'],['epreuves', '🏁', 'Épreuves'],['atelier', '🛠️', 'Atelier'],['marche', '🛒', 'Marché'],['missions', '📜', 'Missions']].forEach(t=>TABS.push(t)); })();
const GRP_AT=['atelier','equipe','base'], GRP_MK=['marche','cartes'];
const labOpen47=()=>!!(sheet&&sheet.t==='ranch');
function swHTML(k,lab){
  const L=(typeof labLv==='function'?labLv():0)>=LAB_LVL;
  const b=(a,id,t,on)=>'<button data-a="'+a+'"'+(id?' data-id="'+id+'"':'')+(on?' aria-current="true"':'')+'>'+t+'</button>';
  if(k==='at') return '<div class="subtabs topsw">'+b('tab','atelier','🔨 Fabrication',view==='atelier'&&!lab)+b('tab','equipe','👥 Équipe',view==='equipe'&&!lab)+(S.age18===true?b('labopen',null,L?'🌿 Labo':'🔒 Labo',!!lab):'')+b('tab','base','🏗️ Base',view==='base'&&!lab)+'</div>';
  return '<div class="subtabs topsw">'+b('tab','marche','🛒 Boutique',view==='marche')+b('tab','cartes','🃏 Cartes',view==='cartes')+'</div>'; }
function labPage47(){
  const on=labOpen47()&&!document.body.classList.contains('hubmode'); document.body.classList.toggle('labpage',on);
  if(on){ const m=document.querySelector('main'), n=document.getElementById('nav'); if(m&&n){ const r=document.documentElement.style; r.setProperty('--topb',Math.round(m.getBoundingClientRect().top)+'px'); r.setProperty('--navb',Math.round(innerHeight-n.getBoundingClientRect().top)+'px'); } } }
function canCross47(){ try{ const F=farm(); const ks=STR.filter(s=>(F.seeds[s.id]||0)>0); return {n:ks.length,tot:ks.reduce((a,s)=>a+F.seeds[s.id],0),can:ks.length>=2||ks.reduce((a,s)=>a+F.seeds[s.id],0)>=2}; }catch(e){ return {n:0,tot:0,can:false}; } }
function emptySlots47(){ try{ const F=farm(), R=F.rooms[RY.tab]; return R?R.slots.map((s,i)=>s?-1:i).filter(i=>i>=0):[]; }catch(e){ return []; } }
function decorLab47(){
  const el=document.getElementById('sheet'); if(!el) return;
  if(!labOpen47()){ el.querySelectorAll('.topsw,.labtools').forEach(e=>e.remove()); return; }
  const grow=(RY.tab==='atelier'||RY.tab==='ranch')&&RY.slot==null, em=grow?emptySlots47().length:0;
  const key=(em>0?'p':'-')+(grow?'g':'-');
  let t=el.querySelector('.labtools');
  if(t&&t.dataset.k!==key){ t.remove(); t=null; el.querySelectorAll('.topsw').forEach(e=>e.remove()); }
  if(!el.querySelector('.topsw')) el.insertAdjacentHTML('afterbegin',swHTML('at',true)+'<div class="labtools" data-k="'+key+'"><button class="btn alt sm" data-a="crossopen">🧬 Croiser</button><button class="btn alt sm" data-a="strainopen">📖 Variétés</button>'+(em>0?'<button class="btn alt sm" data-a="rplantopen">🌱 Tout planter</button>':'')+'</div>'); }
function decorCross47(){
  if(!(sheet&&sheet.t==='cross')) return; const el=document.getElementById('sheet'); if(!el||el.querySelector('.crhow')) return;
  const c=canCross47(), n=el.querySelector('.note'); if(!n) return;
  n.insertAdjacentHTML('afterend','<div class="crhow"><b>Comment croiser ?</b><ol><li class="'+(c.can?'ok':'')+'">Aie des graines : 1 de deux variétés différentes (ou 2 de la même). Tu en as <b>'+c.tot+'</b>.</li><li>Choisis le <b>Parent A</b> et le <b>Parent B</b> ci-dessous.</li><li>Appuie sur <b>Croiser</b> (600 cr) : tu reçois 2 graines d’un hybride inédit, à planter dans le labo.</li></ol>'+(c.can?'':'<button class="btn wide" data-a="crossshop">🛒 Acheter des graines à la boutique du labo</button>')+'</div>'); }
function decor47(){ try{
  const nav=document.getElementById('nav');
  if(nav){ let g=view; if(GRP_AT.includes(view)||labOpen47()) g='atelier'; else if(GRP_MK.includes(view)) g='marche'; else if(view==='prep'||view==='result'||view==='race') g='epreuves';
    nav.querySelectorAll('button').forEach(b=>{ if(b.dataset.id===g) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); }); }
  const v=document.getElementById('view');
  if(v){ v.querySelectorAll('.topsw').forEach(e=>e.remove()); const h=GRP_AT.includes(view)?swHTML('at',false):GRP_MK.includes(view)?swHTML('mk',false):''; if(h) v.insertAdjacentHTML('afterbegin',h); }
  decorLab47(); decorCross47(); decorFus47(); decorEq47(); labPage47(); if(view==='cartes'&&typeof pkFit==='function') pkFit(); }catch(e){ console.error('decor47',e); } }
const _rn47=render; render=function(){ const r=_rn47.apply(this,arguments); decor47(); return r; };
const _rsh47=renderSheet; renderSheet=function(){ const r=_rsh47.apply(this,arguments); try{ decorLab47(); decorCross47(); decorEq47(); labPage47(); }catch(e){ console.error('decor47s',e); } return r; };
setInterval(()=>{ try{ if(labOpen47()){ decorLab47(); labPage47(); } else if(document.body.classList.contains('labpage')) labPage47(); }catch(e){} },1000);
window.addEventListener('resize',()=>{ try{ labPage47(); }catch(e){} });
const _closeSheet47=closeSheet; closeSheet=function(){ const r=_closeSheet47.apply(this,arguments); try{ document.body.classList.remove('labpage'); }catch(e){} return r; };
const _tab47=ACT.tab;
ACT.tab=function(d){ const id=d&&d.id;
  if(id==='cross'){ ACT.crossopen(); return; }
  if(id==='crossshop'){ ACT.crossshop(); return; }
  if(labOpen47()&&id!=='labo'&&id!=='labstock'&&id!=='labnet'){ try{ closeSheet(); }catch(e){} }
  return _tab47.apply(this,arguments); };

/* 2. croisement : plus clair, et accessible depuis le labo */
ACT.crossshop=function(){ try{ ACT.labopen(); }catch(e){} if(!labOpen47()) return; RY.tab='shop'; RY.shop='seeds'; RY.slot=null; renderSheet(); try{ toast('Achète 1 graine de 2 variétés, puis reviens sur 🧬 Croiser'); }catch(e){} };
const _gn47=goalNext; goalNext=function(){ const r=_gn47.apply(this,arguments);
  if(r&&/^Croise deux/.test(r[1])){ const c=canCross47(); return c.can?['🧬','Croise 2 variétés : ouvre le croisement, choisis 2 parents puis touche « Croiser »','cross','Croiser ›']:['🧬','Pour croiser, il te faut des graines de 2 variétés : achète-les à la boutique du labo','crossshop','Boutique ›']; }
  return r; };

/* 3. labo : tout planter d'un coup */
const _rsv47=rSlotView;
rSlotView=function(room,i){ let h=_rsv47.apply(this,arguments);
  try{ const F=farm(), R=F.rooms[room], P=RY.pick||{}; if(!R||R.slots[i]||!/data-a="rplant"/.test(h)) return h;
    const em=R.slots.filter(s=>!s).length, seeds=P.sid?(F.seeds[P.sid]||0):0, mp=P.med&&MED[P.med]?MED[P.med].px:0, byCr=mp>0?Math.floor(S.cr/mp):99, n=Math.min(em,seeds,byCr);
    if(em<2) return h;
    const btn='<button class="btn wide alt" style="margin-top:8px" data-a="rplantall" '+((P.sid&&P.med&&(ROOMS[room].out||P.lamp))?'':'disabled')+'>🌱 Planter tous les pots vides'+(P.sid&&P.med?' ('+n+' sur '+em+')':' ('+em+')')+'</button>';
    return h.replace(/(<button class="btn wide" data-a="rplant"[^>]*>[^<]*<\/button>)/,'$1'+btn); }catch(e){ return h; } };
ACT.rplantopen=function(){ const em=emptySlots47(); if(!em.length) return toast('Aucun pot vide'); const F=farm(); if(!STR.some(s=>(F.seeds[s.id]||0)>0)) return toast('Tu n’as aucune graine : achète-en à la boutique'); ACT.rslot({id:String(em[0])}); try{ toast('Choisis variété, substrat et lampe, puis « Planter tous les pots vides »'); }catch(e){} };
ACT.rplantall=function(){
  const F=farm(), room=RY.tab, R=F.rooms[room]; if(!R) return; const P=Object.assign({},RY.pick||{});
  if(!P.sid||!P.med) return toast('Choisis d’abord une variété et un substrat');
  const idx=R.slots.map((s,i)=>s?-1:i).filter(i=>i>=0); let n=0, why='';
  for(const i of idx){
    if((F.seeds[P.sid]||0)<1){ why='plus de graines'; break; }
    const mp=MED[P.med].px; if(S.cr<mp){ why='pas assez de crédits'; break; }
    if(!ROOMS[room].out&&(F.lamps[P.lamp]||0)<1){ why='pas de lampe'; break; }
    RY.pick=Object.assign({},P); ACT.rplant({id:String(i)});
    if(!R.slots[i]){ why='substrat ou parcelle verrouillé(e)'; break; }
    n++; }
  RY.pick=null; RY.slot=null; try{ save(); }catch(e){} renderSheet();
  toast(n?(n+' pot'+(n>1?'s':'')+' planté'+(n>1?'s':'')+(idx.length>n?' · '+(idx.length-n)+' vide'+(idx.length-n>1?'s':'')+' ('+why+')':'')):('Rien planté : '+why)); };

/* 4. atelier : fusion en masse par rareté */
function fusPlan47(){ const free=atFree(); return RAR.slice(0,6).map((x,r)=>({r,n:free.filter(m=>m.r===r).length,k:Math.floor(free.filter(m=>m.r===r).length/5)})); }
function decorFus47(){
  if(view!=='atelier'||AT.tab!=='fus') return; const v=document.getElementById('view'); if(!v||v.querySelector('.fusall')) return;
  const plan=fusPlan47(), tot=plan.reduce((a,p)=>a+p.k,0), rows=v.querySelectorAll('.x-row.fu');
  rows.forEach((row,i)=>{ const p=plan[i]; if(!p||p.k<2) return; const b=row.querySelector('[data-a="fuse"]'); if(b) b.insertAdjacentHTML('afterend','<button class="btn sm alt" data-a="fuseall" data-id="'+p.r+'">Tout ×'+p.k+'</button>'); });
  const note=v.querySelector('.note'); const html='<button class="btn wide fusall" data-a="fuseall" data-id="all" '+(tot?'':'disabled')+'>✨ Tout fusionner'+(tot?' ('+tot+' fusion'+(tot>1?'s':'')+', '+plan.reduce((a,p)=>a+p.k*5,0)+' modules)':'')+'</button>';
  if(note) note.insertAdjacentHTML('beforebegin',html); else v.insertAdjacentHTML('beforeend',html); }
ACT.fuseall=function(d){
  const rs=d.id==='all'?[0,1,2,3,4,5]:[+d.id], made=[]; let used=0, per=[];
  for(const r of rs){ if(!(r>=0&&r<6)) continue; const pool=atFree().filter(m=>m.r===r&&!made.includes(m)).sort((a,b)=>a.q-b.q), k=Math.floor(pool.length/5); if(!k) continue;
    const take=pool.slice(0,k*5); S.mods=S.mods.filter(m=>!take.includes(m)); for(let j=0;j<k;j++){ const m=newMod(r+1,null,true); S.mods.push(m); made.push(m); } used+=k*5; per.push(k+' '+RAR[r+1].n); }
  if(!made.length) return toast('Pas assez de modules libres (5 de même rareté)');
  try{ bump('fuseN',made.length); }catch(e){} save(); render();
  toast(used+' modules fusionnés → '+per.join(', ')); openSheet({t:'open',cards:made.map(m=>m.u),i:0,pk:'p1'}); };

/* 5. paquets ciblés : de vrais paquets de cartes, rangés par rôle */
const FORD47=['f1','f2','f3','f4','f6','f5'];
const _pk47=packsHTML;
packsHTML=function(){ const h=_pk47.apply(this,arguments).replace('<p class="note" style="margin-top:0">Tous les emplacements, tu prends ce qui tombe.</p>',''); const i=h.lastIndexOf('<div class="fpks">'); if(i<0) return h;
  const list=FORD47.map(id=>FPACKS.find(p=>p.id===id)).filter(Boolean).concat(FPACKS.filter(p=>!FORD47.includes(p.id)));
  const cells=list.map(p=>{ const okC=S.cr>=p.cr, okT=S.tok>=p.tok, ic=(p.slots||[]).map(s=>{ const x=SLOTS.find(q=>q[0]===s); return x?'<i title="'+x[1]+'">'+x[2]+'</i>':''; }).join('');
    return '<div class="fcell">'+pack3d(p,-1).replace('class="pk"','class="pk st"')+'<div class="fsl">'+ic+'</div><small class="fd">'+p.d.replace(/^4 modules de /,'')+'</small><div class="fbt"><button class="btn sm" data-a="pack" data-id="'+p.id+'" data-k="cr" '+(okC?'':'disabled')+'>💰 '+fmt(p.cr)+'</button><button class="btn alt sm" data-a="pack" data-id="'+p.id+'" data-k="tok" '+(okT?'':'disabled')+'>🎟 '+p.tok+'</button></div></div>'; }).join('');
  return h.slice(0,i)+'<div class="fgrid">'+cells+'</div>'; };

/* 6. équiper les meilleures pièces : listes en 2 colonnes */
function decorEq47(){ try{ if(!sheet||(sheet.t!=='eqcar'&&sheet.t!=='eqmod')) return; const el=document.getElementById('sheet'); if(!el||el.querySelector('.eqg')) return;
  const rows=[...el.querySelectorAll(':scope>button.row')]; if(!rows.length) return; const g=document.createElement('div'); g.className='eqg'; rows[0].before(g); rows.forEach(r=>g.appendChild(r)); }catch(e){} }

/* 7. épreuves : tri par niveau puis par gain (sans toucher à l'ordre interne, qui sert à la difficulté) */
const _vEp47=vEpreuves;
vEpreuves=function(){ const f=EVENTS.filter; EVENTS.filter=function(fn){ return f.call(this,fn).sort((a,b)=>(a.lvl-b.lvl)||(a.gain-b.gain)); };
  try{ return _vEp47.apply(this,arguments); } finally{ delete EVENTS.filter; } };

/* 8. drag arcade (boules de boost) : un seul adversaire, couloirs cohérents, pas de changement de voie sur une voiture */
const _sm47=startManche;
startManche=function(i){ try{ const mn=R&&R.ev&&R.ev.manches[i]; if(mn&&mn.bon&&R.opps&&R.opps[i]&&R.opps[i].length>1){ R.opps[i]=R.opps[i].slice().sort((a,b)=>indice(b,mn)-indice(a,mn)).slice(0,1); } }catch(e){ console.error(e); }
  return _sm47.apply(this,arguments); };
const _ln47=ACT.lane;
ACT.lane=function(){ if(!RC||!RC.dbon||RC.done) return;
  if(RC.clock<0){ try{ flash('Attends le feu vert','#FF4D6D',.7); }catch(e){} return; }
  const P=RC.P, tl=-RC.laneT;
  const busy=RC.Os.some(o=>o.fin==null&&Math.abs(o.lane-tl)<1.7&&Math.abs(o.x-P.x)<7+Math.abs((o.v||0)-(P.v||0))*.5);
  if(busy){ try{ flash('Voie occupée','#FF4D6D',.7); navigator.vibrate&&navigator.vibrate(20); }catch(e){} return; }
  return _ln47.apply(this,arguments); };

/* 9. pastille du labo : sur l'onglet Atelier (Base et Labo n'ont plus de bouton dans la barre) */
function labAlert(){ try{ const s=labStat(); const nav=document.getElementById('nav'); if(!nav) return; const b=nav.querySelector('button[data-id="atelier"]'); if(!b) return; let d=b.querySelector('.dot.lab'); const need=s&&(s.ready||s.thirst||s.sick);
  if(need&&!d){ b.insertAdjacentHTML('beforeend','<i class="dot lab"></i>'); } else if(!need&&d) d.remove(); }catch(_){} }
/* ===== v1.2 : paquets en carrousel unique + paquet Voiture + achat x1/x5/x10 ; missions clandestines ; contenu masqué aux mineurs ===== */
/* ---- 1. un seul carrousel : aléatoires, ciblés, voiture ---- */
delete PACKS.find; delete PACKS.findIndex;
Object.assign(PKT,{pcar:{c1:'#ffe27a',c2:'#c98a10',c3:'#2b1d00',emb:'🏎️',tag:'VOITURE'}});
['f1','f2','f3','f4','f6','f5'].forEach(id=>{ const p=FPACKS.find(x=>x.id===id); if(p&&!PACKS.some(x=>x.id===id)) PACKS.push(p); });
if(!PACKS.some(p=>p.id==='pcar')) PACKS.push({id:'pcar',nom:'Paquet Voiture',n:0,cr:50000,tok:50,boost:1,min:0,car:1,rand:0,d:'1 voiture au hasard. La meilleure voiture du jeu est possible, mais très, très rare.'});
const pkq=()=>{ const q=+S.pkq; return q===5||q===10?q:1; };
{ const _p3=pack3d; pack3d=function(p,i){ let h=_p3(p,i); if(p&&p.car) h=h.replace(/<div class="sb">0 modules<\/div>/g,'<div class="sb">1 voiture</div>').replace(/<span class="pips">.*?<\/span>/g,'<span class="pips"><i style="background:#ffd24a"></i><i style="background:#ff8a2b"></i><i style="background:#ff2bd6"></i></span>'); return h; };
  const _pa=pkArt; pkArt=function(p){ let h=_pa(p); if(p&&p.car) h=h.replace(/<div class="sb">0 modules<\/div>/g,'<div class="sb">1 voiture</div>').replace(/<span class="pips">.*?<\/span>/g,'<span class="pips"><i style="background:#ffd24a"></i><i style="background:#ff8a2b"></i><i style="background:#ff2bd6"></i></span>'); return h; }; }
packsHTML=function(){
  const ix=id=>Math.max(0,PACKS.findIndex(p=>p.id===id));
  const chips=[['rand','🎲 Aléatoires',ix('p1')],['fix','🎯 Ciblés',ix('f1')],['car','🚗 Voiture',ix('pcar')]].map(c=>`<button data-a="pkcat" data-id="${c[2]}" data-c="${c[0]}">${c[1]}</button>`).join('');
  return `<div class="pkcat" id="pkcat">${chips}</div><div class="pk3" id="pk3"><button class="pknav l" data-a="pkgo" data-id="-1" aria-label="Précédent">‹</button><div class="ring" id="pkring">${PACKS.map(pack3d).join('')}</div><div class="fl"></div><button class="pknav r" data-a="pkgo" data-id="1" aria-label="Suivant">›</button></div>
    <div class="dots" id="pkdots">${PACKS.map(()=>'<i></i>').join('')}</div><div class="pkInfo" id="pkInfo"></div>`;
};
ACT.pkcat=d=>{ PK.tgt=clamp(+d.id,0,PACKS.length-1); PK.arm=null; PK.shown=-1; try{ pkInfo(true); }catch(e){} };
ACT.pkq=d=>{ S.pkq=+d.id; try{ save(); }catch(e){} PK.shown=-1; PK.arm=null; try{ pkInfo(true); }catch(e){} };
function decorPk48(){
  const el=$('pkInfo'); if(!el||PK.arm) return; const i=clamp(Math.round(PK.drag?PK.pos:PK.tgt),0,PACKS.length-1), p=PACKS[i]; if(!p) return;
  const cat=document.getElementById('pkcat'); if(cat){ const ci=PACKS.findIndex(x=>x.slots), cj=PACKS.findIndex(x=>x.id==='pcar'); const cur=i>=cj?'car':i>=ci?'fix':'rand'; [...cat.children].forEach(b=>b.classList.toggle('on',b.dataset.c===cur)); }
  if(el.querySelector('.pkq')) return; const buy=el.querySelector('.buy'); if(!buy) return; const q=pkq();
  const row=document.createElement('div'); row.className='pkq'; row.innerHTML='<span>Quantité</span>'+[1,5,10].map(n=>`<button data-a="pkq" data-id="${n}" class="${n===q?'on':''}">×${n}</button>`).join(''); buy.parentNode.insertBefore(row,buy);
  const bc=buy.querySelector('button[data-k="cr"]'), bt=buy.querySelector('button[data-k="tok"]'), tc=p.cr*q, tt=p.tok*q;
  if(bc){ bc.dataset.q=q; bc.dataset.d38=1; bc.disabled=S.cr<tc; bc.innerHTML=(q>1?'Acheter ×'+q:'Déchirer')+' · 💰 '+fmt(tc); }
  if(bt){ if(!p.tok) bt.remove(); else{ bt.dataset.q=q; bt.dataset.d38=1; bt.disabled=S.tok<tt; bt.innerHTML='🎟 '+tt; } }
  const t=el.querySelector('.t span'); if(t&&p.car) t.textContent='1 voiture';
  const hint=el.querySelector('.note.sm'); if(hint&&q>1) hint.textContent='Achat groupé : les '+q+' paquets s’ouvrent d’un coup, sans déchirer.';
}
{ const _pki=pkInfo; pkInfo=function(force){ _pki.apply(this,arguments); try{ decorPk48(); }catch(e){ console.error(e); } }; }
/* choix du paiement (tap sur le paquet) : tient compte de la quantité */
function payChoice(id){ const p=PACKS.find(x=>x.id===id); if(!p||document.getElementById('pkpay')) return; const q=pkq(), tc=p.cr*q, tt=p.tok*q;
  const d=document.createElement('div'); d.id='pkpay'; const okC=S.cr>=tc, okT=p.tok&&S.tok>=tt;
  d.innerHTML='<div class="upd-c"><small>OUVRIR'+(q>1?' ×'+q:'')+'</small><h2>'+p.nom+'</h2><p class="tx-p">Tu as <b>'+fmt(S.cr)+' cr</b>'+(p.tok?' et <b>'+S.tok+' jeton'+(S.tok>1?'s':'')+'</b>':'')+'.</p>'+
   '<div class="tx-b"><button class="btn'+(okC?'':' alt')+'" id="ppC" '+(okC?'':'disabled')+'>💰 '+fmt(tc)+' cr</button>'+(p.tok?'<button class="btn'+(okT?'':' alt')+'" id="ppT" '+(okT?'':'disabled')+'>🎟 '+tt+' jeton'+(tt>1?'s':'')+'</button>':'')+'</div><button class="btn alt wide" id="ppX" style="margin-top:8px">Annuler</button></div>';
  document.body.appendChild(d); const go=k=>{ d.remove(); ACT.pack({id,k,q,explicit:1}); };
  d.querySelector('#ppC').onclick=()=>go('cr'); const T=d.querySelector('#ppT'); if(T) T.onclick=()=>go('tok'); d.querySelector('#ppX').onclick=()=>d.remove(); }
/* voiture : probabilités par tier (les 2 meilleures voitures ≈ 0,4 % chacune) */
const CPW={1:30,2:28,3:22,4:12,5:7.2,6:.8};
function carRoll(){ const w=CARS.map(c=>(CPW[c.t]||1)/CARS.filter(x=>x.t===c.t).length), tot=w.reduce((a,b)=>a+b,0); let x=Math.random()*tot; for(let i=0;i<CARS.length;i++){ x-=w[i]; if(x<0) return CARS[i]; } return CARS[0]; }
function openCarPack(k,q){
  const p=PACKS.find(x=>x.id==='pcar'), tk=k==='tok', tot=(tk?p.tok:p.cr)*q; if((tk?S.tok:S.cr)<tot) return toast(tk?'Pas assez de jetons':'Pas assez de crédits'); if(tk) S.tok-=tot; else S.cr-=tot;
  const got=[]; for(let j=0;j<q;j++){ const m=carRoll(), c={uid:S.nuid++,mid:m.id,etat:100,xp:0,lvl:1,up:{},inv:0,mods:{},sh:Math.random()<.06?1:0}; S.cars.push(c); got.push(c.uid); }
  S.stats.carpack=(S.stats.carpack||0)+q; S.stats.packs=(S.stats.packs||0)+q; save(); render(); openSheet({t:'carpack',cars:got,rev:0,q,k:tk?'tok':'cr'});
}
function packMulti(id,k,q){
  const p=PACKS.find(x=>x.id===id); if(!p||document.getElementById('pkov')) return;
  const tot=k==='tok'?p.tok*q:p.cr*q; if(k==='tok'?(!p.tok||S.tok<tot):S.cr<tot) return toast('Pas assez pour ×'+q);
  if(p.car) return openCarPack(k,q);
  if(S.mods.length+p.n*q>invMax()) return toast('Inventaire plein : il faut de la place pour '+(p.n*q)+' modules');
  if(sheet) closeSheet(); if(k==='tok') S.tok-=tot; else S.cr-=tot;
  const got=[]; let carUid=null; PKF.slots=p.slots||null;
  try{ for(let j=0;j<q;j++){ for(let i=0;i<p.n;i++){ const m=newMod(rollRar(p.boost,i===p.n-1?p.min:0)); S.mods.push(m); got.push(m.u); }
      if(Math.random()<(CAR_P[id]||.0005)*(1+.1*pk('luck'))){ const m=carPrize(), c={uid:S.nuid++,mid:m.id,etat:100,xp:0,lvl:1,up:{},inv:0,mods:{},sh:Math.random()<.06?1:0}; S.cars.push(c); S.stats.carpack=(S.stats.carpack||0)+1; if(!carUid) carUid=c.uid; } } }
  finally{ PKF.slots=null; }
  S.stats.packs=(S.stats.packs||0)+q; save(); render(); openSheet({t:'open',cards:got,i:0,pk:id,car:carUid,q}); ACT.revealall();
}
{ const _pk=ACT.pack; ACT.pack=function(d){ const q=+(d&&d.q)||1; if(d&&d.id&&q>1) return packMulti(d.id,d.k||'cr',q); return _pk.apply(this,arguments); }; }
{ const _op=openPack; openPack=function(id,cur){ if(id==='pcar') return openCarPack(cur,1); return _op.apply(this,arguments); }; }
/* fiche de résultat du paquet Voiture */
{ const _sx=sheetExtra; sheetExtra=function(X){
  if(sheet&&sheet.t==='carpack'){ const cs=sheet.cars.map(u=>car(u)).filter(Boolean), el=$('sheet');
    const best=cs.slice().sort((a,b)=>M[b.mid].t-M[a.mid].t||M[b.mid].val-M[a.mid].val)[0], bm=best&&M[best.mid];
    if(!sheet.rev){ el.innerHTML=`${X}<h2>Paquet Voiture${sheet.q>1?' ×'+sheet.q:''}</h2><div class="cpback"><span>🏎️</span><b>${sheet.q>1?sheet.q+' voitures':'1 voiture'}</b><small>Touche pour révéler</small></div><button class="btn wide" data-a="cpreveal">🎁 Révéler</button>`; return true; }
    const top=bm&&bm.t>=5;
    el.innerHTML=`${X}<h2>Paquet Voiture${sheet.q>1?' ×'+sheet.q:''}</h2>
      <div class="carwin ${top?'':'calm'}">${top?'<div class="cw-rays"></div><div class="cw-t">JACKPOT !</div>':''}<div class="cw-car" style="--t:${TIERS[bm.t].c}">${carSVG(bm,100)}</div><div class="cw-n">${bm.nom}${best.sh?' ✨ brillante':''}</div><p class="note">${bm.an} · ${bm.cat} · ${TIERS[bm.t].n}. Elle est dans ton garage.</p></div>
      ${cs.length>1?`<h3 class="rh">Toutes les voitures</h3><div class="grid">${cs.slice().sort((a,b)=>M[b.mid].t-M[a.mid].t).map(c=>cardHTML({mid:c.mid,etat:100,lvl:1,up:{}},{tag:'div'})).join('')}</div>`:''}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="close">Fermer</button><button class="btn" data-a="pack" data-id="pcar" data-k="${sheet.k==='tok'?'tok':'cr'}" ${(sheet.k==='tok'?S.tok<50:S.cr<50000)?'disabled':''}>Encore un · ${sheet.k==='tok'?'🎟 50':cr(50000)}</button></div>`;
    return true; }
  return _sx.apply(this,arguments); }; }
ACT.cpreveal=()=>{ if(sheet&&sheet.t==='carpack'){ sheet.rev=1; try{ auTry(()=>auRip(0)); }catch(e){} renderSheet(); } };
{ const _rs=renderSheet; renderSheet=function(){ const r=_rs.apply(this,arguments); try{ if(sheet&&sheet.t==='open'&&sheet.q>1){ const h=$('sheet').querySelector('h2'); if(h&&!h.dataset.q){ h.dataset.q=1; h.textContent+=' ×'+sheet.q; } } }catch(e){} return r; }; }

/* ---- 2. mineurs : l'illégal est masqué ; adultes : missions clandestines ---- */
const isAdult=()=>S&&S.age18===true;
const illOK=()=>{ try{ return labLv()>=LAB_LVL; }catch(e){ return false; } };
{ const _u=unlFor; unlFor=function(l){ let o=_u.apply(this,arguments); if(!isAdult()) o=o.filter(x=>!/Labo clandestin|Ranch/.test(x[1])); return o; }; }
function syncAge48(){ try{ const a=LINES[0][2]; a.length=0; (isAdult()?['garage','atelier','ranch']:['garage']).forEach(x=>a.push(x)); }catch(e){} }
{ const _r=render; render=function(){ syncAge48(); return _r.apply(this,arguments); }; }
{ const _cs=closeSheet; closeSheet=function(){ if(sheet&&sheet.t==='age'&&sheet.st===2&&S.age18==null) return; return _cs.apply(this,arguments); }; }
const FS48=()=>{ const F=S.farm; return (F&&F.stats)||{}; };
const hiredIll=()=>{ try{ return team().hired.filter(e=>isIll(e.role)).length; }catch(e){ return 0; } };
const ILM=[
 ['i1','Première récolte : récolte 1 plante',s=>[FS48().harv||0,1],{cr:3000}],
 ['i2','Main verte : récolte 10 plantes',s=>[FS48().harv||0,10],{cr:8000}],
 ['i3','Grosse production : récolte 40 plantes',s=>[FS48().harv||0,40],{cr:25000,tok:3}],
 ['i4','Labo niveau 3',s=>[labL(),3],{cr:10000}],
 ['i5','Labo niveau 6',s=>[labL(),6],{cr:40000,tok:5}],
 ['i6','Premier client : vends 25 g',s=>[Math.floor(FS48().sold||0),25],{cr:4000}],
 ['i7','Revendeur : vends 300 g',s=>[Math.floor(FS48().sold||0),300],{cr:15000}],
 ['i8','Baron local : vends 2 000 g',s=>[Math.floor(FS48().sold||0),2000],{cr:60000,tok:5}],
 ['i9','Première livraison clandestine',s=>[FS48().deliv||0,1],{cr:5000}],
 ['i10','Chauffeur de nuit : 10 livraisons réussies',s=>[FS48().deliv||0,10],{cr:30000,tok:3}],
 ['i11','Réputation de rue : atteins 10 de réputation',s=>[Math.floor((s.farm&&s.farm.rep)||0),10],{cr:6000}],
 ['i12','Un nom qui circule : atteins 40 de réputation',s=>[Math.floor((s.farm&&s.farm.rep)||0),40],{cr:25000}],
 ['i13','Sous pression : survis à une descente de police',s=>[FS48().raids||0,1],{cr:8000}],
 ['i14','Équipe de l’ombre : engage un employé clandestin',s=>[hiredIll(),1],{cr:12000}]
];
ILM.forEach(m=>{ if(MISSIONS.some(x=>x.id===m[0])) return; const g=m[3]; g.xp=rxp(g.cr||(g.tok||0)*300||200); MISSIONS.push({id:m[0],t:m[1],p:s=>illOK()?m[2](s):[0,1],g,ill:1}); MCAT[m[0]]='Clandestin'; });
MISSIONS.forEach(m=>{ if(/^l[1-5]$/.test(m.id)&&!m.ill){ m.ill=1; const f=m.p; m.p=s=>illOK()?f(s):[0,1]; } });
const missVis=m=>!m.ill||illOK();
vMissions=function(){
  questsEnsure();
  const can=S.daily!==dayKey(), dr=dailyReward();
  const qRow=(box,key,L,id)=>{ const q=L.find(x=>x.id===id), a=Math.min(qProg(box,q),q.n), done=a>=q.n, got=box.cl[id], g=qRew(q);
    return `<div class="row ${got?'done locked':''}"><span class="grow"><span class="ttl">${q.t}</span><br><span class="sub">Récompense : ${gText(g)}</span>${got?'':`<div class="prog"><i style="width:${a/q.n*100}%"></i></div>`}</span>
      ${got?'<span class="sub">Terminé</span>':done?`<button class="btn sm good" data-a="qclaim" data-k="${key}" data-id="${id}">Récupérer</button>`:`<span class="num">${fmt(a)} / ${fmt(q.n)}</span>`}</div>`; };
  const mRow=m=>{ const [a,b]=m.p(S), done=a>=b, got=S.claimed[m.id];
    return `<div class="row ${got?'done locked':''}"><span class="grow"><span class="ttl">${m.t}</span><br><span class="sub">Récompense : ${gText(m.g)}</span>
      ${got?'':`<div class="prog"><i style="width:${clamp(a/b*100,0,100)}%"></i></div>`}</span>
      ${got?'<span class="sub">Terminée</span>':done?`<button class="btn sm good" data-a="claim" data-id="${m.id}">Récupérer</button>`:`<span class="num">${fmt(Math.min(a,b))} / ${fmt(b)}</span>`}</div>`; };
  const cats=['Débuts','Course','Cartes','Collection','Économie','Progression'].concat(illOK()?['Légal','Clandestin']:[]);
  const left=MISSIONS.filter(m=>missVis(m)&&!S.claimed[m.id]).length;
  return `<div class="head"><h2>Missions</h2><p>${left} objectif${left>1?'s':''} restant${left>1?'s':''}</p></div>
  <div class="row ${can?'':'locked'}"><span class="ico">🎁</span><span class="grow"><span class="ttl">Récompense du jour</span><br><span class="sub">${cr(dr.cr)} et ${dr.tok} 🎟. Série en cours : ${S.streak||0} jour${(S.streak||0)>1?'s':''}. Un bonus tous les 7 jours.</span></span>${can?`<button class="btn sm good" data-a="daily">Récupérer</button>`:'<span class="sub">Reviens demain</span>'}</div>
  <div class="sec"><h3>Défis du jour</h3>${S.dq.ids.map(id=>qRow(S.dq,'dq',DQ,id)).join('')}</div>
  <div class="sec"><h3>Défis de la semaine</h3>${S.wq.ids.map(id=>qRow(S.wq,'wq',WQ,id)).join('')}</div>
  ${cats.map(ct=>{ const ms=MISSIONS.filter(m=>missVis(m)&&(MCAT[m.id]||'Débuts')===ct).sort((a,b)=>(S.claimed[a.id]?1:0)-(S.claimed[b.id]?1:0)); return ms.length?`<div class="sec"><h3>${ct==='Clandestin'?'🕶️ Clandestin':ct}</h3>${ms.map(mRow).join('')}</div>`:''; }).join('')}`;
};
/* ---- v1.2b : boutons de course. DRIFT remplace le gros NITRO, GAZ agrandi, NITRO réduit ---- */
function pad49(h){
  try{
    if(!RC||(RC.kind!=='spa'&&RC.kind!=='race')||(RC.kind==='race'&&RC.mn&&RC.mn.d==='drag')) return h;
    const spa=RC.kind==='spa', auto=!!RC.auto, a=h.indexOf(spa?'<div class="padS">':'<div class="pad3">'), b=h.indexOf('<div id="over"');
    if(a<0||b<0||b<a) return h;
    let steer=''; if(spa){ const s=h.indexOf('<div id="steerZone"',a), e=h.indexOf('<button id="pBrk"',a); if(s<0||e<0) return h; steer=h.slice(s,e); }
    const pad=`<div class="${spa?'padS':'pad3'} pad49 ${spa?'':'p3'}">${steer}
      <div class="nbk"><button id="pNit" class="pedal nit">Nitro<small>×${S.nitro}</small></button><button id="pBrk" class="pedal brk" ${auto?'disabled':''}><span>${auto?'Auto':'Frein'}</span></button></div>
      <button id="pHnd" class="pedal hnd big" ${auto?'disabled':''}><span>Drift</span><small>frein à main</small></button>
      <button id="pGas" class="pedal gas big" ${auto?'disabled':''}><i id="gasPed"></i><span>${auto?'Auto':'Gaz'}<small>${auto?'':'glisse vers le bas pour doser'}</small></span></button>
    </div>
    `;
    h=h.slice(0,a)+pad+h.slice(b);
    if(!spa&&h.indexOf('id="hDrift"')<0) h=h.replace('<div class="hud-lights"','<div class="hud-drift" id="hDrift"></div><div class="hud-lights"');
    return h;
  }catch(e){ try{console.warn('pad49',e);}catch(_){} return h; }
}
{ const _vr=vRace; vRace=function(){ return pad49(_vr.apply(this,arguments)); }; }
{ const _br=bindRace; bindRace=function(){ _br.apply(this,arguments);
  try{ if(RC&&RC.kind==='race'){ const hd=$('pHnd'); if(hd&&!hd._b49){ hd._b49=1;
    hd.addEventListener('pointerdown',e=>{e.preventDefault(); try{hd.setPointerCapture(e.pointerId);}catch(_){} RC.inp.hand=true; hd.classList.add('on');});
    const hu=()=>{RC.inp.hand=false; hd.classList.remove('on');}; hd.addEventListener('pointerup',hu); hd.addEventListener('pointercancel',hu); hd.addEventListener('contextmenu',e=>e.preventDefault()); } } }catch(e){} }; }

setInterval(updPod,4000);

S=load();
render();
if(!S.intro){S.intro=true; localSave(); const go=()=>{ try{ startCine(()=>openSheet({t:'tuto',i:0})); }catch(e){ openSheet({t:'tuto',i:0}); } }; if(S.age18==null){ window.__afterAge=go; openSheet({t:'age',st:2}); } else go(); }
auInstall(); auSet(S.audio);
cloudInit();
ensureModels();
ensureTrack();
