/* ======================================================================
   v0.11 : récompenses avec XP, audio de course, caméra, IA, pilote
   ====================================================================== */
const rxp=cr=>Math.max(10,Math.round(cr/12/5)*5);
MISSIONS.forEach(m=>{ if(m.g.xp==null) m.g.xp=rxp(m.g.cr||(m.g.tok||0)*300||200); });
/* coupure franche de la musique du menu quand on entre dans une épreuve */
function auCutMenu(){
  if(!AU.ok||!AU.ctx) return; const c=AU.ctx, t=c.currentTime;
  auTry(()=>{ AU.mus.gain.cancelScheduledValues(t); AU.mus.gain.setTargetAtTime(.0001,t,.025); AU.revIn.gain.cancelScheduledValues(t); AU.revIn.gain.setTargetAtTime(.0001,t,.025); });
  setTimeout(()=>{ if(!AU.ok) return; auTry(()=>{ auApplyVol(); AU.revIn.gain.setTargetAtTime(.5,AU.ctx.currentTime,.1); }); },450);
}
MOODS.silent={arp:[],oct:1,wave:'sine',av:0,pv:0,filt:19000,hat:false,pulse:false};

/* ---- IA : dépassements (adversaires et pilote automatique) ---- */
function aiPass(o,all,lane0,room){
  const t=RC.clock, look=10+o.v*.95*(room||1); let bl=null, bd=1e9;
  for(const q of all){ if(q===o||q.fin!=null) continue; const dp=dS(q.s,o.s); if(dp>.5&&dp<look&&Math.abs(q.d-o.d)<2.7&&(q.v<o.v+4||dp<7)&&dp<bd){bd=dp; bl=q;} }
  let ref=bl;
  if(!ref&&o.pRef){ const dp=dS(o.pRef.s,o.s); if(dp>-8&&dp<=.5&&t<o.pUntil) ref=o.pRef; else o.pRef=null; }
  if(!ref) return {lane:lane0,cap:1,brake:false};
  if(bl&&(o.pRef!==bl||t>o.pUntil)){
    const i=o.i, wl=TRK.wallL[i], wr=TRK.wallR[i], rl=wl-2.5-bl.d, rr=wr-2.5+bl.d;
    let side=rl>=rr?1:-1; if(Math.abs(rl-rr)<1.2&&o.pSide) side=o.pSide;
    const busy=s2=>all.some(q=>q!==o&&q!==bl&&q.fin==null&&Math.abs(dS(q.s,o.s))<9&&Math.abs(q.d-(bl.d+s2*3.1))<2.2);
    if(busy(side)&&!busy(-side)&&(side>0?rr:rl)>3.1) side=-side;
    o.pSide=side; o.pRef=bl; o.pUntil=t+2.5;
  }
  const lane=ref.d+(o.pSide||1)*3.1, lat=Math.abs(o.d-ref.d);
  let cap=1, brake=false;
  if(bl&&lat<2.3){ const gap=bd; if(gap<4+o.v*.18){cap=.5; if(o.v>bl.v+1&&gap<3+o.v*.1) brake=true;} else if(gap<7+o.v*.3) cap=.85; }
  return {lane,cap,brake};
}

/* ---- caméra libre en pilotage automatique ---- */
const orbitOn=()=>{ const o=RC&&RC.auto&&RC.orb; return !!(o&&(o.down||Math.abs(o.yaw)>.03||Math.abs(o.pit-.25)>.03)); };
function orbStep(o,dt){ if(o.down){o.idle=0; return;} o.idle+=dt; if(o.idle>3.2){ const k=Math.exp(-dt*2.6); o.yaw*=k; o.pit=.25+(o.pit-.25)*k; } }
function orbitSpa(cam,P,ang,dt){
  const o=RC.orb; orbStep(o,dt); const d=9+Math.min(P.v,90)*.02, rd=Math.cos(o.pit)*d, a=ang+o.yaw;
  cam.position.set(P.x-Math.cos(a)*rd,P.y+Math.max(.7,Math.sin(o.pit)*d+1.4),P.z-Math.sin(a)*rd); cam.lookAt(P.x,P.y+1.2,P.z);
}
function orbitRace(cam,P,Pa,dt){
  const o=RC.orb; orbStep(o,dt); const p=pathAt(Pa,clamp(P.x,-Pa.PRE+4,RC.tk.L+Pa.POST-6),P.lane), d=9+Math.min(P.v,90)*.02, rd=Math.cos(o.pit)*d, a=p.th+o.yaw;
  cam.position.set(p.x-Math.cos(a)*rd,Math.max(.8,Math.sin(o.pit)*d+1.4),p.z-Math.sin(a)*rd); cam.lookAt(p.x,1.1,p.z);
}
function bindOrbit(){
  const el=$('rslot'); if(!el||!RC||!RC.auto) return; RC.orb={yaw:0,pit:.25,down:false,idle:0,x:0,y:0};
  el.style.touchAction='none';
  el.addEventListener('pointerdown',e=>{ const o=RC&&RC.orb; if(!o) return; o.down=true; o.x=e.clientX; o.y=e.clientY; try{el.setPointerCapture(e.pointerId);}catch(_){ } });
  el.addEventListener('pointermove',e=>{ const o=RC&&RC.orb; if(!o||!o.down) return; o.yaw+=(e.clientX-o.x)*.012; o.pit=clamp(o.pit-(e.clientY-o.y)*.006,.03,1.2); o.x=e.clientX; o.y=e.clientY; });
  const up=()=>{ const o=RC&&RC.orb; if(o){o.down=false; o.idle=0;} };
  el.addEventListener('pointerup',up); el.addEventListener('pointercancel',up);
  const w=el.parentNode; if(w&&!w.querySelector('.orbhint')) w.insertAdjacentHTML('beforeend','<div class="orbhint">👆 Glisse sur l’écran pour regarder autour de la voiture</div>');
}

/* ---- rétroviseur (courses manuelles) ---- */
let mirTick=0;
function bindMirror(){
  const el=$('rslot'); if(!el||!RC||RC.auto||S.mirOff) return; const w=el.parentNode; if(!w||w.querySelector('.mir')) return;
  w.insertAdjacentHTML('beforeend','<canvas id="mir" class="mir" data-a="mirtog" aria-label="Rétroviseur"></canvas>');
  GL.post=mirrorPost;
}
function mirrorPost(){
  const cv=$('mir'); if(!cv||!RC||!RS||RC.auto||RC.done||GL.mode!=='race') return; if(mirTick++&1) return;
  const R=GL.r, gc=R.domElement, rr=cv.getBoundingClientRect(), gr=gc.getBoundingClientRect(), cw=Math.round(rr.width), ch=Math.round(rr.height); if(cw<20||ch<8||!gr.width) return;
  const sx=gc.clientWidth/gr.width, x=Math.round((rr.left-gr.left)*sx), top=Math.round((rr.top-gr.top)*sx), y=GL.h-top-ch;
  const mc=RS.mcam||(RS.mcam=new THREE.PerspectiveCamera(52,cw/ch,.3,700)); if(Math.abs(mc.aspect-cw/ch)>.01){mc.aspect=cw/ch; mc.updateProjectionMatrix();}
  const P=RC.P, H=(RS.pc&&RS.pc.H)||1.4;
  if(RC.kind==='spa'){ const c=Math.cos(P.psi), s=Math.sin(P.psi); mc.position.set(P.x-c*.3,P.y+H+.45,P.z-s*.3); mc.lookAt(P.x-c*30,P.y+1.1,P.z-s*30); }
  else { const p=pathAt(RS.path,clamp(P.x,-RS.path.PRE+4,RC.tk.L+RS.path.POST-6),P.lane), c=Math.cos(p.th), s=Math.sin(p.th); mc.position.set(p.x,H+.45,p.z); mc.lookAt(p.x-c*30,1.1,p.z-s*30); }
  const pc=RS.pc; if(pc) pc.g.visible=false;
  R.setScissorTest(true); R.setViewport(x,y,cw,ch); R.setScissor(x,y,cw,ch); R.render(GL.scene,mc); R.setScissorTest(false); R.setViewport(0,0,GL.w,GL.h);
  if(pc) pc.g.visible=true;
  const dpr=R.getPixelRatio(), bw=Math.round(cw*dpr), bh=Math.round(ch*dpr); if(cv.width!==bw||cv.height!==bh){cv.width=bw; cv.height=bh;}
  const ctx=cv.getContext('2d'); ctx.save(); ctx.translate(bw,0); ctx.scale(-1,1);
  try{ ctx.drawImage(gc,x*dpr,top*dpr,bw,bh,0,0,bw,bh); }catch(_){ }
  ctx.restore();
}
ACT.mirtog=function(){ S.mirOff=true; const e=document.querySelector('.mir'); if(e) e.remove(); GL.post=null; toast('Rétroviseur masqué pour cette partie'); };
const _bindRace=bindRace;
bindRace=function(){ _bindRace(); try{ bindOrbit(); bindMirror(); }catch(e){ try{console.warn('bindRace+',e);}catch(_){ } } };
