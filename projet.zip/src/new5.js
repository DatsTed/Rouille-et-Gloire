
/* ======================================================================
   Carte pilote : titre, succès à paliers, arbre de compétences
   ====================================================================== */
const pil=()=>{ if(!S.pil) S.pil={sp:{},bdg:{}}; if(!S.pil.sp) S.pil.sp={}; if(!S.pil.bdg) S.pil.bdg={}; return S.pil; };
const pk=id=>((S.pil&&S.pil.sp)||{})[id]||0;
const sk=(c,id,k)=>(c&&c.uid>0)?1+k*pk(id):1;
const f1=x=>(Math.round(x*10)/10).toString().replace('.',',');
const SKT=[
 {b:'pil',n:'Pilotage',c:'#00e5ff',ic:'🏎️',list:[
  {id:'acc',n:'Départ canon',ic:'🚀',max:5,d:l=>`+${f1(1.5*l)} % d’accélération`},
  {id:'brk',n:'Freinage tardif',ic:'🛑',max:5,d:l=>`+${f1(2*l)} % de freinage`},
  {id:'grip',n:'Sens du grip',ic:'🛞',max:5,d:l=>`+${f1(1.2*l)} % de vitesse en virage`},
  {id:'nit',n:'Maître de la nitro',ic:'⚡',max:5,d:l=>`+${8*l} % de durée, +${4*l} % de poussée`}]},
 {b:'mec',n:'Mécanique',c:'#ff9a3c',ic:'🔧',list:[
  {id:'wear',n:'Conduite souple',ic:'🍃',max:4,d:l=>`−${8*l} % d’usure par course`},
  {id:'rep',n:'Mains en or',ic:'🛠️',max:4,d:l=>`−${7*l} % sur les réparations`},
  {id:'upg',n:'Négociateur d’atelier',ic:'💼',max:4,d:l=>`−${5*l} % sur les améliorations`},
  {id:'rel',n:'Mécano de précision',ic:'⚙️',max:3,d:l=>`−${10*l} % de risque de panne`}]},
 {b:'biz',n:'Business',c:'#3ccf7a',ic:'💰',list:[
  {id:'gain',n:'Sponsors',ic:'🤝',max:5,d:l=>`+${4*l} % de crédits en course`},
  {id:'xp',n:'Mentor',ic:'🎓',max:5,d:l=>`+${6*l} % d’expérience`},
  {id:'dly',n:'Fan club',ic:'📣',max:4,d:l=>`+${8*l} % de récompense quotidienne`},
  {id:'pod',n:'Showroom VIP',ic:'🏛️',max:5,d:l=>`+${6*l} % de revenus des podiums`}]},
 {b:'cha',n:'Chance',c:'#ff2bd6',ic:'🍀',list:[
  {id:'tok',n:'Flair',ic:'🎟',max:5,d:l=>`${6*l} % de chance de jeton bonus par victoire`},
  {id:'shopd',n:'Chineur',ic:'🛒',max:4,d:l=>`−${5*l} % sur les pièces du marché`},
  {id:'scrap',n:'Récupérateur',ic:'♻️',max:4,d:l=>`+${8*l} % de ferraille au recyclage`},
  {id:'luck',n:'Chercheur d’éclats',ic:'✨',max:5,d:l=>`+${10*l} % de chances de module brillant`}]}];
const SKI={}; SKT.forEach(b=>b.list.forEach(s=>{s.b=b; SKI[s.id]=s;}));
const RANKS=[[1,'Apprenti','#9aa3ad'],[3,'Pilote du dimanche','#3ccf7a'],[5,'Compétiteur','#3d8bff'],[8,'Professionnel','#b05cff'],[12,'As du volant','#ffb020'],[16,'Champion','#ff3d6e'],[20,'Légende','#00e5ff']];
const rankOf=()=>RANKS.filter(r=>S.lvl>=r[0]).pop();
const albCount=()=>MODT.reduce((t,T)=>{let b=S.alb[T[0]]||0,c=0; while(b){c+=b&1; b>>=1;} return t+c;},0);
const BDG=[
 {id:'races',n:'Habitué des pistes',ic:'🏁',d:'Dispute des épreuves',t:[5,30,120],v:()=>S.stats.races||0},
 {id:'wins',n:'Vainqueur',ic:'🏆',d:'Gagne des épreuves',t:[3,20,80],v:()=>S.stats.wins||0},
 {id:'wins3',n:'Série parfaite',ic:'🎯',d:'Gagne des épreuves de 3 manches ou plus',t:[1,5,20],v:()=>S.stats.wins3||0},
 {id:'pods',n:'Habitué du podium',ic:'🥇',d:'Monte sur le podium d’une épreuve à 6 voitures',t:[3,15,60],v:()=>S.stats.pods||0},
 {id:'w_drag',n:'Roi du drag',ic:'🚦',d:'Gagne des manches de drag',t:[3,15,50],v:()=>S.stats.w_drag||0},
 {id:'w_circuit',n:'Maître de Spa',ic:'🛣️',d:'Gagne des courses de circuit',t:[3,15,50],v:()=>S.stats.w_circuit||0},
 {id:'w_rallye',n:'Bête des chemins',ic:'🌲',d:'Gagne des manches de rallye',t:[3,12,40],v:()=>S.stats.w_rallye||0},
 {id:'w_drift',n:'Drifteur',ic:'💨',d:'Gagne des manches de drift',t:[3,12,40],v:()=>S.stats.w_drift||0},
 {id:'w_endurance',n:'Infatigable',ic:'⏱️',d:'Gagne des manches d’endurance',t:[2,8,25],v:()=>S.stats.w_endurance||0},
 {id:'w_elegance',n:'Œil du jury',ic:'🎩',d:'Remporte des concours d’élégance',t:[2,8,25],v:()=>S.stats.w_elegance||0},
 {id:'earned',n:'Tycoon',ic:'💰',d:'Gagne des crédits en course',t:[10000,100000,1000000],v:()=>S.stats.earned||0},
 {id:'nitroN',n:'Accro à la nitro',ic:'⚡',d:'Utilise des bouteilles de nitro',t:[10,50,200],v:()=>S.stats.nitroN||0},
 {id:'packs',n:'Ouvreur de paquets',ic:'🃏',d:'Ouvre des paquets',t:[5,30,100],v:()=>S.stats.packs||0},
 {id:'best',n:'Chasseur de légendes',ic:'🌟',d:'Obtiens un module de rareté Épique, Mythique puis Ultra rare',t:[3,5,6],v:()=>S.stats.best||0},
 {id:'shiny',n:'Chasseur d’éclats',ic:'✨',d:'Obtiens des modules brillants',t:[1,5,20],v:()=>S.stats.shiny||0},
 {id:'alb',n:'Album complet',ic:'📖',d:'Remplis l’album de modules',t:[20,80,200],v:albCount},
 {id:'fuseN',n:'Alchimiste',ic:'⚗️',d:'Fusionne des modules',t:[2,10,40],v:()=>S.stats.fuseN||0},
 {id:'eqN',n:'Tuner',ic:'🔩',d:'Monte des modules sur tes voitures',t:[10,60,250],v:()=>S.stats.eqN||0},
 {id:'repN',n:'Garagiste',ic:'🛠️',d:'Répare des voitures',t:[5,30,100],v:()=>S.stats.repN||0},
 {id:'shopN',n:'Chineur',ic:'🛒',d:'Achète des pièces au marché',t:[3,20,80],v:()=>S.stats.shopN||0},
 {id:'bats',n:'Bâtisseur',ic:'🏗️',d:'Améliore les bâtiments de la base',t:[3,10,25],v:()=>S.stats.bats||0},
 {id:'cars',n:'Collectionneur',ic:'🚗',d:'Possède des voitures en même temps',t:[3,6,12],v:()=>S.cars.length},
 {id:'lvl',n:'Ascension',ic:'📈',d:'Atteins un niveau de pilote',t:[5,10,20],v:()=>S.lvl}];
const BTIER=[{n:'Bronze',c:'#cd7f32',cr:500,xp:40,tok:0},{n:'Argent',c:'#cfd6e4',cr:2500,xp:150,tok:1},{n:'Or',c:'#ffd24a',cr:10000,xp:500,tok:3}];
const bdgDone=b=>{ const v=b.v(); return b.t.filter(x=>v>=x).length; };
const bdgGot=b=>pil().bdg[b.id]||0;
const bdgReady=()=>BDG.reduce((t,b)=>t+Math.max(0,bdgDone(b)-bdgGot(b)),0);
const bdgGold=()=>BDG.filter(b=>bdgGot(b)>=3).length;
const skTotal=()=>Math.max(0,S.lvl-1)+bdgGold();
const skSpent=()=>Object.values(pil().sp).reduce((a,b)=>a+b,0);
const skAvail=()=>skTotal()-skSpent();
const pilDot=()=>skAvail()>0||bdgReady()>0;

/* récompenses : on ajoute les succès à « tout récupérer » */
function claimList(){
  questsEnsure(); const L=[];
  if(S.daily!==dayKey()) L.push(['daily']);
  [['dq',DQ],['wq',WQ]].forEach(([k,T])=>S[k].ids.forEach(id=>{ const q=T.find(x=>x.id===id); if(q&&!S[k].cl[id]&&qProg(S[k],q)>=q.n) L.push([k,id]); }));
  MISSIONS.forEach(m=>{ if(!S.claimed[m.id]){ const p=m.p(S); if(p[0]>=p[1]) L.push(['m',m.id]); } });
  BDG.forEach(b=>{ if(bdgDone(b)>bdgGot(b)) L.push(['b',b.id]); });
  return L;
}
function claimTotal(L){
  const g={cr:0,tok:0,nitro:0,xp:0}, add=x=>{g.cr+=x.cr||0; g.tok+=x.tok||0; g.nitro+=x.nitro||0; g.xp+=x.xp||0;};
  L.forEach(([k,id])=>{ if(k==='daily') add(dailyReward()); else if(k==='m') add(MISSIONS.find(m=>m.id===id).g);
    else if(k==='b'){ const b=BDG.find(x=>x.id===id); for(let i=bdgGot(b);i<bdgDone(b);i++) add(BTIER[i]); }
    else add(qRew((k==='dq'?DQ:WQ).find(x=>x.id===id))); });
  return g;
}
ACT.claimall=function(){
  const L=claimList(); if(!L.length) return toast('Rien à récupérer');
  const g=claimTotal(L), lv0=S.lvl;
  L.forEach(([k,id])=>{
    if(k==='daily'){ const y=new Date(Date.now()-864e5), yk=y.getFullYear()+'-'+(y.getMonth()+1)+'-'+y.getDate(); S.streak=S.daily===yk?(S.streak||0)+1:1; S.daily=dayKey(); }
    else if(k==='m') S.claimed[id]=1;
    else if(k==='b'){ const b=BDG.find(x=>x.id===id); pil().bdg[id]=bdgDone(b); }
    else S[k].cl[id]=1;
  });
  giveG(g); toast('Tout récupéré : '+[g.cr?fmt(g.cr)+' cr':'',g.xp?g.xp+' XP':'',g.nitro?g.nitro+' nitro':'',g.tok?g.tok+' jeton'+(g.tok>1?'s':''):''].filter(Boolean).join(', ')); save(); render(); if(sheet&&sheet.t==='pilot') renderSheet();
};

/* ---- fenêtre pilote ---- */
const HELM=`<svg viewBox="0 0 64 64"><defs><linearGradient id="hg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f7ff"/><stop offset=".5" stop-color="#9aa6c6"/><stop offset="1" stop-color="#3b4362"/></linearGradient></defs>
<path d="M8 40 C8 20 22 8 38 8 C52 8 60 20 60 34 V46 C60 50 57 52 53 52 H18 C12 52 8 47 8 40Z" fill="url(#hg1)"/><path d="M26 22 H58 V38 H30 C25 38 22 33 24 29Z" fill="#0b0d1c" stroke="var(--rc)" stroke-width="2"/>
<path d="M8 40 C8 20 22 8 38 8" fill="none" stroke="var(--rc)" stroke-width="3" stroke-linecap="round"/><path d="M30 26 H54" stroke="#fff" stroke-width="1.6" opacity=".5" stroke-linecap="round"/><rect x="34" y="42" width="24" height="5" rx="2.5" fill="var(--rc)" opacity=".9"/></svg>`;
const pilStat=(v,l)=>`<div><b>${v}</b><span>${l}</span></div>`;
function pilotSheets(X){
  if(sheet.t!=='pilot') return false;
  const el=$('sheet'), tab=sheet.tab||'card', rk=rankOf(), nx=RANKS.find(r=>r[0]>S.lvl);
  const tabs=`<div class="subtabs">${[['card','Carte'],['skills','Compétences'+(skAvail()>0?` (${skAvail()})`:'')],['bdg','Succès'+(bdgReady()?` (${bdgReady()})`:'')]].map(([id,n])=>`<button data-a="ptab" data-id="${id}" ${tab===id?'aria-current="true"':''}>${n}</button>`).join('')}</div>`;
  let body='';
  if(tab==='card'){
    const gold=BDG.filter(b=>bdgGot(b)>=3||bdgDone(b)>=3).length, sp=skSpent();
    body=`<div class="pcard" style="--rc:${rk[2]}"><div class="pfoil"></div><div class="ptop"><span class="pav">${HELM}</span><div class="pid"><small>CARTE PILOTE</small><b>Pilote</b><span class="prank">${rk[1]}</span></div><div class="plv"><small>NIV.</small>${S.lvl}</div></div>
      <div class="pxp"><i style="width:${clamp(S.xp/need(S.lvl)*100,0,100)}%"></i></div><div class="pxpt">${fmt(S.xp)} / ${fmt(need(S.lvl))} XP${nx?` · prochain titre au niveau ${nx[0]} : ${nx[1]}`:' · rang maximal'}</div>
      <div class="pgrid">${pilStat(fmt(S.stats.races||0),'Épreuves')}${pilStat(fmt(S.stats.wins||0),'Victoires')}${pilStat(fmt(S.stats.pods||0),'Podiums')}${pilStat(fmt(S.cars.length),'Voitures')}${pilStat(fmt(S.mods.length),'Modules')}${pilStat(fmt(albCount()),'Album')}</div>
      <div class="pbad">${BDG.slice(0,12).map(b=>{const n=bdgDone(b); return `<span class="pb t${n}" title="${b.n}">${b.ic}</span>`;}).join('')}</div></div>
      <div class="prow"><button class="pbtn" data-a="ptab" data-id="skills"><b>🌳 Compétences</b><span>${skAvail()>0?`${skAvail()} point${skAvail()>1?'s':''} à dépenser`:`${sp} point${sp>1?'s':''} dépensé${sp>1?'s':''}`}</span></button><button class="pbtn" data-a="ptab" data-id="bdg"><b>🏅 Succès</b><span>${BDG.reduce((t,b)=>t+bdgDone(b),0)} / ${BDG.length*3} paliers, ${gold} en or</span></button></div>
      <p class="note">Chaque niveau donne 1 point de compétence. Un succès en or en donne un de plus.</p>`;
  } else if(tab==='skills'){
    body=`<div class="spts"><b>${skAvail()}</b><span>point${skAvail()>1?'s':''} de compétence</span><button class="btn alt sm" data-a="skreset" ${skSpent()?'':'disabled'}>${sheet.arm?'Confirmer : '+cr(skCost()):'Réinitialiser'}</button></div>
      ${SKT.map(b=>`<div class="sbr" style="--rc:${b.c}"><h3>${b.ic} ${b.n}</h3>${b.list.map(s=>{const l=pk(s.id), mx=l>=s.max;
        return `<div class="sk ${l?'on':''}"><span class="sic">${s.ic}</span><span class="sbody"><b>${s.n}</b><span class="pips">${Array.from({length:s.max},(_,i)=>`<i class="${i<l?'f':''}"></i>`).join('')}</span><small>${l?s.d(l):'Aucun niveau'}${mx?'':`<br><em>Niveau ${l+1} : ${s.d(l+1)}</em>`}</small></span>
          ${mx?'<span class="smax">MAX</span>':`<button class="btn sm ${skAvail()>0?'good':'alt'}" data-a="skup" data-id="${s.id}" ${skAvail()>0?'':'disabled'}>+1</button>`}</div>`;}).join('')}</div>`).join('')}`;
  } else {
    const rdy=bdgReady(), g=claimTotal(BDG.filter(b=>bdgDone(b)>bdgGot(b)).map(b=>['b',b.id]));
    body=`${rdy?`<button class="btn good wide claimall" data-a="claimall"><b>🎁 Tout récupérer</b><span>${rdy} palier${rdy>1?'s':''} : ${gText(g)}</span></button>`:`<p class="note">Chaque succès a trois paliers : bronze, argent, or. Les récompenses sont des crédits, de l’expérience et des jetons.</p>`}
      <div class="bgrid">${BDG.map(b=>{const v=b.v(), n=bdgDone(b), got=bdgGot(b), nxt=b.t[Math.min(n,2)], shown=Math.min(v,nxt);
        return `<div class="bd ${n?'on':''}"><span class="bmed t${n}">${b.ic}</span><b>${b.n}</b><small>${b.d}</small><div class="bp"><i style="width:${clamp(shown/nxt*100,0,100)}%"></i></div><span class="bnum">${n>=3?'Complet':fmt(Math.min(v,nxt))+' / '+fmt(nxt)}</span><span class="btier">${[0,1,2].map(i=>`<u class="${i<n?'d':''} ${i<got?'g':''}" style="--tc:${BTIER[i].c}"></u>`).join('')}</span></div>`;}).join('')}</div>`;
  }
  el.innerHTML=`${X}<h2>Pilote</h2>${tabs}${body}`;
  return true;
}
const skCost=()=>1500+500*skSpent();
Object.assign(ACT,{
  pilot(){ openSheet({t:'pilot',tab:'card'}); },
  ptab(d){ if(!sheet||sheet.t!=='pilot') return; sheet.tab=d.id; sheet.arm=false; renderSheet(); const s=$('sheet'); if(s) s.scrollTop=0; },
  skup(d){ const s=SKI[d.id]; if(!s) return; const l=pk(s.id); if(l>=s.max||skAvail()<1) return; pil().sp[s.id]=l+1; save(); render(); renderSheet(); auTry(()=>auCard(3,false,false)); toast(`${s.n} : niveau ${l+1}`); },
  skreset(){ if(!skSpent()) return; if(!sheet.arm){ sheet.arm=true; return renderSheet(); } const c=skCost(); if(S.cr<c) return toast('Pas assez de crédits'); S.cr-=c; pil().sp={}; sheet.arm=false; save(); render(); renderSheet(); toast('Compétences réinitialisées'); }
});
