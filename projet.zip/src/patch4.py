s=open('main_v010.js',encoding='utf-8').read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a); assert n==cnt,(n,cnt,a[:80]); s=s.replace(a,b)
# --- niveaux plus rapides, xp en récompense
rep("const need = l=>Math.round(80*Math.pow(l,1.4));","const need = l=>Math.round(55*Math.pow(l,1.35));")
rep("const giveG=g=>{S.cr+=g.cr||0; S.nitro+=g.nitro||0; S.tok+=g.tok||0;};","const giveG=g=>{S.cr+=g.cr||0; S.nitro+=g.nitro||0; S.tok+=g.tok||0; if(g.xp) addXP(g.xp);};")
rep("g.tok?`${g.tok} 🎟`:''].filter(Boolean)","g.xp?`${g.xp} XP`:'',g.tok?`${g.tok} 🎟`:''].filter(Boolean)")
rep("const dailyReward=()=>({cr:300+150*S.lvl,tok:1+((S.streak||0)%7===6?2:0)});","const dailyReward=()=>({cr:300+150*S.lvl,xp:40+15*S.lvl,tok:1+((S.streak||0)%7===6?2:0)});")
rep("const qRew=q=>({cr:Math.round((q.g.cr||0)*(1+.1*S.lvl)/10)*10,tok:q.g.tok||0,nitro:q.g.nitro||0});","const qRew=q=>{const c=Math.round((q.g.cr||0)*(1+.1*S.lvl)/10)*10; return {cr:c,xp:q.g.xp||rxp(c),tok:q.g.tok||0,nitro:q.g.nitro||0};};")
rep("S.daily=k; S.cr+=r.cr; S.tok+=r.tok; toast(`+${fmt(r.cr)} cr et +${r.tok} jeton(s)`);","S.daily=k; giveG(r); toast(`+${fmt(r.cr)} cr, +${r.xp} XP et +${r.tok} jeton(s)`);")
rep("S.claimed[m.id]=1; S.cr+=m.g.cr||0; S.nitro+=m.g.nitro||0; S.tok+=m.g.tok||0; toast('Récompense récupérée');","S.claimed[m.id]=1; giveG(m.g); toast('Récompense récupérée : '+gText(m.g).replace(/&nbsp;/g,' '));")
rep("${cr(dr.cr)} et ${dr.tok} 🎟.","${cr(dr.cr)}, ${dr.xp} XP et ${dr.tok} 🎟.")
rep("xp=Math.round(ev.xp*(.3+.7*pay)","xp=Math.round(ev.xp*1.3*(.3+.7*pay)")
# --- audio : coupure du menu, pas de musique d'attente en drag
rep("AU.seq.heldBars=0; AU.seq.level=0; auMood('tense');","AU.seq.heldBars=0; AU.seq.level=0; auCutMenu(); auMood(o.drag?'silent':'tense');")
rep("if(!S_.go) auMood('tense'); else","if(!S_.go) auMood(R_.drag?'silent':'tense'); else")

# --- lot B : drag plus long, difficulté progressive, dépassements, caméra, rétroviseur
rep("drag:     [['S',400]],","drag:     [['S',900]],")
rep("skill:clamp(.8+idx*.015+STYLES[o.sty].sk+rnd(-.015,.015),.78,.95),err:Math.max(.04,.14-idx*.012)","skill:clamp(.8+idx*.016+S.lvl*.003+STYLES[o.sty].sk+rnd(-.015,.015),.78,.975),err:Math.max(.025,.14-idx*.012-S.lvl*.003)")
rep("sk=clamp(.84+idx*.014+stl.sk+rnd(-.015,.015),.8,.98)","sk=clamp(.84+idx*.012+S.lvl*.0025+stl.sk+rnd(-.015,.015),.8,.985)")
rep("const m=pool[rint(0,pool.length-1)], up={}; PARTS.forEach(p=>up[p.id]=ev.opp.up);\n      return {uid:-1-k,mid:m.id,etat:rint(ev.opp.etat[0],ev.opp.etat[1]),xp:0,lvl:1+i,up,",
    "const ex=Math.max(0,S.lvl-ev.lvl), m=pool2[rint(0,pool2.length-1)], up={}; PARTS.forEach(p=>up[p.id]=Math.min(4,ev.opp.up+Math.floor(ex/3)));\n      return {uid:-1-k,mid:m.id,etat:rint(ev.opp.etat[0],ev.opp.etat[1]),xp:0,lvl:1+i+ex,up,")
rep("const pool=CARS.filter(m=>m.t>=ev.opp.t[0]&&m.t<=ev.opp.t[1]&&!m.noAI), i=EVENTS.indexOf(ev);","const pool=CARS.filter(m=>m.t>=ev.opp.t[0]&&m.t<=ev.opp.t[1]&&!m.noAI), i=EVENTS.indexOf(ev), exT=Math.max(0,S.lvl-ev.lvl), hiT=Math.min(6,ev.opp.t[1]+(exT>=4?1:0)+(exT>=9?1:0)), pool2=CARS.filter(m=>m.t>=ev.opp.t[0]&&m.t<=hiT&&!m.noAI).length?CARS.filter(m=>m.t>=ev.opp.t[0]&&m.t<=hiT&&!m.noAI):pool;")

def cutrep(start,end,new):
    global s
    i=s.index(start); j=s.index(end,i); s=s[:i]+new+s[j:]
cutrep("    /* ligne visée : place de grille","    carStep(o,oi,h); carWorld(o,h); o.thrNow=oi.thr;",
"""    let lane=o.laneT+(o.pref-o.laneT)*clamp(o.prog/150,0,1); const trf=aiPass(o,all,lane,o.sty.room); lane=trf.lane;
    const rb=1+clamp((P.prog-o.prog)/2500,-.03,.03);
    const oi=aiControl(o,o.prof,lane,(o.fin!=null?.6:o.skill)*rb);
    if(trf.cap<1){oi.thr=Math.min(oi.thr,trf.cap); if(trf.brake) oi.brake=true;}
""")
rep("if(RC.auto&&P.fin==null) inp=aiControl(P,RC.profP,P.laneT*Math.max(0,1-Math.max(0,P.prog)/200),.9);",
    "if(RC.auto&&P.fin==null){ const l0=P.laneT*Math.max(0,1-Math.max(0,P.prog)/200), trf=aiPass(P,all,l0,1); inp=aiControl(P,RC.profP,trf.lane,.9); if(trf.cap<1){inp.thr=Math.min(inp.thr,trf.cap); if(trf.brake) inp.brake=true;} }")
rep("GL.tick(dt,ts/1000); GL.r.render(GL.scene,GL.cam);","GL.tick(dt,ts/1000); GL.r.render(GL.scene,GL.cam); if(GL.post) GL.post();")
rep("GL.tick=null; GL.mode=null;}","GL.tick=null; GL.mode=null; GL.post=null;}")
rep("cam.lookAt(P.x+fx*12,P.y+1.3,P.z+fz*12);","cam.lookAt(P.x+fx*12,P.y+1.3,P.z+fz*12); if(orbitOn()) orbitSpa(cam,P,ang,dt);")
rep("cam.lookAt(lk.x,1.2,lk.z);","cam.lookAt(lk.x,1.2,lk.z); if(orbitOn()) orbitRace(cam,P,Pa,dt);")

# --- lot C : pilote, compétences
rep("A:(2+s.acc*.09)*ef*lv*(mn.d==='drag'?trb:1),","A:(2+s.acc*.09)*ef*lv*(mn.d==='drag'?trb:1)*sk(c,'acc',.015),")
rep("B:(6+s.fre*.12)*Math.sqrt(wet),","B:(6+s.fre*.12)*Math.sqrt(wet)*sk(c,'brk',.02),")
rep("const grip=base*wet*(mn.d==='rallye'?.9:1)*(mn.d==='drag'?1:trb);","const grip=base*wet*(mn.d==='rallye'?.9:1)*(mn.d==='drag'?1:trb)*sk(c,'grip',.012);")
rep("nP:1+(s.sp.nitP||0), nD:1+(s.sp.nitD||0),","nP:1+(s.sp.nitP||0)+(c.uid>0?.04*pk('nit'):0), nD:1+(s.sp.nitD||0)+(c.uid>0?.08*pk('nit'):0),")
rep("const pP=(100-s.fia)/500*","const pP=(c.uid>0?1-.1*pk('rel'):1)*(100-s.fia)/500*")
rep("const wearK=()=>S.ins>0?.3:1;","const wearK=()=>(S.ins>0?.3:1)*(1-.08*pk('wear'));")
rep("Math.max(1,ECO.rep*.013*","Math.max(1,(1-.07*pk('rep'))*ECO.rep*.013*")
rep("Math.round(ECO.up*.33*","Math.round((1-.05*pk('upg'))*ECO.up*.33*")
rep("Math.round(ev.gain*ECO.gain*","Math.round(ev.gain*ECO.gain*(1+.04*pk('gain'))*")
rep("xp=Math.round(ev.xp*1.3*","xp=Math.round(ev.xp*1.3*(1+.06*pk('xp'))*")
rep("cr:300+150*S.lvl,xp:","cr:Math.round((300+150*S.lvl)*(1+.08*pk('dly'))),xp:")
rep("const podRate=()=>S.pod.slots.reduce(","const podRate=()=>(1+.06*pk('pod'))*S.pod.slots.reduce(")
rep("const tok=first?3:win?1:0;","const tok=(first?3:win?1:0)+(win&&Math.random()<.06*pk('tok')?1:0);")
rep("Math.round(SHOP_P[r]*(.9+m.q*.12)/10)*10","Math.round(SHOP_P[r]*(1-.05*pk('shopd'))*(.9+m.q*.12)/10)*10")
rep("const scrapK=()=>1+.15*(S.bat.entrepot||0);","const scrapK=()=>(1+.15*(S.bat.entrepot||0))*(1+.08*pk('scrap'));")
rep("if(!plain&&r>=2&&Math.random()<SHINY_P) m.sh=1;","if(!plain&&r>=2&&Math.random()<SHINY_P*(1+.1*pk('luck'))) m.sh=1;")
rep("<span class=\"lv\" title=\"Niveau du joueur\">${S.lvl}</span><span class=\"who\">","<button class=\"lv\" data-a=\"pilot\" title=\"Carte pilote\">${S.lvl}${pilDot()?'<i class=\"pdot\"></i>':''}</button><span class=\"who\" data-a=\"pilot\">")
rep("||questReady();","||questReady()||bdgReady()>0;")
rep("  if(tuneSheets(X)) return true;","  if(tuneSheets(X)||pilotSheets(X)) return true;")
n5=open('new5.js',encoding='utf-8').read()
rep("  ${claimBar()}\n","  ${claimBar()}<button class=\"row\" data-a=\"pilot\"><span class=\"ico\">🏅</span><span class=\"grow\"><span class=\"ttl\">Carte pilote</span><br><span class=\"sub\">Titre, succès et arbre de compétences${skAvail()>0?`. ${skAvail()} point${skAvail()>1?'s':''} à dépenser`:''}${bdgReady()?`. ${bdgReady()} succès à récupérer`:''}</span></span><span class=\"gain\">Ouvrir</span></button>\n")

rep("const L=t==='S'?len*k:len, s={t,a:x,b:x+L,base};","const L=t==='S'?len*(mn.d==='drag'?Math.min(k,1.35):k):len, s={t,a:x,b:x+L,base};")
n4=open('new4.js',encoding='utf-8').read()
rep("setInterval(updPod,4000);",n4+n5+"\nsetInterval(updPod,4000);")
s=s.replace("démo v0.10","démo v0.11")
open('main.js','w',encoding='utf-8').write(s); print('ok',len(s))
