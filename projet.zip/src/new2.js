
/* ======================================================================
   v0.9 : audio drag et nouveaux sons, économie, missions, marché
   ====================================================================== */
/* ---- audio : drag (tempo qui monte avec la vitesse) et nouveaux effets ---- */
function dragSD(){ const f=clamp(AU.speedFrac||0,0,1); AU.dsm=(AU.dsm||0)+(f-(AU.dsm||0))*.07; return 15/(120+68*Math.pow(AU.dsm,.85)); }
function dragSched(s,bar,t,ch){
  const q=AU.seq, L=q.level, sd=15/(120+68*Math.pow(AU.dsm||0,.85));
  if(s===0&&bar%4===0) AU.dkey=Math.pow(2,Math.min(5,Math.floor((AU.dsm||0)*6))/12);
  const k=AU.dkey||1;
  if(s===0&&bar%2===0) pad(t,sd*32,ch.pad.map(f=>f*k),.085);
  if(s%4===0) kick(t,L===0?.62:.92,{p0:170,p1:46,dec:.24});
  if(s%4===2) hat(t,.13,true); else if(L>=1&&s%2===1) hat(t,.045,false);
  if(L>=1&&(s===4||s===12)) clap(t,.42);
  if(L>=1&&s%4===2) sub(t,sd*1.7,ch.sub*2*k,.34);
  if(L>=2&&(s===0||s===6||s===10)) reese(t,sd*3,ch.bass*k,.2);
  if(L>=2) pluck(t,ch.arp[(s+bar*2)%6]*2*k,.07,'sawtooth',sd*2.2);
  if(L>=3){
    if([0,3,6,10,12].includes(s)) stab(t,ch.arp[(s>>1)%6]*2*k,.1,sd*2);
    if(s===0&&bar%2===0) crash(t,.26);
    if(s%2===1) hat(t,.06,false);
    if(bar%4===3&&s>=8) snare(t,.25+.04*(s-8),{});
  } else if(L>=2&&bar%4===3&&s>=12) snare(t,.28+.1*(s-12),{});
}
function auWhoosh(){ if(!AU.ok) return; const t=AU.ctx.currentTime+.005, b=burst(t,.42,500,1.6,'bandpass',.5,AU.b.hit); b.fl.frequency.exponentialRampToValueAtTime(3800,t+.34); osc('sine',880,t+.2,.05,AU.b.ui,.07,.002,.2); }
function auDown(){ if(!AU.ok) return; const t=AU.ctx.currentTime+.005, o=osc('triangle',300,t,.12,AU.b.ui,.16,.003,.14); o.o.frequency.exponentialRampToValueAtTime(150,t+.16); }
function auHorn(won){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.02, d=AU.b.jing;
  if(won){ [392,523.25,659.25].forEach((f,i)=>osc('sawtooth',f,t+i*.11,.34,d,.1,.01,.5)); osc('sawtooth',130.8,t,.6,d,.1,.01,.5); burst(t,.7,6000,.5,'highpass',.12,d,true); }
  else { osc('sawtooth',220,t,.5,d,.1,.01,.4); osc('sawtooth',164.8,t+.18,.6,d,.1,.01,.5); }
}
function auLaunch(){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.01, b=burst(t,.55,2300,6,'bandpass',.22,AU.b.amb); b.fl.frequency.linearRampToValueAtTime(3900,t+.5);
  const o=osc('sawtooth',90,t,.3,AU.b.hit,.1,.01,.25); o.o.frequency.exponentialRampToValueAtTime(260,t+.35);
}
function auDing(){ if(!AU.ok) return; const t=AU.ctx.currentTime+.005; osc('sine',1568,t,.08,AU.b.ui,.16,.002,.4); osc('sine',2093,t+.07,.1,AU.b.ui,.14,.002,.5); }

/* ---- économie : gains plus généreux, réparations et améliorations moins chères ---- */
const ECO={gain:1.5,up:.75,rep:.7};
const bump=(k,n)=>{S.stats[k]=(S.stats[k]||0)+(n==null?1:n);};
const wearK=()=>S.ins>0?.3:1;
const invMax=()=>INV_MAX+60*(S.bat.entrepot||0);
const scrapK=()=>1+.15*(S.bat.entrepot||0);
const craftCost=r=>Math.max(1,Math.round(RAR[r].sc*6*(1-.08*(S.bat.entrepot||0))));
const giveG=g=>{S.cr+=g.cr||0; S.nitro+=g.nitro||0; S.tok+=g.tok||0;};
const gText=g=>[g.cr?cr(g.cr):'',g.nitro?`⚡ ${g.nitro}`:'',g.tok?`${g.tok} 🎟`:''].filter(Boolean).join(' + ');
BATS.push(
 {id:'banc',nom:'Banc de puissance',ic:'📈',max:5,cout:[3000,12000,45000,150000,500000],effet:l=>l?`+${l*2} % de puissance et de couple sur toutes tes voitures`:'Règle tes moteurs : +2 % de puissance par niveau'},
 {id:'entrepot',nom:'Entrepôt de pièces',ic:'📦',max:5,cout:[2000,8000,30000,100000,350000],effet:l=>l?`Ferraille +${l*15} %, fabrication −${l*8} %, inventaire de ${INV_MAX+60*l} modules`:'Plus de ferraille, fabrication moins chère, plus de place'},
 {id:'simu',nom:'Simulateur de course',ic:'🕹️',max:5,cout:[4000,16000,60000,200000,700000],effet:l=>l?`+${l*10} % d’expérience gagnée en course`:'Entraîne tes pilotes : +10 % d’expérience par niveau'});

/* ---- défis quotidiens et hebdomadaires ---- */
const DQ=[{id:'d_race',t:'Dispute 3 épreuves',s:'races',n:3,g:{cr:500,tok:1}},{id:'d_win',t:'Gagne 2 épreuves',s:'wins',n:2,g:{cr:800}},
 {id:'d_nit',t:'Utilise 3 bouteilles de nitro',s:'nitroN',n:3,g:{cr:400,nitro:1}},{id:'d_pack',t:'Ouvre 2 paquets',s:'packs',n:2,g:{cr:600,tok:1}},
 {id:'d_rep',t:'Répare 2 voitures',s:'repN',n:2,g:{cr:300}},{id:'d_eq',t:'Monte 2 modules',s:'eqN',n:2,g:{cr:500}},
 {id:'d_shop',t:'Achète une pièce au marché',s:'shopN',n:1,g:{cr:500}},{id:'d_spa',t:'Gagne une course sur le circuit de Spa',s:'w_circuit',n:1,g:{cr:900,tok:1}},
 {id:'d_drag',t:'Gagne un drag',s:'w_drag',n:1,g:{cr:700}}];
const WQ=[{id:'w_win',t:'Gagne 12 épreuves',s:'wins',n:12,g:{cr:6000,tok:6}},{id:'w_pack',t:'Ouvre 10 paquets',s:'packs',n:10,g:{cr:4000,tok:5}},
 {id:'w_earn',t:'Gagne 30 000 cr en course',s:'earned',n:30000,g:{cr:5000,tok:3}},{id:'w_nit',t:'Utilise 15 bouteilles de nitro',s:'nitroN',n:15,g:{cr:3000,nitro:3}},
 {id:'w_spa',t:'Gagne 5 courses sur le circuit de Spa',s:'w_circuit',n:5,g:{cr:5000,tok:4}},{id:'w_fuse',t:'Fusionne 3 fois des modules',s:'fuseN',n:3,g:{cr:3500,tok:3}}];
const weekKey=()=>{const d=new Date(), t=new Date(d.getFullYear(),0,1); return d.getFullYear()+'-w'+Math.ceil(((d-t)/864e5+t.getDay()+1)/7);};
function questsEnsure(){
  const dk=dayKey(), wk=weekKey();
  if(!S.dq||S.dq.k!==dk) S.dq={k:dk,base:Object.assign({},S.stats),ids:DQ.map(q=>q.id).sort(()=>Math.random()-.5).slice(0,3),cl:{}};
  if(!S.wq||S.wq.k!==wk) S.wq={k:wk,base:Object.assign({},S.stats),ids:WQ.map(q=>q.id).sort(()=>Math.random()-.5).slice(0,2),cl:{}};
}
const qProg=(box,q)=>Math.max(0,(S.stats[q.s]||0)-((box.base&&box.base[q.s])||0));
const qRew=q=>({cr:Math.round((q.g.cr||0)*(1+.1*S.lvl)/10)*10,tok:q.g.tok||0,nitro:q.g.nitro||0});
function questReady(){ questsEnsure(); return [['dq',DQ],['wq',WQ]].some(([k,L])=>S[k].ids.some(id=>{const q=L.find(x=>x.id===id); return !S[k].cl[id]&&qProg(S[k],q)>=q.n;})); }
const MISS2=[
 ['m17','Course','Gagne 15 épreuves',s=>[s.stats.wins,15],{cr:3000,tok:2}],['m18','Course','Gagne 40 épreuves',s=>[s.stats.wins,40],{cr:12000,tok:5}],
 ['m19','Course','Dispute 10 épreuves',s=>[s.stats.races,10],{cr:1500}],['m20','Course','Gagne un drag',s=>[s.stats.w_drag||0,1],{cr:800}],
 ['m21','Course','Gagne 3 courses sur le circuit de Spa',s=>[s.stats.w_circuit||0,3],{cr:2500,tok:1}],['m22','Course','Gagne un rallye',s=>[s.stats.w_rallye||0,1],{cr:900}],
 ['m23','Course','Gagne un drift',s=>[s.stats.w_drift||0,1],{cr:1200}],['m24','Course','Gagne une manche d’endurance',s=>[s.stats.w_endurance||0,1],{cr:1800}],
 ['m25','Course','Utilise 10 bouteilles de nitro',s=>[s.stats.nitroN||0,10],{cr:1000,nitro:2}],
 ['m26','Cartes','Ouvre 5 paquets',s=>[s.stats.packs||0,5],{tok:3}],['m27','Cartes','Ouvre 25 paquets',s=>[s.stats.packs||0,25],{cr:6000,tok:8}],
 ['m28','Cartes','Possède 15 modules',s=>[s.mods.length,15],{cr:1200}],['m29','Cartes','Obtiens un module brillant',s=>[s.stats.shiny||0,1],{tok:4}],
 ['m30','Cartes','Obtiens un module Légendaire ou mieux',s=>[(s.stats.best||0)>=4?1:0,1],{cr:8000,tok:10}],
 ['m31','Cartes','Fusionne 3 fois des modules',s=>[s.stats.fuseN||0,3],{cr:2500,tok:2}],['m32','Cartes','Recycle 20 modules',s=>[s.stats.recyN||0,20],{cr:1500}],
 ['m33','Cartes','Monte 6 modules sur une même voiture',s=>[s.stats.eq||0,6],{cr:3500,tok:3}],['m34','Cartes','Équipe les 11 emplacements d’une voiture',s=>[s.stats.eq||0,11],{cr:15000,tok:10}],
 ['m46','Cartes','Remplis 20 cases de l’album',s=>[Object.values(s.alb||{}).reduce((t,b)=>{let c=0; while(b){c+=b&1; b>>=1;} return t+c;},0),20],{cr:3000,tok:3}],
 ['m35','Collection','Possède 5 voitures',s=>[s.cars.length,5],{cr:3000}],['m36','Collection','Possède 10 voitures',s=>[s.cars.length,10],{cr:15000,tok:5}],
 ['m37','Collection','Possède une Supercar',s=>[s.cars.some(c=>M[c.mid].t>=5)?1:0,1],{cr:25000,tok:5}],
 ['m38','Progression','Atteins le niveau 5',s=>[s.lvl,5],{cr:2500}],['m39','Progression','Atteins le niveau 20',s=>[s.lvl,20],{cr:40000,tok:10}],
 ['m47','Progression','Joue 3 jours de suite',s=>[s.streak||0,3],{cr:1500,tok:2}],['m48','Progression','Joue 7 jours de suite',s=>[s.streak||0,7],{cr:5000,tok:5}],
 ['m40','Économie','Gagne 50 000 cr en course',s=>[s.stats.earned||0,50000],{cr:5000}],['m41','Économie','Gagne 500 000 cr en course',s=>[s.stats.earned||0,500000],{cr:40000,tok:10}],
 ['m42','Économie','Répare 5 fois',s=>[s.stats.repN||0,5],{cr:600}],['m43','Économie','Vends une voiture',s=>[s.stats.sellN||0,1],{cr:500}],
 ['m44','Économie','Construis le Banc de puissance',s=>[s.bat.banc||0,1],{cr:3000}],['m45','Économie','Achète 3 pièces au marché',s=>[s.stats.shopN||0,3],{cr:1500}],
 ['m51','Économie','Garde 100 000 cr en banque',s=>[s.cr,100000],{tok:5}],['m50','Économie','Podiums : niveau Or',s=>[s.pod.tier,5],{cr:50000,tok:10}]];
MISS2.forEach(m=>MISSIONS.push({id:m[0],t:m[2],p:m[3],g:m[4]}));
const MCAT={m1:'Débuts',m2:'Débuts',m3:'Débuts',m4:'Débuts',m6:'Débuts',m11:'Débuts',m5:'Course',m7:'Course',m16:'Course',m8:'Collection',m10:'Collection',m9:'Progression',m12:'Progression',m13:'Cartes',m14:'Cartes',m15:'Cartes'};
MISS2.forEach(m=>MCAT[m[0]]=m[1]);
function vMissions(){
  questsEnsure();
  const can=S.daily!==dayKey(), dr=dailyReward();
  const qRow=(box,key,L,id)=>{ const q=L.find(x=>x.id===id), a=Math.min(qProg(box,q),q.n), done=a>=q.n, got=box.cl[id], g=qRew(q);
    return `<div class="row ${got?'done locked':''}"><span class="grow"><span class="ttl">${q.t}</span><br><span class="sub">Récompense : ${gText(g)}</span>${got?'':`<div class="prog"><i style="width:${a/q.n*100}%"></i></div>`}</span>
      ${got?'<span class="sub">Terminé</span>':done?`<button class="btn sm good" data-a="qclaim" data-k="${key}" data-id="${id}">Récupérer</button>`:`<span class="num">${fmt(a)} / ${fmt(q.n)}</span>`}</div>`; };
  const mRow=m=>{ const [a,b]=m.p(S), done=a>=b, got=S.claimed[m.id];
    return `<div class="row ${got?'done locked':''}"><span class="grow"><span class="ttl">${m.t}</span><br><span class="sub">Récompense : ${gText(m.g)}</span>
      ${got?'':`<div class="prog"><i style="width:${clamp(a/b*100,0,100)}%"></i></div>`}</span>
      ${got?'<span class="sub">Terminée</span>':done?`<button class="btn sm good" data-a="claim" data-id="${m.id}">Récupérer</button>`:`<span class="num">${fmt(Math.min(a,b))} / ${fmt(b)}</span>`}</div>`; };
  const cats=['Débuts','Course','Cartes','Collection','Économie','Progression'];
  const left=MISSIONS.filter(m=>!S.claimed[m.id]).length;
  return `<div class="head"><h2>Missions</h2><p>${left} objectif${left>1?'s':''} restant${left>1?'s':''}</p></div>
  <div class="row ${can?'':'locked'}"><span class="ico">🎁</span><span class="grow"><span class="ttl">Récompense du jour</span><br><span class="sub">${cr(dr.cr)} et ${dr.tok} 🎟. Série en cours : ${S.streak||0} jour${(S.streak||0)>1?'s':''}. Un bonus tous les 7 jours.</span></span>${can?`<button class="btn sm good" data-a="daily">Récupérer</button>`:'<span class="sub">Reviens demain</span>'}</div>
  <div class="sec"><h3>Défis du jour</h3>${S.dq.ids.map(id=>qRow(S.dq,'dq',DQ,id)).join('')}</div>
  <div class="sec"><h3>Défis de la semaine</h3>${S.wq.ids.map(id=>qRow(S.wq,'wq',WQ,id)).join('')}</div>
  ${cats.map(ct=>{ const ms=MISSIONS.filter(m=>(MCAT[m.id]||'Débuts')===ct).sort((a,b)=>(S.claimed[a.id]?1:0)-(S.claimed[b.id]?1:0)); return ms.length?`<div class="sec"><h3>${ct}</h3>${ms.map(mRow).join('')}</div>`:''; }).join('')}`;
}

/* ---- marché : voitures, pièces, services ---- */
let mTab='cars';
const SHOP_P=[100,400,1700,9000];
function shopMod(r){
  const T=MODT[rint(0,MODT.length-1)], m={u:0,t:T[0],r,q:Math.round(rnd(.85,1.15)*100)/100};
  if(r>=2){const ks=['ch','nm','adh','fre','man','fia','sty','kg']; m.s=[ks[rint(0,ks.length-1)],Math.round(rnd(.25,.55)*100)/100];}
  return m;
}
function shopRoll(){
  const items=[], W=[55,28,13,4];
  for(let i=0;i<6;i++){ let x=Math.random()*100, r=0; for(;r<3;r++){x-=W[r]; if(x<0) break;} r=Math.min(r,3); const m=shopMod(r); items.push({m,p:Math.round(SHOP_P[r]*(.9+m.q*.12)/10)*10}); }
  items.sort((a,b)=>b.m.r-a.m.r); S.shop={k:dayKey(),items};
}
const fleetRepair=()=>S.cars.reduce((t,c)=>t+Math.ceil((100-c.etat)*repUnit(c)*.85),0);
function vMarche(){
  if(!S.offres.length) newOffres(); if(!S.shop||S.shop.k!==dayKey()) shopRoll();
  const tabs=`<div class="subtabs">${[['cars','🚗 Voitures'],['parts','🔩 Pièces'],['serv','🛠️ Services']].map(([id,n])=>`<button data-a="mtab" data-id="${id}" ${mTab===id?'aria-current="true"':''}>${n}</button>`).join('')}</div>`;
  let body='';
  if(mTab==='cars'){
    const refresh=100*S.bat.casse, cl=S.bat.concession, neuves=cl?CARS.filter(m=>m.t<=cl+1):[];
    body=`<h3>Casse automobile</h3><p class="note">Des épaves à retaper. Les offres changent toutes les 3 épreuves.</p>
    <div class="grid">${S.offres.map((o,i)=>`<div>${cardHTML({mid:o.mid,etat:o.etat,lvl:1,up:{}},{tag:'div'})}
       <button class="btn wide sm" style="margin-top:6px" data-a="buy" data-id="${i}" ${S.cr<o.prix?'disabled':''}>Acheter ${cr(o.prix)}</button></div>`).join('')}</div>
    <button class="btn alt sm" style="margin-top:12px" data-a="refresh" ${S.cr<refresh?'disabled':''}>Voir d’autres épaves, ${cr(refresh)}</button>
    <div class="sec"><h3>Concession</h3>${cl?`<p class="note">Voitures neuves, 100 % d’état.</p><div class="grid">${neuves.map(m=>`<div>${cardHTML({mid:m.id,etat:100,lvl:1,up:{}},{tag:'div'})}
       <button class="btn wide sm" style="margin-top:6px" data-a="buynew" data-id="${m.id}" ${S.cr<m.val?'disabled':''}>Acheter ${cr(m.val)}</button></div>`).join('')}</div>`
       :`<p class="note">Construis la concession dans Atelier › Base pour acheter des voitures neuves.</p>`}</div>`;
  } else if(mTab==='parts'){
    body=`<h3>Boutique de pièces</h3><p class="note">Un stock de modules qui change chaque jour. Pas de hasard : tu vois ce que tu achètes. Pas de Légendaire ici, il faut les gagner dans les paquets.</p>
    <div class="mods">${S.shop.items.map((it,i)=>modHTML(it.m,`<button class="btn sm" data-a="shopbuy" data-id="${i}" ${S.cr<it.p?'disabled':''}>Acheter, ${cr(it.p)}</button>`)).join('')||'<p class="note">Stock épuisé.</p>'}</div>
    <button class="btn alt sm" style="margin-top:12px" data-a="shoproll" ${S.cr<400?'disabled':''}>Renouveler le stock, ${cr(400)}</button>
    <div class="sec"><h3>Atelier de fabrication</h3><p class="note">La ferraille des modules recyclés sert à fabriquer le module de ton choix.</p>
    <div class="row"><span class="ico">♻️</span><span class="grow"><span class="ttl">Ferraille : ${fmt(S.scrap)}</span><br><span class="sub">Fabrication à partir de ${craftCost(0)} ferraille. L’entrepôt la rend moins chère.</span></span><button class="btn sm" data-a="craftopen">Fabriquer</button></div></div>`;
  } else {
    const fr=fleetRepair(), need=S.cars.some(c=>c.etat<100);
    body=`<h3>Services</h3>
    <div class="row"><span class="ico">⚡</span><span class="grow"><span class="ttl">Bouteilles de nitro</span><br><span class="sub">${String(NITRO_DUREE).replace('.',',')} s de poussée. En stock : ${S.nitro}</span></span>
      <span class="pkb"><button class="btn sm" data-a="buynitro" data-id="1" ${S.cr<NITRO_PRIX?'disabled':''}>×1 · ${cr(NITRO_PRIX)}</button><button class="btn sm alt" data-a="buynitro" data-id="5" ${S.cr<650?'disabled':''}>×5 · ${cr(650)}</button><button class="btn sm alt" data-a="buynitro" data-id="12" ${S.cr<1500?'disabled':''}>×12 · ${cr(1500)}</button></span></div>
    <div class="row"><span class="ico">🔧</span><span class="grow"><span class="ttl">Révision de tout le garage</span><br><span class="sub">Remet toutes tes voitures à 100 %, 15 % moins cher que séparément.</span></span><button class="btn sm" data-a="fleetrep" ${!need||S.cr<fr?'disabled':''}>${need?cr(fr):'Rien à faire'}</button></div>
    <div class="row"><span class="ico">🛡️</span><span class="grow"><span class="ttl">Entretien préventif</span><br><span class="sub">Usure réduite de 70 % sur les 3 prochaines épreuves.${S.ins>0?` Actif : ${S.ins} restante${S.ins>1?'s':''}.`:''}</span></span><button class="btn sm" data-a="insure" ${S.cr<900?'disabled':''}>${cr(900)}</button></div>
    <div class="row"><span class="ico">🎓</span><span class="grow"><span class="ttl">Coach de pilotage</span><br><span class="sub">+50 % d’expérience sur les 3 prochaines épreuves.${S.xpb>0?` Actif : ${S.xpb} restante${S.xpb>1?'s':''}.`:''}</span></span><button class="btn sm" data-a="coach" ${S.cr<1200?'disabled':''}>${cr(1200)}</button></div>
    <div class="sec"><h3>Reprise</h3><p class="note">Revends tes modules en trop. Les modules montés et les brillants sont gardés.</p>
    <div class="row"><span class="ico">💱</span><span class="grow"><span class="ttl">Tous les Communs et Peu communs non montés</span><br><span class="sub">${S.mods.filter(m=>m.r<=1&&!m.sh&&m.un==null&&!eqCar(m.u)).length} modules concernés, payés en crédits.</span></span><button class="btn sm" data-a="sellmods" ${S.mods.some(m=>m.r<=1&&!m.sh&&m.un==null&&!eqCar(m.u))?'':'disabled'}>Vendre</button></div></div>`;
  }
  return `<div class="head"><h2>Marché</h2><p>${cr(S.cr)}</p></div>${tabs}${body}`;
}
