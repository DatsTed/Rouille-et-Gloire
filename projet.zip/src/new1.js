
/* ======================================================================
   v0.9 : miniatures 3D, équipement des modules, paquets 3D, effets de course
   ====================================================================== */
let lastView=null;
/* ---- miniatures 3D : chaque voiture est rendue une fois avec le moteur partagé, puis mise en cache ---- */
const TH={c:{},q:[],busy:false,fail:false};
const thKey=c=>c.mid+'|'+lookKey(c)+(c.sh?'|s':'');
function thArt(c){
  const m=M[c.mid], k=thKey(c), u=TH.c[k], rust=c.etat<40;
  if(u) return `<img class="th${rust?' rust':''}" src="${u}" alt="" draggable="false">`;
  if(window.THREE&&!TH.fail&&!TH.q.some(x=>x.k===k)){ TH.q.push({k,c:{mid:c.mid,lk:carLook(c),sh:c.sh}}); setTimeout(thPump,40); }
  return `<div class="thw" data-th="${k}" data-r="${rust?1:0}">${carSVG(m,c.etat)}</div>`;
}
function thFill(k,url){
  document.querySelectorAll('[data-th]').forEach(e=>{ if(e.dataset.th!==k) return;
    e.outerHTML=`<img class="th${e.dataset.r==='1'?' rust':''}" src="${url}" alt="" draggable="false">`; });
}
function thPump(){
  if(TH.busy||TH.fail||!TH.q.length||modelsBusy||view==='race'||!glEnsure()) return;
  TH.busy=true;
  requestAnimationFrame(()=>{
    const it=TH.q.shift();
    try{ const url=thRender(it.c); if(url){TH.c[it.k]=url; thFill(it.k,url);} else TH.fail=true; }
    catch(e){ TH.fail=true; TH.q.length=0; try{console.warn('miniature',e);}catch(_){ } }
    TH.busy=false; if(TH.q.length) setTimeout(thPump,20);
  });
}
function thRender(c){
  const m=M[c.mid], tcs=TIERS[m.t].c, tc=new THREE.Color(tcs), W=640, H=384, R=GL.r;
  const sc=new THREE.Scene();
  const bg=ctex(4,256,(x,w,h)=>{const g=x.createLinearGradient(0,0,0,h); g.addColorStop(0,'#0a0919'); g.addColorStop(.58,'#1a1640'); g.addColorStop(1,'#07060f'); x.fillStyle=g; x.fillRect(0,0,w,h);});
  bg.wrapS=bg.wrapT=THREE.ClampToEdgeWrapping; sc.background=bg;
  sc.add(new THREE.HemisphereLight(0xc6d0ff,0x2a0a4a,1.25));
  const dl=new THREE.DirectionalLight(0xffffff,.95); dl.position.set(-6,12,9); sc.add(dl);
  const rim=new THREE.DirectionalLight(tc,.9); rim.position.set(8,5,-8); sc.add(rim);
  const d2=new THREE.DirectionalLight(0xff9af0,.35); d2.position.set(6,3,8); sc.add(d2);
  const gt=ctex(128,128,(x,w,h)=>{x.fillStyle='#0a0a20'; x.fillRect(0,0,w,h); x.strokeStyle='rgba(0,229,255,.38)'; x.lineWidth=2; x.strokeRect(0,0,w,h);},[16,16]);
  const fl=new THREE.Mesh(new THREE.CircleGeometry(24,48),new THREE.MeshBasicMaterial({map:gt})); fl.rotation.x=-Math.PI/2; sc.add(fl);
  [[3.5,3.66],[4.5,4.56]].forEach(q=>{const r=new THREE.Mesh(new THREE.RingGeometry(q[0],q[1],64),new THREE.MeshBasicMaterial({color:tc,side:THREE.DoubleSide})); r.rotation.x=-Math.PI/2; r.position.y=.02; sc.add(r);});
  const c3=buildCar(m,tcs,c.lk||{}); sc.add(c3.g);
  const cam=new THREE.PerspectiveCamera(30,W/H,.1,200), h=Math.min(1,(c3.H||1.4)*.45), d=Math.max(3.4,(c3.L||4)*2.6), a=.66, p=.2;
  cam.position.set(Math.cos(a)*Math.cos(p)*d,Math.sin(p)*d+h,Math.sin(a)*Math.cos(p)*d); cam.lookAt(0,h*.92,0);
  const rt=new THREE.WebGLRenderTarget(W,H,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,format:THREE.RGBAFormat});
  const buf=new Uint8Array(W*H*4);
  R.setRenderTarget(rt); R.render(sc,cam); R.readRenderTargetPixels(rt,0,0,W,H,buf); R.setRenderTarget(null);
  rt.dispose(); disposeScene(sc);
  const cv=document.createElement('canvas'); cv.width=W; cv.height=H; const x=cv.getContext('2d'), id=x.createImageData(W,H);
  for(let y=0;y<H;y++) id.data.set(buf.subarray((H-1-y)*W*4,(H-y)*W*4),y*W*4);
  x.putImageData(id,0,0);
  const o=document.createElement('canvas'); o.width=448; o.height=268; const ox=o.getContext('2d'); ox.imageSmoothingQuality='high'; ox.drawImage(cv,0,0,448,268);
  return o.toDataURL('image/jpeg',.9);
}

/* ---- équipement des modules ---- */
const eqOther=(u,c)=>{const o=eqCar(u); return o&&o!==c?o:null;};
function equipMod(c,u,slot){
  const o=eqCar(u); if(o) for(const k in o.mods) if(o.mods[k]===u) delete o.mods[k];
  c.mods=c.mods||{}; c.mods[slot]=u; S.stats.eq=Math.max(S.stats.eq||0,Object.keys(c.mods).length);
}
/* plan : pour chaque emplacement, le meilleur module libre (free) et le meilleur module pris sur une autre voiture (taken) */
function bestPlan(c){
  const free=[], taken=[];
  for(const sl of SLOTS){
    const id=sl[0], cur=c.mods&&modOf(c.mods[id]);
    const cands=S.mods.filter(m=>MODI[m.t][1]===id).sort((a,b)=>modPow(b)-modPow(a)); if(!cands.length) continue;
    const best=cands[0], bf=cands.find(m=>!eqOther(m.u,c));
    if(bf&&(!cur||modPow(bf)>modPow(cur)+1e-9)) free.push([id,bf.u]);
    const bo=eqOther(best.u,c);
    if(bo&&(!cur||modPow(best)>modPow(cur)+1e-9)&&(!bf||modPow(best)>modPow(bf)+1e-9)) taken.push([id,best.u,bo]);
  }
  return {free,taken};
}
const sheetBackToCar=uid=>{ render(); openSheet({t:'car',uid}); };
function eqSheets(X){
  const el=$('sheet');
  if(sheet.t==='eqsteal'){
    const c=car(sheet.uid);
    el.innerHTML=`${X}<h2>Prendre des pièces ?</h2><p class="note">Ces meilleures pièces sont déjà montées sur d’autres voitures. Si tu confirmes, elles seront retirées de ces voitures et montées sur ${M[c.mid].nom}.</p>
      <div class="mods">${sheet.list.map(([sl,u])=>{const m=modOf(u), o=eqCar(u); return m?modHTML(m,`<div class="mod-eq">Retirée de : <b>${M[o.mid].nom}</b></div>`):'';}).join('')}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="car" data-id="${c.uid}">Garder comme ça</button><button class="btn mag" data-a="eqsteal">Les prendre</button></div>`;
    return true;
  }
  if(sheet.t==='eqconf'){
    const c=car(sheet.uid), m=modOf(sheet.u), o=m&&eqCar(m.u), cur=c.mods&&modOf(c.mods[sheet.slot]);
    if(!m||!o){ closeSheet(); return true; }
    el.innerHTML=`${X}<h2>Retirer cette pièce ?</h2><p class="note"><b>${modName(m)}</b> est déjà montée sur <b>${M[o.mid].nom}</b>. Une pièce ne peut équiper qu’une voiture à la fois.</p>
      ${modHTML(m)}<p class="note" style="margin-top:10px">Elle sera retirée de ${M[o.mid].nom} et montée sur ${M[c.mid].nom}${cur?`, à la place de ${modName(cur)}`:''}.</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn alt" data-a="modslot" data-id="${sheet.slot}">Annuler</button><button class="btn mag" data-a="eqok">Confirmer le transfert</button></div>`;
    return true;
  }
  if(sheet.t==='eqcar'){
    el.innerHTML=`${X}<h2>Équiper les meilleures pièces</h2><p class="note">Choisis la voiture. Les meilleurs modules libres de chaque emplacement seront montés. Si une pièce meilleure est sur une autre voiture, je te demande avant de la prendre.</p>
      ${S.cars.map(c=>`<button class="row" data-a="eqbest" data-id="${c.uid}"><span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span><span class="grow"><span class="ttl">${M[c.mid].nom}</span><br><span class="sub">${Object.keys(c.mods||{}).length} / ${SLOTS.length} modules montés</span></span><span class="gain">Équiper</span></button>`).join('')}`;
    return true;
  }
  if(sheet.t==='eqmod'){
    const m=modOf(sheet.u); if(!m){closeSheet(); return true;} const sl=MODI[m.t][1], slN=SLOTS.find(s=>s[0]===sl);
    el.innerHTML=`${X}<h2>Monter sur quelle voiture ?</h2>${modHTML(m)}<p class="note" style="margin-top:8px">Emplacement : ${slN[2]} ${slN[1]}. Le module déjà monté sur la voiture choisie retourne dans ton inventaire.</p>
      ${S.cars.map(c=>{const cu=c.mods&&modOf(c.mods[sl]); return `<button class="row" data-a="eqmod" data-id="${c.uid}"><span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span><span class="grow"><span class="ttl">${M[c.mid].nom}</span><br><span class="sub">${cu?'Actuel : '+modName(cu)+' ('+RAR[cu.r].n+')':'Emplacement vide'}</span></span><span class="gain" style="color:${!cu||modPow(m)>modPow(cu)?'var(--good)':'var(--muted)'}">${!cu||modPow(m)>modPow(cu)?'Mieux':'Moins bon'}</span></button>`;}).join('')}`;
    return true;
  }
  return false;
}

/* ---- paquets 3D ---- */
const PKT={p1:{c1:'#6f7f96',c2:'#2d3850',c3:'#0f1626',emb:'🔧',tag:'STARTER'},p2:{c1:'#46e08a',c2:'#14804a',c3:'#07281a',emb:'⚙️',tag:'ATELIER'},
  p3:{c1:'#59a8ff',c2:'#6a3de0',c3:'#2a0a52',emb:'🏁',tag:'ÉLITE'},p4:{c1:'#ffe27a',c2:'#d98a14',c3:'#4d2400',emb:'👑',tag:'LÉGENDE'}};
const PK={pos:0,tgt:0,drag:null,vel:0,raf:0,shown:-1,busy:false,spin:0};
function pack3d(p,i){
  const th=PKT[p.id]||PKT.p1, pips=[0,1,2].map(k=>RAR[Math.min(6,p.min+k)]).map(r=>`<i style="background:${r.c}"></i>`).join('');
  return `<div class="pk" data-i="${i}" style="--c1:${th.c1};--c2:${th.c2};--c3:${th.c3}">
    <div class="lay l1"></div><div class="lay l2"></div><div class="lay l3"></div>
    <div class="lay fr"><div class="crimp t"></div><div class="crimp b"></div>
      <div class="ct"><span class="tag">${th.tag}</span><span class="emb">${th.emb}</span><div><div class="nm">${p.nom.replace('Paquet ','')}</div><div class="sb">${p.n} modules</div></div><span class="pips">${pips}</span></div><div class="shine"></div></div>
    <div class="lay bk"><div class="crimp t"></div><div class="crimp b"></div><div class="ct"><span class="tag">ROUILLE &amp; GLOIRE</span><span class="emb">🃏</span><span class="sb">${p.d}</span><span class="tag">COLLECTION</span></div></div></div>`;
}
function packsHTML(){
  return `<p class="note">Fais glisser les paquets de gauche à droite. Ils s’achètent avec des crédits ou des jetons 🎟 gagnés en jouant, jamais en argent réel.</p>
    <div class="pk3" id="pk3"><button class="pknav l" data-a="pkgo" data-id="-1" aria-label="Précédent">‹</button><div class="ring" id="pkring">${PACKS.map(pack3d).join('')}</div><div class="fl"></div><button class="pknav r" data-a="pkgo" data-id="1" aria-label="Suivant">›</button></div>
    <div class="dots" id="pkdots">${PACKS.map(()=>'<i></i>').join('')}</div><div class="pkInfo" id="pkInfo"></div>
    <button class="btn alt sm" data-a="rates" style="margin-top:12px">Voir les taux de tirage et les garanties</button>`;
}
function pkInfo(force){
  const el=$('pkInfo'); if(!el) return; const i=clamp(Math.round(PK.drag?PK.pos:PK.tgt),0,PACKS.length-1);
  if(!force&&PK.shown===i) return; PK.shown=i; const p=PACKS[i];
  el.innerHTML=`<div class="t"><b>${p.nom}</b><span>${p.n} modules</span></div><p class="note" style="margin:0">${p.d}</p>
    <div class="buy"><button class="btn" data-a="pack" data-id="${p.id}" data-k="cr" ${S.cr<p.cr?'disabled':''}>Ouvrir, ${cr(p.cr)}</button><button class="btn alt" data-a="pack" data-id="${p.id}" data-k="tok" ${S.tok<p.tok?'disabled':''}>${p.tok} 🎟</button></div>`;
  const dots=$('pkdots'); if(dots) [...dots.children].forEach((d,k)=>d.classList.toggle('on',k===i));
}
function pkLayout(time){
  const ring=$('pkring'); if(!ring){PK.raf=0; return false;}
  if(!PK.drag){ const d=PK.tgt-PK.pos; PK.pos+=d*.15; if(Math.abs(d)<.003) PK.pos=PK.tgt; }
  const spinK=PK.spin?Math.max(0,1-(time-PK.spin)/800):0; if(!spinK) PK.spin=0;
  [...ring.children].forEach(el=>{
    const i=+el.dataset.i, o=i-PK.pos, ao=Math.abs(o), sg=o<0?-1:1;
    const x=sg*(Math.min(ao,1)*108+Math.max(0,ao-1)*70), z=-Math.min(ao,2.2)*160;
    let ry=-Math.max(-1.5,Math.min(1.5,o))*44; if(ao<.5) ry+=Math.sin(time/820+i)*5*(1-ao*2);
    if(ao<.5&&spinK) ry+=360*(1-Math.pow(1-spinK,3))*-1+360;
    el.style.transform=`translate3d(${x.toFixed(1)}px,${(-ao*5).toFixed(1)}px,${z.toFixed(1)}px) rotateY(${ry.toFixed(1)}deg) scale(${(1-.06*Math.min(ao,2)).toFixed(3)})`;
    el.style.opacity=ao>2.6?0:(1-.16*Math.min(ao,2.4)).toFixed(2); el.style.zIndex=String(20-Math.round(ao*3));
    el.style.setProperty('--sx',(-30+ry*1.1+Math.sin(time/1300+i)*30).toFixed(0)+'%'); el.classList.toggle('sel',ao<.5);
  });
  pkInfo(); return true;
}
function pkLoop(t){ PK.raf=pkLayout(t)?requestAnimationFrame(pkLoop):0; }
function bindPacks(){
  const st=$('pk3'); if(!st||cTab!=='packs'){PK.raf=0; return;}
  PK.shown=-1; pkLayout(performance.now()); pkInfo(true);
  st.addEventListener('pointerdown',e=>{
    if(e.target.closest('.pknav')) return;
    PK.drag={x:e.clientX,p:PK.pos,moved:0,lx:e.clientX,lt:e.timeStamp,tg:e.target}; PK.vel=0; try{st.setPointerCapture(e.pointerId);}catch(_){}
  });
  st.addEventListener('pointermove',e=>{
    const d=PK.drag; if(!d) return; const dx=e.clientX-d.x; d.moved=Math.max(d.moved,Math.abs(dx));
    PK.pos=clamp(d.p-dx/108,-.3,PACKS.length-.7); const dt=e.timeStamp-d.lt; if(dt>0){PK.vel=PK.vel*.6+((e.clientX-d.lx)/dt)*.4; d.lx=e.clientX; d.lt=e.timeStamp;}
  });
  const up=e=>{
    const d=PK.drag; if(!d) return; PK.drag=null;
    if(d.moved<6){ const pe=d.tg&&d.tg.closest&&d.tg.closest('.pk'); if(pe){const i=+pe.dataset.i; if(i===Math.round(PK.tgt)) PK.spin=performance.now(); else PK.tgt=i;} else PK.tgt=Math.round(PK.pos); return; }
    PK.tgt=clamp(Math.round(PK.pos-PK.vel*170/108),0,PACKS.length-1); auTry(()=>ui('click'));
  };
  st.addEventListener('pointerup',up); st.addEventListener('pointercancel',up);
  if(!PK.raf) PK.raf=requestAnimationFrame(pkLoop);
}
function auRip(i){
  if(!AU.ok) return; const t=AU.ctx.currentTime+.01, d=AU.b.jing;
  burst(t,.5,1800,.8,'bandpass',.5,d,true); burst(t+.08,.4,5200,.6,'highpass',.4,d);
  for(let k=0;k<12;k++) osc('square',1400+Math.random()*1800,t+.04*k,.01,d,.04,.001,.05);
  osc('sine',60,t+.35,.3,d,.5,.004,.4); osc('sawtooth',220*(1+i*.25),t+.4,.35,d,.07,.01,.5); burst(t+.45,.9,3200,.5,'highpass',.25,d,true);
}

/* ---- effets de course : flashs, lignes de vitesse, rampe de régime ---- */
const FXL='<div class="fxl" id="fxl"><div class="fl" id="fxF"></div><div class="sl" id="fxS"></div><div class="rev" id="fxR">'+'<i></i>'.repeat(16)+'</div></div>';
const WHEEL=`<svg viewBox="-60 -60 120 120" aria-hidden="true"><defs><linearGradient id="wg" x1="0" y1="-1" x2="0" y2="1"><stop offset="0" stop-color="#6a6f98"/><stop offset=".5" stop-color="#2a2e52"/><stop offset="1" stop-color="#0c0d20"/></linearGradient></defs>
<circle r="51" fill="none" stroke="url(#wg)" stroke-width="14"/><circle r="57.6" fill="none" stroke="#00E5FF" stroke-opacity=".5" stroke-width="1.4"/><circle r="44" fill="none" stroke="#000" stroke-opacity=".55" stroke-width="1.2"/>
<path d="M-44 -22 A50 50 0 0 1 -14 -47" fill="none" stroke="#fff" stroke-opacity=".2" stroke-width="3.5" stroke-linecap="round"/>
<path d="M-5 -59 L5 -59 L3.4 -43 L-3.4 -43 Z" fill="#FCEE0A"/>
<path d="M-45 5 Q-24 -3 -9 7 L-9 17 Q-25 11 -44 18 Z" fill="url(#wg)" stroke="#00E5FF" stroke-opacity=".4"/>
<path d="M45 5 Q24 -3 9 7 L9 17 Q25 11 44 18 Z" fill="url(#wg)" stroke="#00E5FF" stroke-opacity=".4"/>
<path d="M-9 14 L9 14 L12 44 L-12 44 Z" fill="url(#wg)" stroke="#00E5FF" stroke-opacity=".4"/>
<circle r="15" fill="#10122a" stroke="#00E5FF" stroke-width="2"/><circle r="6.5" fill="#FF2BD6"/><circle r="2.2" fill="#fff" fill-opacity=".8" cx="-2" cy="-2"/></svg>`;
function fxFlash(kind){ const f=$('fxF'); if(!f) return; f.className='fl'; void f.offsetWidth; f.className='fl '+kind; }
function fxUpdate(P,Rc){
  const vTop=Math.max(10,(P.r?P.r.VM:P.VM)||60), frac=clamp(P.v/vTop,0,1), nit=P.nitroT>0;
  const s=$('fxS'); if(s){ const f=clamp((P.v*3.6-80)/190,0,1)+(nit?.5:0), on=f>.12, o=(Math.min(1,f)*.9).toFixed(2); if(s._on!==on){s._on=on; s.classList.toggle('on',on);} if(s._o!==o){s._o=o; s.style.opacity=o;} }
  const r=$('fxR'); if(r){ const n=Math.round(frac*16); if(r._n!==n){ r._n=n; [...r.children].forEach((e,k)=>{ e.className=k<n?'on '+(k>=13?'r':k>=9?'y':''):''; }); } }
  if(Rc&&Rc.clock>3&&Rc.pos){ if(Rc.lastPos!=null){ if(Rc.pos<Rc.lastPos) auTry(auWhoosh); else if(Rc.pos>Rc.lastPos) auTry(auDown); } Rc.lastPos=Rc.pos; }
}
