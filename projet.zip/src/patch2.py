import re
s=open('main_v08.js',encoding='utf-8').read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a); assert n==cnt,(n,cnt,a[:70]); s=s.replace(a,b)
def cut(start,end,new=''):
    global s
    i=s.index(start); j=s.index(end,i); s=s[:i]+new+s[j:]

# --- cartes 3D
rep('<div class="card-art">${carSVG(m,c.etat)}</div>','<div class="card-art">${thArt(c)}</div>')
rep('<span style="width:84px;flex:none;--t:${TIERS[M[c.mid].t].c}">${carSVG(M[c.mid],c.etat)}</span>','<span class="throw" style="--t:${TIERS[M[c.mid].t].c}">${thArt(c)}</span>',2)
rep('<div style="max-width:340px;margin:4px auto 0;--t:${t.c}">${carSVG(m,c.etat)}</div>','<div class="thhero" style="--t:${t.c}">${thArt(c)}<button data-a="view3d">Voir en 3D ⟳</button></div>')
rep('<button class="btn alt wide" style="margin-top:12px" data-a="view3d">Voir en 3D</button>','')
rep('<p class="note">Les cartes de modules s’obtiennent dans l’onglet Cartes. Elles changent les stats et l’apparence.</p>',
    '<p class="note">Les cartes de modules s’obtiennent dans l’onglet Cartes. Elles changent les stats et l’apparence.</p><div class="eqbar"><button class="btn good sm" data-a="eqbest">⚡ Équiper les meilleures</button><button class="btn alt sm" data-a="eqnone" ${Object.keys(c.mods||{}).length?\'\':\'disabled\'}>Tout retirer</button></div>')
# --- render
rep("  renderSheet();\n  if(racing) bindRace();","  if(view!==lastView){lastView=view; const vv=$('view'); vv.classList.remove('enter'); void vv.offsetWidth; if(!racing) vv.classList.add('enter');}\n  renderSheet();\n  if(view==='cartes') bindPacks();\n  if(racing) bindRace();")
rep("const claimable=MISSIONS.some(m=>!S.claimed[m.id]&&m.p(S)[0]>=m.p(S)[1]);","const claimable=MISSIONS.some(m=>!S.claimed[m.id]&&m.p(S)[0]>=m.p(S)[1])||questReady();")
# --- paquets
i=s.index("body=`<p class=\"note\">Les paquets s’achètent"); e=s.index("Voir les taux de tirage et les garanties</button>`;",i)+len("Voir les taux de tirage et les garanties</button>`;")
s=s[:i]+"body=packsHTML();"+s[e:]
rep('modHTML(m,eqCar(m.u)?\'\':`<button class="btn alt sm" data-a="recycle" data-id="${m.u}">Recycler, +${RAR[m.r].sc*(m.sh?3:1)} ♻️</button>`)',
    'modHTML(m,eqCar(m.u)?\'\':`<button class="btn sm" data-a="eqmodopen" data-id="${m.u}">Monter sur…</button><button class="btn alt sm" data-a="recycle" data-id="${m.u}">Recycler, +${Math.round(RAR[m.r].sc*(m.sh?3:1)*scrapK())} ♻️</button>`)')
rep("function sheetExtra(X){\n  const el=$('sheet');","function sheetExtra(X){\n  const el=$('sheet');\n  if(eqSheets(X)) return true;")
rep('modHTML(m,`<button class="btn sm" data-a="modeq" data-id="${m.u}">Monter</button>`)','modHTML(m,eqOther(m.u,c)?`<button class="btn sm mag" data-a="modeq" data-id="${m.u}">Reprendre</button>`:`<button class="btn sm" data-a="modeq" data-id="${m.u}">Monter</button>`)')
rep('<button class="btn alt" data-a="close">Fermer</button><button class="btn" data-a="pack" data-id="${pk.id}" data-k="cr" ${S.cr<pk.cr?\'disabled\':\'\'}>Encore un, ${cr(pk.cr)}</button></div>',
    '<button class="btn alt" data-a="close">Fermer</button><button class="btn" data-a="pack" data-id="${pk.id}" data-k="cr" ${S.cr<pk.cr?\'disabled\':\'\'}>Encore un, ${cr(pk.cr)}</button></div><button class="btn good wide" style="margin-top:8px" data-a="eqcaropen">⚡ Équiper les meilleures pièces sur une voiture</button>')
rep("const r=sheet.r||0, cost=RAR[r].sc*6;\n    el.innerHTML","const r=sheet.r||0, cost=craftCost(r);\n    el.innerHTML")
rep("${x.sc*6} ♻️","${craftCost(i)} ♻️")
rep("if(S.mods.length+pk.n>INV_MAX)","if(S.mods.length+pk.n>invMax())")
# --- actions
old=[l for l in s.split('\n') if l.startswith('  modeq(d){')][0]
s=s.replace(old,"  modeq(d){const c=car(sheet.uid), u=+d.id; if(!c||!modOf(u)) return; if(eqOther(u,c)) return openSheet({t:'eqconf',uid:c.uid,slot:sheet.slot,u}); equipMod(c,u,sheet.slot); save(); sheetBackToCar(c.uid);},")
rep("  pack(d){openPack(d.id,d.k);},",
"""  pack(d){ const pk=PACKS.find(p=>p.id===d.id); if(!pk) return; const i=PACKS.indexOf(pk), ok=(d.k==='tok'?S.tok>=pk.tok:S.cr>=pk.cr)&&S.mods.length+pk.n<=invMax(), st=$('pk3');
    if(ok&&st&&!sheet&&!PK.busy){ PK.busy=true; st.classList.add('burst'); const e=st.querySelector('.pk[data-i="'+i+'"]'); if(e) e.classList.add('burst'); auTry(()=>auRip(i)); setTimeout(()=>{PK.busy=false; openPack(d.id,d.k);},680); return; }
    openPack(d.id,d.k); },""")
rep("  view3d(){openViewer(sheet.uid);},","""  view3d(){openViewer(sheet.uid);},
  eqbest(d){ const c=car(+(d.id||(sheet&&sheet.uid))); if(!c) return; const pl=bestPlan(c);
    pl.free.forEach(([sl,u])=>equipMod(c,u,sl)); save();
    if(pl.taken.length){ render(); openSheet({t:'eqsteal',uid:c.uid,list:pl.taken.map(x=>[x[0],x[1]])}); return; }
    toast(pl.free.length?`${pl.free.length} pièce${pl.free.length>1?'s':''} montée${pl.free.length>1?'s':''}`:'Tu as déjà les meilleures pièces disponibles'); sheetBackToCar(c.uid); },
  eqsteal(){ const c=car(sheet.uid); let n=0; sheet.list.forEach(([sl,u])=>{ if(modOf(u)){ equipMod(c,u,sl); n++; } }); toast(`${n} pièce${n>1?'s':''} reprise${n>1?'s':''}`); save(); sheetBackToCar(c.uid); },
  eqok(){ const c=car(sheet.uid), m=modOf(sheet.u); if(!c||!m) return; const o=eqCar(m.u); equipMod(c,m.u,sheet.slot); toast(`${modName(m)} déplacée${o?' depuis '+M[o.mid].nom:''}`); save(); sheetBackToCar(c.uid); },
  eqnone(){ const c=car(sheet.uid); if(!c) return; c.mods={}; toast('Modules retirés'); save(); sheetBackToCar(c.uid); },
  eqcaropen(){ openSheet({t:'eqcar'}); },
  eqmodopen(d){ openSheet({t:'eqmod',u:+d.id}); },
  eqmod(d){ const m=modOf(sheet.u), c=car(+d.id); if(!m||!c||eqCar(m.u)) return; equipMod(c,m.u,MODI[m.t][1]); toast(`${modName(m)} montée sur ${M[c.mid].nom}`); closeSheet(); save(); render(); },
  pkgo(d){ PK.tgt=clamp(Math.round(PK.tgt)+(+d.id),0,PACKS.length-1); },
  mtab(d){ mTab=d.id; render(); },
  shopbuy(d){ const it=S.shop&&S.shop.items[+d.id]; if(!it||S.cr<it.p) return; if(S.mods.length>=invMax()) return toast('Inventaire plein : recycle ou fusionne des modules');
    S.cr-=it.p; const m=Object.assign({},it.m,{u:S.muid++}); S.mods.push(m); S.alb[m.t]=(S.alb[m.t]||0)|(1<<m.r); S.stats.best=Math.max(S.stats.best||0,m.r); S.shop.items.splice(+d.id,1); bump('shopN'); toast(`${modName(m)} ajouté à ton inventaire`); save(); render(); },
  shoproll(){ if(S.cr<400) return; S.cr-=400; shopRoll(); save(); render(); },
  fleetrep(){ const fr=fleetRepair(); if(S.cr<fr||!fr) return; S.cr-=fr; S.cars.forEach(c=>{c.etat=100;}); bump('repN'); toast('Garage remis à neuf'); save(); render(); },
  insure(){ if(S.cr<900) return; S.cr-=900; S.ins=3; toast('Entretien préventif actif sur 3 épreuves'); save(); render(); },
  coach(){ if(S.cr<1200) return; S.cr-=1200; S.xpb=3; toast('Coach actif sur 3 épreuves'); save(); render(); },
  sellmods(){ const k=S.mods.filter(m=>m.r<=1&&!m.sh&&m.un==null&&!eqCar(m.u)); if(!k.length) return; const v=k.reduce((t,m)=>t+(m.r?60:20),0); S.cr+=v; S.mods=S.mods.filter(m=>!k.includes(m)); bump('recyN',k.length); toast(`${k.length} modules vendus, +${fmt(v)} cr`); save(); render(); },
  qclaim(d){ const box=S[d.k], q=(d.k==='dq'?DQ:WQ).find(x=>x.id===d.id); if(!box||!q||box.cl[q.id]||qProg(box,q)<q.n) return; box.cl[q.id]=1; giveG(qRew(q)); toast('Récompense récupérée'); save(); render(); },""")
rep("  buynitro(){if(S.cr<NITRO_PRIX) return; S.cr-=NITRO_PRIX; S.nitro++; save(); render();},","  buynitro(d){const q=+(d.id||1), p={1:NITRO_PRIX,5:650,12:1500}[q]; if(!p||S.cr<p) return; S.cr-=p; S.nitro+=q; save(); render();},")
# stats dans les actions
rep("S.scrap+=RAR[m.r].sc*(m.sh?3:1); S.mods=S.mods.filter(x=>x!==m);","S.scrap+=Math.round(RAR[m.r].sc*(m.sh?3:1)*scrapK()); bump('recyN'); S.mods=S.mods.filter(x=>x!==m);")
rep("S.scrap+=k.length; S.mods=S.mods.filter(m=>!k.includes(m));","S.scrap+=Math.round(k.length*scrapK()); bump('recyN',k.length); S.mods=S.mods.filter(m=>!k.includes(m));")
rep("const m=newMod(r+1,null,true); S.mods.push(m); save();","const m=newMod(r+1,null,true); S.mods.push(m); bump('fuseN'); save();")
rep("const r=sheet.r||0, cost=RAR[r].sc*6; if(S.scrap<cost||S.mods.length>=INV_MAX) return;","const r=sheet.r||0, cost=craftCost(r); if(S.scrap<cost||S.mods.length>=invMax()) return;")
rep("S.cr-=Math.ceil(pts*u); c.etat+=pts;","S.cr-=Math.ceil(pts*u); c.etat+=pts; bump('repN');")
rep("S.cr+=p; S.cars=S.cars.filter(x=>x.uid!==c.uid);","S.cr+=p; bump('sellN'); S.cars=S.cars.filter(x=>x.uid!==c.uid);")
# --- modèles / miniatures
rep("modelsBusy=false; GG.sig=null; if(view==='garage') render();","modelsBusy=false; GG.sig=null; if(view==='garage') render(); thPump();")
# --- commandes arcade
rep("const zup=()=>{RC.inp.st=0;};","const zup=()=>{RC.inp.st=0; zn.classList.add('rel');};")
rep("zn.addEventListener('pointerdown',e=>{e.preventDefault(); try{zn.setPointerCapture(e.pointerId);}catch(_){} setSt(e);});","zn.addEventListener('pointerdown',e=>{e.preventDefault(); zn.classList.remove('rel'); try{zn.setPointerCapture(e.pointerId);}catch(_){} setSt(e);});")
rep("kn.style.transform=`translateX(${x}px)`;","kn.style.transform=`rotate(${(x*2.6).toFixed(0)}deg)`;")
def blk(start,newm):
    global s
    i=s.index(start); e=s.index('    </div>\n    <div id="over" hidden></div>',i)+len('    </div>')
    s=s[:i]+newm+s[e:]
blk('<div class="padS">','''<div class="padS">
      <div id="steerZone" class="steer ${auto?'off':''}"><div id="steerKnob" class="wheel">${WHEEL}</div><div class="lab">${auto?'Pilote auto':'Volant'}</div></div>
      <button id="pBrk" class="pedal brk" ${auto?'disabled':''}><span>${auto?'Auto':'Frein'}</span></button>
      <button id="pNit" class="pedal nit">Nitro<small>×${S.nitro}</small></button>
      <button id="pGas" class="pedal gas" ${auto?'disabled':''}><i id="gasPed"></i><span>${auto?'Auto':'Gaz'}</span></button>
    </div>''')
blk('<div class="pad3">','''<div class="pad3">
      <button id="pBrk" class="pedal brk" ${auto?'disabled':''}><span>${auto?'Auto':'Frein'}</span><small>${auto?'le pilote gère':'maintiens'}</small></button>
      <button id="pNit" class="pedal nit">Nitro<small>×${S.nitro}</small></button>
      <button id="pGas" class="pedal gas" ${auto?'disabled':''}><i id="gasPed"></i><span>${auto?'Auto':'Gaz'}<small>${auto?'le pilote gère':'glisse vers le bas pour doser'}</small></span></button>
    </div>''')
rep('<i id="nitFill"></i></div></div></div></div></div></div>','<i id="nitFill"></i></div></div></div></div></div>${FXL}</div>',2)
nf="const nf=$('nitFill'); if(nf) nf.style.width=Math.round(clamp(P.nitroT/NITRO_DUREE,0,1)*100)+'%';"
rep(nf,nf+" fxUpdate(P,RC);",2)
rep("const b=$('pNit'); if(b){const sm=b.querySelector('small'); if(sm) sm.textContent='⚡ '+S.nitro;}","const b=$('pNit'); if(b){const sm=b.querySelector('small'); if(sm) sm.textContent='×'+S.nitro;}")
rep("S.nitro--; P.nit++;","S.nitro--; bump('nitroN'); fxFlash('nit'); P.nit++;")
# --- sons
rep("if(!R_.green){R_.green=true; ui('green');} return;","if(!R_.green){R_.green=true; ui('green'); fxFlash('go'); auTry(auLaunch);} return;")
rep("function flash(txt,col,dur){if(RC) RC.flash=","function flash(txt,col,dur){if(txt==='Départ parfait') auTry(auDing); if(RC) RC.flash=")
rep("function auFinish(won){ if(!AU.ok) return; ui(won?'claim':'error'); }","function auFinish(won){ if(!AU.ok) return; ui(won?'claim':'error'); auTry(()=>auHorn(won)); }")
rep("stinger: {arp:[],oct:1,wave:'sine',av:0,pv:.05,filt:2000,hat:false,pulse:false}};","stinger: {arp:[],oct:1,wave:'sine',av:0,pv:.05,filt:2000,hat:false,pulse:false},\n drag:    {arp:[],oct:1,wave:'sine',av:0,pv:.09,filt:19000,hat:false,pulse:false}};")
rep("auTry(()=>schedStep(q.step,q.next)); q.next+=STEP; q.step++;","auTry(()=>schedStep(q.step,q.next)); q.next+=(q.mood==='drag'?dragSD():STEP); q.step++;")
rep("if(q.mood!=='race') return 0;","if(q.mood!=='race'&&q.mood!=='drag') return 0;")
rep("dropStep(step-q.dropFrom,s,t,ch); return; }","dropStep(step-q.dropFrom,s,t,ch); return; }\n  if(q.mood==='drag'){ dragSched(s,bar,t,ch); return; }")
rep("ln:-1,green:false};","ln:-1,green:false,drag:!!o.drag};")
rep("AU.raceLevel=0; AU.seq.cur=0;","AU.raceLevel=0; AU.dsm=0; AU.dkey=1; AU.speedFrac=0; AU.seq.cur=0;")
rep("else auMood(R_.fin?'stinger':'race');","else auMood(R_.fin?'stinger':(R_.drag?'drag':'race'));")
rep("const cur=AU.raceLevel; let L=cur;\n  const up=[.1,.4,.7], dn=[.06,.33,.6];","const cur=AU.raceLevel; let L=cur; AU.speedFrac=frac;\n  const dg=AU.race&&AU.race.drag, up=dg?[.08,.28,.5]:[.1,.4,.7], dn=dg?[.05,.22,.42]:[.06,.33,.6];")
rep("auRaceStart({pm:P.m,oms:Os.map(o=>o.m),rain:mn.m==='pluie',siren:P.m.glb==='patrouille'});","auRaceStart({pm:P.m,oms:Os.map(o=>o.m),rain:mn.m==='pluie',siren:P.m.glb==='patrouille',drag:mn.d==='drag'});")
# --- lumières du drag
rep("  /* voitures */\n  const pc=buildCar(Pm.m,'#00E5FF'","""  let strobe=null;
  if(mn.d==='drag'){ strobe=new THREE.MeshBasicMaterial({color:0x00e5ff}); const pts=[]; for(let s=0;s<tk.L+60;s+=14) for(const sd of [1,-1]) pts.push(pathAt(Pa,s,sd*6.7));
    const sm=new THREE.InstancedMesh(new THREE.BoxGeometry(.5,1.4,.5),strobe,pts.length); pts.forEach((p,i)=>{dm.rotation.set(0,-p.th,0); dm.scale.set(1,1,1); dm.position.set(p.x,.7,p.z); dm.updateMatrix(); sm.setMatrixAt(i,dm.matrix);}); sc.add(sm); }
  /* voitures */
  const pc=buildCar(Pm.m,'#00E5FF'""")
rep("return {scene:sc,cam,path:Pa,pc,oc,ocs,sky,sun,ground,fov:62,weather:mkWeather(me,sc)};","return {scene:sc,cam,path:Pa,pc,oc,ocs,sky,sun,ground,strobe,fov:62,weather:mkWeather(me,sc)};")
rep("  if(RS.weather) updWeather(RS.weather,cam.position.x,cam.position.y,cam.position.z,Math.cos(cp.th),Math.sin(cp.th),dt,P.v);\n}","  if(RS.strobe) RS.strobe.color.setHSL((time*1.6)%1,1,.35+.3*Math.abs(Math.sin(P.x*.05+time*6)));\n  if(RS.weather) updWeather(RS.weather,cam.position.x,cam.position.y,cam.position.z,Math.cos(cp.th),Math.sin(cp.th),dt,P.v);\n}")
# --- économie
rep("bat:{atelier:1,casse:1,bureau:0,concession:0},","bat:{atelier:1,casse:1,bureau:0,concession:0,banc:0,entrepot:0,simu:0},")
rep("  applyMods(s,c);\n","  applyMods(s,c); if(S.bat.banc&&c.uid>0){s.ch*=1+.02*S.bat.banc; s.nm*=1+.02*S.bat.banc;}\n")
rep("Math.round(.33*Math.pow(M[c.mid].val,.8)*Math.pow(l+1,1.6)/10)*10","Math.round(ECO.up*.33*Math.pow(M[c.mid].val,.8)*Math.pow(l+1,1.6)/10)*10")
rep("Math.max(1,.013*Math.pow(M[c.mid].val,.8)*(1-.1*(S.bat.atelier-1)))","Math.max(1,ECO.rep*.013*Math.pow(M[c.mid].val,.8)*(1-.1*(S.bat.atelier-1)))")
rep("const gain=Math.round(ev.gain*(1+.1*S.bat.bureau)","const gain=Math.round(ev.gain*ECO.gain*(1+.1*S.bat.bureau)")
rep("xp=Math.round(ev.xp*(.3+.7*pay)*(1+rows","xp=Math.round(ev.xp*(.3+.7*pay)*(S.xpb>0?1.5:1)*(1+.1*(S.bat.simu||0))*(1+rows")
rep("S.cr+=gain; S.tok+=tok; S.stats.races++;","S.cr+=gain; S.tok+=tok; S.stats.races++; bump('earned',gain); if(S.xpb>0) S.xpb--; if(S.ins>0) S.ins--; rows.forEach(x=>{if(x.won) bump('w_'+x.d);});")
rep("c.etat=Math.max(5,c.etat-rint(2,5)-P.slides-(P.panned?8:0));","c.etat=Math.max(5,c.etat-Math.round((rint(2,5)+P.slides+(P.panned?8:0))*wearK()));")
rep("c.etat=Math.max(5,c.etat-rint(1,3)-Math.round(P.dmg*10));","c.etat=Math.max(5,c.etat-Math.round((rint(1,3)+Math.round(P.dmg*10))*wearK()));")
# equipMod compte
# --- retirer anciennes vues et insérer le nouveau code
cut("function vMarche(){","function vBase(){")
cut("function vMissions(){","/* --- fiches --- */")
n1=open('new1.js',encoding='utf-8').read().replace("c.mods[slot]=u; S.stats.eq=","c.mods[slot]=u; bump('eqN'); S.stats.eq=")
n2=open('new2.js',encoding='utf-8').read()
rep("setInterval(updPod,4000);",n1+n2+"\nsetInterval(updPod,4000);")
s=s.replace("ROUILLE & GLOIRE — démo v0.3","ROUILLE & GLOIRE — démo v0.9")
open('main.js','w',encoding='utf-8').write(s)
print('ok',len(s))
